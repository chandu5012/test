@echo off
echo ============================================
echo   Data-DNA — Auto Setup and Start
echo ============================================
echo.

REM Get the directory where this bat file lives
set PROJECT_DIR=%~dp0
set BACKEND_DIR=%PROJECT_DIR%backend
set FRONTEND_DIR=%PROJECT_DIR%frontend

echo Project folder: %PROJECT_DIR%
echo.

REM ── Step 1: Setup database ──────────────────
echo [1/4] Setting up database...
cd /d "%BACKEND_DIR%"
python setup_db.py
if errorlevel 1 (
    echo ERROR: Python not found. Install from python.org
    pause
    exit /b 1
)
echo.

REM ── Step 2: Create/activate venv ────────────
echo [2/4] Setting up Python environment...
if not exist "%BACKEND_DIR%\venv" (
    echo Creating virtual environment...
    python -m venv venv
)
call "%BACKEND_DIR%\venv\Scripts\activate.bat"
echo Installing dependencies...
pip install -r requirements.txt -q
echo.

REM ── Step 3: Install frontend deps ───────────
echo [3/4] Setting up frontend...
cd /d "%FRONTEND_DIR%"
if not exist "%FRONTEND_DIR%\node_modules" (
    echo Installing Node packages (first time only)...
    npm install
)
echo.

REM ── Step 4: Start both servers ──────────────
echo [4/4] Starting servers...
echo.
echo Starting backend on http://localhost:8000
start "Data-DNA Backend" cmd /k "cd /d "%BACKEND_DIR%" && call venv\Scripts\activate.bat && uvicorn app.main:app --reload --port 8000"

timeout /t 4 /nobreak > nul

echo Starting frontend on http://localhost:3000
start "Data-DNA Frontend" cmd /k "cd /d "%FRONTEND_DIR%" && npm run dev"

timeout /t 5 /nobreak > nul

echo.
echo ============================================
echo   Opening browser...
echo ============================================
start http://localhost:3000

echo.
echo Both servers are running in separate windows.
echo Close those windows to stop the servers.
pause
