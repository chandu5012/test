# 🧬 Data-DNA v2 — AI-Powered Credit Data Lineage Platform

> Production-ready · Multi-AI provider · Persistent storage · Real DB connect

## Quick Start (Windows)

### Terminal 1 — Backend
```cmd
cd backend
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```

### Terminal 2 — Frontend
```cmd
cd frontend
npm install
npm run dev
```

Open **http://localhost:3000**

---

## Features

| Feature | Description |
|---------|-------------|
| ⬡ Graph | Interactive D3 force graph, authoritative + inferred edges |
| ⇢ Timeline | Left-to-right lineage flow view for stakeholders |
| ▦ Dashboard | Completeness score, PII inventory, orphan field gaps |
| ⌕ Search | Natural language field search (TF-IDF) |
| ⚡ Impact | Downstream impact analysis with risk level |
| ⊕ Audit | Full provenance chain + PDF export |
| ◎ Chat | Conversational AI assistant powered by your chosen provider |
| ↑ Ingest | SQL DDL/DML or JSON schema ingestion |
| ⟳ DB Connect | Auto-crawl SQLite / PostgreSQL / MySQL / SQL Server |
| ⚙ Settings | Choose AI provider: Claude, GPT, Gemini, GitHub Copilot, Ollama |

## AI Providers

Configure in **Settings tab** — no restart needed:

| Provider | Key URL |
|----------|---------|
| Anthropic Claude | console.anthropic.com |
| OpenAI GPT | platform.openai.com/api-keys |
| Google Gemini | aistudio.google.com |
| GitHub Copilot | github.com/settings/tokens |
| Ollama (free/local) | ollama.com/download |

## Docker (one command)
```bash
docker-compose up
```

## Run Tests
```cmd
cd backend
pytest tests/ -v --cov=app
```

## Python 3.10 users
Change in requirements.txt:
- `numpy==1.26.4` → `numpy==1.24.4`
- `scikit-learn==1.4.2` → `scikit-learn==1.3.2`
