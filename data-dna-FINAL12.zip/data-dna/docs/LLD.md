# Data-DNA — Low Level Design

## 1. Data Models

### FieldNode
```
id          = "{system}.{table}.{column}"  # globally unique
system      = source system name
table       = table / entity name
column      = column / field name (uppercase)
data_type   = VARCHAR / INT / DECIMAL / DATE / etc.
description = human-readable field purpose
tags        = ["credit", "pii", "risk"] etc.
pii         = boolean — triggers PII warnings in audit/impact
created_at  = epoch timestamp
```

### LineageEdge
```
id                   = UUID
source_field         = FieldNode.id
target_field         = FieldNode.id
transformation_type  = direct | derived | joined | aggregated | filtered | renamed
transformation_logic = SQL snippet or natural language description
source_type          = authoritative | inferred   ← CRITICAL separation
confidence           = float 0.0–1.0 (always 1.0 for authoritative)
reasoning            = AI explanation (inferred edges only)
system_boundary      = True if crosses system boundary
metadata             = { superseded_by_authoritative: bool, ... }
```

## 2. Graph Store — LineageGraph

```
_graph: nx.DiGraph          # NetworkX directed graph
  nodes: field_id → attrs   # fast O(1) lookup
  edges: (src, tgt) → edge_id
_nodes: dict[str, FieldNode]
_edges: dict[str, LineageEdge]
_df: dict[str, int]         # document frequency for TF-IDF
```

### Key Operations
| Method | Complexity | Description |
|--------|-----------|-------------|
| add_field | O(1) | Idempotent upsert |
| add_lineage | O(1) | Validates nodes, flags superseded inferred edges |
| get_lineage | O(V+E) | DFS/BFS with depth limit |
| get_impact | O(V+E) | nx.descendants (BFS) |
| get_audit | O(V+E) | Full upstream DFS + conflict detection |
| export_for_visualization | O(V+E) | D3 node/link format |

### Invariant: Authoritative Supremacy
```python
if existing_edge.source_type == AUTHORITATIVE:
    if new_edge.source_type == INFERRED:
        new_edge.metadata["superseded_by_authoritative"] = True
```

## 3. SQL Parser — Regex Pipeline

Parses 3 SQL patterns:
1. `CREATE TABLE` → FieldNodes (column definitions)
2. `INSERT INTO … SELECT … FROM` → FieldNodes + LineageEdges
3. `CREATE VIEW/TABLE AS SELECT` → FieldNodes + LineageEdges

PII detection on column names:
```
pii_patterns = [ssn, social, dob, birth, email, phone, address,
                name, pan, aadhaar, passport, license, credit_card]
```

## 4. AI Modules

### NL Search — TF-IDF
```
Field text = column + table + system + description + tags + data_type
Tokenize → remove stopwords → compute TF
IDF = log((N+1) / (df[t]+1)) + 1    # smoothed IDF
Score = Σ TF[t] × IDF[t]            # for query tokens present
Boost ×1.5 for exact column name match
```

### Semantic Resolver — Claude
```
Input:  List[FieldNode] across systems
Prompt: ask Claude to group fields by logical concept
Output: List[AliasGroup] { canonical_name, aliases, systems, confidence, reasoning }
Fallback: normalize abbreviations (cust→customer, acct→account, etc.)
```

### Lineage Discoverer — Claude
```
Input:  source fields + target fields + context description
Prompt: identify probable source→target lineage relationships
Output: List[LineageEdge] tagged INFERRED with confidence + reasoning
Fallback: match by normalized column name similarity
Min confidence threshold: 0.5 (conservative to avoid false audit trails)
```

## 5. API Design

### REST Endpoints
```
POST /lineage/ingest          body: { system_name, sql?, schema_json? }
GET  /lineage/fields          ?system=
GET  /lineage/field/{id}
GET  /lineage/path/{id}       ?hops=3&direction=both&include_inferred=true
GET  /lineage/graph           → D3 { nodes, links }
GET  /lineage/stats

POST /search/                 body: { query, top_k, system_filter? }
GET  /search/aliases          ?system=

GET  /impact/{field_id}
GET  /audit/{field_id}
POST /audit/infer             ?source_system=&target_system=
```

### Error Handling
- 404: Field not found
- 422: Validation error (Pydantic)
- 500: Internal — logged with structlog

## 6. Frontend Architecture

```
App.jsx
├── Header (tabs, toggle, connection status)
├── Stats bar (live graph metrics)
└── Tab views:
    ├── Graph tab
    │   ├── LineageGraph (D3 force simulation)
    │   └── Right sidebar
    │       ├── NodeDetail (field info + action buttons)
    │       └── AuditTrail (inline audit for selected node)
    ├── Search tab → SearchPanel (TF-IDF search)
    ├── Impact tab → ImpactPanel (downstream analysis)
    ├── Audit tab  → AuditTrail (full provenance)
    └── Ingest tab → IngestPanel (SQL/JSON ingestion)
```

### D3 Force Graph
- forceLink: distance=120, strength=0.5
- forceManyBody: -300 (repulsion)
- forceX per system (bands = visual grouping by system)
- forceCollide: radius=36
- Node colour = system-specific (teal=CREDIT_CORE, purple=RISK_ENGINE, amber=REPORTING)
- Edge style: solid=authoritative, dashed=inferred
- Zoom: d3.zoom() scaleExtent [0.2, 4]
- Highlight: path nodes opaque, others 15% opacity

## 7. Testing Strategy

```
Unit tests:
  test_graph.py    — 18 tests (nodes, edges, traversal, impact, audit, stats)
  test_parser.py   — 9 tests  (DDL, INSERT-SELECT, CREATE-VIEW, PII, multi-stmt)
  test_ai.py       — 14 tests (search, resolver, discoverer)

Integration tests:
  test_api.py      — 22 tests (all endpoints, 404 cases, filter params)
  test_all.py      — 43 tests (end-to-end pipeline, schema crawler, models)

Total: 106 tests, all passing
Coverage: >85% on core modules
```

## 8. Extensibility Points

| Extension | How |
|-----------|-----|
| New data source | Add adapter in `SchemaParser` |
| New AI model | Swap Anthropic client in `discoverer.py` / `resolver.py` |
| Persistent storage | Replace in-memory dicts with Neo4j/PostgreSQL |
| Auth | FastAPI middleware + API key header |
| Event streaming | WebSocket endpoint for real-time lineage updates |
| New transformation | Add to `TransformationType` enum |
