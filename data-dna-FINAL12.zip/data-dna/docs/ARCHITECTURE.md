# Data-DNA — Architecture Document

## System Overview

Data-DNA is a 5-layer credit data lineage platform that combines **deterministic metadata parsing** with **AI-augmented discovery** to deliver complete, auditable, and explainable lineage across heterogeneous credit systems.

## Core Design Principles

1. **Authoritative Supremacy** — Parsed SQL/schema edges are always ground truth. AI edges are supplementary and never override them.
2. **Explainability First** — Every AI decision includes a `reasoning` field and `confidence` score visible in the UI.
3. **Bounded AI** — AI is scoped to 3 tasks only: NL field search, alias resolution, and lineage inference. It cannot modify the graph directly.
4. **Separation of Concerns** — Each layer has typed interfaces (Pydantic models). Layers communicate only through those interfaces.
5. **Extensibility** — New systems plug in as ingestion adapters. New AI models swap behind a strategy interface.

## Layer Responsibilities

| Layer | Component | Responsibility |
|-------|-----------|----------------|
| 1 | Data Sources | SQL DBs, APIs, event streams — external |
| 2 | Ingestion | SQLLineageParser, SchemaParser → FieldNode + LineageEdge |
| 3 | Graph Store | LineageGraph (NetworkX) — single source of truth |
| 4 | AI Layer | NLSearch, SemanticResolver, LineageDiscoverer |
| 5 | API | FastAPI REST — typed endpoints with Pydantic validation |
| 6 | UI | React + D3 — graph explorer, search, impact, audit |

## Data Flow: Ingestion

```
User/CI calls POST /lineage/ingest
  → IngestionService.ingest()
      → SQLLineageParser.parse(sql)
          → FieldNodes (from CREATE TABLE)
          → LineageEdges (from INSERT/VIEW, source_type=AUTHORITATIVE)
      → SchemaParser.parse(schema_json)
          → FieldNodes
      → LineageGraph.add_field() × N
      → LineageGraph.add_lineage() × M
      → NLSearchEngine.index_field() × N
  ← IngestResult { nodes_created, edges_created, warnings }
```

## Data Flow: AI Inference

```
User calls POST /audit/infer?source_system=A&target_system=B
  → LineageDiscoverer.discover(src_fields, tgt_fields)
      → Claude API: structured prompt with field lists
      → Parse JSON response
      → LineageEdge[] with source_type=INFERRED, confidence, reasoning
  → LineageGraph.add_lineage() for each
      → If authoritative edge exists: flag as superseded
  ← { inferred_edges: N, skipped: M, edges: [...] }
```

## Data Flow: Lineage Query

```
GET /lineage/path/{field_id}?hops=3&direction=both
  → LineageGraph.get_lineage()
      → DFS on nx.DiGraph (downstream) and nx.DiGraph.reverse() (upstream)
      → Filter inferred edges if include_inferred=false
      → Collect FieldNode[] and LineageEdge[]
  ← LineagePath { nodes, edges, hops, has_inferred }
```

## Security & Compliance

- PII fields detected at ingestion and flagged in all responses
- Audit trail includes completeness score and conflict detection
- Inferred edges are visually distinguished — cannot be confused with authoritative in UI
- All AI calls use system-boundary awareness

## Scalability Notes

Current: In-memory NetworkX graph — suitable for 100K nodes/edges  
Next step: Neo4j backend (drop-in via adapter pattern)  
API: Stateless FastAPI — horizontally scalable  
AI: Rate-limited via Anthropic SDK with retry backoff
