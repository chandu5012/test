/**
 * Analytics Dashboard
 * Lineage completeness, PII inventory, system health, gap analysis.
 */
import { useState, useEffect } from 'react';
import { api } from '../utils/api.js';

const SYS_COLOR = { CREDIT_CORE:'#00d4aa', RISK_ENGINE:'#6c63ff', REPORTING:'#ffb347', BUREAU_DATA:'#60a5fa' };
const col = s => SYS_COLOR[s] || '#8b85ff';

function MiniBar({ value, max, color }) {
  const pct = max ? Math.round((value / max) * 100) : 0;
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
      <div style={{ flex: 1, height: 6, background: 'var(--bg3)', borderRadius: 3, overflow: 'hidden' }}>
        <div style={{ width: `${pct}%`, height: '100%', background: color, borderRadius: 3, transition: 'width 0.4s ease' }} />
      </div>
      <span style={{ fontSize: 10, color: 'var(--text3)', minWidth: 28, textAlign: 'right' }}>{pct}%</span>
    </div>
  );
}

function MetricCard({ label, value, sub, color, icon }) {
  return (
    <div style={{ padding: '14px 16px', background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 'var(--radius-lg)' }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 8 }}>
        <span style={{ fontSize: 10, color: 'var(--text3)', textTransform: 'uppercase', letterSpacing: '0.07em' }}>{label}</span>
        <span style={{ fontSize: 16 }}>{icon}</span>
      </div>
      <div style={{ fontSize: 28, fontWeight: 800, color: color || 'var(--text)', fontFamily: 'var(--font-head)', lineHeight: 1 }}>{value}</div>
      {sub && <div style={{ fontSize: 11, color: 'var(--text3)', marginTop: 4 }}>{sub}</div>}
    </div>
  );
}

export default function Dashboard({ onSelectField }) {
  const [stats, setStats] = useState(null);
  const [fields, setFields] = useState([]);
  const [graphData, setGraphData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([api.stats(), api.fields(), api.graph()]).then(([s, f, g]) => {
      setStats(s); setFields(f); setGraphData(g); setLoading(false);
    }).catch(() => setLoading(false));
  }, []);

  if (loading) return <div style={{ color: 'var(--text3)', padding: 24 }} className="pulse">Loading dashboard…</div>;
  if (!stats) return <div style={{ color: 'var(--text3)', padding: 24 }}>Could not load data.</div>;

  // Compute metrics
  const piiFields = fields.filter(f => f.pii);
  const systems = stats.systems || [];

  // Fields per system
  const fieldsBySys = {};
  systems.forEach(s => { fieldsBySys[s] = fields.filter(f => f.system === s).length; });

  // Edges per system
  const edgesBySys = {};
  systems.forEach(s => { edgesBySys[s] = 0; });
  graphData?.links?.forEach(l => {
    const srcId = typeof l.source === 'object' ? l.source.id : l.source;
    const sys = srcId.split('.')[0];
    if (edgesBySys[sys] !== undefined) edgesBySys[sys]++;
  });

  // Orphan nodes (no edges at all)
  const connectedNodes = new Set();
  graphData?.links?.forEach(l => {
    connectedNodes.add(typeof l.source === 'object' ? l.source.id : l.source);
    connectedNodes.add(typeof l.target === 'object' ? l.target.id : l.target);
  });
  const orphans = fields.filter(f => !connectedNodes.has(f.id));

  // Auth vs inferred ratio
  const authPct = stats.total_edges > 0
    ? Math.round((stats.authoritative_edges / stats.total_edges) * 100) : 0;

  const maxFields = Math.max(...Object.values(fieldsBySys), 1);

  return (
    <div style={{ padding: 24, overflow: 'auto', height: '100%' }}>
      <h2 style={{ fontFamily: 'var(--font-head)', fontWeight: 700, color: 'var(--text)', marginBottom: 20, fontSize: 18 }}>
        Lineage Health Dashboard
      </h2>

      {/* Top metrics */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, minmax(0,1fr))', gap: 12, marginBottom: 24 }}>
        <MetricCard label="Total fields" value={stats.total_fields} sub="across all systems" color="var(--text)" icon="⬡" />
        <MetricCard label="Lineage coverage" value={`${authPct}%`} sub="authoritative edges" color={authPct > 70 ? 'var(--green)' : authPct > 40 ? 'var(--amber)' : 'var(--red)'} icon="⊕" />
        <MetricCard label="PII fields" value={piiFields.length} sub="require masking" color="var(--red)" icon="⚠" />
        <MetricCard label="Orphan fields" value={orphans.length} sub="no lineage at all" color={orphans.length > 5 ? 'var(--amber)' : 'var(--green)'} icon="◌" />
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16, marginBottom: 24 }}>

        {/* Fields per system */}
        <div style={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 'var(--radius-lg)', padding: '16px 20px' }}>
          <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--text)', marginBottom: 14 }}>Fields per system</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {systems.map(sys => (
              <div key={sys}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                  <span style={{ fontSize: 11, color: col(sys), fontWeight: 500 }}>{sys}</span>
                  <span style={{ fontSize: 11, color: 'var(--text3)' }}>{fieldsBySys[sys]} fields · {edgesBySys[sys]} edges</span>
                </div>
                <MiniBar value={fieldsBySys[sys]} max={maxFields} color={col(sys)} />
              </div>
            ))}
          </div>
        </div>

        {/* Edge quality */}
        <div style={{ background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 'var(--radius-lg)', padding: '16px 20px' }}>
          <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--text)', marginBottom: 14 }}>Edge quality</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            <div>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                <span style={{ fontSize: 11, color: 'var(--teal)' }}>Authoritative</span>
                <span style={{ fontSize: 11, color: 'var(--text3)' }}>{stats.authoritative_edges}</span>
              </div>
              <MiniBar value={stats.authoritative_edges} max={stats.total_edges || 1} color="var(--teal)" />
            </div>
            <div>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
                <span style={{ fontSize: 11, color: 'var(--accent2)' }}>AI inferred</span>
                <span style={{ fontSize: 11, color: 'var(--text3)' }}>{stats.inferred_edges}</span>
              </div>
              <MiniBar value={stats.inferred_edges} max={stats.total_edges || 1} color="var(--accent)" />
            </div>
            <div style={{ padding: '8px 0', borderTop: '1px solid var(--border)', fontSize: 11, color: 'var(--text3)' }}>
              Total edges: <strong style={{ color: 'var(--text)' }}>{stats.total_edges}</strong>
              <span style={{ marginLeft: 12 }}>DAG: <strong style={{ color: stats.is_dag ? 'var(--green)' : 'var(--red)' }}>{stats.is_dag ? '✓ valid' : '✗ cycle!'}</strong></span>
            </div>
          </div>
        </div>
      </div>

      {/* PII inventory */}
      {piiFields.length > 0 && (
        <div style={{ background: 'var(--surface)', border: '1px solid rgba(255,90,125,0.2)', borderRadius: 'var(--radius-lg)', padding: '16px 20px', marginBottom: 20 }}>
          <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--red)', marginBottom: 12, display: 'flex', alignItems: 'center', gap: 8 }}>
            <span>⚠</span> PII Field Inventory — {piiFields.length} fields require data masking
          </div>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
            {piiFields.map(f => (
              <button key={f.id} onClick={() => onSelectField?.(f.id)}
                style={{ padding: '4px 10px', background: 'rgba(255,90,125,0.1)', border: '1px solid rgba(255,90,125,0.3)', borderRadius: 20, color: 'var(--red)', fontSize: 11, cursor: 'pointer' }}>
                {f.system.slice(0,2)} · {f.column}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Orphan fields — lineage gaps */}
      {orphans.length > 0 && (
        <div style={{ background: 'var(--surface)', border: '1px solid rgba(255,179,71,0.2)', borderRadius: 'var(--radius-lg)', padding: '16px 20px' }}>
          <div style={{ fontSize: 12, fontWeight: 600, color: 'var(--amber)', marginBottom: 12, display: 'flex', alignItems: 'center', gap: 8 }}>
            <span>◌</span> Lineage Gaps — {orphans.length} fields with no lineage
          </div>
          <div style={{ fontSize: 11, color: 'var(--text3)', marginBottom: 10 }}>
            These fields have no upstream or downstream connections. Consider ingesting SQL that defines their origin.
          </div>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
            {orphans.slice(0, 20).map(f => (
              <button key={f.id} onClick={() => onSelectField?.(f.id)}
                style={{ padding: '4px 10px', background: 'rgba(255,179,71,0.08)', border: '1px solid rgba(255,179,71,0.25)', borderRadius: 20, color: 'var(--amber)', fontSize: 11, cursor: 'pointer' }}>
                {f.system.slice(0,2)} · {f.column}
              </button>
            ))}
            {orphans.length > 20 && <span style={{ fontSize: 11, color: 'var(--text3)', alignSelf: 'center' }}>+{orphans.length - 20} more</span>}
          </div>
        </div>
      )}
    </div>
  );
}
