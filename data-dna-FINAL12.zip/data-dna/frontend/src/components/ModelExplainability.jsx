/**
 * AI Model Explainability Trail — US Banking context
 * ECOA / Fair Lending / SR 11-7 / CFPB requires adverse action explanations
 * Connects model input features → RISK fields → raw source fields
 */
import { useState, useEffect, useMemo } from 'react';

const BASE = 'http://localhost:8000';

// Pre-loaded US banking model registry
const STARTER_MODELS = [
  {
    id: 'PD_SCORECARD_V2', name: 'PD Scorecard v2', type: 'Credit Risk',
    regulation: 'SR 11-7 / CECL', version: '2.1', status: 'Production',
    purpose: 'Probability of Default — retail lending',
    features: [
      { name:'CREDIT_SCORE', weight:0.28, source:'BUREAU', desc:'FICO/VantageScore from credit bureau' },
      { name:'DEBT_TO_INCOME_RATIO', weight:0.22, source:'RISK', desc:'Monthly debt obligations / gross monthly income' },
      { name:'PAYMENT_HISTORY_12M', weight:0.18, source:'CORE_BANKING', desc:'On-time payment ratio last 12 months' },
      { name:'OUTSTANDING_BALANCE', weight:0.15, source:'CORE_BANKING', desc:'Current total outstanding loan balance' },
      { name:'MONTHS_ON_BOOK', weight:0.10, source:'CORE_BANKING', desc:'Account age in months' },
      { name:'UTILIZATION_RATIO', weight:0.07, source:'BUREAU', desc:'Credit utilization rate from bureau' },
    ]
  },
  {
    id: 'FAIR_LENDING_SCREEN', name: 'Fair Lending Disparate Impact Screen', type: 'Compliance',
    regulation: 'ECOA / Fair Housing Act', version: '1.0', status: 'Production',
    purpose: 'Detect disparate impact in credit decisions',
    features: [
      { name:'LOAN_AMOUNT', weight:0.20, source:'LOS', desc:'Requested loan amount' },
      { name:'LTV_RATIO', weight:0.18, source:'RISK', desc:'Loan-to-value ratio' },
      { name:'DTI_RATIO', weight:0.17, source:'RISK', desc:'Debt-to-income ratio' },
      { name:'BORROWER_INCOME', weight:0.15, source:'LOS', desc:'Verified gross annual income' },
      { name:'PROPERTY_VALUE', weight:0.15, source:'LOS', desc:'Appraised property value' },
      { name:'CREDIT_SCORE', weight:0.15, source:'BUREAU', desc:'Credit score at origination' },
    ]
  },
  {
    id: 'DFAST_LOSS_MODEL', name: 'DFAST Severely Adverse Loss Model', type: 'Stress Test',
    regulation: 'DFAST / SR 12-7', version: '3.2', status: 'Production',
    purpose: 'Estimate loan losses under severely adverse macroeconomic scenario',
    features: [
      { name:'LTV_AT_ORIGINATION', weight:0.25, source:'RISK', desc:'Original LTV ratio' },
      { name:'CURRENT_LTV', weight:0.20, source:'RISK', desc:'Current mark-to-market LTV' },
      { name:'CREDIT_SCORE_AT_ORIG', weight:0.18, source:'LOS', desc:'FICO score at origination' },
      { name:'UNEMPLOYMENT_RATE', weight:0.15, source:'MACRO', desc:'Fed macro scenario unemployment' },
      { name:'HOUSE_PRICE_INDEX', weight:0.12, source:'MACRO', desc:'FHFA house price index change' },
      { name:'DPD_HISTORY', weight:0.10, source:'CORE_BANKING', desc:'Days past due history' },
    ]
  },
];

const STATUS_STYLE = {
  Production: {bg:'rgba(34,197,94,0.1)',color:'#166534'},
  Validation: {bg:'rgba(245,158,11,0.1)',color:'#92400e'},
  Retired:    {bg:'rgba(107,114,128,0.1)',color:'#374151'},
};

export default function ModelExplainability() {
  const [fields,  setFields]  = useState([]);
  const [links,   setLinks]   = useState([]);
  const [loading, setLoading] = useState(true);
  const [models,  setModels]  = useState(STARTER_MODELS);
  const [selModel, setSelModel] = useState(STARTER_MODELS[0]);
  const [view, setView] = useState('trail'); // trail | register | explain

  useEffect(() => {
    Promise.all([
      fetch(`${BASE}/lineage/fields`).then(r=>r.json()),
      fetch(`${BASE}/lineage/graph`).then(r=>r.json()),
    ]).then(([f,g])=>{setFields(f);setLinks(g.links||[]);setLoading(false);})
     .catch(()=>setLoading(false));
  }, []);

  // Find physical field matching a feature name
  const findField = (featureName) => {
    const patterns = featureName.toUpperCase().split('_');
    return fields.find(f =>
      patterns.every(p => p.length < 3 || f.column.toUpperCase().includes(p)) ||
      f.column.toUpperCase() === featureName.toUpperCase()
    ) || null;
  };

  // Trace lineage for a feature back to root sources
  const traceToSource = (fieldId, depth=0, visited=new Set()) => {
    if (depth > 5 || visited.has(fieldId)) return [];
    visited.add(fieldId);
    const upstream = links.filter(l => (typeof l.target==='object'?l.target.id:l.target) === fieldId);
    if (upstream.length === 0) return [{ fieldId, depth, isSource: true }];
    const result = [{ fieldId, depth, isSource: false }];
    upstream.forEach(l => {
      const srcId = typeof l.source==='object'?l.source.id:l.source;
      result.push(...traceToSource(srcId, depth+1, new Set(visited)));
    });
    return result;
  };

  const regColor = r => r.includes('ECOA')||r.includes('Fair')?'#ef4444':r.includes('DFAST')||r.includes('SR 12')?'#f59e0b':'#7c6fff';

  return (
    <div style={{display:'flex',flexDirection:'column',height:'100%',overflow:'hidden'}}>
      <div style={{padding:'12px 16px',flexShrink:0,borderBottom:'1px solid var(--color-border-tertiary)'}}>
        <div style={{display:'flex',alignItems:'center',gap:12,marginBottom:10}}>
          <div>
            <div style={{fontSize:15,fontWeight:500,color:'var(--color-text-primary)'}}>AI Model Explainability Trail</div>
            <div style={{fontSize:11,color:'var(--color-text-tertiary)',marginTop:2}}>
              Trace credit model inputs back to raw source data. Required for ECOA adverse action, SR 11-7 model governance, and DFAST documentation.
            </div>
          </div>
          <div style={{marginLeft:'auto',display:'flex',gap:6}}>
            {[['trail','Lineage trail'],['register','Model registry'],['explain','Adverse action']].map(([m,l])=>(
              <button key={m} onClick={()=>setView(m)}
                style={{padding:'5px 12px',fontSize:11,borderRadius:20,cursor:'pointer',
                  background:view===m?'var(--color-background-info)':'transparent',
                  color:view===m?'var(--color-text-info)':'var(--color-text-secondary)',
                  border:`1px solid ${view===m?'var(--color-border-info)':'var(--color-border-secondary)'}`,
                  fontWeight:view===m?500:400}}>
                {l}
              </button>
            ))}
          </div>
        </div>
        {/* Model selector */}
        <div style={{display:'flex',gap:6,flexWrap:'wrap'}}>
          {models.map(m=>{
            const sty = STATUS_STYLE[m.status]||STATUS_STYLE.Validation;
            return (
              <button key={m.id} onClick={()=>setSelModel(m)}
                style={{padding:'5px 12px',fontSize:11,borderRadius:6,cursor:'pointer',
                  background:selModel?.id===m.id?'var(--color-background-secondary)':'transparent',
                  color:'var(--color-text-secondary)',
                  border:`1px solid ${selModel?.id===m.id?'var(--color-border-primary)':'var(--color-border-secondary)'}`,
                  display:'flex',alignItems:'center',gap:6}}>
                <span>{m.name}</span>
                <span style={{padding:'1px 5px',borderRadius:3,fontSize:8,fontWeight:700,...sty}}>{m.status}</span>
              </button>
            );
          })}
        </div>
      </div>

      <div style={{flex:1,overflow:'auto',padding:16}}>
        {loading ? (
          <div style={{display:'flex',alignItems:'center',justifyContent:'center',height:200,color:'var(--color-text-tertiary)',fontSize:13}}>
            Loading model registry…
          </div>
        ) : !selModel ? (
          <div style={{textAlign:'center',color:'var(--color-text-tertiary)',padding:40}}>Select a model above</div>
        ) : view === 'trail' ? (
          <TrailView model={selModel} findField={findField} traceToSource={traceToSource} fields={fields}/>
        ) : view === 'register' ? (
          <RegisterView models={models} setModels={setModels} selModel={selModel} setSelModel={setSelModel}/>
        ) : (
          <AdverseActionView model={selModel} findField={findField} fields={fields}/>
        )}
      </div>
    </div>
  );
}

function TrailView({ model, findField, traceToSource, fields }) {
  const [expanded, setExpanded] = useState(null);
  return (
    <div>
      {/* Model info */}
      <div style={{padding:'12px 16px',background:'var(--color-background-secondary)',
        borderRadius:8,border:'0.5px solid var(--color-border-secondary)',marginBottom:16}}>
        <div style={{display:'flex',gap:16,flexWrap:'wrap',fontSize:11}}>
          <div><span style={{color:'var(--color-text-tertiary)'}}>Model: </span><strong style={{color:'var(--color-text-primary)'}}>{model.name} v{model.version}</strong></div>
          <div><span style={{color:'var(--color-text-tertiary)'}}>Type: </span><span style={{color:'var(--color-text-secondary)'}}>{model.type}</span></div>
          <div><span style={{color:'var(--color-text-tertiary)'}}>Regulation: </span><span style={{color:'var(--color-text-secondary)'}}>{model.regulation}</span></div>
          <div style={{flex:1}}><span style={{color:'var(--color-text-tertiary)'}}>Purpose: </span><span style={{color:'var(--color-text-secondary)'}}>{model.purpose}</span></div>
        </div>
      </div>

      <div style={{fontSize:12,fontWeight:500,color:'var(--color-text-primary)',marginBottom:12}}>
        Feature → Physical field → Source data lineage chain
      </div>

      {model.features.map((feat,fi) => {
        const physField = findField(feat.name);
        const trail = physField ? traceToSource(physField.id) : [];
        const isExp = expanded === fi;
        return (
          <div key={feat.name} style={{marginBottom:8,background:'var(--color-background-primary)',
            border:'0.5px solid var(--color-border-secondary)',borderRadius:8,overflow:'hidden'}}>
            <div onClick={()=>setExpanded(isExp?null:fi)}
              style={{display:'flex',alignItems:'center',gap:10,padding:'10px 14px',cursor:'pointer',
                background:isExp?'var(--color-background-info)':'transparent'}}>
              {/* Weight bar */}
              <div style={{width:4,height:32,borderRadius:2,flexShrink:0,
                background:`hsl(${Math.round(feat.weight*200+20)},70%,50%)`}}/>
              <div style={{flex:1}}>
                <div style={{display:'flex',alignItems:'center',gap:8}}>
                  <span style={{fontSize:12,fontWeight:500,color:'var(--color-text-primary)',fontFamily:'monospace'}}>{feat.name}</span>
                  <span style={{fontSize:10,padding:'1px 7px',borderRadius:10,
                    background:'var(--color-background-tertiary)',color:'var(--color-text-secondary)'}}>{feat.source}</span>
                  <span style={{fontSize:10,color:'var(--color-text-tertiary)',marginLeft:'auto'}}>
                    Weight: <strong style={{color:'var(--color-text-primary)'}}>{(feat.weight*100).toFixed(0)}%</strong>
                  </span>
                </div>
                <div style={{fontSize:10,color:'var(--color-text-tertiary)',marginTop:1}}>{feat.desc}</div>
              </div>
              <div style={{flexShrink:0}}>
                {physField
                  ?<span style={{fontSize:9,color:'#22c55e',fontWeight:600}}>✓ TRACED</span>
                  :<span style={{fontSize:9,color:'#ef4444',fontWeight:600}}>⚠ UNMAPPED</span>}
              </div>
              <span style={{fontSize:11,color:'var(--color-text-tertiary)',marginLeft:6}}>{isExp?'▲':'▼'}</span>
            </div>

            {isExp && (
              <div style={{padding:'12px 14px',borderTop:'0.5px solid var(--color-border-tertiary)'}}>
                {!physField ? (
                  <div style={{color:'#ef4444',fontSize:11,padding:'8px 12px',borderRadius:6,
                    background:'rgba(239,68,68,0.06)',border:'0.5px solid rgba(239,68,68,0.3)'}}>
                    Model feature "{feat.name}" is not mapped to any physical data field.
                    Use the Map Fields tab to create this mapping for SR 11-7 compliance.
                  </div>
                ) : (
                  <div>
                    <div style={{fontSize:11,color:'var(--color-text-secondary)',marginBottom:8}}>
                      Physical field: <code style={{color:'var(--color-text-info)'}}>{physField.id}</code>
                      {physField.description&&<span style={{marginLeft:8,color:'var(--color-text-tertiary)'}}>— {physField.description.slice(0,60)}</span>}
                    </div>
                    {trail.length > 0 && (
                      <div>
                        <div style={{fontSize:10,fontWeight:600,color:'var(--color-text-tertiary)',textTransform:'uppercase',letterSpacing:'.07em',marginBottom:6}}>
                          Data provenance chain:
                        </div>
                        {trail.slice(0,6).map((t,i)=>{
                          const f = fields.find(f=>f.id===t.fieldId);
                          return (
                            <div key={i} style={{display:'flex',alignItems:'center',gap:6,padding:'4px 0',
                              marginLeft:t.depth*16}}>
                              <span style={{fontSize:10,color:'var(--color-text-tertiary)',fontFamily:'monospace'}}>
                                {t.depth>0?'└─►':'⊕'}
                              </span>
                              <span style={{fontSize:10,fontFamily:'monospace',
                                color:t.isSource?'#22c55e':'var(--color-text-secondary)'}}>{t.fieldId}</span>
                              {t.isSource&&<span style={{fontSize:8,color:'#22c55e',fontWeight:600}}>ROOT SOURCE</span>}
                            </div>
                          );
                        })}
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}

function RegisterView({ models, setModels, selModel, setSelModel }) {
  return (
    <div>
      <div style={{display:'flex',gap:10,flexWrap:'wrap',marginBottom:16}}>
        {models.map(m=>{
          const sty = STATUS_STYLE[m.status]||STATUS_STYLE.Validation;
          const covered = m.features.length;
          return (
            <div key={m.id} onClick={()=>setSelModel(m)}
              style={{padding:'14px 16px',borderRadius:10,cursor:'pointer',
                border:`1.5px solid ${selModel?.id===m.id?'var(--color-border-primary)':'var(--color-border-tertiary)'}`,
                background:selModel?.id===m.id?'var(--color-background-info)':'var(--color-background-primary)',
                minWidth:240,flex:'1 1 240px'}}>
              <div style={{display:'flex',alignItems:'center',gap:6,marginBottom:6}}>
                <div style={{fontWeight:500,color:'var(--color-text-primary)',flex:1}}>{m.name}</div>
                <span style={{padding:'2px 7px',borderRadius:4,fontSize:9,fontWeight:700,...sty}}>{m.status}</span>
              </div>
              <div style={{fontSize:10,color:'var(--color-text-tertiary)',marginBottom:4}}>v{m.version} · {m.type}</div>
              <div style={{fontSize:10,color:'var(--color-text-secondary)',marginBottom:6}}>{m.purpose}</div>
              <div style={{fontSize:10,padding:'4px 8px',borderRadius:4,
                background:'rgba(124,111,255,0.08)',color:'#7c6fff',display:'inline-block'}}>
                Reg: {m.regulation}
              </div>
              <div style={{marginTop:6,fontSize:10,color:'var(--color-text-tertiary)'}}>
                {covered} input features · Click to see lineage trail
              </div>
            </div>
          );
        })}
      </div>
      <div style={{padding:'10px 14px',background:'var(--color-background-secondary)',borderRadius:8,
        fontSize:11,color:'var(--color-text-secondary)',lineHeight:1.7}}>
        <strong style={{color:'var(--color-text-primary)'}}>SR 11-7 requirement:</strong> Each model in production must have documented data lineage 
        showing which source systems feed its input features. The Lineage Trail tab above shows this chain for each model.
        Use the Map Fields tab to link any unmapped features to physical fields.
      </div>
    </div>
  );
}

function AdverseActionView({ model, findField, fields }) {
  const [loanId, setLoanId] = useState('LOAN-2024-8841');
  const [generated, setGenerated] = useState(false);

  const reasons = model.features
    .sort((a,b)=>b.weight-a.weight)
    .slice(0,4)
    .map(feat => {
      const physField = findField(feat.name);
      return {
        factor: feat.name.replace(/_/g,' ').toLowerCase(),
        weight: feat.weight,
        field: physField,
        regulation: 'ECOA / Reg B',
      };
    });

  return (
    <div>
      <div style={{padding:'12px 16px',background:'var(--color-background-secondary)',
        borderRadius:8,border:'0.5px solid var(--color-border-secondary)',marginBottom:16}}>
        <div style={{fontSize:12,fontWeight:500,color:'var(--color-text-primary)',marginBottom:8}}>
          Generate Adverse Action Notice (ECOA / Reg B compliant)
        </div>
        <div style={{display:'flex',gap:8,alignItems:'center'}}>
          <label style={{fontSize:11,color:'var(--color-text-secondary)'}}>Loan application ID:</label>
          <input value={loanId} onChange={e=>setLoanId(e.target.value)}
            style={{padding:'4px 8px',fontSize:11,border:'1px solid var(--color-border-secondary)',
              borderRadius:6,background:'var(--color-background-primary)',color:'var(--color-text-primary)',width:160}}/>
          <button onClick={()=>setGenerated(true)}
            style={{padding:'5px 14px',fontSize:11,borderRadius:6,cursor:'pointer',
              background:'var(--color-background-info)',color:'var(--color-text-info)',
              border:'1px solid var(--color-border-info)',fontWeight:500}}>
            Generate notice
          </button>
        </div>
      </div>

      {generated && (
        <div style={{background:'var(--color-background-primary)',border:'1px solid var(--color-border-secondary)',
          borderRadius:8,padding:'20px 24px'}}>
          <div style={{fontSize:12,color:'var(--color-text-tertiary)',marginBottom:12}}>ADVERSE ACTION NOTICE — {model.regulation}</div>
          <div style={{fontSize:13,fontWeight:500,color:'var(--color-text-primary)',marginBottom:8}}>
            Re: Credit Application {loanId}
          </div>
          <div style={{fontSize:12,color:'var(--color-text-secondary)',lineHeight:1.7,marginBottom:14}}>
            We regret to inform you that your credit application has been declined based on information 
            obtained from your credit profile and application data. The principal reasons for this decision 
            are listed below, along with the data fields that informed each factor.
          </div>
          <div style={{marginBottom:14}}>
            <div style={{fontSize:11,fontWeight:600,color:'var(--color-text-primary)',marginBottom:8}}>
              Principal adverse action reasons:
            </div>
            {reasons.map((r,i)=>(
              <div key={i} style={{padding:'10px 14px',marginBottom:6,borderRadius:7,
                background:'var(--color-background-secondary)',border:'0.5px solid var(--color-border-secondary)'}}>
                <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:4}}>
                  <span style={{fontSize:11,fontWeight:600,color:'var(--color-text-primary)'}}>{i+1}. {r.factor.charAt(0).toUpperCase()+r.factor.slice(1)}</span>
                  <span style={{fontSize:10,color:'var(--color-text-tertiary)'}}>(weight: {(r.weight*100).toFixed(0)}%)</span>
                </div>
                {r.field && (
                  <div style={{fontSize:10,color:'var(--color-text-tertiary)',fontFamily:'monospace'}}>
                    Source data: {r.field.id} · {r.field.system} · {r.field.description?.slice(0,60)||'No description'}
                  </div>
                )}
                <div style={{fontSize:9,color:'#7c6fff',marginTop:3}}>Regulation: {r.regulation}</div>
              </div>
            ))}
          </div>
          <div style={{fontSize:11,color:'var(--color-text-tertiary)',lineHeight:1.6,
            borderTop:'0.5px solid var(--color-border-tertiary)',paddingTop:10}}>
            This notice is provided pursuant to the Equal Credit Opportunity Act (ECOA) and Regulation B. 
            You have the right to a statement of reasons within 60 days. Model: {model.name} v{model.version}. 
            All data lineage documented in Data-DNA per SR 11-7 model governance requirements.
          </div>
        </div>
      )}
    </div>
  );
}
