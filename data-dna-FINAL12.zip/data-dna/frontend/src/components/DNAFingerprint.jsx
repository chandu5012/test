/**
 * DNA Fingerprint — detects duplicate/ghost/orphan fields via lineage hash
 * US banks: 30% of columns are duplicates under different names
 * "Which outstanding balance is the real one? We have 4 of them."
 */
import { useState, useEffect, useMemo } from 'react';

const BASE = 'http://localhost:8000';

// Generate a fingerprint for a field based on its lineage pattern
function fingerprint(field, links) {
  const upstream = links
    .filter(l => (typeof l.target==='object'?l.target.id:l.target) === field.id)
    .map(l => ({
      src: typeof l.source==='object'?l.source.id:l.source,
      type: (l.transformation_type||'direct').replace('TransformationType.','')
    }))
    .sort((a,b)=>a.src.localeCompare(b.src));
  const upHash = upstream.map(u=>`${u.src}:${u.type}`).join('|');
  const typeBase = (field.data_type||'').split('(')[0].toUpperCase();
  return `${typeBase}::${upHash || 'ROOT'}`;
}

export default function DNAFingerprint() {
  const [fields,  setFields]  = useState([]);
  const [links,   setLinks]   = useState([]);
  const [loading, setLoading] = useState(true);
  const [view,    setView]    = useState('duplicates'); // duplicates | ghosts | orphans
  const [expanded, setExpanded] = useState(null);
  const [filterSys, setFilterSys] = useState('ALL');

  useEffect(() => {
    Promise.all([
      fetch(`${BASE}/lineage/fields`).then(r=>r.json()),
      fetch(`${BASE}/lineage/graph`).then(r=>r.json()),
    ]).then(([f,g])=>{setFields(f);setLinks(g.links||[]);setLoading(false);})
     .catch(()=>setLoading(false));
  }, []);

  // Group fields by fingerprint
  const fpGroups = useMemo(() => {
    const groups = {};
    fields.forEach(f => {
      const fp = fingerprint(f, links);
      if (!groups[fp]) groups[fp] = [];
      groups[fp].push(f);
    });
    return groups;
  }, [fields, links]);

  // Duplicates: same fingerprint, different names, different systems
  const duplicates = useMemo(() => {
    return Object.entries(fpGroups)
      .filter(([fp, flds]) => {
        if (flds.length < 2) return false;
        const systems = new Set(flds.map(f=>f.system));
        return systems.size > 1; // across systems = interesting
      })
      .map(([fp, flds]) => ({
        fingerprint: fp,
        fields: flds,
        systems: [...new Set(flds.map(f=>f.system))],
        sameType: new Set(flds.map(f=>(f.data_type||'').split('(')[0])).size === 1,
      }))
      .sort((a,b)=>b.fields.length-a.fields.length);
  }, [fpGroups]);

  // Ghost fields: defined but no upstream AND no downstream
  const allLinkedFields = useMemo(() => {
    const s = new Set();
    links.forEach(l => {
      s.add(typeof l.source==='object'?l.source.id:l.source);
      s.add(typeof l.target==='object'?l.target.id:l.target);
    });
    return s;
  }, [links]);

  const ghosts = useMemo(() =>
    fields.filter(f => !allLinkedFields.has(f.id) && !f.description)
  , [fields, allLinkedFields]);

  // Orphans: no upstream (root) and no downstream (leaf) but has a description
  const orphans = useMemo(() =>
    fields.filter(f => !allLinkedFields.has(f.id) && f.description)
  , [fields, allLinkedFields]);

  const filtered = (arr) => filterSys === 'ALL' ? arr
    : arr.filter(f => (f.system||f.fields?.[0]?.system) === filterSys);

  const systems = useMemo(()=>[...new Set(fields.map(f=>f.system))].sort(),[fields]);

  return (
    <div style={{display:'flex',flexDirection:'column',height:'100%',overflow:'hidden'}}>
      <div style={{padding:'12px 16px',flexShrink:0,borderBottom:'1px solid var(--color-border-tertiary)'}}>
        <div style={{display:'flex',alignItems:'center',gap:12,marginBottom:10}}>
          <div>
            <div style={{fontSize:15,fontWeight:500,color:'var(--color-text-primary)'}}>Data DNA Fingerprint</div>
            <div style={{fontSize:11,color:'var(--color-text-tertiary)',marginTop:2}}>
              Unique lineage hash per field detects duplicate columns, ghost fields and orphans. Average bank has 30% duplicates.
            </div>
          </div>
          <div style={{marginLeft:'auto',display:'flex',gap:8}}>
            {[
              {label:'Duplicate groups',value:duplicates.length,color:'#f59e0b'},
              {label:'Ghost fields',    value:ghosts.length,    color:'#ef4444'},
              {label:'Orphan fields',   value:orphans.length,   color:'#7c6fff'},
            ].map((s,i)=>(
              <div key={i} style={{padding:'8px 14px',background:'var(--color-background-secondary)',
                border:'1px solid var(--color-border-tertiary)',borderRadius:8,textAlign:'center',minWidth:80}}>
                <div style={{fontSize:18,fontWeight:600,color:s.color}}>{loading?'…':s.value}</div>
                <div style={{fontSize:9,color:'var(--color-text-tertiary)',whiteSpace:'nowrap'}}>{s.label}</div>
              </div>
            ))}
          </div>
        </div>
        <div style={{display:'flex',gap:6,alignItems:'center'}}>
          {[
            ['duplicates','Duplicates','#f59e0b'],
            ['ghosts','Ghost fields','#ef4444'],
            ['orphans','Orphans','#7c6fff'],
          ].map(([m,l,c])=>(
            <button key={m} onClick={()=>setView(m)}
              style={{padding:'4px 12px',fontSize:11,borderRadius:20,cursor:'pointer',
                background:view===m?`${c}18`:'transparent',
                color:view===m?c:'var(--color-text-secondary)',
                border:`1px solid ${view===m?`${c}60`:'var(--color-border-secondary)'}`,
                fontWeight:view===m?500:400}}>
              {l}
            </button>
          ))}
          <select value={filterSys} onChange={e=>setFilterSys(e.target.value)}
            style={{marginLeft:8,padding:'4px 8px',fontSize:11,border:'1px solid var(--color-border-secondary)',
              borderRadius:6,background:'var(--color-background-primary)',color:'var(--color-text-primary)'}}>
            <option value="ALL">All systems</option>
            {systems.map(s=><option key={s} value={s}>{s}</option>)}
          </select>
        </div>
      </div>

      <div style={{flex:1,overflow:'auto',padding:16}}>
        {loading ? (
          <div style={{display:'flex',alignItems:'center',justifyContent:'center',height:200,color:'var(--color-text-tertiary)',fontSize:13}}>
            Computing lineage fingerprints…
          </div>
        ) : view === 'duplicates' ? (
          <DuplicatesView groups={duplicates.filter(g=>filterSys==='ALL'||g.systems.includes(filterSys))} expanded={expanded} setExpanded={setExpanded}/>
        ) : view === 'ghosts' ? (
          <GhostsView fields={ghosts.filter(f=>filterSys==='ALL'||f.system===filterSys)}/>
        ) : (
          <OrphansView fields={orphans.filter(f=>filterSys==='ALL'||f.system===filterSys)}/>
        )}
      </div>
    </div>
  );
}

function DuplicatesView({ groups, expanded, setExpanded }) {
  if (groups.length === 0) return (
    <div style={{display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',height:200,gap:8,color:'var(--color-text-tertiary)'}}>
      <div style={{fontSize:28,opacity:.3}}>✓</div>
      <div style={{fontSize:13,fontWeight:500,color:'var(--color-text-secondary)'}}>No duplicate fields detected</div>
      <div style={{fontSize:11}}>All fields appear to have unique lineage signatures across systems</div>
    </div>
  );
  return (
    <div>
      <div style={{fontSize:12,color:'var(--color-text-secondary)',marginBottom:12}}>
        {groups.length} groups of duplicate fields found (same lineage fingerprint, different systems).
        <span style={{color:'#f59e0b',marginLeft:6}}>Recommendation: choose one authoritative field per metric.</span>
      </div>
      {groups.map((g,i)=>{
        const isExp = expanded===i;
        const sameType = g.sameType;
        return (
          <div key={i} style={{marginBottom:8,background:'var(--color-background-primary)',
            border:'0.5px solid var(--color-border-secondary)',borderRadius:8,overflow:'hidden'}}>
            <div onClick={()=>setExpanded(isExp?null:i)}
              style={{display:'flex',alignItems:'center',gap:10,padding:'10px 14px',cursor:'pointer',
                background:isExp?'var(--color-background-warning)':'var(--color-background-secondary)'}}>
              <div style={{width:8,height:8,borderRadius:'50%',background:'#f59e0b',flexShrink:0}}/>
              <div style={{flex:1}}>
                <div style={{fontSize:11,fontWeight:500,color:'var(--color-text-primary)'}}>
                  {g.fields.length} fields share the same lineage fingerprint
                  {!sameType&&<span style={{fontSize:10,color:'#ef4444',marginLeft:6}}>⚠ Different data types!</span>}
                </div>
                <div style={{fontSize:10,color:'var(--color-text-tertiary)',marginTop:1}}>
                  Found in: {g.systems.join(', ')} · Fingerprint: <code style={{fontSize:9}}>{g.fingerprint.slice(0,60)}</code>
                </div>
              </div>
              <span style={{fontSize:11,color:'var(--color-text-tertiary)'}}>{isExp?'▲':'▼'}</span>
            </div>
            {isExp && (
              <div style={{padding:'12px 14px'}}>
                <div style={{display:'flex',gap:8,flexWrap:'wrap',marginBottom:10}}>
                  {g.fields.map(f=>(
                    <div key={f.id} style={{padding:'8px 12px',borderRadius:7,
                      background:'var(--color-background-secondary)',border:'0.5px solid var(--color-border-secondary)',minWidth:180}}>
                      <div style={{fontSize:11,fontWeight:500,color:'var(--color-text-primary)',marginBottom:2,fontFamily:'monospace'}}>{f.column}</div>
                      <div style={{fontSize:10,color:'var(--color-text-secondary)'}}>{f.system} · {f.table}</div>
                      <div style={{fontSize:10,color:'var(--color-text-tertiary)',fontFamily:'monospace'}}>{f.data_type||'—'}</div>
                      {f.description&&<div style={{fontSize:10,color:'var(--color-text-secondary)',marginTop:4,lineHeight:1.4}}>{f.description.slice(0,60)}</div>}
                      {!f.description&&<div style={{fontSize:10,color:'#f59e0b',marginTop:4,fontStyle:'italic'}}>No description — unclear if authoritative</div>}
                    </div>
                  ))}
                </div>
                <div style={{padding:'8px 12px',borderRadius:6,background:'rgba(245,158,11,0.06)',
                  border:'0.5px solid rgba(245,158,11,0.3)',fontSize:11,color:'var(--color-text-secondary)',lineHeight:1.6}}>
                  <strong style={{color:'#f59e0b'}}>Action:</strong> Identify which is the authoritative source.
                  Add a description to the authoritative field noting it is the "single source of truth."
                  Map all others to it using the <strong>Map Fields</strong> tab.
                  This eliminates the "which outstanding balance is correct?" confusion in DFAST/Call Report submissions.
                </div>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}

function GhostsView({ fields }) {
  if (fields.length === 0) return (
    <div style={{display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',height:200,gap:8,color:'var(--color-text-tertiary)'}}>
      <div style={{fontSize:28,opacity:.3}}>✓</div>
      <div style={{fontSize:13,fontWeight:500,color:'var(--color-text-secondary)'}}>No ghost fields detected</div>
      <div style={{fontSize:11}}>All fields are connected to at least one lineage edge</div>
    </div>
  );
  return (
    <div>
      <div style={{fontSize:12,color:'var(--color-text-secondary)',marginBottom:12}}>
        {fields.length} ghost fields — defined in the catalog but with no lineage connections and no description.
        <span style={{color:'#ef4444',marginLeft:6}}>These are candidates for deletion or documentation.</span>
      </div>
      <table style={{width:'100%',borderCollapse:'collapse',fontSize:11}}>
        <thead><tr style={{background:'var(--color-background-secondary)'}}>
          {['System','Table','Column','Data type','Recommendation'].map((h,i)=>(
            <th key={i} style={{padding:'7px 12px',textAlign:'left',fontSize:9,fontWeight:700,
              color:'var(--color-text-tertiary)',textTransform:'uppercase',letterSpacing:'.08em',
              borderBottom:'2px solid var(--color-border-secondary)'}}>{h}</th>
          ))}
        </tr></thead>
        <tbody>
          {fields.map((f,i)=>(
            <tr key={f.id} style={{borderBottom:'1px solid var(--color-border-tertiary)',
              background:i%2===0?'transparent':'var(--color-background-secondary)'}}>
              <td style={{padding:'6px 12px',color:'var(--color-text-secondary)'}}>{f.system}</td>
              <td style={{padding:'6px 12px',color:'var(--color-text-secondary)'}}>{f.table}</td>
              <td style={{padding:'6px 12px',fontFamily:'monospace',fontWeight:500,color:'var(--color-text-primary)'}}>{f.column}</td>
              <td style={{padding:'6px 12px',color:'var(--color-text-tertiary)',fontFamily:'monospace'}}>{f.data_type||'—'}</td>
              <td style={{padding:'6px 12px'}}>
                <span style={{fontSize:10,color:'#ef4444'}}>Map to a source or document purpose</span>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function OrphansView({ fields }) {
  if (fields.length === 0) return (
    <div style={{display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',height:200,gap:8,color:'var(--color-text-tertiary)'}}>
      <div style={{fontSize:13,fontWeight:500,color:'var(--color-text-secondary)'}}>No orphan fields</div>
    </div>
  );
  return (
    <div>
      <div style={{fontSize:12,color:'var(--color-text-secondary)',marginBottom:12}}>
        {fields.length} isolated fields — have descriptions but no lineage edges. May need mapping.
      </div>
      <table style={{width:'100%',borderCollapse:'collapse',fontSize:11}}>
        <thead><tr style={{background:'var(--color-background-secondary)'}}>
          {['System','Table','Column','Description','Type'].map((h,i)=>(
            <th key={i} style={{padding:'7px 12px',textAlign:'left',fontSize:9,fontWeight:700,
              color:'var(--color-text-tertiary)',textTransform:'uppercase',letterSpacing:'.08em',
              borderBottom:'2px solid var(--color-border-secondary)'}}>{h}</th>
          ))}
        </tr></thead>
        <tbody>
          {fields.map((f,i)=>(
            <tr key={f.id} style={{borderBottom:'1px solid var(--color-border-tertiary)',
              background:i%2===0?'transparent':'var(--color-background-secondary)'}}>
              <td style={{padding:'6px 12px',color:'var(--color-text-secondary)'}}>{f.system}</td>
              <td style={{padding:'6px 12px',color:'var(--color-text-secondary)'}}>{f.table}</td>
              <td style={{padding:'6px 12px',fontFamily:'monospace',color:'var(--color-text-primary)'}}>{f.column}</td>
              <td style={{padding:'6px 12px',color:'var(--color-text-secondary)',maxWidth:200,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{f.description}</td>
              <td style={{padding:'6px 12px',color:'var(--color-text-tertiary)',fontFamily:'monospace',fontSize:10}}>{f.data_type||'—'}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
