/**
 * Regulation Radar — US Banking Regulatory Template Mapping
 * Pre-loaded: DFAST, CCAR, FR Y-9C, Call Report (FFIEC 031), HMDA, CRA, BSA/AML
 * Maps regulatory fields to physical data fields automatically
 */
import { useState, useEffect, useMemo } from 'react';

const BASE = 'http://localhost:8000';

// US Banking regulatory templates
const REGULATIONS = {
  DFAST: {
    name: 'DFAST / Dodd-Frank Stress Test',
    regulator: 'Federal Reserve',
    frequency: 'Annual',
    description: 'Capital adequacy stress test required for banks with $100B+ assets',
    fields: [
      { id:'D01', name:'PPNR_NET_INTEREST_INCOME', category:'Revenue', desc:'Pre-provision net revenue — net interest income', required:true },
      { id:'D02', name:'PPNR_NONINTEREST_INCOME', category:'Revenue', desc:'Pre-provision net revenue — non-interest income', required:true },
      { id:'D03', name:'LOAN_LOSS_PROVISION', category:'Credit', desc:'Provision for loan and lease losses', required:true },
      { id:'D04', name:'NPL_TOTAL', category:'Credit', desc:'Total non-performing loans', required:true },
      { id:'D05', name:'NET_CHARGE_OFF_RATE', category:'Credit', desc:'Net charge-off rate by loan category', required:true },
      { id:'D06', name:'CET1_CAPITAL_RATIO', category:'Capital', desc:'Common Equity Tier 1 capital ratio', required:true },
      { id:'D07', name:'TIER1_CAPITAL_RATIO', category:'Capital', desc:'Tier 1 capital ratio', required:true },
      { id:'D08', name:'TOTAL_RISK_BASED_CAPITAL', category:'Capital', desc:'Total risk-based capital ratio', required:true },
      { id:'D09', name:'LEVERAGE_RATIO', category:'Capital', desc:'Tier 1 leverage ratio', required:true },
      { id:'D10', name:'TOTAL_LOANS_OUTSTANDING', category:'Balance Sheet', desc:'Total loans and leases outstanding', required:true },
      { id:'D11', name:'COMMERCIAL_REAL_ESTATE_LOANS', category:'Balance Sheet', desc:'CRE loan balances', required:true },
      { id:'D12', name:'RESIDENTIAL_MORTGAGE_LOANS', category:'Balance Sheet', desc:'Residential mortgage loan balances', required:true },
      { id:'D13', name:'CONSUMER_LOANS', category:'Balance Sheet', desc:'Total consumer loan balances', required:true },
      { id:'D14', name:'C_AND_I_LOANS', category:'Balance Sheet', desc:'Commercial and industrial loan balances', required:true },
      { id:'D15', name:'AVAILABLE_FOR_SALE_SECURITIES', category:'Balance Sheet', desc:'AFS securities portfolio', required:false },
    ]
  },
  CALL_REPORT: {
    name: 'Call Report (FFIEC 031/041)',
    regulator: 'OCC / FDIC / Federal Reserve',
    frequency: 'Quarterly',
    description: 'Quarterly financial data submission — over 2,400 data items',
    fields: [
      { id:'C01', name:'TOTAL_ASSETS', category:'Balance Sheet', desc:'Total assets RC-A', required:true },
      { id:'C02', name:'TOTAL_DEPOSITS', category:'Liabilities', desc:'Total deposits RC-E', required:true },
      { id:'C03', name:'LOANS_AND_LEASES_NET', category:'Assets', desc:'Net loans and leases RC-B', required:true },
      { id:'C04', name:'ALLOWANCE_CREDIT_LOSSES', category:'Credit', desc:'Allowance for credit losses RC-G', required:true },
      { id:'C05', name:'PAST_DUE_30_89_DAYS', category:'Credit Quality', desc:'Loans 30-89 days past due RC-N', required:true },
      { id:'C06', name:'PAST_DUE_90_PLUS', category:'Credit Quality', desc:'Loans 90+ days past due RC-N', required:true },
      { id:'C07', name:'NONACCRUAL_LOANS', category:'Credit Quality', desc:'Nonaccrual loans RC-N', required:true },
      { id:'C08', name:'CHARGE_OFFS_GROSS', category:'Credit Quality', desc:'Gross charge-offs RIAD-4635', required:true },
      { id:'C09', name:'RECOVERIES', category:'Credit Quality', desc:'Loan recoveries RIAD-4605', required:true },
      { id:'C10', name:'NET_INTEREST_INCOME_YTYL', category:'Income', desc:'Net interest income YTD RI-B', required:true },
      { id:'C11', name:'PROVISION_FOR_LOAN_LOSSES', category:'Income', desc:'Provision for loan losses RI', required:true },
      { id:'C12', name:'NONINTEREST_EXPENSE', category:'Income', desc:'Total noninterest expense RI', required:true },
      { id:'C13', name:'EQUITY_CAPITAL', category:'Capital', desc:'Total equity capital RC-R', required:true },
      { id:'C14', name:'TIER1_CAPITAL', category:'Capital', desc:'Tier 1 capital RC-R', required:true },
      { id:'C15', name:'RISK_WEIGHTED_ASSETS', category:'Capital', desc:'Total risk-weighted assets RC-R', required:true },
    ]
  },
  HMDA: {
    name: 'HMDA — Home Mortgage Disclosure Act',
    regulator: 'CFPB / FFIEC',
    frequency: 'Annual',
    description: 'Mortgage lending data submission to detect fair lending compliance',
    fields: [
      { id:'H01', name:'LOAN_ORIGINATION_AMOUNT', category:'Loan', desc:'Loan amount in dollars', required:true },
      { id:'H02', name:'BORROWER_RACE', category:'Demographic', desc:'Race of applicant (fair lending)', required:true },
      { id:'H03', name:'BORROWER_ETHNICITY', category:'Demographic', desc:'Ethnicity of applicant', required:true },
      { id:'H04', name:'BORROWER_SEX', category:'Demographic', desc:'Sex of applicant', required:true },
      { id:'H05', name:'BORROWER_INCOME', category:'Financial', desc:'Gross annual income', required:true },
      { id:'H06', name:'LOAN_TYPE', category:'Loan', desc:'Conventional/FHA/VA/USDA', required:true },
      { id:'H07', name:'LOAN_PURPOSE', category:'Loan', desc:'Purchase/refinance/home improvement', required:true },
      { id:'H08', name:'OCCUPANCY_TYPE', category:'Property', desc:'Principal/secondary/investment', required:true },
      { id:'H09', name:'PROPERTY_TYPE', category:'Property', desc:'Single family/multifamily/condo', required:true },
      { id:'H10', name:'ACTION_TAKEN', category:'Decision', desc:'Originated/denied/withdrawn etc.', required:true },
      { id:'H11', name:'DENIAL_REASON', category:'Decision', desc:'Reason for denial (1-4)', required:false },
      { id:'H12', name:'RATE_SPREAD', category:'Pricing', desc:'Rate spread over APOR', required:false },
      { id:'H13', name:'HOEPA_STATUS', category:'Compliance', desc:'High-cost mortgage flag', required:true },
      { id:'H14', name:'LIEN_STATUS', category:'Loan', desc:'First/subordinate lien', required:true },
      { id:'H15', name:'CREDIT_SCORE', category:'Financial', desc:'Applicant credit score (new 2018)', required:false },
    ]
  },
  CRA: {
    name: 'CRA — Community Reinvestment Act',
    regulator: 'OCC / Federal Reserve / FDIC',
    frequency: 'Annual',
    description: 'Community investment activity data to prevent redlining',
    fields: [
      { id:'R01', name:'SMALL_BUSINESS_LOAN_COUNT', category:'Lending', desc:'Number of small business loans by census tract', required:true },
      { id:'R02', name:'SMALL_BUSINESS_LOAN_AMOUNT', category:'Lending', desc:'Dollar amount of small business loans', required:true },
      { id:'R03', name:'COMMUNITY_DEVELOPMENT_LOANS', category:'Lending', desc:'Qualified community development loan balances', required:true },
      { id:'R04', name:'CENSUS_TRACT_CODE', category:'Geography', desc:'Census tract for each loan', required:true },
      { id:'R05', name:'LOW_MOD_INCOME_FLAG', category:'Geography', desc:'LMI census tract indicator', required:true },
      { id:'R06', name:'SMALL_FARM_LOANS', category:'Lending', desc:'Agricultural loans to small farms', required:false },
      { id:'R07', name:'CD_INVESTMENT_AMOUNT', category:'Investment', desc:'Community development investment dollars', required:true },
      { id:'R08', name:'CD_SERVICE_HOURS', category:'Service', desc:'Hours of community development service', required:false },
    ]
  },
  BSA_AML: {
    name: 'BSA/AML — Bank Secrecy Act / Anti-Money Laundering',
    regulator: 'FinCEN / OCC',
    frequency: 'Ongoing / Annual',
    description: 'Anti-money laundering program data and SAR/CTR reporting',
    fields: [
      { id:'A01', name:'CTR_CASH_AMOUNT', category:'Transaction', desc:'Currency transaction report amount (>$10K)', required:true },
      { id:'A02', name:'SAR_FLAG', category:'Suspicious Activity', desc:'Suspicious activity report indicator', required:true },
      { id:'A03', name:'CUSTOMER_RISK_RATING', category:'Risk', desc:'AML customer risk rating', required:true },
      { id:'A04', name:'TRANSACTION_TYPE_CODE', category:'Transaction', desc:'Transaction type for monitoring', required:true },
      { id:'A05', name:'BENEFICIAL_OWNER_FLAG', category:'KYC', desc:'Beneficial ownership certification', required:true },
      { id:'A06', name:'PEP_FLAG', category:'KYC', desc:'Politically exposed person indicator', required:true },
      { id:'A07', name:'OFAC_SCREENING_DATE', category:'Compliance', desc:'OFAC sanctions screening date', required:true },
      { id:'A08', name:'WIRE_TRANSFER_COUNTRY', category:'Transaction', desc:'Origination country for wire transfers', required:false },
    ]
  },
};

const STATUS_COLOR = { mapped:'#22c55e', partial:'#f59e0b', unmapped:'#ef4444' };

export default function RegulationRadar() {
  const [fields,   setFields]   = useState([]);
  const [loading,  setLoading]  = useState(true);
  const [selReg,   setSelReg]   = useState('DFAST');
  const [mappings, setMappings] = useState({}); // regFieldId → fieldId
  const [expanded, setExpanded] = useState(null);

  useEffect(() => {
    fetch(`${BASE}/lineage/fields`).then(r=>r.json())
      .then(d=>{
        setFields(d);
        // Auto-map by name similarity
        const autoMap = {};
        Object.entries(REGULATIONS).forEach(([regKey, reg]) => {
          reg.fields.forEach(rf => {
            const patterns = rf.name.split('_').filter(p=>p.length>3);
            const best = d.find(f =>
              patterns.some(p => f.column.toUpperCase().includes(p)) ||
              rf.name.toUpperCase().includes(f.column.toUpperCase())
            );
            if (best) autoMap[rf.id] = best.id;
          });
        });
        setMappings(autoMap);
        setLoading(false);
      }).catch(()=>setLoading(false));
  }, []);

  const reg = REGULATIONS[selReg];
  const regFields = reg.fields;

  const mappedCount   = regFields.filter(rf=>mappings[rf.id]).length;
  const unmappedCount = regFields.filter(rf=>!mappings[rf.id]).length;
  const readiness     = Math.round((mappedCount / regFields.length) * 100);

  const getStatus = (rf) => {
    const mapped = mappings[rf.id];
    if (!mapped) return 'unmapped';
    const f = fields.find(f=>f.id===mapped);
    if (!f) return 'unmapped';
    if (!f.description) return 'partial';
    return 'mapped';
  };

  const readinessColor = readiness >= 90 ? '#22c55e' : readiness >= 70 ? '#f59e0b' : '#ef4444';

  return (
    <div style={{display:'flex',flexDirection:'column',height:'100%',overflow:'hidden'}}>
      {/* Header */}
      <div style={{padding:'12px 16px',flexShrink:0,borderBottom:'1px solid var(--color-border-tertiary)'}}>
        <div style={{display:'flex',alignItems:'center',gap:12,marginBottom:10}}>
          <div>
            <div style={{fontSize:15,fontWeight:500,color:'var(--color-text-primary)'}}>Regulation Radar</div>
            <div style={{fontSize:11,color:'var(--color-text-tertiary)',marginTop:2}}>
              US banking regulatory templates pre-loaded. Auto-maps your physical fields to regulatory submission requirements.
            </div>
          </div>
          <div style={{marginLeft:'auto',display:'flex',gap:6}}>
            <div style={{padding:'8px 14px',background:'var(--color-background-secondary)',
              border:'1px solid var(--color-border-tertiary)',borderRadius:8,textAlign:'center',minWidth:80}}>
              <div style={{fontSize:22,fontWeight:600,color:readinessColor}}>{readiness}%</div>
              <div style={{fontSize:9,color:'var(--color-text-tertiary)'}}>Readiness</div>
            </div>
            <div style={{padding:'8px 14px',background:'var(--color-background-secondary)',
              border:'1px solid var(--color-border-tertiary)',borderRadius:8,textAlign:'center',minWidth:70}}>
              <div style={{fontSize:22,fontWeight:600,color:'#22c55e'}}>{mappedCount}</div>
              <div style={{fontSize:9,color:'var(--color-text-tertiary)'}}>Mapped</div>
            </div>
            <div style={{padding:'8px 14px',background:'var(--color-background-secondary)',
              border:'1px solid var(--color-border-tertiary)',borderRadius:8,textAlign:'center',minWidth:70}}>
              <div style={{fontSize:22,fontWeight:600,color:'#ef4444'}}>{unmappedCount}</div>
              <div style={{fontSize:9,color:'var(--color-text-tertiary)'}}>Unmapped</div>
            </div>
          </div>
        </div>

        {/* Regulation selector */}
        <div style={{display:'flex',gap:6,flexWrap:'wrap'}}>
          {Object.entries(REGULATIONS).map(([key,r])=>{
            const rFields = r.fields;
            const rMapped = rFields.filter(rf=>mappings[rf.id]).length;
            const rPct = Math.round((rMapped/rFields.length)*100);
            const rColor = rPct>=90?'#22c55e':rPct>=70?'#f59e0b':'#ef4444';
            return (
              <button key={key} onClick={()=>setSelReg(key)}
                style={{padding:'5px 12px',fontSize:11,borderRadius:6,cursor:'pointer',
                  background:selReg===key?'var(--color-background-info)':'transparent',
                  color:selReg===key?'var(--color-text-info)':'var(--color-text-secondary)',
                  border:`1px solid ${selReg===key?'var(--color-border-info)':'var(--color-border-secondary)'}`,
                  fontWeight:selReg===key?500:400,display:'flex',alignItems:'center',gap:5}}>
                {key.replace('_',' ')}
                <span style={{fontSize:9,color:rColor,fontWeight:600}}>{rPct}%</span>
              </button>
            );
          })}
          <button onClick={()=>{
            const rows = [['Regulation','Field ID','Regulatory Name','Category','Required','Your Field','Status','Description']];
            regFields.forEach(rf=>{
              const mapped = mappings[rf.id]?fields.find(f=>f.id===mappings[rf.id]):null;
              rows.push([selReg,rf.id,rf.name,rf.category,rf.required?'Yes':'No',
                mapped?.id||'UNMAPPED',getStatus(rf),rf.desc]);
            });
            const csv = rows.map(r=>r.map(c=>`"${c}"`).join(',')).join('\n');
            const blob = new Blob([csv],{type:'text/csv'});
            const a = document.createElement('a');
            a.href=URL.createObjectURL(blob);a.download=`${selReg}-gap-report.csv`;a.click();
          }} style={{marginLeft:'auto',padding:'5px 12px',fontSize:11,borderRadius:6,cursor:'pointer',
            background:'transparent',color:'var(--color-text-secondary)',
            border:'1px solid var(--color-border-secondary)'}}>
            ↓ Gap report CSV
          </button>
        </div>

        {/* Selected regulation info */}
        <div style={{marginTop:8,padding:'8px 12px',background:'var(--color-background-secondary)',
          borderRadius:7,display:'flex',gap:16,alignItems:'center',fontSize:11,flexWrap:'wrap'}}>
          <span style={{fontWeight:500,color:'var(--color-text-primary)'}}>{reg.name}</span>
          <span style={{color:'var(--color-text-tertiary)'}}>Regulator: <strong style={{color:'var(--color-text-secondary)'}}>{reg.regulator}</strong></span>
          <span style={{color:'var(--color-text-tertiary)'}}>Frequency: <strong style={{color:'var(--color-text-secondary)'}}>{reg.frequency}</strong></span>
          <span style={{color:'var(--color-text-tertiary)',flex:1}}>{reg.description}</span>
        </div>
      </div>

      {/* Table */}
      <div style={{flex:1,overflow:'auto'}}>
        {loading ? (
          <div style={{display:'flex',alignItems:'center',justifyContent:'center',height:200,color:'var(--color-text-tertiary)',fontSize:13}}>Loading regulatory templates…</div>
        ) : (
          <table style={{width:'100%',borderCollapse:'collapse',fontSize:11}}>
            <thead style={{position:'sticky',top:0,zIndex:2}}>
              <tr style={{background:'var(--color-background-secondary)'}}>
                {['ID','Regulatory field','Category','Req?','Mapped to','Status',''].map((h,i)=>(
                  <th key={i} style={{padding:'8px 12px',textAlign:'left',fontSize:9,fontWeight:700,
                    color:'var(--color-text-tertiary)',textTransform:'uppercase',letterSpacing:'.08em',
                    borderBottom:'2px solid var(--color-border-secondary)'}}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {regFields.map((rf,i)=>{
                const status = getStatus(rf);
                const mapped = mappings[rf.id] ? fields.find(f=>f.id===mappings[rf.id]) : null;
                const isExp = expanded === rf.id;
                return [
                  <tr key={rf.id} onClick={()=>setExpanded(isExp?null:rf.id)}
                    style={{cursor:'pointer',borderBottom:'1px solid var(--color-border-tertiary)',
                      background:isExp?'var(--color-background-info)':(i%2===0?'transparent':'var(--color-background-secondary)')}}>
                    <td style={{padding:'8px 12px',fontFamily:'monospace',color:'var(--color-text-tertiary)',fontSize:10}}>{rf.id}</td>
                    <td style={{padding:'8px 12px'}}>
                      <div style={{fontWeight:500,color:'var(--color-text-primary)'}}>{rf.name.replace(/_/g,' ')}</div>
                      <div style={{fontSize:10,color:'var(--color-text-tertiary)',marginTop:1}}>{rf.desc}</div>
                    </td>
                    <td style={{padding:'8px 12px'}}>
                      <span style={{fontSize:10,padding:'1px 7px',borderRadius:10,
                        background:'var(--color-background-tertiary)',color:'var(--color-text-secondary)'}}>{rf.category}</span>
                    </td>
                    <td style={{padding:'8px 12px',textAlign:'center'}}>
                      {rf.required
                        ?<span style={{fontSize:9,color:'#ef4444',fontWeight:600}}>REQ</span>
                        :<span style={{fontSize:9,color:'var(--color-text-tertiary)'}}>opt</span>}
                    </td>
                    <td style={{padding:'8px 12px',fontFamily:'monospace',fontSize:10}}>
                      {mapped
                        ?<span style={{color:'#22c55e'}}>{mapped.system}.{mapped.column}</span>
                        :<select onClick={e=>e.stopPropagation()}
                          onChange={e=>setMappings(prev=>({...prev,[rf.id]:e.target.value||undefined}))}
                          style={{fontSize:10,padding:'2px 4px',border:'1px solid var(--color-border-secondary)',
                            borderRadius:4,background:'var(--color-background-primary)',color:'var(--color-text-primary)',maxWidth:180}}>
                          <option value="">Map a field…</option>
                          {fields.slice(0,100).map(f=><option key={f.id} value={f.id}>{f.id}</option>)}
                        </select>
                      }
                    </td>
                    <td style={{padding:'8px 12px'}}>
                      <span style={{fontSize:9,padding:'2px 8px',borderRadius:4,fontWeight:600,
                        background:`${STATUS_COLOR[status]}18`,color:STATUS_COLOR[status],
                        border:`1px solid ${STATUS_COLOR[status]}40`}}>
                        {status==='mapped'?'MAPPED':status==='partial'?'NO DESC':'UNMAPPED'}
                      </span>
                    </td>
                    <td style={{padding:'8px 6px',textAlign:'center',color:'var(--color-text-tertiary)',fontSize:11}}>{isExp?'▲':'▼'}</td>
                  </tr>,
                  isExp && mapped && (
                    <tr key={`${rf.id}-exp`} style={{borderBottom:'2px solid var(--color-border-info)'}}>
                      <td colSpan={7} style={{padding:'10px 16px',background:'var(--color-background-info)'}}>
                        <div style={{display:'flex',gap:20,fontSize:11,flexWrap:'wrap'}}>
                          <div>
                            <div style={{fontSize:9,color:'var(--color-text-tertiary)',textTransform:'uppercase',letterSpacing:'.07em',marginBottom:3}}>Physical field</div>
                            <code style={{color:'var(--color-text-info)'}}>{mapped.id}</code>
                          </div>
                          <div>
                            <div style={{fontSize:9,color:'var(--color-text-tertiary)',textTransform:'uppercase',letterSpacing:'.07em',marginBottom:3}}>Data type</div>
                            <span style={{color:'var(--color-text-secondary)'}}>{mapped.data_type||'unknown'}</span>
                          </div>
                          {mapped.description && <div style={{flex:1}}>
                            <div style={{fontSize:9,color:'var(--color-text-tertiary)',textTransform:'uppercase',letterSpacing:'.07em',marginBottom:3}}>Description</div>
                            <span style={{color:'var(--color-text-secondary)'}}>{mapped.description}</span>
                          </div>}
                          {!mapped.description && (
                            <div style={{color:'#f59e0b',fontSize:11}}>
                              ⚠ No description — add one in the Metadata tab to complete this mapping
                            </div>
                          )}
                        </div>
                      </td>
                    </tr>
                  )
                ];
              })}
            </tbody>
          </table>
        )}
      </div>

      <div style={{flexShrink:0,padding:'6px 16px',borderTop:'1px solid var(--color-border-tertiary)',
        background:'var(--color-background-secondary)',fontSize:10,color:'var(--color-text-tertiary)',display:'flex',gap:16}}>
        <span style={{color:'#22c55e',fontWeight:500}}>Green = fully mapped + described</span>
        <span style={{color:'#f59e0b',fontWeight:500}}>Amber = mapped but missing description</span>
        <span style={{color:'#ef4444',fontWeight:500}}>Red = not mapped to any physical field</span>
        <span style={{marginLeft:'auto'}}>Click row to review · Use dropdown to map manually</span>
      </div>
    </div>
  );
}
