/**
 * Data Lie Detector — detects when the same business metric
 * is computed differently across systems (US banking context)
 * Example: NPL_RATIO computed 3 ways → Fed, board, and risk see different numbers
 */
import { useState, useEffect, useMemo } from 'react';

const BASE = 'http://localhost:8000';

// US Banking metric patterns to detect conflicts
const METRIC_GROUPS = [
  { name: 'NPL / Non-Performing Loans', patterns: ['NPL','NON_PERFORM','NONPERFORM','PAST_DUE_90','DELINQ_90'] },
  { name: 'Net Interest Margin', patterns: ['NIM','NET_INTEREST_MARGIN','NET_INT_MARGIN'] },
  { name: 'Credit Loss / Allowance', patterns: ['ALLL','ACL','ALLOWANCE','CREDIT_LOSS','CECL'] },
  { name: 'Capital Ratio (CET1)', patterns: ['CET1','TIER1','CAPITAL_RATIO','RISK_WEIGHTED'] },
  { name: 'Loan Loss Provision', patterns: ['PROVISION','LOAN_LOSS','LLP','PCL'] },
  { name: 'Outstanding Balance', patterns: ['OUTSTANDING','OUTSTANDING_BAL','CURRENT_BAL','PRINCIPAL_BAL','LEDGER_BAL'] },
  { name: 'Credit Score', patterns: ['CREDIT_SCORE','FICO','VANTAGE','SCORE','COMPOSITE_SCORE'] },
  { name: 'Debt-to-Income', patterns: ['DTI','DEBT_TO_INCOME','DEBT_INCOME'] },
  { name: 'Loan-to-Value', patterns: ['LTV','LOAN_TO_VALUE','LOAN_VALUE'] },
  { name: 'Days Past Due', patterns: ['DPD','DAYS_PAST_DUE','DAYS_DELINQUENT','DELINQ_DAYS'] },
  { name: 'Net Charge-Off', patterns: ['NCO','NET_CHARGE','CHARGE_OFF','WRITEOFF','WRITE_OFF'] },
  { name: 'Exposure at Default', patterns: ['EAD','EXPOSURE_DEFAULT','GROSS_EXPOSURE'] },
];

function conflictScore(fields) {
  // How different are these fields? Check data_type, system diversity, edge count
  const systems = new Set(fields.map(f=>f.system));
  const types = new Set(fields.map(f=>(f.data_type||'').split('(')[0].toUpperCase()));
  let score = 0;
  if (systems.size > 1) score += 40; // across systems = likely conflict
  if (fields.length > 2) score += 20; // many copies = suspicious
  if (types.size > 1) score += 20;    // different data types
  if (fields.some(f=>!f.description)) score += 10; // undocumented
  if (fields.some(f=>f.pii)) score += 10;
  return Math.min(100, score);
}

function RiskBadge({ score }) {
  const color = score >= 70 ? '#ef4444' : score >= 40 ? '#f59e0b' : '#22c55e';
  const label = score >= 70 ? 'HIGH' : score >= 40 ? 'MEDIUM' : 'LOW';
  return (
    <span style={{padding:'2px 8px',borderRadius:4,fontSize:9,fontWeight:700,
      background:`${color}18`,color,border:`1px solid ${color}40`}}>{label}</span>
  );
}

export default function DataLieDetector() {
  const [fields, setFields]   = useState([]);
  const [loading, setLoading] = useState(true);
  const [expanded, setExpanded] = useState(null);
  const [searchQ, setSearchQ] = useState('');
  const [filterRisk, setFilterRisk] = useState('ALL');

  useEffect(() => {
    fetch(`${BASE}/lineage/fields`).then(r=>r.json())
      .then(d=>{setFields(d);setLoading(false);})
      .catch(()=>setLoading(false));
  }, []);

  // Group fields by business metric
  const groups = useMemo(() => {
    const result = [];
    METRIC_GROUPS.forEach(mg => {
      const matched = fields.filter(f =>
        mg.patterns.some(p => f.column.toUpperCase().includes(p))
      );
      if (matched.length < 2) return;
      const systems = [...new Set(matched.map(f=>f.system))];
      if (systems.length < 2) return; // only interesting if across systems
      const score = conflictScore(matched);
      result.push({ ...mg, fields: matched, systems, score });
    });
    return result.sort((a,b)=>b.score-a.score);
  }, [fields]);

  const filtered = groups.filter(g => {
    if (searchQ && !g.name.toLowerCase().includes(searchQ.toLowerCase()) &&
        !g.fields.some(f=>f.column.toLowerCase().includes(searchQ.toLowerCase()))) return false;
    if (filterRisk === 'HIGH' && g.score < 70) return false;
    if (filterRisk === 'MEDIUM' && (g.score < 40 || g.score >= 70)) return false;
    if (filterRisk === 'LOW' && g.score >= 40) return false;
    return true;
  });

  const highCount = groups.filter(g=>g.score>=70).length;
  const medCount  = groups.filter(g=>g.score>=40&&g.score<70).length;

  return (
    <div style={{display:'flex',flexDirection:'column',height:'100%',overflow:'hidden'}}>
      {/* Header */}
      <div style={{padding:'12px 16px 0',flexShrink:0}}>
        <div style={{display:'flex',alignItems:'center',gap:10,marginBottom:12}}>
          <div>
            <div style={{fontSize:15,fontWeight:500,color:'var(--color-text-primary)'}}>
              Data Lie Detector
            </div>
            <div style={{fontSize:11,color:'var(--color-text-tertiary)',marginTop:2}}>
              Detects when the same business metric is computed differently across systems — your Fed examiner will find these if you don't.
            </div>
          </div>
          <div style={{marginLeft:'auto',display:'flex',gap:8}}>
            {[
              {label:'High risk conflicts', value:highCount, color:'#ef4444'},
              {label:'Medium risk', value:medCount, color:'#f59e0b'},
              {label:'Total metric groups', value:groups.length, color:'var(--color-text-primary)'},
            ].map((s,i)=>(
              <div key={i} style={{padding:'8px 14px',background:'var(--color-background-secondary)',
                border:'1px solid var(--color-border-tertiary)',borderRadius:8,textAlign:'center',minWidth:80}}>
                <div style={{fontSize:20,fontWeight:600,color:s.color}}>{loading?'…':s.value}</div>
                <div style={{fontSize:9,color:'var(--color-text-tertiary)',whiteSpace:'nowrap'}}>{s.label}</div>
              </div>
            ))}
          </div>
        </div>

        {/* Filters */}
        <div style={{display:'flex',gap:6,marginBottom:10,flexWrap:'wrap',alignItems:'center'}}>
          <div style={{position:'relative'}}>
            <input value={searchQ} onChange={e=>setSearchQ(e.target.value)}
              placeholder="Search metrics or fields…"
              style={{padding:'5px 8px 5px 24px',fontSize:11,border:'1px solid var(--color-border-secondary)',
                borderRadius:6,background:'var(--color-background-secondary)',color:'var(--color-text-primary)',width:200}}/>
            <span style={{position:'absolute',left:7,top:'50%',transform:'translateY(-50%)',fontSize:11,color:'var(--color-text-tertiary)'}}>⌕</span>
          </div>
          {['ALL','HIGH','MEDIUM','LOW'].map(r=>(
            <button key={r} onClick={()=>setFilterRisk(r)}
              style={{padding:'4px 10px',fontSize:11,borderRadius:20,cursor:'pointer',
                background:filterRisk===r?'var(--color-background-info)':'transparent',
                color:filterRisk===r?'var(--color-text-info)':'var(--color-text-secondary)',
                border:`1px solid ${filterRisk===r?'var(--color-border-info)':'var(--color-border-secondary)'}`}}>
              {r}
            </button>
          ))}
          <span style={{marginLeft:'auto',fontSize:10,color:'var(--color-text-tertiary)'}}>
            {filtered.length} metric conflicts found
          </span>
        </div>
      </div>

      {/* Table */}
      <div style={{flex:1,overflow:'auto'}}>
        {loading ? (
          <div style={{display:'flex',alignItems:'center',justifyContent:'center',height:200,
            color:'var(--color-text-tertiary)',fontSize:13}}>Scanning all fields for metric conflicts…</div>
        ) : filtered.length === 0 ? (
          <div style={{display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',
            height:200,gap:8,color:'var(--color-text-tertiary)'}}>
            <div style={{fontSize:32,opacity:.3}}>✓</div>
            <div style={{fontSize:13,fontWeight:500,color:'var(--color-text-secondary)'}}>No metric conflicts detected</div>
            <div style={{fontSize:11}}>All business metrics appear to be computed consistently across systems</div>
          </div>
        ) : (
          <table style={{width:'100%',borderCollapse:'collapse',fontSize:11}}>
            <thead style={{position:'sticky',top:0,zIndex:2}}>
              <tr style={{background:'var(--color-background-secondary)'}}>
                {['Business Metric','Risk','Systems Affected','Field Count','Conflict Detail',''].map((h,i)=>(
                  <th key={i} style={{padding:'8px 12px',textAlign:i>=3?'center':'left',fontSize:9,fontWeight:700,
                    color:'var(--color-text-tertiary)',textTransform:'uppercase',letterSpacing:'.08em',
                    borderBottom:'2px solid var(--color-border-secondary)',whiteSpace:'nowrap'}}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filtered.map((g,i) => {
                const isExp = expanded === g.name;
                return [
                  <tr key={g.name}
                    onClick={()=>setExpanded(isExp?null:g.name)}
                    style={{cursor:'pointer',borderBottom:'1px solid var(--color-border-tertiary)',
                      background:isExp?'var(--color-background-info)':(i%2===0?'transparent':'var(--color-background-secondary)')}}>
                    <td style={{padding:'10px 12px',fontWeight:500,color:'var(--color-text-primary)'}}>{g.name}</td>
                    <td style={{padding:'10px 12px'}}><RiskBadge score={g.score}/></td>
                    <td style={{padding:'10px 12px'}}>
                      <div style={{display:'flex',gap:4,flexWrap:'wrap'}}>
                        {g.systems.map(s=>(
                          <span key={s} style={{padding:'1px 7px',borderRadius:10,fontSize:10,
                            background:'var(--color-background-tertiary)',color:'var(--color-text-secondary)',
                            border:'0.5px solid var(--color-border-secondary)'}}>{s}</span>
                        ))}
                      </div>
                    </td>
                    <td style={{padding:'10px 12px',textAlign:'center',color:'var(--color-text-secondary)'}}>
                      {g.fields.length} fields
                    </td>
                    <td style={{padding:'10px 12px',color:'var(--color-text-secondary)'}}>
                      {g.score>=70?'Different formulas likely — requires reconciliation':
                       g.score>=40?'Possibly same source, different aggregation logic':
                       'Minor naming variation — verify same calculation'}
                    </td>
                    <td style={{padding:'10px 12px',textAlign:'center',color:'var(--color-text-tertiary)',fontSize:12}}>
                      {isExp?'▲':'▼'}
                    </td>
                  </tr>,
                  isExp && (
                    <tr key={`${g.name}-exp`} style={{borderBottom:'2px solid var(--color-border-info)'}}>
                      <td colSpan={6} style={{padding:'14px 16px',background:'var(--color-background-info)'}}>
                        <div style={{marginBottom:10,fontSize:11,fontWeight:500,color:'var(--color-text-primary)'}}>
                          Conflicting field definitions for "{g.name}"
                        </div>
                        <div style={{display:'flex',gap:8,flexWrap:'wrap',marginBottom:10}}>
                          {g.fields.map(f=>(
                            <div key={f.id} style={{padding:'10px 14px',borderRadius:8,
                              background:'var(--color-background-primary)',
                              border:'0.5px solid var(--color-border-secondary)',minWidth:200}}>
                              <div style={{fontSize:11,fontWeight:600,color:'var(--color-text-primary)',marginBottom:3}}>{f.column}</div>
                              <div style={{fontSize:10,color:'var(--color-text-secondary)',marginBottom:3}}>{f.system} · {f.table}</div>
                              <div style={{fontSize:10,color:'var(--color-text-tertiary)',fontFamily:'monospace'}}>{f.data_type||'unknown type'}</div>
                              {f.description && <div style={{fontSize:10,color:'var(--color-text-secondary)',marginTop:5,lineHeight:1.5,borderTop:'0.5px solid var(--color-border-tertiary)',paddingTop:5}}>{f.description.slice(0,80)}</div>}
                              {!f.description && <div style={{fontSize:10,color:'var(--color-text-tertiary)',marginTop:5,fontStyle:'italic'}}>No description — source of confusion</div>}
                            </div>
                          ))}
                        </div>
                        <div style={{padding:'8px 12px',borderRadius:7,background:'rgba(239,68,68,0.06)',
                          border:'0.5px solid rgba(239,68,68,0.2)',fontSize:11,color:'var(--color-text-secondary)',lineHeight:1.6}}>
                          <strong style={{color:'#ef4444'}}>Examiner risk:</strong> Fed / OCC examiners compare your DFAST submission, Call Report and internal board pack. 
                          If these fields compute "{g.name}" differently, your numbers won't reconcile. 
                          Use the <strong>Map Fields</strong> tab to document which definition is authoritative.
                        </div>
                      </td>
                    </tr>
                  )
                ];
              })}
            </tbody>
          </table>
        )}
      </div>

      {/* Footer */}
      <div style={{flexShrink:0,padding:'6px 16px',borderTop:'1px solid var(--color-border-tertiary)',
        background:'var(--color-background-secondary)',fontSize:10,color:'var(--color-text-tertiary)',
        display:'flex',gap:16}}>
        <span>Scans column names across all systems for semantic duplicates</span>
        <span>High risk = same metric in 2+ systems with different data types or no lineage connection</span>
        <span style={{marginLeft:'auto'}}>Click any row to see conflicting field definitions</span>
      </div>
    </div>
  );
}
