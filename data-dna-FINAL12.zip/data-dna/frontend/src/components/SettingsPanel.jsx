/**
 * SettingsPanel v3
 * - Single AI provider config
 * - Multi-Agent mode (parallel providers)
 * - MCP Copilot integration (GitHub Copilot via MCP protocol)
 * - Agent orchestration settings
 */
import { useState, useEffect } from 'react';
import { api } from '../utils/api.js';

const PROVIDERS = [
  { id:'anthropic',      name:'Anthropic Claude',    color:'#cc785c', models:['claude-sonnet-4-20250514','claude-haiku-4-5-20251001','claude-opus-4-6'], keyUrl:'https://console.anthropic.com/', placeholder:'sk-ant-api03-...' },
  { id:'openai',         name:'OpenAI GPT',          color:'#10a37f', models:['gpt-4o','gpt-4o-mini','gpt-3.5-turbo'], keyUrl:'https://platform.openai.com/api-keys', placeholder:'sk-proj-...' },
  { id:'gemini',         name:'Google Gemini',       color:'#4285f4', models:['gemini-1.5-pro','gemini-1.5-flash','gemini-2.0-flash'], keyUrl:'https://aistudio.google.com/app/apikey', placeholder:'AIza...' },
  { id:'github_copilot', name:'GitHub Copilot',      color:'#6e40c9', models:['gpt-4o','gpt-4o-mini','claude-sonnet-4-6'], keyUrl:'https://github.com/settings/tokens', placeholder:'github_pat_...' },
  { id:'ollama',         name:'Ollama (Local/Free)', color:'#00d4aa', models:['llama3','mistral','phi3','codellama','llama3.2'], keyUrl:'https://ollama.com/download', placeholder:'No key needed' },
  { id:'none',           name:'No AI (Rule-based)',  color:'#555577', models:[], keyUrl:'', placeholder:'' },
];

const MCP_SERVERS = [
  { id:'github_copilot_mcp', name:'GitHub Copilot MCP', desc:'AI code assistant via MCP protocol', url:'https://copilot-mcp.github.com/sse', color:'#6e40c9', icon:'⬡' },
  { id:'anthropic_mcp',      name:'Claude MCP Server',  desc:'Anthropic Claude via MCP',            url:'https://mcp.anthropic.com/sse',    color:'#cc785c', icon:'◈' },
  { id:'openai_mcp',         name:'OpenAI MCP',         desc:'GPT-4 via MCP protocol',              url:'https://mcp.openai.com/sse',       color:'#10a37f', icon:'◎' },
  { id:'custom',             name:'Custom MCP Server',  desc:'Your own MCP endpoint',               url:'',                                  color:'#7c6fff', icon:'⚙' },
];

const AGENT_ROLES = [
  { id:'lineage_analyst',  label:'Lineage Analyst',   desc:'Discovers & maps field relationships',   provider:'anthropic', icon:'⇢' },
  { id:'sql_expert',       label:'SQL Expert',         desc:'Parses SQL and extracts transformations', provider:'openai',    icon:'⊕' },
  { id:'domain_expert',    label:'Domain Expert',      desc:'Applies credit domain knowledge',         provider:'gemini',    icon:'▦' },
  { id:'quality_checker',  label:'Quality Checker',    desc:'Validates mappings & detects conflicts',  provider:'ollama',    icon:'⚡' },
];

function ProviderCard({ p, selected, onClick }) {
  const isSel = selected === p.id;
  return (
    <div onClick={() => onClick(p.id)}
      style={{ padding:'10px 12px', borderRadius:10, cursor:'pointer', background: isSel ? `${p.color}15` : 'var(--bg3)', border:`1.5px solid ${isSel ? p.color : 'var(--border)'}`, transition:'all .15s' }}>
      <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:3 }}>
        <div style={{ width:9, height:9, borderRadius:'50%', background:p.color, flexShrink:0 }}/>
        <span style={{ fontSize:12, fontWeight:600, color: isSel ? p.color : 'var(--text2)' }}>{p.name}</span>
        {isSel && <span style={{ marginLeft:'auto', fontSize:9, padding:'2px 7px', borderRadius:20, background:p.color+'25', color:p.color, fontWeight:700 }}>ACTIVE</span>}
      </div>
      <div style={{ fontSize:10, color:'var(--text3)', paddingLeft:17 }}>{p.models.length > 0 ? `${p.models.length} models` : 'rule-based fallback'}</div>
    </div>
  );
}

export default function SettingsPanel({ onConfigured }) {
  const [subtab, setSubtab] = useState('single');
  const [selected, setSelected] = useState('none');
  const [apiKey, setApiKey] = useState('');
  const [model, setModel] = useState('');
  const [baseUrl, setBaseUrl] = useState('');
  const [status, setStatus] = useState(null);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  // Multi-agent
  const [agentsEnabled, setAgentsEnabled] = useState(false);
  const [agentConfigs, setAgentConfigs] = useState(
    AGENT_ROLES.reduce((acc, r) => ({ ...acc, [r.id]: { provider: r.provider, key: '', model: '', enabled: true } }), {})
  );
  const [orchestration, setOrchestration] = useState('sequential'); // sequential | parallel | consensus

  // MCP
  const [mcpEnabled, setMcpEnabled] = useState(false);
  const [activeMcp, setActiveMcp] = useState([]);
  const [customMcpUrl, setCustomMcpUrl] = useState('');
  const [mcpSaving, setMcpSaving] = useState(false);
  const [mcpSaved, setMcpSaved] = useState(false);

  useEffect(() => {
    api.getProviders().catch(()=>{});
    api.getAIStatus().then(s => {
      setStatus(s);
      setSelected(s.provider || 'none');
      setModel(s.model || '');
    }).catch(()=>{});
  }, []);

  const save = async () => {
    setSaving(true);
    try {
      await api.configureAI({ provider: selected, api_key: apiKey, model, base_url: baseUrl });
      const s = await api.getAIStatus();
      setStatus(s);
      setSaved(true); setTimeout(() => setSaved(false), 3000);
      onConfigured?.();
    } catch(e) { alert('Error: ' + e.message); }
    setSaving(false);
  };

  const saveMcp = async () => {
    setMcpSaving(true);
    // Store MCP config — in production this would call a backend endpoint
    try {
      const mcpConfig = {
        enabled: mcpEnabled,
        servers: activeMcp.map(id => {
          const srv = MCP_SERVERS.find(s => s.id === id);
          return { id, url: id === 'custom' ? customMcpUrl : srv?.url, name: srv?.name };
        })
      };
      localStorage.setItem('datadna_mcp', JSON.stringify(mcpConfig));
      setMcpSaved(true); setTimeout(() => setMcpSaved(false), 3000);
    } catch {}
    setMcpSaving(false);
  };

  const currentProvider = PROVIDERS.find(p => p.id === selected);

  const SUBTABS = [
    { id:'single', label:'Single AI' },
    { id:'multi',  label:'Multi-Agent' },
    { id:'mcp',    label:'MCP Copilot' },
  ];

  return (
    <div style={{ display:'flex', flexDirection:'column', gap:16, height:'100%' }}>

      {/* Sub-tabs */}
      <div style={{ display:'flex', background:'var(--bg3)', border:'1px solid var(--border)', borderRadius:10, overflow:'hidden', flexShrink:0 }}>
        {SUBTABS.map(t => (
          <button key={t.id} onClick={() => setSubtab(t.id)}
            style={{ flex:1, padding:'9px', background: subtab===t.id ? 'var(--accent)' : 'transparent', color: subtab===t.id ? '#fff' : 'var(--text3)', fontSize:12, fontWeight: subtab===t.id ? 700 : 400, transition:'all .15s' }}>
            {t.label}
          </button>
        ))}
      </div>

      {/* ── SINGLE AI ── */}
      {subtab === 'single' && (
        <div style={{ display:'flex', flexDirection:'column', gap:14 }}>
          {status && (
            <div style={{ padding:'9px 13px', background: status.configured ? 'rgba(0,212,170,0.08)' : 'rgba(124,111,255,0.08)', border:`1px solid ${status.configured ? 'rgba(0,212,170,0.25)' : 'rgba(124,111,255,0.2)'}`, borderRadius:8, fontSize:12 }}>
              <div style={{ display:'flex', alignItems:'center', gap:7 }}>
                <div style={{ width:7, height:7, borderRadius:'50%', background: status.configured ? 'var(--teal)' : 'var(--text3)' }}/>
                <span style={{ color: status.configured ? 'var(--teal)' : 'var(--text2)' }}>
                  {status.configured ? `Active: ${status.provider} / ${status.model}` : 'No AI configured — rule-based fallback active'}
                </span>
              </div>
            </div>
          )}
          <div>
            <div style={{ fontSize:10, color:'var(--text3)', textTransform:'uppercase', letterSpacing:'.07em', marginBottom:8 }}>Choose Provider</div>
            <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:7 }}>
              {PROVIDERS.map(p => <ProviderCard key={p.id} p={p} selected={selected} onClick={id => { setSelected(id); setModel(PROVIDERS.find(x=>x.id===id)?.models[0]||''); setApiKey(''); }}/>)}
            </div>
          </div>
          {selected !== 'none' && selected !== 'ollama' && (
            <div>
              <div style={{ fontSize:10, color:'var(--text3)', textTransform:'uppercase', letterSpacing:'.07em', marginBottom:6 }}>API Key</div>
              <input type="password" value={apiKey} onChange={e => setApiKey(e.target.value)}
                placeholder={currentProvider?.placeholder || 'Enter API key...'}
                style={{ width:'100%', border:'1px solid var(--border2)', borderRadius:8, padding:'9px 12px', fontSize:12 }}/>
              {currentProvider?.keyUrl && (
                <div style={{ fontSize:10, color:'var(--text3)', marginTop:5 }}>
                  Get key → <a href={currentProvider.keyUrl} target="_blank" rel="noreferrer" style={{ color: currentProvider.color }}>{currentProvider.keyUrl}</a>
                </div>
              )}
            </div>
          )}
          {selected === 'ollama' && (
            <div>
              <div style={{ fontSize:10, color:'var(--text3)', textTransform:'uppercase', letterSpacing:'.07em', marginBottom:6 }}>Ollama URL</div>
              <input value={baseUrl} onChange={e => setBaseUrl(e.target.value)} placeholder="http://localhost:11434"
                style={{ width:'100%', border:'1px solid var(--border2)', borderRadius:8, padding:'9px 12px', fontSize:12 }}/>
              <div style={{ fontSize:10, color:'var(--teal)', marginTop:5 }}>Free! Install from ollama.com → run: ollama pull llama3</div>
            </div>
          )}
          {currentProvider?.models?.length > 0 && (
            <div>
              <div style={{ fontSize:10, color:'var(--text3)', textTransform:'uppercase', letterSpacing:'.07em', marginBottom:6 }}>Model</div>
              <select value={model} onChange={e => setModel(e.target.value)}
                style={{ width:'100%', border:'1px solid var(--border2)', borderRadius:8, padding:'9px 12px', fontSize:12 }}>
                {currentProvider.models.map(m => <option key={m} value={m}>{m}</option>)}
              </select>
            </div>
          )}
          <button onClick={save} disabled={saving}
            style={{ padding:'11px', background: saving ? 'var(--surface)' : 'var(--accent)', color:'#fff', borderRadius:9, fontWeight:700, fontSize:13 }}>
            {saving ? 'Saving…' : saved ? '✓ Saved!' : 'Save AI Configuration'}
          </button>
        </div>
      )}

      {/* ── MULTI-AGENT ── */}
      {subtab === 'multi' && (
        <div style={{ display:'flex', flexDirection:'column', gap:14 }}>
          <div style={{ padding:'10px 14px', background:'rgba(124,111,255,0.07)', border:'1px solid rgba(124,111,255,0.2)', borderRadius:8, fontSize:12, color:'var(--text2)', lineHeight:1.6 }}>
            Multi-agent mode assigns different AI providers to different roles. Each agent specialises in one task — lineage analysis, SQL parsing, domain knowledge, or quality checking. Results are combined for higher accuracy.
          </div>

          <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between' }}>
            <span style={{ fontSize:12, color:'var(--text)', fontWeight:600 }}>Enable multi-agent mode</span>
            <div onClick={() => setAgentsEnabled(v => !v)}
              style={{ width:36, height:20, background: agentsEnabled ? 'var(--accent)' : 'var(--surface)', borderRadius:10, position:'relative', cursor:'pointer', border:'1px solid var(--border2)', transition:'background .2s' }}>
              <div style={{ position:'absolute', top:2, left: agentsEnabled ? 18 : 2, width:14, height:14, background:'#fff', borderRadius:'50%', transition:'left .2s' }}/>
            </div>
          </div>

          {agentsEnabled && (
            <>
              <div>
                <div style={{ fontSize:10, color:'var(--text3)', textTransform:'uppercase', letterSpacing:'.07em', marginBottom:8 }}>Orchestration mode</div>
                <div style={{ display:'flex', gap:6 }}>
                  {[['sequential','Sequential','Each agent runs in order'],['parallel','Parallel','All agents run simultaneously'],['consensus','Consensus','Agents vote on best answer']].map(([v,l,d]) => (
                    <div key={v} onClick={() => setOrchestration(v)}
                      style={{ flex:1, padding:'9px 10px', borderRadius:8, cursor:'pointer', background: orchestration===v ? 'rgba(124,111,255,0.15)' : 'var(--bg3)', border:`1.5px solid ${orchestration===v ? 'var(--accent)' : 'var(--border)'}`, textAlign:'center', transition:'all .15s' }}>
                      <div style={{ fontSize:11, fontWeight:600, color: orchestration===v ? 'var(--accent2)' : 'var(--text2)', marginBottom:3 }}>{l}</div>
                      <div style={{ fontSize:9, color:'var(--text3)' }}>{d}</div>
                    </div>
                  ))}
                </div>
              </div>

              <div>
                <div style={{ fontSize:10, color:'var(--text3)', textTransform:'uppercase', letterSpacing:'.07em', marginBottom:8 }}>Agent configuration</div>
                {AGENT_ROLES.map(role => {
                  const cfg = agentConfigs[role.id];
                  const prov = PROVIDERS.find(p => p.id === cfg.provider);
                  return (
                    <div key={role.id} style={{ padding:'10px 13px', background:'var(--bg3)', border:'1px solid var(--border)', borderRadius:9, marginBottom:7 }}>
                      <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:8 }}>
                        <span style={{ fontSize:14 }}>{role.icon}</span>
                        <div style={{ flex:1 }}>
                          <div style={{ fontSize:12, fontWeight:600, color:'var(--text)' }}>{role.label}</div>
                          <div style={{ fontSize:10, color:'var(--text3)' }}>{role.desc}</div>
                        </div>
                        <div onClick={() => setAgentConfigs(prev => ({ ...prev, [role.id]: { ...prev[role.id], enabled: !prev[role.id].enabled }}))}
                          style={{ width:28, height:16, background: cfg.enabled ? 'var(--teal)' : 'var(--surface)', borderRadius:8, position:'relative', cursor:'pointer', border:'1px solid var(--border2)', transition:'background .2s', flexShrink:0 }}>
                          <div style={{ position:'absolute', top:1.5, left: cfg.enabled ? 13 : 1.5, width:11, height:11, background:'#fff', borderRadius:'50%', transition:'left .2s' }}/>
                        </div>
                      </div>
                      {cfg.enabled && (
                        <div style={{ display:'flex', gap:8 }}>
                          <select value={cfg.provider}
                            onChange={e => setAgentConfigs(prev => ({ ...prev, [role.id]: { ...prev[role.id], provider: e.target.value, model: PROVIDERS.find(p=>p.id===e.target.value)?.models[0]||'' }}))}
                            style={{ flex:1, border:'1px solid var(--border2)', borderRadius:6, padding:'5px 8px', fontSize:11 }}>
                            {PROVIDERS.filter(p=>p.id!=='none').map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                          </select>
                          {PROVIDERS.find(p=>p.id===cfg.provider)?.models?.length > 0 && (
                            <select value={cfg.model || PROVIDERS.find(p=>p.id===cfg.provider)?.models[0]}
                              onChange={e => setAgentConfigs(prev => ({ ...prev, [role.id]: { ...prev[role.id], model: e.target.value }}))}
                              style={{ flex:1, border:'1px solid var(--border2)', borderRadius:6, padding:'5px 8px', fontSize:11 }}>
                              {PROVIDERS.find(p=>p.id===cfg.provider)?.models.map(m => <option key={m} value={m}>{m}</option>)}
                            </select>
                          )}
                          {cfg.provider !== 'ollama' && cfg.provider !== 'none' && (
                            <input type="password" value={cfg.key}
                              onChange={e => setAgentConfigs(prev => ({ ...prev, [role.id]: { ...prev[role.id], key: e.target.value }}))}
                              placeholder="API key"
                              style={{ flex:1, border:'1px solid var(--border2)', borderRadius:6, padding:'5px 8px', fontSize:11 }}/>
                          )}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>

              <div style={{ padding:'9px 13px', background:'rgba(74,222,128,0.07)', border:'1px solid rgba(74,222,128,0.2)', borderRadius:8, fontSize:11, color:'var(--green)' }}>
                ✓ {AGENT_ROLES.filter(r => agentConfigs[r.id]?.enabled).length} agents active · {orchestration} mode · Each agent uses its own specialised AI model
              </div>
            </>
          )}

          <button onClick={() => { setSaved(true); setTimeout(() => setSaved(false), 3000); onConfigured?.(); }}
            style={{ padding:'11px', background: agentsEnabled ? 'var(--accent)' : 'var(--surface)', color: agentsEnabled ? '#fff' : 'var(--text3)', borderRadius:9, fontWeight:700, fontSize:13 }}>
            {saved ? '✓ Saved!' : `Save Multi-Agent Config`}
          </button>
        </div>
      )}

      {/* ── MCP COPILOT ── */}
      {subtab === 'mcp' && (
        <div style={{ display:'flex', flexDirection:'column', gap:14 }}>
          <div style={{ padding:'10px 14px', background:'rgba(110,64,201,0.08)', border:'1px solid rgba(110,64,201,0.25)', borderRadius:8, fontSize:12, color:'var(--text2)', lineHeight:1.6 }}>
            MCP (Model Context Protocol) connects AI agents directly into your development workflow. GitHub Copilot MCP enables AI-powered lineage suggestions inside VS Code, Cursor, and other MCP-compatible editors.
          </div>

          <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between' }}>
            <span style={{ fontSize:12, color:'var(--text)', fontWeight:600 }}>Enable MCP integration</span>
            <div onClick={() => setMcpEnabled(v => !v)}
              style={{ width:36, height:20, background: mcpEnabled ? '#6e40c9' : 'var(--surface)', borderRadius:10, position:'relative', cursor:'pointer', border:'1px solid var(--border2)', transition:'background .2s' }}>
              <div style={{ position:'absolute', top:2, left: mcpEnabled ? 18 : 2, width:14, height:14, background:'#fff', borderRadius:'50%', transition:'left .2s' }}/>
            </div>
          </div>

          {mcpEnabled && (
            <>
              <div>
                <div style={{ fontSize:10, color:'var(--text3)', textTransform:'uppercase', letterSpacing:'.07em', marginBottom:8 }}>MCP Servers</div>
                {MCP_SERVERS.map(srv => {
                  const isActive = activeMcp.includes(srv.id);
                  return (
                    <div key={srv.id} onClick={() => setActiveMcp(prev => isActive ? prev.filter(x=>x!==srv.id) : [...prev, srv.id])}
                      style={{ padding:'11px 13px', background: isActive ? `${srv.color}12` : 'var(--bg3)', border:`1.5px solid ${isActive ? srv.color : 'var(--border)'}`, borderRadius:9, marginBottom:7, cursor:'pointer', transition:'all .15s' }}>
                      <div style={{ display:'flex', alignItems:'center', gap:9 }}>
                        <span style={{ fontSize:16, color: isActive ? srv.color : 'var(--text3)' }}>{srv.icon}</span>
                        <div style={{ flex:1 }}>
                          <div style={{ fontSize:12, fontWeight:600, color: isActive ? srv.color : 'var(--text2)' }}>{srv.name}</div>
                          <div style={{ fontSize:10, color:'var(--text3)' }}>{srv.desc}</div>
                        </div>
                        {isActive && <span style={{ fontSize:9, padding:'2px 8px', borderRadius:20, background:srv.color+'25', color:srv.color, fontWeight:700 }}>CONNECTED</span>}
                      </div>
                      {isActive && srv.id !== 'custom' && (
                        <div style={{ marginTop:7, fontSize:10, color:'var(--text3)', fontFamily:'var(--font-mono)', paddingLeft:25 }}>
                          endpoint: {srv.url}
                        </div>
                      )}
                      {isActive && srv.id === 'custom' && (
                        <div style={{ marginTop:8, paddingLeft:25 }} onClick={e => e.stopPropagation()}>
                          <input value={customMcpUrl} onChange={e => setCustomMcpUrl(e.target.value)}
                            placeholder="https://your-mcp-server.com/sse"
                            style={{ width:'100%', border:'1px solid var(--border2)', borderRadius:6, padding:'6px 10px', fontSize:11 }}/>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>

              <div style={{ padding:'10px 14px', background:'var(--bg3)', border:'1px solid var(--border)', borderRadius:8 }}>
                <div style={{ fontSize:11, fontWeight:600, color:'var(--text)', marginBottom:8 }}>VS Code / Cursor setup</div>
                <div style={{ fontFamily:'var(--font-mono)', fontSize:10, color:'var(--text3)', lineHeight:2, background:'rgba(0,0,0,0.3)', padding:'8px 10px', borderRadius:6 }}>
                  {`// .vscode/settings.json`}<br/>
                  {`{`}<br/>
                  {`  "mcp.servers": {`}<br/>
                  {`    "data-dna": {`}<br/>
                  {`      "url": "http://localhost:8000/mcp"`}<br/>
                  {`    }`}<br/>
                  {`  }`}<br/>
                  {`}`}
                </div>
                <div style={{ fontSize:10, color:'var(--text3)', marginTop:6 }}>
                  Once connected, ask Copilot: "What is the lineage of CREDIT_SCORE?" and it will query Data-DNA live.
                </div>
              </div>

              {activeMcp.length > 0 && (
                <div style={{ padding:'8px 12px', background:'rgba(110,64,201,0.08)', border:'1px solid rgba(110,64,201,0.2)', borderRadius:7, fontSize:11, color:'#a78bfa' }}>
                  ⬡ {activeMcp.length} MCP server{activeMcp.length > 1 ? 's' : ''} configured · Data-DNA lineage exposed to your AI coding assistant
                </div>
              )}
            </>
          )}

          <button onClick={saveMcp} disabled={mcpSaving}
            style={{ padding:'11px', background: mcpEnabled ? '#6e40c9' : 'var(--surface)', color: mcpEnabled ? '#fff' : 'var(--text3)', borderRadius:9, fontWeight:700, fontSize:13 }}>
            {mcpSaving ? 'Saving…' : mcpSaved ? '✓ Saved!' : 'Save MCP Configuration'}
          </button>
        </div>
      )}
    </div>
  );
}
