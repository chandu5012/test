/**
 * LineageGraph v6 — Enterprise Real-Time Data Lineage
 * Designed for 5000 systems, 100K tables — fully virtualized & on-demand
 *
 * ARCHITECTURE:
 *   Level 1: System view    — select a system → see its upstream/downstream systems
 *   Level 2: Table view     — select a table → see source/target tables with edge count
 *   Level 3: Field mapping  — select source+target table → bezier field-level mapping
 *   + Force graph  (D3, lazy-loaded per system)
 *   + Layered view (left→right bands)
 *
 * NO rendering of all nodes at once. Everything is on-demand.
 */
import { useEffect, useRef, useState, useCallback, useMemo } from 'react';
import * as d3 from 'd3';

const BASE = 'http://localhost:8000';

// Dynamic color assignment — not hardcoded, supports 5000 systems
const COLOR_PALETTE = [
  '#00d4aa','#7c6fff','#4fc3f7','#ffb347','#ff5a7d',
  '#00b896','#ab47bc','#26c6da','#ff8f00','#ec407a',
  '#64b5f6','#a5d6a7','#fff176','#ffcc80','#ef9a9a',
];
const sysColorMap = {};
let colorIdx = 0;
const sc = s => {
  if (!sysColorMap[s]) sysColorMap[s] = COLOR_PALETTE[colorIdx++ % COLOR_PALETTE.length];
  return sysColorMap[s];
};

const TC = {
  direct:'#00d4aa', renamed:'#4fc3f7', aggregated:'#ffb347',
  derived:'#ab47bc', filtered:'#ec407a', joined:'#ff8f00',
};

/* ═══════════════════════════════════════════════════════════════
   UTILITIES
═══════════════════════════════════════════════════════════════ */
function buildIndex(data) {
  // Build comprehensive lookup structures once
  const bySystem = {};
  const byTable  = {};
  const edgeBySrcSys = {};  // src_sys → [edges]
  const edgeByTgtSys = {};  // tgt_sys → [edges]
  const edgeBySrcTbl = {};  // src_sys.src_tbl → [edges]
  const edgeByTgtTbl = {};  // tgt_sys.tgt_tbl → [edges]

  (data?.nodes || []).forEach(n => {
    if (!bySystem[n.system]) bySystem[n.system] = { tables: {}, count: 0 };
    if (!bySystem[n.system].tables[n.table]) bySystem[n.system].tables[n.table] = [];
    bySystem[n.system].tables[n.table].push(n);
    bySystem[n.system].count++;
    byTable[`${n.system}.${n.table}`] = byTable[`${n.system}.${n.table}`] || [];
    byTable[`${n.system}.${n.table}`].push(n);
  });

  (data?.links || []).forEach(l => {
    const sid = typeof l.source === 'object' ? l.source.id : l.source;
    const tid = typeof l.target === 'object' ? l.target.id : l.target;
    const [ss, st] = sid.split('.');
    const [ts, tt] = tid.split('.');
    if (!ss || !ts) return;

    if (!edgeBySrcSys[ss]) edgeBySrcSys[ss] = [];
    edgeBySrcSys[ss].push(l);
    if (!edgeByTgtSys[ts]) edgeByTgtSys[ts] = [];
    edgeByTgtSys[ts].push(l);

    const sk = `${ss}.${st}`, tk = `${ts}.${tt}`;
    if (!edgeBySrcTbl[sk]) edgeBySrcTbl[sk] = [];
    edgeBySrcTbl[sk].push(l);
    if (!edgeByTgtTbl[tk]) edgeByTgtTbl[tk] = [];
    edgeByTgtTbl[tk].push(l);
  });

  return { bySystem, byTable, edgeBySrcSys, edgeByTgtSys, edgeBySrcTbl, edgeByTgtTbl };
}

/* ═══════════════════════════════════════════════════════════════
   LEFT PANEL — Virtual scrolling for 5000 systems
═══════════════════════════════════════════════════════════════ */
function LeftPanel({ index, selSystem, selTable, onSelectSystem, onSelectTable }) {
  const [search, setSearch]     = useState('');
  const [expanded, setExpanded] = useState(new Set());

  const systems = useMemo(() => {
    const all = Object.keys(index.bySystem || {}).sort();
    if (!search) return all;
    const q = search.toLowerCase();
    return all.filter(s => s.toLowerCase().includes(q) ||
      Object.keys(index.bySystem[s]?.tables || {}).some(t => t.toLowerCase().includes(q)));
  }, [index, search]);

  const toggle = s => setExpanded(prev => {
    const n = new Set(prev);
    n.has(s) ? n.delete(s) : n.add(s);
    return n;
  });

  return (
    <div style={{width:220,flexShrink:0,display:'flex',flexDirection:'column',height:'100%',
      borderRight:'1px solid var(--color-border-tertiary)',background:'var(--color-background-secondary)'}}>
      {/* Header */}
      <div style={{padding:'10px',borderBottom:'1px solid var(--color-border-tertiary)',flexShrink:0}}>
        <div style={{fontSize:11,fontWeight:600,color:'var(--color-text-primary)',marginBottom:6}}>Data Catalog</div>
        <div style={{position:'relative'}}>
          <input value={search} onChange={e => setSearch(e.target.value)}
            placeholder="Search systems, tables…"
            style={{width:'100%',padding:'4px 22px 4px 6px',fontSize:10,
              border:'1px solid var(--color-border-secondary)',borderRadius:5,
              background:'var(--color-background-primary)',color:'var(--color-text-primary)'}}/>
          {search
            ? <button onClick={()=>setSearch('')} style={{position:'absolute',right:5,top:'50%',transform:'translateY(-50%)',background:'none',color:'var(--color-text-tertiary)',fontSize:12,border:'none',cursor:'pointer'}}>×</button>
            : <span style={{position:'absolute',right:7,top:'50%',transform:'translateY(-50%)',fontSize:10,color:'var(--color-text-tertiary)'}}>⌕</span>
          }
        </div>
        <div style={{fontSize:9,color:'var(--color-text-tertiary)',marginTop:4}}>
          {systems.length} systems · {Object.values(index.bySystem||{}).reduce((a,s)=>a+s.count,0)} fields
        </div>
      </div>

      {/* All systems row */}
      <div onClick={() => { onSelectSystem(null); onSelectTable(null,null); }}
        style={{display:'flex',alignItems:'center',gap:6,padding:'5px 10px',cursor:'pointer',
          borderBottom:'1px solid var(--color-border-tertiary)',
          background:!selSystem?'var(--color-background-info)':'transparent'}}>
        <span style={{fontSize:10,color:!selSystem?'var(--color-text-info)':'var(--color-text-secondary)',
          fontWeight:!selSystem?600:400}}>All systems</span>
        <span style={{fontSize:9,color:'var(--color-text-tertiary)',marginLeft:'auto'}}>{systems.length}</span>
      </div>

      {/* System list */}
      <div style={{flex:1,overflow:'auto'}}>
        {systems.map(sys => {
          const d = index.bySystem[sys] || {};
          const tables = Object.keys(d.tables || {}).sort();
          const isExp = expanded.has(sys);
          const isSel = selSystem === sys;
          const color = sc(sys);
          const srcCount = (index.edgeBySrcSys[sys]||[]).length;
          const tgtCount = (index.edgeByTgtSys[sys]||[]).length;

          // Apply table search filter
          const visibleTables = search
            ? tables.filter(t => t.toLowerCase().includes(search.toLowerCase()) || sys.toLowerCase().includes(search.toLowerCase()))
            : tables;

          if (search && visibleTables.length === 0 && !sys.toLowerCase().includes(search.toLowerCase())) return null;

          return (
            <div key={sys}>
              {/* System row */}
              <div style={{display:'flex',alignItems:'center',gap:5,padding:'5px 8px',cursor:'pointer',
                borderBottom:'1px solid var(--color-border-tertiary)',
                background:isSel && !selTable ? `${color}12` : 'transparent'}}
                onClick={() => { toggle(sys); onSelectSystem(sys); onSelectTable(sys, null); }}>
                <span style={{color,fontSize:8,transition:'transform .15s',display:'inline-block',
                  transform:isExp?'rotate(90deg)':'rotate(0)',flexShrink:0}}>▶</span>
                <div style={{width:7,height:7,borderRadius:'50%',background:color,flexShrink:0}}/>
                <span style={{fontSize:10,fontWeight:500,color,flex:1,
                  overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{sys}</span>
                <div style={{display:'flex',gap:2,flexShrink:0}}>
                  {srcCount > 0 && <span style={{fontSize:8,color:'#00d4aa',fontWeight:600}} title={`${srcCount} outgoing edges`}>↗{srcCount}</span>}
                  {tgtCount > 0 && <span style={{fontSize:8,color:'#ffb347',fontWeight:600}} title={`${tgtCount} incoming edges`}>↙{tgtCount}</span>}
                </div>
              </div>
              {/* Table rows */}
              {isExp && visibleTables.map(tbl => {
                const isSelTbl = selSystem === sys && selTable === tbl;
                const tblKey = `${sys}.${tbl}`;
                const srcE = (index.edgeBySrcTbl[tblKey]||[]).length;
                const tgtE = (index.edgeByTgtTbl[tblKey]||[]).length;
                return (
                  <div key={tbl}
                    onClick={() => { onSelectSystem(sys); onSelectTable(sys, tbl); }}
                    style={{display:'flex',alignItems:'center',gap:5,padding:'4px 8px 4px 24px',cursor:'pointer',
                      borderBottom:'1px solid var(--color-border-tertiary)',
                      background:isSelTbl?`${color}18`:'transparent'}}>
                    <svg width="9" height="9" viewBox="0 0 9 9" style={{flexShrink:0}}>
                      <rect x="0.5" y="0.5" width="8" height="8" rx="1" fill="none" stroke={isSelTbl?color:'var(--color-border-secondary)'} strokeWidth="0.8"/>
                      <line x1="0.5" y1="3.5" x2="8.5" y2="3.5" stroke={isSelTbl?color:'var(--color-border-secondary)'} strokeWidth="0.6"/>
                      <line x1="0.5" y1="6" x2="8.5" y2="6" stroke={isSelTbl?color:'var(--color-border-secondary)'} strokeWidth="0.6"/>
                    </svg>
                    <span style={{fontSize:10,color:isSelTbl?color:'var(--color-text-secondary)',
                      flex:1,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}
                      title={tbl}>{tbl}</span>
                    <div style={{display:'flex',gap:2,flexShrink:0}}>
                      {srcE > 0 && <span style={{fontSize:8,color:'#00d4aa',fontWeight:600}}>↗{srcE}</span>}
                      {tgtE > 0 && <span style={{fontSize:8,color:'#ffb347',fontWeight:600}}>↙{tgtE}</span>}
                    </div>
                  </div>
                );
              })}
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════
   SYSTEM LINEAGE VIEW — Level 1
   Shows: selected system + its direct upstream/downstream systems
═══════════════════════════════════════════════════════════════ */
function SystemLineageView({ selSystem, index, onSelectSystem, onSelectTable }) {
  if (!selSystem) {
    // Overview: all system-level connections
    return <SystemOverview index={index} onSelectSystem={onSelectSystem}/>;
  }

  const color = sc(selSystem);

  // Find upstream systems (feed INTO selSystem)
  const upstreamSystems = useMemo(() => {
    const up = {};
    (index.edgeByTgtSys[selSystem] || []).forEach(l => {
      const sid = typeof l.source==='object'?l.source.id:l.source;
      const srcSys = sid.split('.')[0];
      if (srcSys === selSystem) return;
      if (!up[srcSys]) up[srcSys] = { count: 0, tables: new Set() };
      up[srcSys].count++;
      up[srcSys].tables.add(sid.split('.')[1]);
    });
    return up;
  }, [index, selSystem]);

  // Find downstream systems (receive FROM selSystem)
  const downstreamSystems = useMemo(() => {
    const dn = {};
    (index.edgeBySrcSys[selSystem] || []).forEach(l => {
      const tid = typeof l.target==='object'?l.target.id:l.target;
      const tgtSys = tid.split('.')[0];
      if (tgtSys === selSystem) return;
      if (!dn[tgtSys]) dn[tgtSys] = { count: 0, tables: new Set() };
      dn[tgtSys].count++;
      dn[tgtSys].tables.add(tid.split('.')[1]);
    });
    return dn;
  }, [index, selSystem]);

  const upList = Object.entries(upstreamSystems);
  const dnList = Object.entries(downstreamSystems);

  // Selected system's own tables
  const ownTables = Object.keys(index.bySystem[selSystem]?.tables || {}).sort();

  return (
    <div style={{flex:1,overflow:'auto',padding:20}}>
      {/* Breadcrumb */}
      <div style={{display:'flex',alignItems:'center',gap:6,marginBottom:16,fontSize:11}}>
        <button onClick={()=>onSelectSystem(null)} style={{color:'var(--color-text-tertiary)',background:'none',border:'none',cursor:'pointer',padding:0,fontSize:11}}>All systems</button>
        <span style={{color:'var(--color-text-tertiary)'}}>›</span>
        <span style={{color,fontWeight:600}}>{selSystem}</span>
      </div>

      {/* 3-column layout: Upstream | Selected | Downstream */}
      <div style={{display:'grid',gridTemplateColumns:'1fr auto 1fr',gap:0,alignItems:'flex-start',minHeight:300}}>

        {/* UPSTREAM */}
        <div style={{paddingRight:20}}>
          <div style={{fontSize:10,fontWeight:700,color:'var(--color-text-tertiary)',
            textTransform:'uppercase',letterSpacing:'.09em',marginBottom:10}}>
            Upstream sources ({upList.length})
          </div>
          {upList.length === 0 ? (
            <EmptyState icon="←" msg="No upstream sources" sub={`${selSystem} is a root system — data originates here`}/>
          ) : upList.map(([sys, info]) => (
            <SystemCard key={sys} sys={sys} info={info} direction="upstream"
              onClick={() => { onSelectSystem(sys); onSelectTable(sys, null); }}/>
          ))}
        </div>

        {/* CENTER — selected system */}
        <div style={{padding:'0 16px',display:'flex',flexDirection:'column',alignItems:'center',minWidth:200}}>
          <div style={{width:2,height:30,background:`${color}30`}}/>
          <div style={{background:color,borderRadius:10,padding:'12px 20px',
            textAlign:'center',minWidth:180}}>
            <div style={{fontSize:14,fontWeight:600,color:'#fff',marginBottom:3}}>{selSystem}</div>
            <div style={{fontSize:10,color:'rgba(255,255,255,0.75)'}}>{ownTables.length} tables · {index.bySystem[selSystem]?.count||0} fields</div>
          </div>
          <div style={{width:2,height:30,background:`${color}30`}}/>

          {/* Own tables */}
          <div style={{width:'100%',marginTop:8}}>
            <div style={{fontSize:9,fontWeight:700,color:'var(--color-text-tertiary)',
              textTransform:'uppercase',letterSpacing:'.09em',marginBottom:6,textAlign:'center'}}>Tables</div>
            <div style={{maxHeight:300,overflow:'auto'}}>
              {ownTables.map(tbl => {
                const tblKey = `${selSystem}.${tbl}`;
                const srcE = (index.edgeBySrcTbl[tblKey]||[]).length;
                const tgtE = (index.edgeByTgtTbl[tblKey]||[]).length;
                return (
                  <div key={tbl} onClick={()=>onSelectTable(selSystem,tbl)}
                    style={{display:'flex',alignItems:'center',gap:6,padding:'5px 8px',
                      borderRadius:6,border:`0.5px solid ${color}30`,marginBottom:4,
                      cursor:'pointer',background:`${color}08`,
                      transition:'background .1s'}}>
                    <svg width="9" height="9" viewBox="0 0 9 9">
                      <rect x="0.5" y="0.5" width="8" height="8" rx="1" fill="none" stroke={color} strokeWidth="0.8"/>
                      <line x1="0.5" y1="3.5" x2="8.5" y2="3.5" stroke={color} strokeWidth="0.6"/>
                    </svg>
                    <span style={{fontSize:10,color:'var(--color-text-secondary)',flex:1,
                      overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}} title={tbl}>{tbl}</span>
                    <div style={{display:'flex',gap:3,flexShrink:0}}>
                      {srcE>0&&<span style={{fontSize:8,color:'#00d4aa',fontWeight:600}}>↗{srcE}</span>}
                      {tgtE>0&&<span style={{fontSize:8,color:'#ffb347',fontWeight:600}}>↙{tgtE}</span>}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* DOWNSTREAM */}
        <div style={{paddingLeft:20}}>
          <div style={{fontSize:10,fontWeight:700,color:'var(--color-text-tertiary)',
            textTransform:'uppercase',letterSpacing:'.09em',marginBottom:10}}>
            Downstream targets ({dnList.length})
          </div>
          {dnList.length === 0 ? (
            <EmptyState icon="→" msg="No downstream targets" sub={`${selSystem} is a leaf system — data ends here`}/>
          ) : dnList.map(([sys, info]) => (
            <SystemCard key={sys} sys={sys} info={info} direction="downstream"
              onClick={() => { onSelectSystem(sys); onSelectTable(sys, null); }}/>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════
   SYSTEM OVERVIEW — when no system selected
═══════════════════════════════════════════════════════════════ */
function SystemOverview({ index, onSelectSystem }) {
  const systems = Object.keys(index.bySystem || {}).sort();
  // Build system-level edge summary
  const sysEdges = useMemo(() => {
    const pairs = {};
    Object.keys(index.edgeBySrcSys || {}).forEach(src => {
      (index.edgeBySrcSys[src] || []).forEach(l => {
        const tid = typeof l.target==='object'?l.target.id:l.target;
        const tgt = tid.split('.')[0];
        if (src === tgt) return;
        const k = `${src}→${tgt}`;
        pairs[k] = (pairs[k] || 0) + 1;
      });
    });
    return pairs;
  }, [index]);

  return (
    <div style={{flex:1,overflow:'auto',padding:20}}>
      <div style={{fontSize:11,color:'var(--color-text-tertiary)',marginBottom:16}}>
        Select a system from the left panel to see its lineage. Overview of all {systems.length} systems:
      </div>

      {/* System cards grid */}
      <div style={{display:'flex',flexWrap:'wrap',gap:10,marginBottom:24}}>
        {systems.map(sys => {
          const d = index.bySystem[sys] || {};
          const srcOut = new Set(
            (index.edgeBySrcSys[sys]||[]).map(l=>{
              const t=typeof l.target==='object'?l.target.id:l.target;
              return t.split('.')[0];
            })
          );
          srcOut.delete(sys);
          const tgtIn = new Set(
            (index.edgeByTgtSys[sys]||[]).map(l=>{
              const s=typeof l.source==='object'?l.source.id:l.source;
              return s.split('.')[0];
            })
          );
          tgtIn.delete(sys);
          const color = sc(sys);
          return (
            <div key={sys} onClick={()=>onSelectSystem(sys)}
              style={{display:'flex',flexDirection:'column',gap:4,padding:'10px 14px',
                borderRadius:8,border:`1px solid ${color}40`,cursor:'pointer',
                background:`${color}08`,minWidth:150,transition:'all .15s'}}>
              <div style={{display:'flex',alignItems:'center',gap:6}}>
                <div style={{width:8,height:8,borderRadius:'50%',background:color,flexShrink:0}}/>
                <span style={{fontSize:12,fontWeight:600,color}}>{sys}</span>
              </div>
              <div style={{fontSize:10,color:'var(--color-text-tertiary)'}}>
                {Object.keys(d.tables||{}).length} tables · {d.count} fields
              </div>
              <div style={{display:'flex',gap:8,marginTop:2}}>
                {tgtIn.size > 0 && <span style={{fontSize:9,color:'#00d4aa'}}>← {tgtIn.size} upstream</span>}
                {srcOut.size > 0 && <span style={{fontSize:9,color:'#ffb347'}}>{srcOut.size} downstream →</span>}
                {tgtIn.size === 0 && srcOut.size === 0 && <span style={{fontSize:9,color:'var(--color-text-tertiary)'}}>No lineage edges</span>}
              </div>
            </div>
          );
        })}
      </div>

      {/* System-level lineage edges */}
      {Object.keys(sysEdges).length > 0 && (
        <div>
          <div style={{fontSize:10,fontWeight:700,color:'var(--color-text-tertiary)',
            textTransform:'uppercase',letterSpacing:'.09em',marginBottom:10}}>
            System-level lineage connections
          </div>
          <div style={{display:'flex',flexWrap:'wrap',gap:6}}>
            {Object.entries(sysEdges).sort((a,b)=>b[1]-a[1]).map(([pair,cnt])=>{
              const [src,tgt] = pair.split('→');
              return (
                <div key={pair} style={{display:'flex',alignItems:'center',gap:6,
                  padding:'5px 10px',borderRadius:20,background:'var(--color-background-primary)',
                  border:'0.5px solid var(--color-border-secondary)',fontSize:11}}>
                  <span style={{color:sc(src),fontWeight:500}}>{src}</span>
                  <span style={{color:'var(--color-text-tertiary)',fontSize:10}}>——{cnt}——→</span>
                  <span style={{color:sc(tgt),fontWeight:500}}>{tgt}</span>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════
   TABLE LINEAGE VIEW — Level 2
   Shows: selected table + source/target tables with field counts
═══════════════════════════════════════════════════════════════ */
function TableLineageView({ selSystem, selTable, index, data, onSelectTable, onSelectSystem }) {
  const color = sc(selSystem);
  const tblKey = `${selSystem}.${selTable}`;

  // Source tables (feed into this table)
  const sourceTables = useMemo(() => {
    const src = {};
    (index.edgeByTgtTbl[tblKey] || []).forEach(l => {
      const sid = typeof l.source==='object'?l.source.id:l.source;
      const [ss, st] = sid.split('.');
      const k = `${ss}.${st}`;
      if (k === tblKey) return;
      if (!src[k]) src[k] = { sys:ss, tbl:st, edges:[], fieldPairs:new Set() };
      src[k].edges.push(l);
      const scol = sid.split('.')[2];
      const tcol = (typeof l.target==='object'?l.target.id:l.target).split('.')[2];
      src[k].fieldPairs.add(`${scol}→${tcol}`);
    });
    return Object.values(src);
  }, [index, tblKey]);

  // Target tables (receive from this table)
  const targetTables = useMemo(() => {
    const tgt = {};
    (index.edgeBySrcTbl[tblKey] || []).forEach(l => {
      const tid = typeof l.target==='object'?l.target.id:l.target;
      const [ts, tt] = tid.split('.');
      const k = `${ts}.${tt}`;
      if (k === tblKey) return;
      if (!tgt[k]) tgt[k] = { sys:ts, tbl:tt, edges:[], fieldPairs:new Set() };
      tgt[k].edges.push(l);
      const scol = (typeof l.source==='object'?l.source.id:l.source).split('.')[2];
      const tcol = tid.split('.')[2];
      tgt[k].fieldPairs.add(`${scol}→${tcol}`);
    });
    return Object.values(tgt);
  }, [index, tblKey]);

  // Own fields
  const ownFields = index.byTable[tblKey] || [];

  // Selected pair for field-level view
  const [selSrcTbl, setSelSrcTbl] = useState(null);
  const [selTgtTbl, setSelTgtTbl] = useState(null);

  return (
    <div style={{flex:1,display:'flex',flexDirection:'column',overflow:'hidden'}}>
      {/* Breadcrumb */}
      <div style={{display:'flex',alignItems:'center',gap:6,padding:'10px 16px',
        borderBottom:'1px solid var(--color-border-tertiary)',flexShrink:0,fontSize:11}}>
        <button onClick={()=>{onSelectSystem(null);onSelectTable(null,null);}}
          style={{color:'var(--color-text-tertiary)',background:'none',border:'none',cursor:'pointer',padding:0,fontSize:11}}>All systems</button>
        <span style={{color:'var(--color-text-tertiary)'}}>›</span>
        <button onClick={()=>onSelectTable(selSystem,null)}
          style={{color:color,background:'none',border:'none',cursor:'pointer',padding:0,fontSize:11,fontWeight:500}}>{selSystem}</button>
        <span style={{color:'var(--color-text-tertiary)'}}>›</span>
        <span style={{color:'var(--color-text-primary)',fontWeight:600}}>{selTable}</span>
        <span style={{marginLeft:'auto',fontSize:10,color:'var(--color-text-tertiary)'}}>
          {sourceTables.length} upstream tables · {targetTables.length} downstream tables · {ownFields.length} fields
        </span>
      </div>

      <div style={{flex:1,overflow:'auto',padding:16}}>
        {/* 3-column: source tables | center table | target tables */}
        <div style={{display:'grid',gridTemplateColumns:'1fr auto 1fr',gap:0,alignItems:'flex-start'}}>

          {/* SOURCE TABLES */}
          <div style={{paddingRight:16}}>
            <div style={{fontSize:9,fontWeight:700,color:'#00d4aa',
              textTransform:'uppercase',letterSpacing:'.09em',marginBottom:8}}>
              Source tables ({sourceTables.length})
            </div>
            {sourceTables.length === 0 ? (
              <EmptyState icon="←" msg="No source tables" sub="This table has no upstream dependencies — data originates here"/>
            ) : sourceTables.map(info => (
              <MappingTableCard key={`${info.sys}.${info.tbl}`}
                sys={info.sys} tbl={info.tbl} edgeCount={info.edges.length}
                fieldPairs={info.fieldPairs}
                isSelected={selSrcTbl===`${info.sys}.${info.tbl}`}
                onClick={()=>setSelSrcTbl(prev=>prev===`${info.sys}.${info.tbl}`?null:`${info.sys}.${info.tbl}`)}
                direction="source"/>
            ))}
          </div>

          {/* CENTER TABLE */}
          <div style={{padding:'0 12px',display:'flex',flexDirection:'column',alignItems:'center',minWidth:200}}>
            <div style={{background:color,borderRadius:8,padding:'10px 16px',textAlign:'center',minWidth:180}}>
              <div style={{fontSize:13,fontWeight:600,color:'#fff',marginBottom:2}}>{selTable}</div>
              <div style={{fontSize:10,color:'rgba(255,255,255,0.75)'}}>{selSystem} · {ownFields.length} columns</div>
            </div>
            {/* Field list */}
            <div style={{width:'100%',marginTop:10,maxHeight:350,overflow:'auto'}}>
              {ownFields
                .sort((a,b)=>(a.column_order||99)-(b.column_order||99)||(a.column>b.column?1:-1))
                .map((f,i) => {
                const hasSrcEdge = (index.edgeByTgtTbl[tblKey]||[]).some(l=>(typeof l.target==='object'?l.target.id:l.target).endsWith('.'+f.column));
                const hasTgtEdge = (index.edgeBySrcTbl[tblKey]||[]).some(l=>(typeof l.source==='object'?l.source.id:l.source).endsWith('.'+f.column));
                return (
                  <div key={f.id} style={{display:'flex',alignItems:'center',gap:5,
                    padding:'3px 6px',borderRadius:4,marginBottom:2,
                    background:`${color}06`,border:`0.5px solid ${color}20`}}>
                    {f.is_primary_key
                      ?<svg width="9" height="9" viewBox="0 0 9 9"><circle cx="3.5" cy="3.5" r="2.2" fill="none" stroke="#f59e0b" strokeWidth="1"/><line x1="5" y1="5" x2="8.5" y2="8.5" stroke="#f59e0b" strokeWidth="1" strokeLinecap="round"/></svg>
                      :f.is_foreign_key
                      ?<svg width="9" height="9" viewBox="0 0 9 9"><circle cx="3.5" cy="3.5" r="2.2" fill="none" stroke="#3b82f6" strokeWidth="1" strokeDasharray="1.5,0.8"/></svg>
                      :<div style={{width:4,height:4,borderRadius:'50%',background:hasSrcEdge||hasTgtEdge?color:'var(--color-border-secondary)',flexShrink:0}}/>
                    }
                    <span style={{fontSize:9,color:'var(--color-text-secondary)',flex:1,
                      overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{f.column}</span>
                    <span style={{fontSize:8,color:'var(--color-text-tertiary)',fontFamily:'monospace',flexShrink:0}}>
                      {(f.data_type||'').split('(')[0].substring(0,6)}
                    </span>
                    {hasSrcEdge&&<span style={{fontSize:7,color:'#ffb347',fontWeight:700}}>↙</span>}
                    {hasTgtEdge&&<span style={{fontSize:7,color:'#00d4aa',fontWeight:700}}>↗</span>}
                  </div>
                );
              })}
            </div>
          </div>

          {/* TARGET TABLES */}
          <div style={{paddingLeft:16}}>
            <div style={{fontSize:9,fontWeight:700,color:'#ffb347',
              textTransform:'uppercase',letterSpacing:'.09em',marginBottom:8}}>
              Target tables ({targetTables.length})
            </div>
            {targetTables.length === 0 ? (
              <EmptyState icon="→" msg="No target tables" sub="This table has no downstream consumers — data ends here"/>
            ) : targetTables.map(info => (
              <MappingTableCard key={`${info.sys}.${info.tbl}`}
                sys={info.sys} tbl={info.tbl} edgeCount={info.edges.length}
                fieldPairs={info.fieldPairs}
                isSelected={selTgtTbl===`${info.sys}.${info.tbl}`}
                onClick={()=>setSelTgtTbl(prev=>prev===`${info.sys}.${info.tbl}`?null:`${info.sys}.${info.tbl}`)}
                direction="target"/>
            ))}
          </div>
        </div>

        {/* Field-level mapping when a src/tgt table is selected */}
        {(selSrcTbl || selTgtTbl) && (
          <FieldMappingPanel
            srcKey={selSrcTbl || tblKey}
            tgtKey={selTgtTbl || tblKey}
            index={index} data={data}/>
        )}
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════
   FIELD MAPPING PANEL — Level 3
   Source table fields ——bezier——→ Target table fields
═══════════════════════════════════════════════════════════════ */
function FieldMappingPanel({ srcKey, tgtKey, index, data }) {
  const [srcSys, srcTbl] = srcKey.split('.');
  const [tgtSys, tgtTbl] = tgtKey.split('.');
  const srcColor = sc(srcSys);
  const tgtColor = sc(tgtSys);

  const srcFields = useMemo(() =>
    (index.byTable[srcKey]||[]).sort((a,b)=>(a.column_order||99)-(b.column_order||99)||(a.column>b.column?1:-1))
  , [index, srcKey]);

  const tgtFields = useMemo(() =>
    (index.byTable[tgtKey]||[]).sort((a,b)=>(a.column_order||99)-(b.column_order||99)||(a.column>b.column?1:-1))
  , [index, tgtKey]);

  const edges = useMemo(() =>
    (data?.links||[]).filter(l => {
      const sid = typeof l.source==='object'?l.source.id:l.source;
      const tid = typeof l.target==='object'?l.target.id:l.target;
      return sid.startsWith(srcKey+'.') && tid.startsWith(tgtKey+'.');
    })
  , [data, srcKey, tgtKey]);

  const [selField, setSelField] = useState(null);

  const ROW_H = 28, HDR_H = 50, CARD_W = 230;

  if (srcFields.length === 0 && tgtFields.length === 0) return null;

  return (
    <div style={{marginTop:20,padding:16,background:'var(--color-background-secondary)',
      borderRadius:10,border:'0.5px solid var(--color-border-tertiary)'}}>
      <div style={{display:'flex',alignItems:'center',gap:8,marginBottom:12}}>
        <span style={{fontSize:11,fontWeight:600,color:'var(--color-text-primary)'}}>Field-level mapping</span>
        <span style={{fontSize:11,color:srcColor,fontWeight:500}}>{srcTbl}</span>
        <span style={{fontSize:11,color:'var(--color-text-tertiary)'}}>→</span>
        <span style={{fontSize:11,color:tgtColor,fontWeight:500}}>{tgtTbl}</span>
        <span style={{marginLeft:'auto',fontSize:10,color:'var(--color-text-tertiary)'}}>
          {edges.length} mappings · click field to highlight
        </span>
      </div>

      {edges.length === 0 ? (
        <div style={{padding:'16px',textAlign:'center',color:'var(--color-text-tertiary)',fontSize:12}}>
          No field-level mappings defined between these tables yet.
          <br/><span style={{fontSize:11}}>Use the Map Fields tab to create mappings.</span>
        </div>
      ) : (
        <div style={{display:'flex',gap:0,alignItems:'flex-start',position:'relative',overflowX:'auto'}}>
          {/* SVG edges */}
          <svg style={{position:'absolute',left:CARD_W,top:0,zIndex:1,pointerEvents:'none'}}
            width={160}
            height={Math.max(srcFields.length,tgtFields.length)*ROW_H+HDR_H+20}>
            <defs>
              {Object.entries(TC).map(([k,c])=>(
                <marker key={k} id={`fmp-${k}`} viewBox="0 0 10 10" refX="8" refY="5" markerWidth="5" markerHeight="5" orient="auto">
                  <path d="M2 1L8 5L2 9" fill="none" stroke={c} strokeWidth="1.5" strokeLinecap="round"/>
                </marker>
              ))}
            </defs>
            {edges.map((l,i) => {
              const sid = typeof l.source==='object'?l.source.id:l.source;
              const tid = typeof l.target==='object'?l.target.id:l.target;
              const scol = sid.split('.')[2];
              const tcol = tid.split('.')[2];
              const si = srcFields.findIndex(f=>f.column===scol);
              const ti = tgtFields.findIndex(f=>f.column===tcol);
              if (si<0||ti<0) return null;
              const y1 = HDR_H + si*ROW_H + ROW_H/2;
              const y2 = HDR_H + ti*ROW_H + ROW_H/2;
              const ttype = (l.transformation_type||'direct').replace('TransformationType.','').toLowerCase();
              const col = TC[ttype]||'#8b85ff';
              const isSel = selField===sid||selField===tid;
              const dimmed = selField && !isSel;
              return (
                <path key={i}
                  d={`M0,${y1} C80,${y1} 80,${y2} 160,${y2}`}
                  fill="none" stroke={col}
                  strokeWidth={isSel?2.5:1.5}
                  strokeOpacity={dimmed?0.08:isSel?1:0.65}
                  strokeDasharray={ttype.includes('infer')?'5,3':undefined}
                  markerEnd={`url(#fmp-${ttype})`}/>
              );
            })}
          </svg>

          {/* Source card */}
          <FieldCard fields={srcFields} sys={srcSys} tbl={srcTbl} color={srcColor}
            selField={selField} setSelField={setSelField}
            connectedFields={new Set(edges.map(l=>typeof l.source==='object'?l.source.id:l.source))}
            width={CARD_W} rowH={ROW_H} hdrH={HDR_H}/>

          {/* Gap for arrows */}
          <div style={{width:160,flexShrink:0}}/>

          {/* Target card */}
          <FieldCard fields={tgtFields} sys={tgtSys} tbl={tgtTbl} color={tgtColor}
            selField={selField} setSelField={setSelField}
            connectedFields={new Set(edges.map(l=>typeof l.target==='object'?l.target.id:l.target))}
            width={CARD_W} rowH={ROW_H} hdrH={HDR_H}/>
        </div>
      )}
    </div>
  );
}

/* ── Field Card (used in FieldMappingPanel) ─── */
function FieldCard({ fields, sys, tbl, color, selField, setSelField, connectedFields, width, rowH, hdrH }) {
  return (
    <div style={{width,flexShrink:0,background:'var(--color-background-primary)',
      border:`1.5px solid ${color}40`,borderRadius:7,overflow:'hidden'}}>
      <div style={{padding:'8px 10px',background:`${color}14`,borderBottom:`1px solid ${color}30`,height:hdrH,display:'flex',flexDirection:'column',justifyContent:'center'}}>
        <div style={{fontSize:11,fontWeight:600,color}}>{tbl}</div>
        <div style={{fontSize:10,color:'var(--color-text-tertiary)'}}>{sys} · {fields.length} cols · {connectedFields.size} mapped</div>
      </div>
      {fields.map((f,fi) => {
        const conn = connectedFields.has(f.id);
        const isSel = selField===f.id;
        return (
          <div key={fi} onClick={()=>setSelField(s=>s===f.id?null:f.id)}
            style={{display:'flex',alignItems:'center',gap:5,padding:'3px 8px',
              height:rowH,cursor:'pointer',
              background:isSel?`${color}20`:conn?`${color}06`:'transparent',
              borderBottom:fi<fields.length-1?'1px solid var(--color-border-tertiary)':undefined}}>
            {f.is_primary_key
              ?<svg width="9" height="9" viewBox="0 0 9 9"><circle cx="3.5" cy="3.5" r="2.2" fill="none" stroke="#f59e0b" strokeWidth="1"/><line x1="5" y1="5" x2="8.5" y2="8.5" stroke="#f59e0b" strokeWidth="1" strokeLinecap="round"/></svg>
              :f.is_foreign_key
              ?<svg width="9" height="9" viewBox="0 0 9 9"><circle cx="3.5" cy="3.5" r="2.2" fill="none" stroke="#3b82f6" strokeWidth="1" strokeDasharray="1.5,0.8"/></svg>
              :<div style={{width:4,height:4,borderRadius:'50%',flexShrink:0,
                background:conn?color:'var(--color-border-secondary)'}}/>
            }
            <span style={{flex:1,fontSize:10,fontWeight:isSel?600:f.is_primary_key?500:400,
              color:isSel?color:conn?'var(--color-text-primary)':'var(--color-text-secondary)',
              overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{f.column}</span>
            <span style={{fontSize:8,color:'var(--color-text-tertiary)',flexShrink:0,fontFamily:'monospace'}}>
              {(f.data_type||'').split('(')[0].substring(0,7)}
            </span>
            {f.nullable===false && <span style={{fontSize:7,color:'#f59e0b',fontWeight:700,flexShrink:0}}>NN</span>}
          </div>
        );
      })}
    </div>
  );
}

/* ── Small helper components ─── */
function SystemCard({ sys, info, direction, onClick }) {
  const color = sc(sys);
  return (
    <div onClick={onClick}
      style={{padding:'10px 12px',borderRadius:8,border:`1px solid ${color}35`,
        cursor:'pointer',background:`${color}06`,marginBottom:8,transition:'all .15s'}}>
      <div style={{display:'flex',alignItems:'center',gap:6,marginBottom:4}}>
        <div style={{width:7,height:7,borderRadius:'50%',background:color,flexShrink:0}}/>
        <span style={{fontSize:12,fontWeight:600,color}}>{sys}</span>
        <span style={{marginLeft:'auto',fontSize:9,color:'var(--color-text-tertiary)'}}>
          {info.count} edges
        </span>
      </div>
      <div style={{fontSize:10,color:'var(--color-text-secondary)'}}>
        {info.tables.size} table{info.tables.size!==1?'s':''}: {[...info.tables].slice(0,3).join(', ')}{info.tables.size>3?'…':''}
      </div>
    </div>
  );
}

function MappingTableCard({ sys, tbl, edgeCount, fieldPairs, isSelected, onClick, direction }) {
  const color = sc(sys);
  return (
    <div onClick={onClick}
      style={{padding:'9px 12px',borderRadius:8,marginBottom:8,cursor:'pointer',
        border:`1px solid ${isSelected?color:color+'35'}`,
        background:isSelected?`${color}12`:`${color}06`,transition:'all .15s'}}>
      <div style={{display:'flex',alignItems:'center',gap:6,marginBottom:3}}>
        <div style={{width:7,height:7,borderRadius:'50%',background:color,flexShrink:0}}/>
        <span style={{fontSize:11,fontWeight:600,color,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap',flex:1}} title={tbl}>{tbl}</span>
        <span style={{fontSize:9,color:'var(--color-text-tertiary)',flexShrink:0}}>{edgeCount} edges</span>
      </div>
      <div style={{fontSize:10,color:'var(--color-text-secondary)'}}>{sys}</div>
      {isSelected && fieldPairs.size > 0 && (
        <div style={{marginTop:5,fontSize:9,color:'var(--color-text-tertiary)'}}>
          {[...fieldPairs].slice(0,3).join(' · ')}{fieldPairs.size>3?` +${fieldPairs.size-3} more`:''}
        </div>
      )}
    </div>
  );
}

function EmptyState({ icon, msg, sub }) {
  return (
    <div style={{padding:'20px 16px',textAlign:'center',borderRadius:8,
      border:'1px dashed var(--color-border-secondary)',color:'var(--color-text-tertiary)'}}>
      <div style={{fontSize:20,marginBottom:6,opacity:0.4}}>{icon}</div>
      <div style={{fontSize:12,fontWeight:500,color:'var(--color-text-secondary)',marginBottom:3}}>{msg}</div>
      <div style={{fontSize:10,lineHeight:1.5}}>{sub}</div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════
   FORCE GRAPH — D3 with enterprise controls
═══════════════════════════════════════════════════════════════ */
function ForceGraph({ data, onNodeClick, selectedNode, highlightPath, viewMode }) {
  const svgRef  = useRef(null);
  const simRef  = useRef(null);
  const [tooltip,     setTooltip]     = useState(null);
  const [systems,     setSystems]     = useState([]);
  const [visible,     setVisible]     = useState(new Set());
  const [searchQ,     setSearchQ]     = useState('');
  const [clusterMode, setClusterMode] = useState(true); // default cluster for large data
  const [focusNode,   setFocusNode]   = useState(null);
  const [maxNodes,    setMaxNodes]    = useState(200); // performance cap

  useEffect(() => {
    if (!data?.nodes?.length) return;
    const sl = [...new Set(data.nodes.map(n=>n.system))].sort();
    setSystems(sl);
    setVisible(new Set(sl));
  }, [data]);

  const filteredData = useCallback(() => {
    if (!data?.nodes) return { nodes:[], links:[] };
    let nodes = data.nodes.filter(n=>visible.has(n.system));
    if (focusNode) {
      const nb = new Set([focusNode]);
      data.links.forEach(l=>{
        const s=typeof l.source==='object'?l.source.id:l.source;
        const t=typeof l.target==='object'?l.target.id:l.target;
        if(s===focusNode)nb.add(t); if(t===focusNode)nb.add(s);
      });
      nodes = nodes.filter(n=>nb.has(n.id));
    }
    const ids = new Set(nodes.map(n=>n.id));
    const links = data.links.filter(l=>{
      const s=typeof l.source==='object'?l.source.id:l.source;
      const t=typeof l.target==='object'?l.target.id:l.target;
      return ids.has(s)&&ids.has(t);
    });
    if (clusterMode) {
      const tm={};
      nodes.forEach(n=>{
        const k=`${n.system}.${n.table}`;
        if(!tm[k])tm[k]={id:k,system:n.system,table:n.table,column:`(0 fields)`,data_type:'TABLE',pii:false,tags:[],_cluster:true,_count:0};
        tm[k]._count++; tm[k].column=`(${tm[k]._count} fields)`; if(n.pii)tm[k].pii=true;
      });
      const cn=Object.values(tm).slice(0, maxNodes);
      const cl=[],seen=new Set();
      links.forEach(l=>{
        const s=typeof l.source==='object'?l.source.id:l.source,t=typeof l.target==='object'?l.target.id:l.target;
        const sn=nodes.find(n=>n.id===s),tn=nodes.find(n=>n.id===t);
        if(!sn||!tn)return;
        const sk=`${sn.system}.${sn.table}`,tk=`${tn.system}.${tn.table}`;
        if(sk===tk||!tm[sk]||!tm[tk])return;
        const lk=`${sk}→${tk}`;
        if(!seen.has(lk)){seen.add(lk);cl.push({...l,source:sk,target:tk,id:lk});}
      });
      return{nodes:cn,links:cl};
    }
    return{nodes:nodes.slice(0,maxNodes),links};
  },[data,visible,focusNode,clusterMode,maxNodes]);

  useEffect(()=>{
    const el=svgRef.current; if(!el||!systems.length)return;
    const fd=filteredData();
    d3.select(el).selectAll('*').remove();
    if(!fd.nodes.length) return;
    const W=el.clientWidth||900,H=el.clientHeight||600;
    const svg=d3.select(el).attr('viewBox',`0 0 ${W} ${H}`).attr('width',W).attr('height',H);
    const defs=svg.append('defs');
    const sysList=[...new Set(fd.nodes.map(n=>n.system))];
    sysList.forEach((s,i)=>{
      const c=sc(s);
      defs.append('marker').attr('id',`fg-${i}`).attr('viewBox','0 0 10 10')
        .attr('refX',clusterMode?28:18).attr('refY',5).attr('markerWidth',5).attr('markerHeight',5).attr('orient','auto')
        .append('path').attr('d','M2 1L8 5L2 9').attr('fill','none').attr('stroke',c)
        .attr('stroke-width',1.5).attr('stroke-linecap','round');
    });
    const LCOLORS=['#00d4aa','#7c6fff','#ffb347'];
    if(viewMode==='layered'){
      const bw=W/3;
      LCOLORS.forEach((c,i)=>{
        svg.append('rect').attr('x',i*bw).attr('y',0).attr('width',bw).attr('height',H).attr('fill',c).attr('opacity',0.04);
        svg.append('line').attr('x1',(i+1)*bw).attr('y1',0).attr('x2',(i+1)*bw).attr('y2',H).attr('stroke',c).attr('stroke-width',1).attr('opacity',0.15);
        svg.append('text').attr('x',i*bw+bw/2).attr('y',22).attr('text-anchor','middle').attr('fill',c).attr('font-size',11).attr('font-family','monospace').attr('opacity',0.6).text(['Source','Middle','Reporting'][i]);
      });
    }
    const g=svg.append('g');
    svg.call(d3.zoom().scaleExtent([0.05,8]).on('zoom',e=>g.attr('transform',e.transform)));
    const nodes=fd.nodes.map(n=>({...n})),links=fd.links.map(l=>({...l}));
    const hlNodes=new Set(highlightPath?.nodes?.map(n=>n.id)||[]);
    const hlLinks=new Set(highlightPath?.edges?.map(e=>e.id)||[]);
    const sHL=searchQ.trim().length>1?new Set(nodes.filter(n=>n.column.toLowerCase().includes(searchQ.toLowerCase())||n.table.toLowerCase().includes(searchQ.toLowerCase())).map(n=>n.id)):new Set();
    const hasHL=hlNodes.size>0||sHL.size>0;
    const R = clusterMode ? 22 : 14;
    const sim=d3.forceSimulation(nodes)
      .force('link',d3.forceLink(links).id(d=>d.id).distance(clusterMode?130:85).strength(0.5))
      .force('charge',d3.forceManyBody().strength(clusterMode?-700:-240))
      .force('center',d3.forceCenter(W/2,H/2))
      .force('collision',d3.forceCollide(R+8));
    simRef.current=sim;
    if(viewMode==='layered'){
      const layerMap={'CBS':0,'LOS':0,'CRM':0,'BUREAU':0,'CREDIT_CORE':0,'RISK':1,'FRAUD':1,'COLLECTIONS':1,'MIS':2,'DWH':2,'REGULATOR':2};
      sim.force('lx',d3.forceX(n=>{const l=layerMap[n.system]??1;return(W/3)*l+W/6;}).strength(0.4));
      sim.force('ly',d3.forceY(H/2).strength(0.06));
    }else{
      const sb=W/(sysList.length+1);
      sim.force('sx',d3.forceX(n=>{const idx=sysList.indexOf(n.system);return sb*(idx+1);}).strength(0.12));
      sim.force('cy',d3.forceY(H/2).strength(0.05));
    }
    const link=g.append('g').selectAll('line').data(links).join('line')
      .attr('stroke',d=>{if(hlLinks.has(d.id))return'#ffb347';const s=typeof d.source==='object'?d.source.system:d.source.split('.')[0];return sc(s);})
      .attr('stroke-width',d=>hlLinks.has(d.id)?2.5:1.2)
      .attr('stroke-opacity',d=>hasHL?hlLinks.has(d.id)?1:0.05:0.55)
      .attr('stroke-dasharray',d=>d.type==='inferred'?'5,3':null)
      .attr('marker-end',d=>{const s=typeof d.source==='object'?d.source.system:d.source.split('.')[0];return`url(#fg-${sysList.indexOf(s)})`;});
    const nodeG=g.append('g').selectAll('g').data(nodes).join('g').attr('cursor','pointer')
      .call(d3.drag()
        .on('start',e=>{if(!e.active)sim.alphaTarget(0.3).restart();e.subject.fx=e.subject.x;e.subject.fy=e.subject.y;})
        .on('drag',e=>{e.subject.fx=e.x;e.subject.fy=e.y;})
        .on('end',e=>{if(!e.active)sim.alphaTarget(0);e.subject.fx=null;e.subject.fy=null;}))
      .on('click',(e,d)=>{onNodeClick&&onNodeClick(d);})
      .on('dblclick',(e,d)=>{setFocusNode(f=>f===d.id?null:d.id);})
      .on('mouseenter',(e,d)=>setTooltip({x:e.pageX,y:e.pageY,d}))
      .on('mouseleave',()=>setTooltip(null));
    nodeG.append('circle').attr('r',R)
      .attr('fill',d=>`${sc(d.system)}22`)
      .attr('stroke',d=>sc(d.system))
      .attr('stroke-width',d=>selectedNode?.id===d.id||hlNodes.has(d.id)||sHL.has(d.id)?2.5:1)
      .attr('stroke-opacity',d=>hasHL?hlNodes.has(d.id)||sHL.has(d.id)?1:0.1:1)
      .attr('fill-opacity',d=>hasHL?hlNodes.has(d.id)||sHL.has(d.id)?0.95:0.03:0.95);
    nodeG.append('text').attr('text-anchor','middle').attr('dominant-baseline','central')
      .attr('font-size',clusterMode?9:7.5).attr('font-family','monospace')
      .attr('fill',d=>sc(d.system)).attr('fill-opacity',d=>hasHL?hlNodes.has(d.id)||sHL.has(d.id)?1:0.12:1)
      .attr('pointer-events','none')
      .text(d=>d.column.length>11?d.column.slice(0,10)+'…':d.column);
    if(clusterMode){
      nodeG.append('text').attr('y',R+12).attr('text-anchor','middle').attr('font-size',8.5)
        .attr('fill',d=>sc(d.system)).attr('fill-opacity',0.65).attr('pointer-events','none')
        .text(d=>d.table?.length>16?d.table.slice(0,15)+'…':d.table);
    }
    nodeG.filter(d=>d.pii).append('circle').attr('r',4).attr('cx',R-2).attr('cy',-(R-2)).attr('fill','#ff5a7d');
    sim.on('tick',()=>{
      link.attr('x1',d=>d.source.x).attr('y1',d=>d.source.y).attr('x2',d=>d.target.x).attr('y2',d=>d.target.y);
      nodeG.attr('transform',d=>`translate(${d.x},${d.y})`);
    });
    return()=>{ sim.stop(); };
  },[filteredData,viewMode,highlightPath,searchQ,onNodeClick,systems.length,clusterMode,maxNodes]);

  const toggle=s=>setVisible(v=>{const n=new Set(v);n.has(s)?n.delete(s):n.add(s);return n;});
  const totalNodes = filteredData().nodes.length;
  const totalInData = (data?.nodes||[]).filter(n=>visible.has(n.system)).length;

  return (
    <div style={{display:'flex',height:'100%',overflow:'hidden'}}>
      <div style={{flex:1,display:'flex',flexDirection:'column',overflow:'hidden'}}>
        {/* Controls */}
        <div style={{display:'flex',gap:7,padding:'7px 10px',flexShrink:0,
          borderBottom:'1px solid var(--color-border-tertiary)',
          background:'var(--color-background-secondary)',flexWrap:'wrap',alignItems:'center'}}>
          <div style={{position:'relative'}}>
            <input value={searchQ} onChange={e=>setSearchQ(e.target.value)} placeholder="Search…"
              style={{padding:'4px 7px 4px 22px',fontSize:11,border:'1px solid var(--color-border-secondary)',
                borderRadius:6,background:'var(--color-background-primary)',color:'var(--color-text-primary)',width:120}}/>
            <span style={{position:'absolute',left:6,top:'50%',transform:'translateY(-50%)',fontSize:11,color:'var(--color-text-tertiary)'}}>⌕</span>
          </div>
          <button onClick={()=>setClusterMode(v=>!v)}
            style={{padding:'4px 9px',fontSize:11,borderRadius:6,cursor:'pointer',
              background:clusterMode?'var(--color-background-info)':'transparent',
              color:clusterMode?'var(--color-text-info)':'var(--color-text-secondary)',
              border:`1px solid ${clusterMode?'var(--color-border-info)':'var(--color-border-secondary)'}`}}>
            Group by table
          </button>
          {focusNode&&<button onClick={()=>setFocusNode(null)}
            style={{padding:'4px 9px',fontSize:11,borderRadius:6,cursor:'pointer',
              background:'var(--color-background-warning)',color:'var(--color-text-warning)',
              border:'1px solid var(--color-border-warning)'}}>✕ Exit focus</button>}
          {totalInData > maxNodes && (
            <div style={{display:'flex',alignItems:'center',gap:5,fontSize:10,color:'var(--color-text-warning)'}}>
              <span>Showing {maxNodes}/{totalInData}</span>
              <button onClick={()=>setMaxNodes(n=>Math.min(n+200,totalInData))}
                style={{fontSize:10,padding:'1px 7px',border:'1px solid var(--color-border-warning)',
                  borderRadius:4,cursor:'pointer',background:'transparent',color:'var(--color-text-warning)'}}>Load more</button>
            </div>
          )}
          <div style={{display:'flex',gap:4,flexWrap:'wrap',marginLeft:'auto'}}>
            {systems.map(s=>(
              <button key={s} onClick={()=>toggle(s)}
                style={{padding:'3px 8px',fontSize:9,borderRadius:20,cursor:'pointer',
                  background:visible.has(s)?`${sc(s)}18`:'transparent',
                  border:`1px solid ${visible.has(s)?sc(s):'var(--color-border-secondary)'}`,
                  color:visible.has(s)?sc(s):'var(--color-text-tertiary)'}}>
                {s}
              </button>
            ))}
          </div>
        </div>
        <div style={{flex:1,position:'relative'}}>
          <svg ref={svgRef} style={{width:'100%',height:'100%'}}/>
          {tooltip&&(
            <div style={{position:'fixed',left:tooltip.x+14,top:tooltip.y-10,
              background:'var(--color-background-primary)',border:'1px solid var(--color-border-secondary)',
              borderRadius:8,padding:'8px 12px',fontSize:11,pointerEvents:'none',zIndex:100,
              boxShadow:'0 4px 16px rgba(0,0,0,0.15)',maxWidth:240}}>
              <div style={{fontWeight:600,color:sc(tooltip.d.system),marginBottom:3}}>{tooltip.d.column}</div>
              <div style={{color:'var(--color-text-secondary)'}}>{tooltip.d.system} · {tooltip.d.table}</div>
              {tooltip.d.data_type&&<div style={{color:'var(--color-text-tertiary)',fontSize:10,marginTop:2}}>{tooltip.d.data_type}{tooltip.d.is_primary_key?' · PK':''}{tooltip.d.nullable===false?' · NOT NULL':''}</div>}
              {tooltip.d.description&&<div style={{color:'var(--color-text-secondary)',marginTop:4,fontSize:10,lineHeight:1.4,borderTop:'1px solid var(--color-border-tertiary)',paddingTop:4}}>{tooltip.d.description.slice(0,100)}</div>}
              {tooltip.d.pii&&<div style={{color:'#ff5a7d',fontSize:10,marginTop:3}}>⚠ PII</div>}
              <div style={{color:'var(--color-text-tertiary)',fontSize:9,marginTop:3}}>Double-click to focus</div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

/* ═══════════════════════════════════════════════════════════════
   MAIN EXPORT
═══════════════════════════════════════════════════════════════ */
export default function LineageGraph({ data, onNodeClick, selectedNode, highlightPath }) {
  const [viewMode, setViewMode] = useState('lineage'); // lineage | force | layered
  const [selSystem, setSelSystem] = useState(null);
  const [selTable,  setSelTable]  = useState(null);

  // Build index once when data changes
  const index = useMemo(() => buildIndex(data), [data]);

  const handleSelectSystem = useCallback(sys => {
    setSelSystem(sys);
    setSelTable(null);
  }, []);

  const handleSelectTable = useCallback((sys, tbl) => {
    if (sys) setSelSystem(sys);
    setSelTable(tbl);
  }, []);

  const totalSystems = Object.keys(index.bySystem || {}).length;
  const totalEdges   = (data?.links || []).length;

  return (
    <div style={{display:'flex',flexDirection:'column',height:'100%',overflow:'hidden'}}>
      {/* Top bar */}
      <div style={{display:'flex',gap:6,padding:'7px 12px',
        borderBottom:'1px solid var(--color-border-tertiary)',
        background:'var(--color-background-secondary)',flexShrink:0,alignItems:'center',flexWrap:'wrap'}}>
        {[
          ['lineage','Lineage view'],
          ['force','Force graph'],
          ['layered','Layered view'],
        ].map(([m,l])=>(
          <button key={m} onClick={()=>setViewMode(m)}
            style={{padding:'5px 14px',fontSize:12,borderRadius:20,cursor:'pointer',
              background:viewMode===m?'var(--color-background-info)':'transparent',
              color:viewMode===m?'var(--color-text-info)':'var(--color-text-secondary)',
              border:`1px solid ${viewMode===m?'var(--color-border-info)':'var(--color-border-secondary)'}`,
              fontWeight:viewMode===m?500:400,transition:'all .15s'}}>
            {l}
          </button>
        ))}
        {/* Breadcrumb for lineage view */}
        {viewMode === 'lineage' && (
          <div style={{display:'flex',alignItems:'center',gap:4,marginLeft:8,fontSize:11}}>
            <span style={{color:'var(--color-text-tertiary)'}}>View:</span>
            {!selSystem && <span style={{color:'var(--color-text-secondary)'}}>All systems</span>}
            {selSystem && !selTable && <span style={{color:sc(selSystem),fontWeight:500}}>{selSystem}</span>}
            {selSystem && selTable && (
              <>
                <button onClick={()=>handleSelectTable(selSystem,null)} style={{color:sc(selSystem),background:'none',border:'none',cursor:'pointer',fontWeight:500,fontSize:11,padding:0}}>{selSystem}</button>
                <span style={{color:'var(--color-text-tertiary)'}}>›</span>
                <span style={{color:'var(--color-text-primary)',fontWeight:600}}>{selTable}</span>
              </>
            )}
          </div>
        )}
        <span style={{marginLeft:'auto',fontSize:10,color:'var(--color-text-tertiary)'}}>
          {totalSystems} systems · {data?.nodes?.length||0} fields · {totalEdges} edges
        </span>
      </div>

      {/* Content */}
      {viewMode === 'lineage' ? (
        <div style={{flex:1,display:'flex',overflow:'hidden'}}>
          <LeftPanel index={index} selSystem={selSystem} selTable={selTable}
            onSelectSystem={handleSelectSystem} onSelectTable={handleSelectTable}/>

          {selTable
            ? <TableLineageView selSystem={selSystem} selTable={selTable}
                index={index} data={data}
                onSelectTable={handleSelectTable} onSelectSystem={handleSelectSystem}/>
            : <SystemLineageView selSystem={selSystem} index={index}
                onSelectSystem={handleSelectSystem} onSelectTable={handleSelectTable}/>
          }
        </div>
      ) : (
        <div style={{flex:1,display:'flex',overflow:'hidden'}}>
          <LeftPanel index={index} selSystem={selSystem} selTable={selTable}
            onSelectSystem={s=>{ handleSelectSystem(s); }}
            onSelectTable={(s,t)=>{ handleSelectSystem(s); }}/>
          <ForceGraph data={data} onNodeClick={onNodeClick}
            selectedNode={selectedNode} highlightPath={highlightPath}
            viewMode={viewMode}/>
        </div>
      )}
    </div>
  );
}
