/**
 * Lineage Time Machine — point-in-time lineage replay
 * US banking: Fed/OCC examinations ask for lineage on specific dates
 * "Show us your DFAST data lineage as of December 31"
 */
import { useState, useEffect, useMemo, useCallback } from 'react';

const BASE = 'http://localhost:8000';

function fmtDate(ts) {
  if (!ts) return '—';
  return new Date(ts * 1000).toLocaleDateString('en-US', {year:'numeric',month:'short',day:'numeric'});
}
function fmtDateFull(ts) {
  if (!ts) return '—';
  return new Date(ts * 1000).toLocaleString('en-US', {year:'numeric',month:'short',day:'numeric',hour:'2-digit',minute:'2-digit'});
}

export default function LineageTimeMachine() {
  const [edges,   setEdges]   = useState([]);
  const [fields,  setFields]  = useState([]);
  const [loading, setLoading] = useState(true);
  const [asOf,    setAsOf]    = useState('');   // ISO date string
  const [compare, setCompare] = useState('');   // second date for diff
  const [mode,    setMode]    = useState('replay'); // replay | diff
  const [selectedField, setSelField] = useState('');
  const [filterSys, setFilterSys]   = useState('ALL');

  useEffect(() => {
    Promise.all([
      fetch(`${BASE}/lineage/fields`).then(r=>r.json()),
      fetch(`${BASE}/lineage/graph`).then(r=>r.json()),
    ]).then(([f, g]) => {
      setFields(f);
      setEdges(g.links || []);
      // Default: today
      setAsOf(new Date().toISOString().split('T')[0]);
      setCompare(new Date(Date.now() - 90*24*60*60*1000).toISOString().split('T')[0]);
      setLoading(false);
    }).catch(()=>setLoading(false));
  }, []);

  // Filter edges by date
  const edgesAsOf = useCallback((dateStr) => {
    if (!dateStr) return edges;
    const ts = new Date(dateStr).getTime() / 1000;
    return edges.filter(e => !e.created_at || e.created_at <= ts);
  }, [edges]);

  const edgesNow  = useMemo(() => edgesAsOf(asOf),     [edgesAsOf, asOf]);
  const edgesPrev = useMemo(() => edgesAsOf(compare),  [edgesAsOf, compare]);

  // Diff: edges added between compare and asOf dates
  const addedEdges   = useMemo(() => {
    const prevIds = new Set(edgesPrev.map(e=>e.id));
    return edgesNow.filter(e=>!prevIds.has(e.id));
  }, [edgesNow, edgesPrev]);
  const removedEdges = useMemo(() => {
    const nowIds = new Set(edgesNow.map(e=>e.id));
    return edgesPrev.filter(e=>!nowIds.has(e.id));
  }, [edgesNow, edgesPrev]);

  const systems = useMemo(()=>[...new Set(fields.map(f=>f.system))].sort(),[fields]);

  // Field lineage at a given date
  const fieldLineage = useMemo(() => {
    if (!selectedField) return { upstream:[], downstream:[] };
    const activeEdges = edgesNow;
    const upstream   = activeEdges.filter(e=>{
      const t = typeof e.target==='object'?e.target.id:e.target;
      return t===selectedField;
    });
    const downstream = activeEdges.filter(e=>{
      const s = typeof e.source==='object'?e.source.id:e.source;
      return s===selectedField;
    });
    return { upstream, downstream };
  }, [edgesNow, selectedField]);

  // Stats
  const filteredEdges = filterSys === 'ALL' ? edgesNow
    : edgesNow.filter(e=>{
        const s=typeof e.source==='object'?e.source.id:e.source;
        const t=typeof e.target==='object'?e.target.id:e.target;
        return s.startsWith(filterSys+'.')||t.startsWith(filterSys+'.');
      });

  // All edge timestamps for timeline
  const timestamps = useMemo(() =>
    [...new Set(edges.map(e=>e.created_at).filter(Boolean))].sort()
  , [edges]);

  const minDate = timestamps.length ? new Date(timestamps[0]*1000).toISOString().split('T')[0] : '2020-01-01';
  const maxDate = new Date().toISOString().split('T')[0];

  const fieldOptions = useMemo(()=>
    fields.filter(f=>filterSys==='ALL'||f.system===filterSys)
  ,[fields,filterSys]);

  return (
    <div style={{display:'flex',flexDirection:'column',height:'100%',overflow:'hidden'}}>
      {/* Header */}
      <div style={{padding:'12px 16px',flexShrink:0,borderBottom:'1px solid var(--color-border-tertiary)'}}>
        <div style={{display:'flex',alignItems:'center',gap:12,marginBottom:12}}>
          <div>
            <div style={{fontSize:15,fontWeight:500,color:'var(--color-text-primary)'}}>Lineage Time Machine</div>
            <div style={{fontSize:11,color:'var(--color-text-tertiary)',marginTop:2}}>
              Replay lineage as it existed on any past date. Fed/OCC examiners ask: <em>"Show us your DFAST lineage as of December 31."</em>
            </div>
          </div>
          <div style={{marginLeft:'auto',display:'flex',gap:6}}>
            {[['replay','Replay'],['diff','Compare dates'],['field','Field trace']].map(([m,l])=>(
              <button key={m} onClick={()=>setMode(m)}
                style={{padding:'5px 12px',fontSize:11,borderRadius:20,cursor:'pointer',
                  background:mode===m?'var(--color-background-info)':'transparent',
                  color:mode===m?'var(--color-text-info)':'var(--color-text-secondary)',
                  border:`1px solid ${mode===m?'var(--color-border-info)':'var(--color-border-secondary)'}`,
                  fontWeight:mode===m?500:400}}>
                {l}
              </button>
            ))}
          </div>
        </div>

        {/* Controls */}
        <div style={{display:'flex',gap:10,alignItems:'center',flexWrap:'wrap'}}>
          {(mode==='replay'||mode==='field') && (
            <div style={{display:'flex',alignItems:'center',gap:6}}>
              <label style={{fontSize:11,color:'var(--color-text-secondary)',fontWeight:500}}>As of date:</label>
              <input type="date" value={asOf} onChange={e=>setAsOf(e.target.value)}
                min={minDate} max={maxDate}
                style={{padding:'4px 8px',fontSize:11,border:'1px solid var(--color-border-secondary)',
                  borderRadius:6,background:'var(--color-background-primary)',color:'var(--color-text-primary)'}}/>
              <span style={{fontSize:10,color:'var(--color-text-tertiary)'}}>
                → {filteredEdges.length} edges active on this date
              </span>
            </div>
          )}
          {mode==='diff' && (
            <div style={{display:'flex',alignItems:'center',gap:8}}>
              <input type="date" value={compare} onChange={e=>setCompare(e.target.value)}
                min={minDate} max={maxDate}
                style={{padding:'4px 8px',fontSize:11,border:'1px solid var(--color-border-secondary)',
                  borderRadius:6,background:'var(--color-background-primary)',color:'var(--color-text-primary)'}}/>
              <span style={{fontSize:12,color:'var(--color-text-tertiary)'}}>→</span>
              <input type="date" value={asOf} onChange={e=>setAsOf(e.target.value)}
                min={minDate} max={maxDate}
                style={{padding:'4px 8px',fontSize:11,border:'1px solid var(--color-border-secondary)',
                  borderRadius:6,background:'var(--color-background-primary)',color:'var(--color-text-primary)'}}/>
              <span style={{fontSize:10,color:'#22c55e',fontWeight:500}}>+{addedEdges.length} added</span>
              <span style={{fontSize:10,color:'#ef4444',fontWeight:500}}>−{removedEdges.length} removed</span>
            </div>
          )}
          {mode==='field' && (
            <div style={{display:'flex',alignItems:'center',gap:6}}>
              <label style={{fontSize:11,color:'var(--color-text-secondary)',fontWeight:500}}>Field:</label>
              <select value={selectedField} onChange={e=>setSelField(e.target.value)}
                style={{padding:'4px 8px',fontSize:11,border:'1px solid var(--color-border-secondary)',
                  borderRadius:6,background:'var(--color-background-primary)',color:'var(--color-text-primary)',maxWidth:280}}>
                <option value="">Select a field to trace…</option>
                {fieldOptions.map(f=><option key={f.id} value={f.id}>{f.id}</option>)}
              </select>
            </div>
          )}
          <div style={{display:'flex',alignItems:'center',gap:6}}>
            <label style={{fontSize:11,color:'var(--color-text-secondary)'}}>System:</label>
            <select value={filterSys} onChange={e=>setFilterSys(e.target.value)}
              style={{padding:'4px 8px',fontSize:11,border:'1px solid var(--color-border-secondary)',
                borderRadius:6,background:'var(--color-background-primary)',color:'var(--color-text-primary)'}}>
              <option value="ALL">All</option>
              {systems.map(s=><option key={s} value={s}>{s}</option>)}
            </select>
          </div>
          <button onClick={()=>{
            const data = mode==='diff'
              ? {mode:'diff',from:compare,to:asOf,added:addedEdges,removed:removedEdges}
              : {mode:'replay',asOf,edges:filteredEdges};
            const blob = new Blob([JSON.stringify(data,null,2)],{type:'application/json'});
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href=url; a.download=`lineage-${mode}-${asOf}.json`; a.click();
          }} style={{padding:'5px 12px',fontSize:11,borderRadius:6,cursor:'pointer',
            background:'transparent',color:'var(--color-text-secondary)',
            border:'1px solid var(--color-border-secondary)',marginLeft:'auto'}}>
            ↓ Export for examiner
          </button>
        </div>
      </div>

      {/* Content */}
      <div style={{flex:1,overflow:'auto',padding:16}}>
        {loading ? (
          <div style={{display:'flex',alignItems:'center',justifyContent:'center',height:200,
            color:'var(--color-text-tertiary)',fontSize:13}}>Loading lineage history…</div>
        ) : mode === 'replay' ? (
          <ReplayView edges={filteredEdges} asOf={asOf}/>
        ) : mode === 'diff' ? (
          <DiffView addedEdges={addedEdges} removedEdges={removedEdges} fromDate={compare} toDate={asOf}/>
        ) : (
          <FieldTraceView field={fields.find(f=>f.id===selectedField)} lineage={fieldLineage} asOf={asOf} fields={fields}/>
        )}
      </div>
    </div>
  );
}

function ReplayView({ edges, asOf }) {
  // Group by system pair
  const pairs = {};
  edges.forEach(e => {
    const s = typeof e.source==='object'?e.source.id:e.source;
    const t = typeof e.target==='object'?e.target.id:e.target;
    const ss = s.split('.')[0], ts_ = t.split('.')[0];
    const k = `${ss}→${ts_}`;
    if (!pairs[k]) pairs[k] = {src:ss,tgt:ts_,edges:[]};
    pairs[k].edges.push({...e, srcId:s, tgtId:t});
  });
  return (
    <div>
      <div style={{fontSize:12,color:'var(--color-text-secondary)',marginBottom:12}}>
        Lineage state as of <strong style={{color:'var(--color-text-primary)'}}>{new Date(asOf).toLocaleDateString('en-US',{year:'numeric',month:'long',day:'numeric'})}</strong> — {edges.length} active edges
      </div>
      {Object.keys(pairs).length === 0 ? (
        <div style={{padding:40,textAlign:'center',color:'var(--color-text-tertiary)',fontSize:13}}>
          No edges existed on this date.<br/>
          <span style={{fontSize:11}}>Try selecting an earlier date or add lineage edges via the Map Fields tab.</span>
        </div>
      ) : (
        <div style={{display:'flex',flexDirection:'column',gap:10}}>
          {Object.values(pairs).map(p=>(
            <div key={`${p.src}→${p.tgt}`} style={{background:'var(--color-background-primary)',
              border:'0.5px solid var(--color-border-secondary)',borderRadius:8,overflow:'hidden'}}>
              <div style={{padding:'8px 14px',background:'var(--color-background-secondary)',
                display:'flex',alignItems:'center',gap:8,borderBottom:'0.5px solid var(--color-border-tertiary)'}}>
                <span style={{fontSize:12,fontWeight:500,color:'var(--color-text-primary)'}}>{p.src}</span>
                <span style={{fontSize:12,color:'var(--color-text-tertiary)'}}>——→</span>
                <span style={{fontSize:12,fontWeight:500,color:'var(--color-text-primary)'}}>{p.tgt}</span>
                <span style={{marginLeft:'auto',fontSize:10,color:'var(--color-text-tertiary)'}}>
                  {p.edges.length} field mappings
                </span>
              </div>
              <table style={{width:'100%',borderCollapse:'collapse',fontSize:11}}>
                <tbody>
                  {p.edges.slice(0,10).map((e,i)=>(
                    <tr key={i} style={{borderBottom:'0.5px solid var(--color-border-tertiary)'}}>
                      <td style={{padding:'5px 14px',color:'var(--color-text-secondary)',fontFamily:'monospace'}}>{e.srcId.split('.').slice(1).join('.')}</td>
                      <td style={{padding:'5px 8px',textAlign:'center',color:'var(--color-text-tertiary)',fontSize:10}}>
                        [{(e.transformation_type||'direct').replace('TransformationType.','')}]
                      </td>
                      <td style={{padding:'5px 14px',color:'var(--color-text-secondary)',fontFamily:'monospace'}}>{e.tgtId.split('.').slice(1).join('.')}</td>
                      <td style={{padding:'5px 14px',color:'var(--color-text-tertiary)',fontSize:10}}>{e.created_at ? new Date(e.created_at*1000).toLocaleDateString() : 'legacy'}</td>
                    </tr>
                  ))}
                  {p.edges.length > 10 && (
                    <tr><td colSpan={4} style={{padding:'5px 14px',color:'var(--color-text-tertiary)',fontSize:10}}>
                      … and {p.edges.length-10} more mappings
                    </td></tr>
                  )}
                </tbody>
              </table>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function DiffView({ addedEdges, removedEdges, fromDate, toDate }) {
  return (
    <div>
      <div style={{fontSize:12,color:'var(--color-text-secondary)',marginBottom:14}}>
        Changes between <strong style={{color:'var(--color-text-primary)'}}>{new Date(fromDate).toLocaleDateString('en-US',{month:'short',day:'numeric',year:'numeric'})}</strong> and <strong style={{color:'var(--color-text-primary)'}}>{new Date(toDate).toLocaleDateString('en-US',{month:'short',day:'numeric',year:'numeric'})}</strong>
      </div>
      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:14}}>
        <div>
          <div style={{fontSize:11,fontWeight:600,color:'#22c55e',marginBottom:8}}>
            + {addedEdges.length} edges added
          </div>
          {addedEdges.length === 0 ? (
            <div style={{padding:'16px',textAlign:'center',color:'var(--color-text-tertiary)',fontSize:11,
              border:'1px dashed var(--color-border-secondary)',borderRadius:8}}>No edges added in this period</div>
          ) : addedEdges.map((e,i)=>{
            const s=typeof e.source==='object'?e.source.id:e.source;
            const t=typeof e.target==='object'?e.target.id:e.target;
            return(
              <div key={i} style={{padding:'8px 12px',marginBottom:6,borderRadius:7,
                background:'rgba(34,197,94,0.06)',border:'0.5px solid rgba(34,197,94,0.3)'}}>
                <div style={{fontSize:11,fontFamily:'monospace',color:'var(--color-text-primary)'}}>{s}</div>
                <div style={{fontSize:10,color:'var(--color-text-tertiary)',margin:'2px 0'}}>↓ {(e.transformation_type||'direct').replace('TransformationType.','')}</div>
                <div style={{fontSize:11,fontFamily:'monospace',color:'var(--color-text-primary)'}}>{t}</div>
              </div>
            );
          })}
        </div>
        <div>
          <div style={{fontSize:11,fontWeight:600,color:'#ef4444',marginBottom:8}}>
            − {removedEdges.length} edges removed
          </div>
          {removedEdges.length === 0 ? (
            <div style={{padding:'16px',textAlign:'center',color:'var(--color-text-tertiary)',fontSize:11,
              border:'1px dashed var(--color-border-secondary)',borderRadius:8}}>No edges removed in this period</div>
          ) : removedEdges.map((e,i)=>{
            const s=typeof e.source==='object'?e.source.id:e.source;
            const t=typeof e.target==='object'?e.target.id:e.target;
            return(
              <div key={i} style={{padding:'8px 12px',marginBottom:6,borderRadius:7,
                background:'rgba(239,68,68,0.06)',border:'0.5px solid rgba(239,68,68,0.3)'}}>
                <div style={{fontSize:11,fontFamily:'monospace',color:'var(--color-text-tertiary)',textDecoration:'line-through'}}>{s}</div>
                <div style={{fontSize:10,color:'var(--color-text-tertiary)',margin:'2px 0'}}>↓</div>
                <div style={{fontSize:11,fontFamily:'monospace',color:'var(--color-text-tertiary)',textDecoration:'line-through'}}>{t}</div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

function FieldTraceView({ field, lineage, asOf, fields }) {
  if (!field) return (
    <div style={{display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',
      height:200,gap:8,color:'var(--color-text-tertiary)'}}>
      <div style={{fontSize:28,opacity:.3}}>⇢</div>
      <div style={{fontSize:13,fontWeight:500,color:'var(--color-text-secondary)'}}>Select a field to trace its lineage</div>
      <div style={{fontSize:11}}>Use the field dropdown above to pick any field from any system</div>
    </div>
  );
  const getField = id => fields.find(f=>f.id===id);
  return (
    <div>
      <div style={{fontSize:12,color:'var(--color-text-secondary)',marginBottom:14}}>
        Lineage trail for <strong style={{color:'var(--color-text-primary)'}}>{field.id}</strong> as of {new Date(asOf).toLocaleDateString('en-US',{month:'long',day:'numeric',year:'numeric'})}
      </div>
      <div style={{display:'grid',gridTemplateColumns:'1fr auto 1fr',gap:0,alignItems:'flex-start'}}>
        <div>
          <div style={{fontSize:10,fontWeight:700,color:'#00d4aa',textTransform:'uppercase',letterSpacing:'.08em',marginBottom:8}}>
            Upstream ({lineage.upstream.length} sources)
          </div>
          {lineage.upstream.length === 0 ? (
            <div style={{padding:'14px',textAlign:'center',color:'var(--color-text-tertiary)',fontSize:11,
              border:'1px dashed var(--color-border-secondary)',borderRadius:8}}>
              No upstream on this date<br/><span style={{fontSize:10}}>This field is a root source</span>
            </div>
          ) : lineage.upstream.map((e,i)=>{
            const sid = typeof e.source==='object'?e.source.id:e.source;
            const sf = getField(sid);
            return (
              <div key={i} style={{padding:'9px 12px',marginBottom:6,borderRadius:8,
                background:'var(--color-background-primary)',border:'0.5px solid var(--color-border-secondary)'}}>
                <div style={{fontSize:11,fontWeight:500,color:'var(--color-text-primary)',fontFamily:'monospace',marginBottom:2}}>{sid}</div>
                {sf?.description && <div style={{fontSize:10,color:'var(--color-text-secondary)',lineHeight:1.5}}>{sf.description.slice(0,70)}</div>}
                <div style={{fontSize:9,color:'var(--color-text-tertiary)',marginTop:3}}>
                  {(e.transformation_type||'direct').replace('TransformationType.','')} · added {e.created_at ? new Date(e.created_at*1000).toLocaleDateString() : 'legacy'}
                </div>
              </div>
            );
          })}
        </div>

        <div style={{padding:'0 20px',display:'flex',flexDirection:'column',alignItems:'center',minWidth:180}}>
          <div style={{width:2,height:20,background:'var(--color-border-secondary)'}}/>
          <div style={{background:'var(--color-background-info)',border:'1px solid var(--color-border-info)',
            borderRadius:8,padding:'10px 14px',textAlign:'center'}}>
            <div style={{fontSize:12,fontWeight:600,color:'var(--color-text-info)',marginBottom:2}}>{field.column}</div>
            <div style={{fontSize:10,color:'var(--color-text-secondary)'}}>{field.system} · {field.table}</div>
            {field.description && <div style={{fontSize:10,color:'var(--color-text-tertiary)',marginTop:4}}>{field.description.slice(0,50)}</div>}
          </div>
          <div style={{width:2,height:20,background:'var(--color-border-secondary)'}}/>
        </div>

        <div>
          <div style={{fontSize:10,fontWeight:700,color:'#ffb347',textTransform:'uppercase',letterSpacing:'.08em',marginBottom:8}}>
            Downstream ({lineage.downstream.length} consumers)
          </div>
          {lineage.downstream.length === 0 ? (
            <div style={{padding:'14px',textAlign:'center',color:'var(--color-text-tertiary)',fontSize:11,
              border:'1px dashed var(--color-border-secondary)',borderRadius:8}}>
              No downstream on this date<br/><span style={{fontSize:10}}>This field is a leaf</span>
            </div>
          ) : lineage.downstream.map((e,i)=>{
            const tid = typeof e.target==='object'?e.target.id:e.target;
            const tf = getField(tid);
            return (
              <div key={i} style={{padding:'9px 12px',marginBottom:6,borderRadius:8,
                background:'var(--color-background-primary)',border:'0.5px solid var(--color-border-secondary)'}}>
                <div style={{fontSize:11,fontWeight:500,color:'var(--color-text-primary)',fontFamily:'monospace',marginBottom:2}}>{tid}</div>
                {tf?.description && <div style={{fontSize:10,color:'var(--color-text-secondary)',lineHeight:1.5}}>{tf.description.slice(0,70)}</div>}
                <div style={{fontSize:9,color:'var(--color-text-tertiary)',marginTop:3}}>
                  {(e.transformation_type||'direct').replace('TransformationType.','')} · added {e.created_at ? new Date(e.created_at*1000).toLocaleDateString() : 'legacy'}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
