import { useEffect, useState } from 'react';
import { api } from '../utils/api.js';

function ConfidenceBadge({ score }) {
  const pct = Math.round(score * 100);
  const color = score >= 0.85 ? '#00d4aa' : score >= 0.6 ? '#ffb347' : '#ff5a7d';
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
      <div style={{ width: 60, height: 5, background: 'var(--bg)', borderRadius: 3, overflow: 'hidden' }}>
        <div style={{ width: `${pct}%`, height: '100%', background: color, borderRadius: 3 }} />
      </div>
      <span style={{ fontSize: 10, color }}>{pct}%</span>
    </div>
  );
}

export default function AuditTrail({ fieldId }) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [expanded, setExpanded] = useState(false);

  useEffect(() => {
    if (!fieldId) return;
    setLoading(true);
    api.audit(fieldId).then(setData).catch(() => setData(null)).finally(() => setLoading(false));
  }, [fieldId]);

  if (!fieldId) return <div style={{ color: 'var(--text3)', padding: 16 }}>Select a field to view its audit trail.</div>;
  if (loading) return <div style={{ color: 'var(--text3)', padding: 16 }} className="pulse">Loading audit trail…</div>;
  if (!data) return <div style={{ color: 'var(--text3)', padding: 16 }}>Audit data unavailable.</div>;

  const authEdges = data.lineage_path?.edges?.filter(e => e.source_type === 'authoritative') || [];
  const infEdges = data.lineage_path?.edges?.filter(e => e.source_type === 'inferred') || [];

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
      {/* Completeness */}
      <div style={{ padding: '10px 14px', background: 'var(--bg3)', borderRadius: 'var(--radius)', border: '1px solid var(--border)' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 }}>
          <span style={{ fontSize: 11, color: 'var(--text3)' }}>Lineage completeness</span>
          <ConfidenceBadge score={data.completeness_score} />
        </div>
        <div style={{ display: 'flex', gap: 16, fontSize: 11, color: 'var(--text2)' }}>
          <span><span style={{ color: 'var(--teal)' }}>{authEdges.length}</span> authoritative</span>
          <span><span style={{ color: 'var(--accent2)' }}>{infEdges.length}</span> inferred</span>
        </div>
      </div>

      {/* Conflicts */}
      {data.conflicts?.length > 0 && (
        <div style={{ padding: '8px 12px', background: 'rgba(255,90,125,0.07)', border: '1px solid rgba(255,90,125,0.2)', borderRadius: 'var(--radius)' }}>
          <div style={{ color: 'var(--red)', fontSize: 11, fontWeight: 600, marginBottom: 4 }}>⚠ Conflicts detected</div>
          {data.conflicts.map((c, i) => (
            <div key={i} style={{ color: 'var(--text2)', fontSize: 10, marginBottom: 2 }}>• {c}</div>
          ))}
        </div>
      )}

      {/* Authoritative edges */}
      {authEdges.length > 0 && (
        <div>
          <div style={{ fontSize: 10, color: 'var(--teal)', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 6, display: 'flex', alignItems: 'center', gap: 6 }}>
            <div style={{ width: 8, height: 8, borderRadius: '50%', background: 'var(--teal)' }} /> Authoritative sources
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
            {authEdges.map(e => (
              <div key={e.id} style={{ padding: '7px 10px', background: 'var(--bg3)', border: '1px solid rgba(0,212,170,0.15)', borderRadius: 6, fontSize: 11 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 2 }}>
                  <span style={{ color: 'var(--text2)' }}>{e.source_field.split('.').slice(-1)[0]}</span>
                  <span style={{ color: 'var(--text3)' }}>→</span>
                  <span style={{ color: 'var(--text)' }}>{e.target_field.split('.').slice(-1)[0]}</span>
                  <span className="tag tag-auth" style={{ marginLeft: 'auto' }}>{e.transformation_type}</span>
                </div>
                {e.transformation_logic && (
                  <div style={{ color: 'var(--text3)', fontSize: 10, fontStyle: 'italic' }}>{e.transformation_logic}</div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Inferred edges */}
      {infEdges.length > 0 && (
        <div>
          <div style={{ fontSize: 10, color: 'var(--accent2)', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 6, display: 'flex', alignItems: 'center', gap: 6 }}>
            <div style={{ width: 8, height: 8, borderRadius: '50%', background: 'var(--accent)', border: '1px dashed var(--accent)' }} /> AI-inferred links
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
            {infEdges.slice(0, expanded ? undefined : 3).map(e => (
              <div key={e.id} style={{ padding: '7px 10px', background: 'var(--bg3)', border: '1px dashed rgba(108,99,255,0.25)', borderRadius: 6, fontSize: 11 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginBottom: 2 }}>
                  <span style={{ color: 'var(--text2)' }}>{e.source_field.split('.').slice(-1)[0]}</span>
                  <span style={{ color: 'var(--text3)' }}>⇢</span>
                  <span style={{ color: 'var(--text)' }}>{e.target_field.split('.').slice(-1)[0]}</span>
                  <ConfidenceBadge score={e.confidence} />
                </div>
                {e.reasoning && (
                  <div style={{ color: 'var(--text3)', fontSize: 10, marginTop: 3, fontStyle: 'italic', borderLeft: '2px solid var(--accent)', paddingLeft: 6 }}>{e.reasoning}</div>
                )}
              </div>
            ))}
            {infEdges.length > 3 && (
              <button onClick={() => setExpanded(!expanded)}
                style={{ background: 'none', color: 'var(--accent2)', fontSize: 11, textAlign: 'left', padding: '2px 0' }}>
                {expanded ? '▲ Show less' : `▼ +${infEdges.length - 3} more`}
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
