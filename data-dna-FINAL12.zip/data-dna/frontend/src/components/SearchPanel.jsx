import { useState } from 'react';
import { api } from '../utils/api.js';

export default function SearchPanel({ onSelect }) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [systemFilter, setSystemFilter] = useState('');

  const search = async (e) => {
    e.preventDefault();
    if (!query.trim()) return;
    setLoading(true);
    try {
      const res = await api.search(query, 8, systemFilter || undefined);
      setResults(res.results || []);
    } catch { setResults([]); }
    setLoading(false);
  };

  const examples = ['customer id', 'credit limit', 'outstanding balance', 'composite score'];

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      <form onSubmit={search} style={{ marginBottom: 12 }}>
        <div style={{ display: 'flex', gap: 8, marginBottom: 8 }}>
          <input
            value={query} onChange={e => setQuery(e.target.value)}
            placeholder="Search fields by name, meaning, or description…"
            style={{
              flex: 1, background: 'var(--bg3)', border: '1px solid var(--border2)',
              borderRadius: 'var(--radius)', padding: '8px 12px', color: 'var(--text)',
              fontSize: 12,
            }}
          />
          <button type="submit" style={{
            padding: '8px 16px', background: 'var(--accent)', color: '#fff',
            borderRadius: 'var(--radius)', fontSize: 12, fontWeight: 600,
          }}>
            {loading ? '…' : 'Search'}
          </button>
        </div>
        <select value={systemFilter} onChange={e => setSystemFilter(e.target.value)}
          style={{ background: 'var(--bg3)', border: '1px solid var(--border)', borderRadius: 'var(--radius)', padding: '5px 10px', color: 'var(--text2)', fontSize: 11 }}>
          <option value="">All systems</option>
          <option>CREDIT_CORE</option>
          <option>RISK_ENGINE</option>
          <option>REPORTING</option>
        </select>
      </form>

      {!results.length && !loading && (
        <div>
          <div style={{ color: 'var(--text3)', fontSize: 11, marginBottom: 8 }}>Try:</div>
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
            {examples.map(ex => (
              <button key={ex} onClick={() => { setQuery(ex); }}
                style={{ padding: '4px 10px', background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 20, color: 'var(--text2)', fontSize: 11 }}>
                {ex}
              </button>
            ))}
          </div>
        </div>
      )}

      <div style={{ flex: 1, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: 6 }}>
        {results.map(r => (
          <div key={r.field_id} onClick={() => onSelect?.(r.field_id)}
            style={{
              padding: '10px 12px', background: 'var(--bg3)', border: '1px solid var(--border)',
              borderRadius: 'var(--radius)', cursor: 'pointer', transition: 'border-color 0.15s',
            }}
            onMouseEnter={e => e.currentTarget.style.borderColor = 'var(--accent)'}
            onMouseLeave={e => e.currentTarget.style.borderColor = 'var(--border)'}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 3 }}>
              <span style={{ color: 'var(--text)', fontWeight: 600, fontSize: 12 }}>
                {r.table}<span style={{ color: 'var(--text3)' }}>.</span>{r.column}
              </span>
              <span style={{ color: 'var(--text3)', fontSize: 10 }}>{(r.score * 100).toFixed(0)}% match</span>
            </div>
            <div style={{ color: 'var(--text3)', fontSize: 10, marginBottom: 4 }}>{r.system}</div>
            <div style={{ color: 'var(--text2)', fontSize: 10 }}>{r.match_reason}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
