/**
 * InferPanel — Visual Source→Target selector for AI lineage discovery
 * User picks source system + target system from dropdowns or drag UI
 * Then clicks "Discover Lineage" — AI maps fields between them
 */
import { useState, useEffect } from 'react';
import { api } from '../utils/api.js';

const SYS_COLOR = {
  CREDIT_CORE: '#00d4aa', RISK_ENGINE: '#6c63ff',
  REPORTING: '#ffb347',   BUREAU_DATA: '#60a5fa',
};
const col = (s) => SYS_COLOR[s] || '#8b85ff';

function SystemCard({ system, fieldCount, role, selected, onClick, side }) {
  const c = col(system);
  const isSelected = selected === system;
  const borderColor = side === 'source' ? '#00d4aa' : '#ff5a7d';

  return (
    <div onClick={() => onClick(system)}
      style={{
        padding: '12px 14px', borderRadius: 10, cursor: 'pointer',
        background: isSelected ? `${borderColor}12` : 'var(--bg3)',
        border: `1.5px solid ${isSelected ? borderColor : 'var(--border)'}`,
        transition: 'all 0.15s', position: 'relative',
      }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
        <div style={{ width: 10, height: 10, borderRadius: '50%', background: c, flexShrink: 0 }} />
        <span style={{ fontSize: 12, fontWeight: 600, color: isSelected ? borderColor : 'var(--text)' }}>{system}</span>
        {isSelected && (
          <span style={{
            marginLeft: 'auto', fontSize: 10, padding: '2px 8px', borderRadius: 20,
            background: borderColor + '20', color: borderColor, fontWeight: 600
          }}>
            {side === 'source' ? '⬆ SOURCE' : '⬇ TARGET'}
          </span>
        )}
      </div>
      <div style={{ fontSize: 11, color: 'var(--text3)', paddingLeft: 18 }}>
        {fieldCount} fields
        {role && <span style={{ marginLeft: 8, color: role === 'root' ? '#4ade80' : role === 'leaf' ? '#ff5a7d' : '#ffb347' }}>· {role}</span>}
      </div>
    </div>
  );
}

function MappingRow({ edge, index }) {
  const srcField = edge.source_field?.split('.').slice(-1)[0] || edge.source_field;
  const tgtField = edge.target_field?.split('.').slice(-1)[0] || edge.target_field;
  const srcSystem = edge.source_field?.split('.')[0];
  const tgtSystem = edge.target_field?.split('.')[0];
  const confidence = Math.round((edge.confidence || 0) * 100);
  const confColor = confidence >= 85 ? '#4ade80' : confidence >= 65 ? '#ffb347' : '#ff5a7d';

  const typeColors = {
    direct: '#00d4aa', renamed: '#60a5fa',
    aggregated: '#ffb347', derived: '#9b91ff',
    filtered: '#ff5a7d', joined: '#f472b6',
  };
  const tcolor = typeColors[edge.transformation_type] || '#9b91ff';

  return (
    <div className="fade-in" style={{
      padding: '10px 14px', background: 'var(--bg3)',
      border: '1px dashed rgba(108,99,255,0.3)', borderRadius: 8,
      marginBottom: 6, animationDelay: `${index * 0.04}s`
    }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 8, marginBottom: 4 }}>
        {/* Source field */}
        <div style={{ flex: 1, padding: '4px 8px', background: 'rgba(0,212,170,0.08)', border: '1px solid rgba(0,212,170,0.25)', borderRadius: 6, fontSize: 11, color: '#00d4aa', fontFamily: 'var(--font-mono)' }}>
          <div style={{ fontSize: 9, color: 'var(--text3)', marginBottom: 1 }}>{srcSystem}</div>
          {srcField}
        </div>

        {/* Arrow + type */}
        <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 2, flexShrink: 0 }}>
          <div style={{ fontSize: 9, padding: '1px 6px', borderRadius: 10, background: tcolor + '20', color: tcolor }}>{edge.transformation_type || 'direct'}</div>
          <div style={{ color: 'var(--text3)', fontSize: 16 }}>→</div>
        </div>

        {/* Target field */}
        <div style={{ flex: 1, padding: '4px 8px', background: 'rgba(255,90,125,0.08)', border: '1px solid rgba(255,90,125,0.25)', borderRadius: 6, fontSize: 11, color: '#ff5a7d', fontFamily: 'var(--font-mono)' }}>
          <div style={{ fontSize: 9, color: 'var(--text3)', marginBottom: 1 }}>{tgtSystem}</div>
          {tgtField}
        </div>

        {/* Confidence */}
        <div style={{ flexShrink: 0, textAlign: 'center', minWidth: 36 }}>
          <div style={{ fontSize: 13, fontWeight: 700, color: confColor, fontFamily: 'var(--font-head)' }}>{confidence}%</div>
          <div style={{ fontSize: 9, color: 'var(--text3)' }}>conf</div>
        </div>
      </div>

      {/* Reasoning */}
      {edge.reasoning && (
        <div style={{ fontSize: 10, color: 'var(--text3)', borderLeft: '2px solid rgba(108,99,255,0.3)', paddingLeft: 8, marginTop: 4, fontStyle: 'italic', lineHeight: 1.5 }}>
          {edge.reasoning}
        </div>
      )}
    </div>
  );
}

export default function InferPanel({ onGraphRefresh }) {
  const [systems, setSystems] = useState([]);
  const [fieldCounts, setFieldCounts] = useState({});
  const [source, setSource] = useState('');
  const [target, setTarget] = useState('');
  const [context, setContext] = useState('');
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState(null);
  const [error, setError] = useState('');
  const [saved, setSaved] = useState(false);
  const [step, setStep] = useState(1); // 1=pick, 2=context, 3=results

  useEffect(() => {
    api.stats().then(s => {
      const sysList = s.systems || [];
      setSystems(sysList);
      // Get field counts per system
      Promise.all(sysList.map(sys =>
        api.fields(sys).then(f => [sys, f.length]).catch(() => [sys, 0])
      )).then(counts => {
        const map = {};
        counts.forEach(([sys, cnt]) => { map[sys] = cnt; });
        setFieldCounts(map);
      });
    });
  }, []);

  const handleSourceClick = (sys) => {
    if (sys === target) setTarget('');
    setSource(sys);
    if (source && target && sys !== target) setStep(2);
  };

  const handleTargetClick = (sys) => {
    if (sys === source) setSource('');
    setTarget(sys);
    if (source && sys !== source) setStep(2);
  };

  const runInference = async () => {
    if (!source || !target) { setError('Select both source and target systems'); return; }
    if (source === target) { setError('Source and target must be different'); return; }
    setLoading(true);
    setError('');
    setResults(null);
    try {
      const url = `/audit/infer?source_system=${encodeURIComponent(source)}&target_system=${encodeURIComponent(target)}${context ? `&context=${encodeURIComponent(context)}` : ''}`;
      const res = await fetch(`http://localhost:8000${url}`, { method: 'POST' });
      if (!res.ok) throw new Error(await res.text());
      const data = await res.json();
      setResults(data);
      setStep(3);
    } catch (e) {
      setError(e.message || 'Inference failed');
    }
    setLoading(false);
  };

  const saveToGraph = () => {
    onGraphRefresh?.();
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  const reset = () => {
    setSource(''); setTarget(''); setResults(null);
    setError(''); setStep(1); setSaved(false);
  };

  const CONTEXT_EXAMPLES = {
    'CBS_SYSTEM→RISK_ENGINE':   'CBS sends daily loan account data to RISK for exposure calculation',
    'LOS→CBS_SYSTEM':           'LOS sends approved loan applications to CBS for account creation',
    'CBS_SYSTEM→REPORTING':     'CBS feeds monthly MIS reports with aggregated account data',
    'CREDIT_CORE→RISK_ENGINE':  'CREDIT_CORE sends account data to RISK for scoring and exposure',
  };
  const contextHint = CONTEXT_EXAMPLES[`${source}→${target}`] || '';

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%', gap: 0, overflow: 'auto' }}>

      {/* Header */}
      <div style={{ padding: '20px 24px 0', flexShrink: 0 }}>
        <h2 style={{ fontFamily: 'var(--font-head)', fontWeight: 700, color: 'var(--text)', marginBottom: 4, fontSize: 18 }}>
          ⟳ Discover Lineage
        </h2>
        <p style={{ color: 'var(--text3)', fontSize: 12, marginBottom: 16 }}>
          Pick a source system and a target system — AI will map which fields flow from source to target.
        </p>

        {/* Step indicator */}
        <div style={{ display: 'flex', gap: 6, alignItems: 'center', marginBottom: 20 }}>
          {[['1','Pick systems'],['2','Add context'],['3','View mappings']].map(([n,l], i) => (
            <div key={n} style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
              <div style={{
                width: 22, height: 22, borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: 11, fontWeight: 600,
                background: step > i+1 ? 'var(--green)' : step === i+1 ? 'var(--accent)' : 'var(--surface)',
                color: step >= i+1 ? '#fff' : 'var(--text3)',
              }}>{step > i+1 ? '✓' : n}</div>
              <span style={{ fontSize: 11, color: step === i+1 ? 'var(--text)' : 'var(--text3)' }}>{l}</span>
              {i < 2 && <div style={{ width: 20, height: 1, background: 'var(--border)' }} />}
            </div>
          ))}
          {(source || target || results) && (
            <button onClick={reset} style={{ marginLeft: 'auto', fontSize: 11, color: 'var(--text3)', background: 'none', padding: '3px 8px', border: '1px solid var(--border)', borderRadius: 6 }}>
              ↺ Reset
            </button>
          )}
        </div>
      </div>

      <div style={{ flex: 1, padding: '0 24px 24px', overflow: 'auto' }}>

        {/* Step 1 — Pick systems */}
        <div style={{ marginBottom: 20 }}>
          <div style={{ display: 'grid', gridTemplateColumns: '1fr auto 1fr', gap: 12, alignItems: 'start' }}>

            {/* Source column */}
            <div>
              <div style={{ fontSize: 11, fontWeight: 600, color: '#00d4aa', textTransform: 'uppercase', letterSpacing: '0.07em', marginBottom: 8, display: 'flex', alignItems: 'center', gap: 6 }}>
                <div style={{ width: 8, height: 8, borderRadius: '50%', background: '#00d4aa' }} />
                Source system
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                {systems.length === 0 && (
                  <div style={{ fontSize: 12, color: 'var(--text3)', padding: '12px', background: 'var(--bg3)', borderRadius: 8, textAlign: 'center' }}>
                    No systems loaded yet.<br/>Go to Ingest or DB Connect first.
                  </div>
                )}
                {systems.map(sys => (
                  <SystemCard key={sys} system={sys} fieldCount={fieldCounts[sys] || 0}
                    selected={source} onClick={handleSourceClick} side="source" />
                ))}
              </div>
            </div>

            {/* Middle arrow */}
            <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', paddingTop: 32 }}>
              <div style={{ fontSize: 28, color: source && target ? 'var(--accent)' : 'var(--border2)' }}>⇢</div>
              {source && target && (
                <div style={{ fontSize: 9, color: 'var(--text3)', textAlign: 'center', marginTop: 4, maxWidth: 60 }}>
                  {source.split('_')[0]} → {target.split('_')[0]}
                </div>
              )}
            </div>

            {/* Target column */}
            <div>
              <div style={{ fontSize: 11, fontWeight: 600, color: '#ff5a7d', textTransform: 'uppercase', letterSpacing: '0.07em', marginBottom: 8, display: 'flex', alignItems: 'center', gap: 6 }}>
                <div style={{ width: 8, height: 8, borderRadius: '50%', background: '#ff5a7d' }} />
                Target system
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
                {systems.map(sys => (
                  <SystemCard key={sys} system={sys} fieldCount={fieldCounts[sys] || 0}
                    selected={target} onClick={handleTargetClick} side="target" />
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Step 2 — Context */}
        {source && target && (
          <div className="fade-in" style={{ marginBottom: 16 }}>
            <div style={{ fontSize: 11, color: 'var(--text3)', textTransform: 'uppercase', letterSpacing: '0.07em', marginBottom: 6 }}>
              Context (optional — improves accuracy)
            </div>
            <textarea value={context} onChange={e => setContext(e.target.value)}
              placeholder={contextHint || `Describe how ${source} sends data to ${target}. E.g. "Nightly batch ETL copies loan account data for risk calculations"`}
              style={{ width: '100%', background: 'var(--bg3)', border: '1px solid var(--border2)', borderRadius: 8, padding: '9px 12px', fontSize: 12, resize: 'vertical', minHeight: 64, lineHeight: 1.6, color: 'var(--text)' }} />
            {contextHint && !context && (
              <button onClick={() => setContext(contextHint)}
                style={{ fontSize: 11, color: 'var(--accent2)', background: 'none', padding: '4px 0', marginTop: 2 }}>
                Use suggestion: "{contextHint}" →
              </button>
            )}

            {/* Ready banner */}
            <div style={{ marginTop: 12, padding: '10px 14px', background: 'rgba(108,99,255,0.08)', border: '1px solid rgba(108,99,255,0.25)', borderRadius: 8, display: 'flex', alignItems: 'center', gap: 10 }}>
              <div style={{ flex: 1, fontSize: 12, color: 'var(--text2)' }}>
                <span style={{ color: '#00d4aa', fontWeight: 600 }}>{source}</span>
                <span style={{ color: 'var(--text3)', margin: '0 8px' }}>({fieldCounts[source] || 0} fields)</span>
                <span style={{ color: 'var(--accent2)', fontSize: 16 }}>⇢</span>
                <span style={{ color: '#ff5a7d', fontWeight: 600, marginLeft: 8 }}>{target}</span>
                <span style={{ color: 'var(--text3)', marginLeft: 8 }}>({fieldCounts[target] || 0} fields)</span>
              </div>
              <button onClick={runInference} disabled={loading}
                style={{ padding: '9px 20px', background: loading ? 'var(--surface)' : 'var(--accent)', color: '#fff', borderRadius: 8, fontWeight: 700, fontSize: 13, flexShrink: 0, minWidth: 140 }}>
                {loading ? (
                  <span style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                    <span className="pulse">◎</span> Discovering…
                  </span>
                ) : '⟳ Discover Lineage'}
              </button>
            </div>
          </div>
        )}

        {error && (
          <div style={{ padding: '10px 14px', background: 'rgba(255,90,125,0.08)', border: '1px solid rgba(255,90,125,0.3)', borderRadius: 8, fontSize: 12, color: 'var(--red)', marginBottom: 12 }}>
            ⚠ {error}
          </div>
        )}

        {/* Step 3 — Results */}
        {results && (
          <div className="fade-in">
            {/* Summary */}
            <div style={{ display: 'flex', gap: 10, marginBottom: 14 }}>
              <div style={{ flex: 1, padding: '10px 14px', background: 'rgba(108,99,255,0.08)', border: '1px solid rgba(108,99,255,0.2)', borderRadius: 8, fontSize: 12 }}>
                <div style={{ color: 'var(--text3)', fontSize: 10, marginBottom: 2 }}>MAPPINGS FOUND</div>
                <div style={{ fontSize: 22, fontWeight: 800, color: 'var(--accent2)', fontFamily: 'var(--font-head)' }}>{results.inferred_edges || 0}</div>
              </div>
              <div style={{ flex: 1, padding: '10px 14px', background: 'rgba(74,222,128,0.06)', border: '1px solid rgba(74,222,128,0.2)', borderRadius: 8, fontSize: 12 }}>
                <div style={{ color: 'var(--text3)', fontSize: 10, marginBottom: 2 }}>AVG CONFIDENCE</div>
                <div style={{ fontSize: 22, fontWeight: 800, color: 'var(--green)', fontFamily: 'var(--font-head)' }}>
                  {results.edges?.length > 0
                    ? Math.round(results.edges.reduce((a, e) => a + (e.confidence || 0), 0) / results.edges.length * 100) + '%'
                    : '—'}
                </div>
              </div>
              <div style={{ flex: 1, padding: '10px 14px', background: 'rgba(255,179,71,0.06)', border: '1px solid rgba(255,179,71,0.2)', borderRadius: 8, fontSize: 12 }}>
                <div style={{ color: 'var(--text3)', fontSize: 10, marginBottom: 2 }}>SKIPPED</div>
                <div style={{ fontSize: 22, fontWeight: 800, color: 'var(--amber)', fontFamily: 'var(--font-head)' }}>{results.skipped || 0}</div>
              </div>
            </div>

            {/* Mappings list */}
            <div style={{ fontSize: 11, color: 'var(--text3)', textTransform: 'uppercase', letterSpacing: '0.07em', marginBottom: 8, display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <span>Field mappings (dashed = AI inferred)</span>
              <div style={{ display: 'flex', gap: 8 }}>
                {saved
                  ? <span style={{ color: 'var(--green)', fontSize: 11 }}>✓ Saved to graph</span>
                  : <button onClick={saveToGraph}
                      style={{ fontSize: 11, padding: '4px 12px', background: 'var(--teal)', color: '#000', borderRadius: 6, fontWeight: 600 }}>
                      Save to graph
                    </button>
                }
                <button onClick={() => window.open('http://localhost:8000/docs#/audit/infer_lineage_audit_infer_post', '_blank')}
                  style={{ fontSize: 11, padding: '4px 10px', background: 'var(--surface)', border: '1px solid var(--border)', color: 'var(--text3)', borderRadius: 6 }}>
                  API docs ↗
                </button>
              </div>
            </div>

            {results.edges?.length === 0 && (
              <div style={{ padding: '20px', textAlign: 'center', color: 'var(--text3)', fontSize: 12, background: 'var(--bg3)', borderRadius: 8 }}>
                No mappings found between these systems.<br/>
                Try adding an AI provider in Settings, or add field descriptions to improve accuracy.
              </div>
            )}

            {results.edges?.map((edge, i) => (
              <MappingRow key={edge.id || i} edge={edge} index={i} />
            ))}

            {results.edges?.length > 0 && (
              <div style={{ padding: '10px 14px', background: 'rgba(255,179,71,0.07)', border: '1px solid rgba(255,179,71,0.2)', borderRadius: 8, fontSize: 11, color: 'var(--amber)', marginTop: 8 }}>
                ⚠ These are AI-inferred mappings — always verify with a domain expert. To make any mapping authoritative, paste the actual ETL SQL in the Ingest tab.
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}
