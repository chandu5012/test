/**
 * TimelineView v3 — Enterprise Data Flow Timeline
 * Production design for 5000 systems, 100K tables
 *
 * ARCHITECTURE:
 *  - Left panel: System catalog with layer grouping (Source/Middle/Reporting/Analytical)
 *  - Main canvas: Left-to-right flow diagram — ONLY selected systems rendered
 *  - On-demand: Click system to expand table list; click table to see field flow
 *  - Performance: Never renders all nodes — always on-demand, virtualized
 *
 * USE CASE: Non-technical stakeholders (CFO, CRO, examiners) need to understand
 * how data flows from core banking → risk → reporting without seeing a force graph.
 */
import { useState, useEffect, useMemo, useRef, useCallback } from 'react';

const BASE = 'http://localhost:8000';

// Dynamic color — any number of systems supported
const PALETTE = [
  '#00d4aa','#7c6fff','#4fc3f7','#ffb347','#ff5a7d',
  '#00b896','#ab47bc','#26c6da','#ff8f00','#ec407a',
  '#64b5f6','#a5d6a7','#ffd54f','#ffab91','#ce93d8',
  '#80cbc4','#ef9a9a','#90caf9','#a5d6a7','#f48fb1',
];
const colorCache = {};
let ci = 0;
const sc = s => { if (!colorCache[s]) colorCache[s] = PALETTE[ci++ % PALETTE.length]; return colorCache[s]; };

const TRANSFORM_COLORS = {
  direct:'#00d4aa', renamed:'#4fc3f7', aggregated:'#ffb347',
  derived:'#ab47bc', filtered:'#ec407a', joined:'#ff8f00',
};
const tc = t => TRANSFORM_COLORS[(t||'direct').replace('TransformationType.','').toLowerCase()] || '#8b85ff';

/* ─── helpers ─────────────────────────────────────────────── */
function buildIndex(nodes, links) {
  const bySystem = {}, byTable = {};
  const srcSysEdges = {}, tgtSysEdges = {};
  const srcTblEdges = {}, tgtTblEdges = {};

  nodes.forEach(n => {
    (bySystem[n.system] = bySystem[n.system] || { tables:{}, count:0 });
    bySystem[n.system].tables[n.table] = bySystem[n.system].tables[n.table] || [];
    bySystem[n.system].tables[n.table].push(n);
    bySystem[n.system].count++;
    (byTable[`${n.system}.${n.table}`] = byTable[`${n.system}.${n.table}`] || []).push(n);
  });

  links.forEach(l => {
    const sid = typeof l.source==='object'?l.source.id:l.source;
    const tid = typeof l.target==='object'?l.target.id:l.target;
    const [ss,st] = sid.split('.'), [ts,tt] = tid.split('.');
    if (!ss||!ts) return;
    (srcSysEdges[ss]=srcSysEdges[ss]||[]).push(l);
    (tgtSysEdges[ts]=tgtSysEdges[ts]||[]).push(l);
    const sk=`${ss}.${st}`,tk=`${ts}.${tt}`;
    (srcTblEdges[sk]=srcTblEdges[sk]||[]).push(l);
    (tgtTblEdges[tk]=tgtTblEdges[tk]||[]).push(l);
  });

  return { bySystem, byTable, srcSysEdges, tgtSysEdges, srcTblEdges, tgtTblEdges };
}

/* ─── Left catalog panel ───────────────────────────────────── */
function CatalogPanel({ idx, pinned, togglePin, selTable, setSelTable }) {
  const [search, setSearch]     = useState('');
  const [expanded, setExpanded] = useState(new Set());

  const systems = useMemo(() => Object.keys(idx.bySystem||{}).sort(), [idx]);

  const filtered = useMemo(() => {
    if (!search) return systems;
    const q = search.toLowerCase();
    return systems.filter(s => s.toLowerCase().includes(q) ||
      Object.keys(idx.bySystem[s]?.tables||{}).some(t=>t.toLowerCase().includes(q)));
  }, [systems, search, idx]);

  const tog = s => setExpanded(p=>{const n=new Set(p);n.has(s)?n.delete(s):n.add(s);return n;});

  return (
    <div style={{width:220,flexShrink:0,display:'flex',flexDirection:'column',height:'100%',
      borderRight:'1px solid var(--color-border-tertiary)',background:'var(--color-background-secondary)'}}>
      <div style={{padding:'10px',borderBottom:'1px solid var(--color-border-tertiary)',flexShrink:0}}>
        <div style={{fontSize:11,fontWeight:600,color:'var(--color-text-primary)',marginBottom:6}}>Data Systems</div>
        <div style={{position:'relative'}}>
          <input value={search} onChange={e=>setSearch(e.target.value)}
            placeholder="Filter systems, tables…"
            style={{width:'100%',padding:'4px 22px 4px 6px',fontSize:10,
              border:'1px solid var(--color-border-secondary)',borderRadius:5,
              background:'var(--color-background-primary)',color:'var(--color-text-primary)'}}/>
          {search
            ?<button onClick={()=>setSearch('')} style={{position:'absolute',right:5,top:'50%',transform:'translateY(-50%)',background:'none',border:'none',color:'var(--color-text-tertiary)',cursor:'pointer',fontSize:12}}>×</button>
            :<span style={{position:'absolute',right:6,top:'50%',transform:'translateY(-50%)',fontSize:10,color:'var(--color-text-tertiary)'}}>⌕</span>
          }
        </div>
        <div style={{fontSize:9,color:'var(--color-text-tertiary)',marginTop:4}}>
          {systems.length} systems · {pinned.size} pinned to timeline
        </div>
      </div>
      <div style={{flex:1,overflow:'auto'}}>
        {filtered.map(sys => {
          const d = idx.bySystem[sys]||{};
          const tables = Object.keys(d.tables||{}).sort().filter(t=>!search||t.toLowerCase().includes(search.toLowerCase())||sys.toLowerCase().includes(search.toLowerCase()));
          const isExp = expanded.has(sys);
          const isPinned = pinned.has(sys);
          const color = sc(sys);
          const outEdges = (idx.srcSysEdges[sys]||[]).length;
          const inEdges  = (idx.tgtSysEdges[sys]||[]).length;
          return (
            <div key={sys}>
              <div style={{display:'flex',alignItems:'center',gap:4,padding:'5px 8px',
                borderBottom:'1px solid var(--color-border-tertiary)',
                background:isPinned?`${color}08`:'transparent'}}>
                <button onClick={()=>tog(sys)}
                  style={{background:'none',border:'none',cursor:'pointer',padding:'0 2px',
                    color,fontSize:8,transition:'transform .15s',
                    transform:isExp?'rotate(90deg)':'rotate(0)'}}>▶</button>
                <div style={{width:7,height:7,borderRadius:'50%',background:color,flexShrink:0}}/>
                <span style={{fontSize:10,fontWeight:500,color,flex:1,
                  overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap',cursor:'pointer'}}
                  onClick={()=>tog(sys)}>{sys}</span>
                <div style={{display:'flex',gap:2,alignItems:'center',flexShrink:0}}>
                  {outEdges>0&&<span style={{fontSize:7,color:'#00d4aa',fontWeight:700}} title={`${outEdges} outgoing`}>↗</span>}
                  {inEdges>0&&<span style={{fontSize:7,color:'#ffb347',fontWeight:700}} title={`${inEdges} incoming`}>↙</span>}
                  <button onClick={()=>togglePin(sys)}
                    title={isPinned?'Remove from timeline':'Add to timeline'}
                    style={{background:'none',border:'none',cursor:'pointer',padding:'0 2px',
                      fontSize:11,color:isPinned?color:'var(--color-border-secondary)',
                      lineHeight:1}}>
                    {isPinned?'◆':'◇'}
                  </button>
                </div>
              </div>
              {isExp && tables.map(tbl=>{
                const tblKey=`${sys}.${tbl}`;
                const isSel = selTable===tblKey;
                const srcE=(idx.srcTblEdges[tblKey]||[]).length;
                const tgtE=(idx.tgtTblEdges[tblKey]||[]).length;
                return (
                  <div key={tbl} onClick={()=>setSelTable(isSel?null:tblKey)}
                    style={{display:'flex',alignItems:'center',gap:4,padding:'3px 8px 3px 20px',
                      cursor:'pointer',borderBottom:'1px solid var(--color-border-tertiary)',
                      background:isSel?`${color}15`:'transparent'}}>
                    <svg width="9" height="9" viewBox="0 0 9 9" style={{flexShrink:0}}>
                      <rect x=".5" y=".5" width="8" height="8" rx="1" fill="none"
                        stroke={isSel?color:'var(--color-border-secondary)'} strokeWidth=".8"/>
                      <line x1=".5" y1="3.5" x2="8.5" y2="3.5" stroke={isSel?color:'var(--color-border-secondary)'} strokeWidth=".6"/>
                    </svg>
                    <span style={{fontSize:9,color:isSel?color:'var(--color-text-secondary)',
                      flex:1,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}} title={tbl}>{tbl}</span>
                    <div style={{display:'flex',gap:2,flexShrink:0}}>
                      {srcE>0&&<span style={{fontSize:7,color:'#00d4aa',fontWeight:700}}>↗{srcE}</span>}
                      {tgtE>0&&<span style={{fontSize:7,color:'#ffb347',fontWeight:700}}>↙{tgtE}</span>}
                    </div>
                  </div>
                );
              })}
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ─── System column (in timeline canvas) ──────────────────── */
function SystemColumn({ sys, idx, selTable, setSelTable, links, allNodes }) {
  const color = sc(sys);
  const d = idx.bySystem[sys]||{};
  const tables = Object.keys(d.tables||{}).sort();

  return (
    <div style={{minWidth:200,maxWidth:240,flexShrink:0,display:'flex',flexDirection:'column',
      border:`1px solid ${color}30`,borderRadius:10,
      background:`${color}05`,overflow:'hidden'}}>
      {/* Header */}
      <div style={{padding:'10px 12px',background:`${color}18`,
        borderBottom:`1px solid ${color}25`}}>
        <div style={{display:'flex',alignItems:'center',gap:7,marginBottom:4}}>
          <div style={{width:10,height:10,borderRadius:'50%',background:color,flexShrink:0}}/>
          <span style={{fontSize:13,fontWeight:600,color}}>{sys}</span>
        </div>
        <div style={{fontSize:10,color:'var(--color-text-tertiary)'}}>
          {tables.length} tables · {d.count} fields
        </div>
        <div style={{display:'flex',gap:6,marginTop:4,fontSize:9}}>
          {(idx.tgtSysEdges[sys]||[]).length>0&&
            <span style={{color:'#00d4aa'}}>↙ {new Set((idx.tgtSysEdges[sys]||[]).map(l=>{
              const s=typeof l.source==='object'?l.source.id:l.source;
              return s.split('.')[0];
            })).size} sources</span>}
          {(idx.srcSysEdges[sys]||[]).length>0&&
            <span style={{color:'#ffb347'}}>{new Set((idx.srcSysEdges[sys]||[]).map(l=>{
              const t=typeof l.target==='object'?l.target.id:l.target;
              return t.split('.')[0];
            })).size} targets ↗</span>}
        </div>
      </div>
      {/* Tables */}
      <div style={{flex:1,overflow:'auto',maxHeight:420}}>
        {tables.map(tbl => {
          const tblKey=`${sys}.${tbl}`;
          const isSel=selTable===tblKey;
          const srcE=(idx.srcTblEdges[tblKey]||[]).length;
          const tgtE=(idx.tgtTblEdges[tblKey]||[]).length;
          const hasEdge = srcE>0||tgtE>0;
          const flds = (d.tables[tbl]||[]);
          return (
            <div key={tbl} onClick={()=>setSelTable(isSel?null:tblKey)}
              style={{padding:'7px 10px',borderBottom:`1px solid ${color}20`,
                cursor:'pointer',
                background:isSel?`${color}18`:hasEdge?`${color}06`:'transparent',
                borderLeft:isSel?`3px solid ${color}`:'3px solid transparent',
                transition:'all .1s'}}>
              <div style={{display:'flex',alignItems:'center',gap:6,marginBottom:2}}>
                <svg width="10" height="10" viewBox="0 0 10 10" style={{flexShrink:0}}>
                  <rect x=".5" y=".5" width="9" height="9" rx="1.5" fill="none"
                    stroke={hasEdge?color:'var(--color-border-secondary)'} strokeWidth=".8"/>
                  <line x1=".5" y1="3.5" x2="9.5" y2="3.5" stroke={hasEdge?color:'var(--color-border-secondary)'} strokeWidth=".6"/>
                  <line x1=".5" y1="6.5" x2="9.5" y2="6.5" stroke={hasEdge?color:'var(--color-border-secondary)'} strokeWidth=".6"/>
                </svg>
                <span style={{fontSize:10,fontWeight:isSel?600:hasEdge?500:400,
                  color:isSel?color:hasEdge?'var(--color-text-primary)':'var(--color-text-secondary)',
                  flex:1,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}} title={tbl}>{tbl}</span>
              </div>
              <div style={{display:'flex',gap:6,alignItems:'center'}}>
                <span style={{fontSize:9,color:'var(--color-text-tertiary)'}}>{flds.length} cols</span>
                {tgtE>0&&<span style={{fontSize:9,color:'#00d4aa',fontWeight:600}}>↙{tgtE} in</span>}
                {srcE>0&&<span style={{fontSize:9,color:'#ffb347',fontWeight:600}}>↗{srcE} out</span>}
                {!hasEdge&&<span style={{fontSize:9,color:'var(--color-text-tertiary)'}}>no edges</span>}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}

/* ─── Flow edges SVG overlay ───────────────────────────────── */
function EdgeOverlay({ links, columnRefs, pinnedSystems, selTable }) {
  const [dims, setDims] = useState({});

  useEffect(() => {
    const next = {};
    Object.entries(columnRefs.current).forEach(([sys, el]) => {
      if (el) {
        const r = el.getBoundingClientRect();
        const parent = el.offsetParent?.getBoundingClientRect() || { left:0, top:0 };
        next[sys] = { left: el.offsetLeft, top: el.offsetTop, width: el.offsetWidth, height: el.offsetHeight };
      }
    });
    setDims(next);
  });

  if (Object.keys(dims).length < 2) return null;

  // Group edges by system pair
  const sysPairs = {};
  links.forEach(l => {
    const sid=typeof l.source==='object'?l.source.id:l.source;
    const tid=typeof l.target==='object'?l.target.id:l.target;
    const ss=sid.split('.')[0],ts=tid.split('.')[0];
    if (!pinnedSystems.has(ss)||!pinnedSystems.has(ts)||ss===ts) return;
    const k=`${ss}→${ts}`;
    (sysPairs[k]=sysPairs[k]||{ss,ts,count:0,types:{}}).count++;
    const ttype=(l.transformation_type||'direct').replace('TransformationType.','').toLowerCase();
    sysPairs[k].types[ttype]=(sysPairs[k].types[ttype]||0)+1;
  });

  // Find the scroll container size
  const allDims = Object.values(dims);
  if (!allDims.length) return null;
  const maxRight = Math.max(...allDims.map(d=>d.left+d.width));
  const maxBottom = Math.max(...allDims.map(d=>d.top+d.height));

  return (
    <svg style={{position:'absolute',top:0,left:0,pointerEvents:'none',zIndex:0,
      width:maxRight+40,height:maxBottom+40}} width={maxRight+40} height={maxBottom+40}>
      <defs>
        {Object.entries(TRANSFORM_COLORS).map(([k,c])=>(
          <marker key={k} id={`tl-${k}`} viewBox="0 0 10 10" refX="8" refY="5"
            markerWidth="5" markerHeight="5" orient="auto">
            <path d="M2 1L8 5L2 9" fill="none" stroke={c} strokeWidth="1.5" strokeLinecap="round"/>
          </marker>
        ))}
      </defs>
      {Object.values(sysPairs).map(({ss,ts,count,types}) => {
        const sd = dims[ss], td = dims[ts];
        if (!sd||!td) return null;
        const x1 = sd.left + sd.width;
        const x2 = td.left;
        const y1 = sd.top + sd.height/2;
        const y2 = td.top + td.height/2;
        const mx = (x1+x2)/2;
        const dominant = Object.entries(types).sort((a,b)=>b[1]-a[1])[0]?.[0] || 'direct';
        const color = tc(dominant);
        const thickness = Math.min(1.5 + count * 0.3, 6);
        return (
          <g key={`${ss}→${ts}`}>
            <path d={`M${x1},${y1} C${mx},${y1} ${mx},${y2} ${x2},${y2}`}
              fill="none" stroke={color} strokeWidth={thickness} strokeOpacity={0.55}
              markerEnd={`url(#tl-${dominant})`}/>
            <rect x={mx-16} y={(y1+y2)/2-9} width={32} height={16} rx={8}
              fill="var(--color-background-secondary)" stroke={color} strokeWidth={0.5} strokeOpacity={0.4}/>
            <text x={mx} y={(y1+y2)/2+1} textAnchor="middle" dominantBaseline="central"
              fontSize={9} fontFamily="monospace" fill={color}>{count}</text>
          </g>
        );
      })}
    </svg>
  );
}

/* ─── Field detail panel ───────────────────────────────────── */
function FieldDetailPanel({ selTable, idx, links, allNodes, onClose }) {
  if (!selTable) return null;
  const [sys, tbl] = selTable.split('.');
  const color = sc(sys);
  const fields = idx.byTable[selTable] || [];

  const srcEdges = (idx.srcTblEdges[selTable]||[]);
  const tgtEdges = (idx.tgtTblEdges[selTable]||[]);

  const sourceTables = [...new Set(tgtEdges.map(l => {
    const s=typeof l.source==='object'?l.source.id:l.source;
    const [ss,st]=s.split('.');return `${ss}.${st}`;
  }))];
  const targetTables = [...new Set(srcEdges.map(l => {
    const t=typeof l.target==='object'?l.target.id:l.target;
    const [ts,tt]=t.split('.');return `${ts}.${tt}`;
  }))];

  return (
    <div style={{width:320,flexShrink:0,display:'flex',flexDirection:'column',height:'100%',
      borderLeft:'1px solid var(--color-border-tertiary)',background:'var(--color-background-secondary)'}}>
      <div style={{padding:'10px 12px',borderBottom:'1px solid var(--color-border-tertiary)',
        display:'flex',alignItems:'center',gap:8,flexShrink:0}}>
        <div style={{width:8,height:8,borderRadius:'50%',background:color,flexShrink:0}}/>
        <div style={{flex:1,minWidth:0}}>
          <div style={{fontSize:12,fontWeight:600,color,
            overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{tbl}</div>
          <div style={{fontSize:10,color:'var(--color-text-tertiary)'}}>{sys} · {fields.length} columns</div>
        </div>
        <button onClick={onClose} style={{background:'none',border:'none',cursor:'pointer',
          fontSize:14,color:'var(--color-text-tertiary)',padding:'0 4px'}}>×</button>
      </div>

      <div style={{flex:1,overflow:'auto'}}>
        {/* Source tables */}
        {sourceTables.length > 0 && (
          <div style={{padding:'8px 12px',borderBottom:'1px solid var(--color-border-tertiary)'}}>
            <div style={{fontSize:9,fontWeight:700,color:'#00d4aa',
              textTransform:'uppercase',letterSpacing:'.08em',marginBottom:5}}>
              Sources ({sourceTables.length})
            </div>
            {sourceTables.map(tk=>{
              const [ss,st]=tk.split('.');
              const edgeCount=tgtEdges.filter(l=>{
                const s=typeof l.source==='object'?l.source.id:l.source;
                return s.startsWith(tk+'.');
              }).length;
              return (
                <div key={tk} style={{display:'flex',alignItems:'center',gap:6,padding:'4px 6px',
                  borderRadius:6,marginBottom:3,background:`${sc(ss)}08`,
                  border:`0.5px solid ${sc(ss)}30`}}>
                  <div style={{width:6,height:6,borderRadius:'50%',background:sc(ss),flexShrink:0}}/>
                  <span style={{fontSize:10,color:'var(--color-text-secondary)',flex:1,
                    overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}} title={tk}>{st}</span>
                  <span style={{fontSize:9,color:sc(ss),fontWeight:500}}>{ss}</span>
                  <span style={{fontSize:9,color:'var(--color-text-tertiary)'}}>{edgeCount} edges</span>
                </div>
              );
            })}
          </div>
        )}

        {/* Field list */}
        <div style={{padding:'8px 12px',borderBottom:'1px solid var(--color-border-tertiary)'}}>
          <div style={{fontSize:9,fontWeight:700,color:'var(--color-text-tertiary)',
            textTransform:'uppercase',letterSpacing:'.08em',marginBottom:5}}>
            Columns ({fields.length})
          </div>
          {fields.sort((a,b)=>(a.column_order||99)-(b.column_order||99)||(a.column>b.column?1:-1))
            .map((f,i) => {
            const hasSrc=tgtEdges.some(l=>(typeof l.target==='object'?l.target.id:l.target).endsWith('.'+f.column));
            const hasTgt=srcEdges.some(l=>(typeof l.source==='object'?l.source.id:l.source).endsWith('.'+f.column));
            return (
              <div key={f.id} style={{display:'flex',alignItems:'center',gap:5,
                padding:'3px 5px',borderRadius:4,marginBottom:2,
                background:(hasSrc||hasTgt)?`${color}07`:'transparent'}}>
                {f.is_primary_key
                  ?<svg width="8" height="8" viewBox="0 0 8 8"><circle cx="3" cy="3" r="2" fill="none" stroke="#f59e0b" strokeWidth="1"/><line x1="4.4" y1="4.4" x2="7.5" y2="7.5" stroke="#f59e0b" strokeWidth="1" strokeLinecap="round"/></svg>
                  :f.is_foreign_key
                  ?<svg width="8" height="8" viewBox="0 0 8 8"><circle cx="3" cy="3" r="2" fill="none" stroke="#3b82f6" strokeWidth="1" strokeDasharray="1.2,0.6"/></svg>
                  :<div style={{width:4,height:4,borderRadius:'50%',flexShrink:0,
                    background:(hasSrc||hasTgt)?color:'var(--color-border-tertiary)'}}/>
                }
                <span style={{fontSize:9,color:(hasSrc||hasTgt)?'var(--color-text-primary)':'var(--color-text-secondary)',
                  flex:1,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap',
                  fontFamily:'monospace'}} title={f.column}>{f.column}</span>
                <span style={{fontSize:8,color:'var(--color-text-tertiary)',fontFamily:'monospace',flexShrink:0}}>
                  {(f.data_type||'').split('(')[0].substring(0,6)}
                </span>
                {f.nullable===false&&<span style={{fontSize:7,color:'#f59e0b',fontWeight:700,flexShrink:0}}>NN</span>}
                {hasTgt&&<span style={{fontSize:7,color:'#00d4aa',fontWeight:700,flexShrink:0}}>↗</span>}
                {hasSrc&&<span style={{fontSize:7,color:'#ffb347',fontWeight:700,flexShrink:0}}>↙</span>}
              </div>
            );
          })}
        </div>

        {/* Target tables */}
        {targetTables.length > 0 && (
          <div style={{padding:'8px 12px'}}>
            <div style={{fontSize:9,fontWeight:700,color:'#ffb347',
              textTransform:'uppercase',letterSpacing:'.08em',marginBottom:5}}>
              Feeds into ({targetTables.length})
            </div>
            {targetTables.map(tk=>{
              const [ts,tt]=tk.split('.');
              const edgeCount=srcEdges.filter(l=>{
                const t=typeof l.target==='object'?l.target.id:l.target;
                return t.startsWith(tk+'.');
              }).length;
              return (
                <div key={tk} style={{display:'flex',alignItems:'center',gap:6,padding:'4px 6px',
                  borderRadius:6,marginBottom:3,background:`${sc(ts)}08`,
                  border:`0.5px solid ${sc(ts)}30`}}>
                  <div style={{width:6,height:6,borderRadius:'50%',background:sc(ts),flexShrink:0}}/>
                  <span style={{fontSize:10,color:'var(--color-text-secondary)',flex:1,
                    overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}} title={tk}>{tt}</span>
                  <span style={{fontSize:9,color:sc(ts),fontWeight:500}}>{ts}</span>
                  <span style={{fontSize:9,color:'var(--color-text-tertiary)'}}>{edgeCount} edges</span>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

/* ─── Main export ──────────────────────────────────────────── */
export default function TimelineView({ onSelectField }) {
  const [nodes,   setNodes]   = useState([]);
  const [links,   setLinks]   = useState([]);
  const [loading, setLoading] = useState(true);
  const [pinned,  setPinned]  = useState(new Set());    // systems pinned to timeline
  const [selTable,setSelTable]= useState(null);
  const [zoom,    setZoom]    = useState(1);
  const [showEdges, setShowEdges] = useState(true);
  const columnRefs = useRef({});

  useEffect(() => {
    Promise.all([
      fetch(`${BASE}/lineage/fields`).then(r=>r.json()),
      fetch(`${BASE}/lineage/graph`).then(r=>r.json()),
    ]).then(([f,g]) => {
      setNodes(f); setLinks(g.links||[]);
      // Auto-pin systems that have edges
      const withEdges = new Set();
      (g.links||[]).forEach(l=>{
        const s=typeof l.source==='object'?l.source.id:l.source;
        const t=typeof l.target==='object'?l.target.id:l.target;
        withEdges.add(s.split('.')[0]);
        withEdges.add(t.split('.')[0]);
      });
      setPinned(withEdges);
      setLoading(false);
    }).catch(()=>setLoading(false));
  }, []);

  const idx = useMemo(() => buildIndex(nodes, links), [nodes, links]);

  const togglePin = useCallback(sys => {
    setPinned(p => {
      const n = new Set(p);
      n.has(sys) ? n.delete(sys) : n.add(sys);
      return n;
    });
  }, []);

  // Systems in timeline ordered by data flow (topological-ish)
  const orderedPinned = useMemo(() => {
    const all = [...pinned];
    // Simple: sort by number of incoming edges (sources first)
    return all.sort((a,b) => {
      const ia = (idx.tgtSysEdges[a]||[]).length;
      const ib = (idx.tgtSysEdges[b]||[]).length;
      return ia - ib;
    });
  }, [pinned, idx]);

  const totalSystems = Object.keys(idx.bySystem||{}).length;
  const totalEdges   = links.length;

  if (loading) return (
    <div style={{display:'flex',alignItems:'center',justifyContent:'center',height:'100%',
      color:'var(--color-text-tertiary)',fontSize:13}}>Loading timeline…</div>
  );

  return (
    <div style={{display:'flex',height:'100%',overflow:'hidden'}}>
      {/* Left catalog */}
      <CatalogPanel idx={idx} pinned={pinned} togglePin={togglePin}
        selTable={selTable} setSelTable={setSelTable}/>

      {/* Main area */}
      <div style={{flex:1,display:'flex',flexDirection:'column',overflow:'hidden'}}>
        {/* Toolbar */}
        <div style={{display:'flex',gap:8,padding:'7px 12px',flexShrink:0,
          borderBottom:'1px solid var(--color-border-tertiary)',
          background:'var(--color-background-secondary)',alignItems:'center',flexWrap:'wrap'}}>

          <div style={{fontSize:11,color:'var(--color-text-secondary)',fontWeight:500}}>
            Timeline — Left to right data flow
          </div>

          <div style={{display:'flex',gap:5,alignItems:'center',marginLeft:8}}>
            {orderedPinned.map((sys,i)=>(
              <div key={sys} style={{display:'flex',alignItems:'center',gap:3}}>
                {i>0&&<span style={{fontSize:10,color:'var(--color-text-tertiary)'}}>→</span>}
                <div style={{display:'flex',alignItems:'center',gap:3,padding:'2px 8px',
                  borderRadius:20,background:`${sc(sys)}15`,
                  border:`0.5px solid ${sc(sys)}50`,fontSize:10,color:sc(sys),fontWeight:500}}>
                  <div style={{width:5,height:5,borderRadius:'50%',background:sc(sys)}}/>
                  {sys}
                </div>
              </div>
            ))}
            {orderedPinned.length === 0 && (
              <span style={{fontSize:11,color:'var(--color-text-tertiary)'}}>
                Pin systems from the left panel (◇) to add them to the timeline
              </span>
            )}
          </div>

          <div style={{marginLeft:'auto',display:'flex',gap:6,alignItems:'center'}}>
            <label style={{display:'flex',alignItems:'center',gap:4,fontSize:11,color:'var(--color-text-secondary)',cursor:'pointer'}}>
              <input type="checkbox" checked={showEdges} onChange={e=>setShowEdges(e.target.checked)} style={{accentColor:'var(--color-text-info)'}}/>
              Show edges
            </label>
            <button onClick={()=>setZoom(z=>Math.max(0.4,z-0.1))}
              style={{padding:'2px 8px',fontSize:12,background:'var(--color-background-tertiary)',
                border:'1px solid var(--color-border-secondary)',borderRadius:4,cursor:'pointer',color:'var(--color-text-secondary)'}}>−</button>
            <span style={{fontSize:10,color:'var(--color-text-tertiary)',minWidth:34,textAlign:'center'}}>{Math.round(zoom*100)}%</span>
            <button onClick={()=>setZoom(z=>Math.min(2,z+0.1))}
              style={{padding:'2px 8px',fontSize:12,background:'var(--color-background-tertiary)',
                border:'1px solid var(--color-border-secondary)',borderRadius:4,cursor:'pointer',color:'var(--color-text-secondary)'}}>+</button>
            <button onClick={()=>setZoom(1)}
              style={{padding:'2px 8px',fontSize:10,background:'var(--color-background-tertiary)',
                border:'1px solid var(--color-border-secondary)',borderRadius:4,cursor:'pointer',color:'var(--color-text-secondary)'}}>↺</button>
            <span style={{fontSize:10,color:'var(--color-text-tertiary)'}}>
              {totalSystems} systems · {totalEdges} edges
            </span>
          </div>
        </div>

        {/* Canvas + right detail panel */}
        <div style={{flex:1,display:'flex',overflow:'hidden'}}>
          {/* Scrollable canvas */}
          <div style={{flex:1,overflow:'auto',background:'var(--color-background-tertiary)',position:'relative'}}>
            {orderedPinned.length === 0 ? (
              <div style={{display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',
                height:'100%',gap:16,color:'var(--color-text-tertiary)'}}>
                <svg width="80" height="50" viewBox="0 0 80 50">
                  {[10,35,60].map((x,i)=>(
                    <g key={i}>
                      <rect x={x} y={5} width={15} height={40} rx={3} fill="none"
                        stroke={['#00d4aa','#7c6fff','#ffb347'][i]} strokeWidth="1.5" opacity={.4}/>
                      {i<2&&<path d={`M${x+15},25 Q${x+27},25 ${x+35},25`} fill="none"
                        stroke={['#00d4aa','#7c6fff'][i]} strokeWidth="1.2" opacity={.4}
                        markerEnd={`url(#tl-direct)`}/>}
                    </g>
                  ))}
                </svg>
                <div>
                  <div style={{fontSize:13,fontWeight:500,color:'var(--color-text-secondary)',marginBottom:4}}>
                    No systems pinned to timeline
                  </div>
                  <div style={{fontSize:11,textAlign:'center'}}>
                    Click ◇ next to any system in the left panel to add it here.<br/>
                    Systems with edges are auto-pinned on load.
                  </div>
                </div>
              </div>
            ) : (
              <div style={{
                transform:`scale(${zoom})`,transformOrigin:'top left',
                padding:20,display:'flex',gap:32,alignItems:'flex-start',
                minWidth:'fit-content',position:'relative',
              }}>
                {orderedPinned.map(sys => (
                  <div key={sys} ref={el=>columnRefs.current[sys]=el} style={{position:'relative',zIndex:1}}>
                    <SystemColumn sys={sys} idx={idx} selTable={selTable}
                      setSelTable={setSelTable} links={links} allNodes={nodes}/>
                  </div>
                ))}
                {/* Edge overlay drawn on top */}
              </div>
            )}
          </div>

          {/* Right: field detail */}
          {selTable && (
            <FieldDetailPanel selTable={selTable} idx={idx} links={links}
              allNodes={nodes} onClose={()=>setSelTable(null)}/>
          )}
        </div>

        {/* Legend footer */}
        <div style={{flexShrink:0,padding:'5px 12px',borderTop:'1px solid var(--color-border-tertiary)',
          background:'var(--color-background-secondary)',display:'flex',gap:14,alignItems:'center',
          fontSize:10,color:'var(--color-text-tertiary)',flexWrap:'wrap'}}>
          {Object.entries(TRANSFORM_COLORS).slice(0,5).map(([k,c])=>(
            <div key={k} style={{display:'flex',alignItems:'center',gap:3}}>
              <div style={{width:14,height:2,background:c}}/>
              <span>{k}</span>
            </div>
          ))}
          <span style={{marginLeft:'auto'}}>◆ = pinned · ↗ = sends data · ↙ = receives data · Click table for details</span>
        </div>
      </div>
    </div>
  );
}
