/**
 * Field Trust Propagation — trust score flows through lineage
 * When a source field has issues, all downstream fields auto-degrade
 * US banking: CFO needs to know which board pack numbers to trust today
 */
import { useState, useEffect, useMemo, useCallback } from 'react';

const BASE = 'http://localhost:8000';

function baseTrust(field) {
  let t = 100;
  if (!field.description) t -= 20;
  if (!field.data_type)   t -= 10;
  if (field.pii && !field.tags?.includes('masked')) t -= 5;
  return Math.max(0, t);
}

function trustColor(score) {
  if (score >= 85) return '#22c55e';
  if (score >= 65) return '#f59e0b';
  if (score >= 45) return '#ef4444';
  return '#7f1d1d';
}

function TrustGauge({ score, size = 36 }) {
  const c = trustColor(score);
  const r = size/2 - 3;
  const circ = 2 * Math.PI * r;
  return (
    <div style={{display:'flex',alignItems:'center',gap:6}}>
      <svg width={size} height={size} style={{transform:'rotate(-90deg)'}}>
        <circle cx={size/2} cy={size/2} r={r} fill="none" stroke="var(--color-border-tertiary)" strokeWidth="3"/>
        <circle cx={size/2} cy={size/2} r={r} fill="none" stroke={c} strokeWidth="3"
          strokeDasharray={`${(score/100)*circ} ${circ}`} strokeLinecap="round"/>
      </svg>
      <span style={{fontSize:12,fontWeight:600,color:c,minWidth:34}}>{Math.round(score)}%</span>
    </div>
  );
}

export default function TrustPropagation() {
  const [fields,   setFields]   = useState([]);
  const [links,    setLinks]    = useState([]);
  const [loading,  setLoading]  = useState(true);
  const [issues,   setIssues]   = useState({}); // fieldId → issue level 0-100
  const [selField, setSelField] = useState(null);
  const [view,     setView]     = useState('overview'); // overview | cascade | simulate

  useEffect(() => {
    Promise.all([
      fetch(`${BASE}/lineage/fields`).then(r=>r.json()),
      fetch(`${BASE}/lineage/graph`).then(r=>r.json()),
    ]).then(([f,g])=>{
      setFields(f);
      setLinks(g.links||[]);
      setLoading(false);
    }).catch(()=>setLoading(false));
  }, []);

  // Compute trust scores with propagation
  const trustScores = useMemo(() => {
    const scores = {};
    // Base scores
    fields.forEach(f => {
      let base = baseTrust(f);
      if (issues[f.id]) base = Math.max(0, base - issues[f.id]);
      scores[f.id] = base;
    });

    // Propagate through lineage (BFS from source)
    const DECAY = { direct:0.95, renamed:0.93, aggregated:0.88, derived:0.82, filtered:0.90, joined:0.85 };
    // Sort edges: process sources first (simple topological)
    let changed = true;
    let iterations = 0;
    while (changed && iterations < 20) {
      changed = false;
      iterations++;
      links.forEach(l => {
        const sid = typeof l.source==='object'?l.source.id:l.source;
        const tid = typeof l.target==='object'?l.target.id:l.target;
        const ttype = (l.transformation_type||'direct').replace('TransformationType.','').toLowerCase();
        const decay = DECAY[ttype] || 0.90;
        const propagated = (scores[sid] || 100) * decay;
        if (scores[tid] === undefined || propagated < scores[tid]) {
          scores[tid] = propagated;
          changed = true;
        }
      });
    }
    return scores;
  }, [fields, links, issues]);

  // Find impacted fields for a given source issue
  const getImpacted = useCallback((fieldId) => {
    const visited = new Set();
    const queue = [fieldId];
    const result = [];
    while (queue.length) {
      const curr = queue.shift();
      if (visited.has(curr)) continue;
      visited.add(curr);
      links.forEach(l => {
        const s = typeof l.source==='object'?l.source.id:l.source;
        const t = typeof l.target==='object'?l.target.id:l.target;
        if (s === curr && !visited.has(t)) {
          result.push({ field: fields.find(f=>f.id===t), edge: l });
          queue.push(t);
        }
      });
    }
    return result;
  }, [fields, links]);

  const systems = useMemo(()=>[...new Set(fields.map(f=>f.system))].sort(),[fields]);
  const [filterSys, setFilterSys] = useState('ALL');

  const filtered = fields.filter(f=>filterSys==='ALL'||f.system===filterSys);

  // Stats
  const criticalCount = filtered.filter(f=>trustScores[f.id]<50).length;
  const warningCount  = filtered.filter(f=>trustScores[f.id]>=50&&trustScores[f.id]<80).length;
  const avgTrust = filtered.length ? Math.round(filtered.reduce((a,f)=>a+(trustScores[f.id]||100),0)/filtered.length) : 0;

  const impacted = selField ? getImpacted(selField.id) : [];

  return (
    <div style={{display:'flex',flexDirection:'column',height:'100%',overflow:'hidden'}}>
      {/* Header */}
      <div style={{padding:'12px 16px',flexShrink:0,borderBottom:'1px solid var(--color-border-tertiary)'}}>
        <div style={{display:'flex',alignItems:'center',gap:12,marginBottom:10}}>
          <div>
            <div style={{fontSize:15,fontWeight:500,color:'var(--color-text-primary)'}}>Field Trust Propagation</div>
            <div style={{fontSize:11,color:'var(--color-text-tertiary)',marginTop:2}}>
              If a source field has bad data, all downstream fields auto-degrade. CFOs know which board-pack numbers to trust today.
            </div>
          </div>
          <div style={{marginLeft:'auto',display:'flex',gap:8}}>
            <div style={{padding:'8px 14px',background:'var(--color-background-secondary)',
              border:'1px solid var(--color-border-tertiary)',borderRadius:8,textAlign:'center'}}>
              <div style={{fontSize:20,fontWeight:600,color:trustColor(avgTrust)}}>{avgTrust}%</div>
              <div style={{fontSize:9,color:'var(--color-text-tertiary)'}}>Avg trust</div>
            </div>
            <div style={{padding:'8px 14px',background:'var(--color-background-secondary)',
              border:'1px solid var(--color-border-tertiary)',borderRadius:8,textAlign:'center'}}>
              <div style={{fontSize:20,fontWeight:600,color:'#ef4444'}}>{criticalCount}</div>
              <div style={{fontSize:9,color:'var(--color-text-tertiary)'}}>Critical (&lt;50%)</div>
            </div>
            <div style={{padding:'8px 14px',background:'var(--color-background-secondary)',
              border:'1px solid var(--color-border-tertiary)',borderRadius:8,textAlign:'center'}}>
              <div style={{fontSize:20,fontWeight:600,color:'#f59e0b'}}>{warningCount}</div>
              <div style={{fontSize:9,color:'var(--color-text-tertiary)'}}>Warning (&lt;80%)</div>
            </div>
          </div>
        </div>

        <div style={{display:'flex',gap:6,alignItems:'center',flexWrap:'wrap'}}>
          {[['overview','All fields'],['cascade','Cascade view'],['simulate','Simulate issue']].map(([m,l])=>(
            <button key={m} onClick={()=>setView(m)}
              style={{padding:'4px 10px',fontSize:11,borderRadius:20,cursor:'pointer',
                background:view===m?'var(--color-background-info)':'transparent',
                color:view===m?'var(--color-text-info)':'var(--color-text-secondary)',
                border:`1px solid ${view===m?'var(--color-border-info)':'var(--color-border-secondary)'}`,
                fontWeight:view===m?500:400}}>
              {l}
            </button>
          ))}
          <select value={filterSys} onChange={e=>setFilterSys(e.target.value)}
            style={{padding:'4px 8px',fontSize:11,border:'1px solid var(--color-border-secondary)',
              borderRadius:6,background:'var(--color-background-primary)',color:'var(--color-text-primary)'}}>
            <option value="ALL">All systems</option>
            {systems.map(s=><option key={s} value={s}>{s}</option>)}
          </select>
        </div>
      </div>

      <div style={{flex:1,overflow:'auto',padding:16}}>
        {loading ? (
          <div style={{display:'flex',alignItems:'center',justifyContent:'center',height:200,color:'var(--color-text-tertiary)',fontSize:13}}>Computing trust scores…</div>
        ) : view === 'overview' ? (
          <OverviewView fields={filtered} trustScores={trustScores} issues={issues}
            onSelect={setSelField} selField={selField}/>
        ) : view === 'cascade' ? (
          <CascadeView fields={filtered} trustScores={trustScores} links={links}
            selField={selField} setSelField={setSelField} impacted={impacted}/>
        ) : (
          <SimulateView fields={fields} trustScores={trustScores} issues={issues}
            setIssues={setIssues} links={links} getImpacted={getImpacted}/>
        )}
      </div>
    </div>
  );
}

function OverviewView({ fields, trustScores, issues, onSelect, selField }) {
  const sorted = [...fields].sort((a,b)=>(trustScores[a.id]||100)-(trustScores[b.id]||100));
  return (
    <table style={{width:'100%',borderCollapse:'collapse',fontSize:11}}>
      <thead style={{position:'sticky',top:0,zIndex:2}}>
        <tr style={{background:'var(--color-background-secondary)'}}>
          {['Field','System','Type','Trust Score','Status','Issue'].map((h,i)=>(
            <th key={i} style={{padding:'7px 10px',textAlign:i>=3?'center':'left',fontSize:9,fontWeight:700,
              color:'var(--color-text-tertiary)',textTransform:'uppercase',letterSpacing:'.08em',
              borderBottom:'2px solid var(--color-border-secondary)'}}>{h}</th>
          ))}
        </tr>
      </thead>
      <tbody>
        {sorted.map((f,i)=>{
          const ts = trustScores[f.id] ?? 100;
          const hasIssue = issues[f.id] > 0;
          return (
            <tr key={f.id} onClick={()=>onSelect(selField?.id===f.id?null:f)}
              style={{cursor:'pointer',borderBottom:'1px solid var(--color-border-tertiary)',
                background:selField?.id===f.id?'var(--color-background-info)':(i%2===0?'transparent':'var(--color-background-secondary)')}}>
              <td style={{padding:'6px 10px',fontFamily:'monospace',color:'var(--color-text-primary)',
                overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap',maxWidth:180}} title={f.column}>{f.column}</td>
              <td style={{padding:'6px 10px',color:'var(--color-text-secondary)'}}>{f.system}</td>
              <td style={{padding:'6px 10px',color:'var(--color-text-tertiary)',fontFamily:'monospace',fontSize:10}}>{(f.data_type||'').split('(')[0]}</td>
              <td style={{padding:'6px 10px'}}><TrustGauge score={ts} size={28}/></td>
              <td style={{padding:'6px 10px',textAlign:'center'}}>
                <span style={{fontSize:9,padding:'2px 7px',borderRadius:4,fontWeight:600,
                  background:ts>=85?'rgba(34,197,94,0.1)':ts>=65?'rgba(245,158,11,0.1)':'rgba(239,68,68,0.1)',
                  color:trustColor(ts)}}>
                  {ts>=85?'TRUSTED':ts>=65?'CAUTION':'UNRELIABLE'}
                </span>
              </td>
              <td style={{padding:'6px 10px',textAlign:'center'}}>
                {hasIssue && <span style={{fontSize:9,color:'#ef4444',fontWeight:600}}>⚠ Issue flagged</span>}
              </td>
            </tr>
          );
        })}
      </tbody>
    </table>
  );
}

function CascadeView({ fields, trustScores, links, selField, setSelField, impacted }) {
  if (!selField) return (
    <div style={{display:'flex',flexDirection:'column',alignItems:'center',justifyContent:'center',
      height:200,gap:8,color:'var(--color-text-tertiary)'}}>
      <div style={{fontSize:28,opacity:.3}}>⇣</div>
      <div style={{fontSize:13,fontWeight:500,color:'var(--color-text-secondary)'}}>Select a field to see trust cascade</div>
      <div style={{fontSize:11}}>Click any field in the Overview tab first, then switch here</div>
    </div>
  );
  const ts = trustScores[selField.id] ?? 100;
  return (
    <div>
      <div style={{padding:'10px 14px',background:'var(--color-background-secondary)',borderRadius:8,
        border:'0.5px solid var(--color-border-secondary)',marginBottom:14}}>
        <div style={{display:'flex',alignItems:'center',gap:10}}>
          <TrustGauge score={ts} size={40}/>
          <div>
            <div style={{fontSize:12,fontWeight:600,color:'var(--color-text-primary)'}}>{selField.id}</div>
            <div style={{fontSize:11,color:'var(--color-text-tertiary)'}}>Source field · {impacted.length} downstream fields impacted</div>
          </div>
        </div>
      </div>
      {impacted.length === 0 ? (
        <div style={{textAlign:'center',color:'var(--color-text-tertiary)',fontSize:12,padding:20}}>
          This field has no downstream consumers — trust issue stays contained here.
        </div>
      ) : (
        <div style={{display:'flex',flexDirection:'column',gap:6}}>
          {impacted.map(({field:f,edge:e},i) => {
            if (!f) return null;
            const fts = trustScores[f.id] ?? 100;
            const ttype = (e.transformation_type||'direct').replace('TransformationType.','').toLowerCase();
            return (
              <div key={f.id} style={{display:'flex',alignItems:'center',gap:10,padding:'8px 14px',
                background:'var(--color-background-primary)',borderRadius:8,
                border:`0.5px solid ${trustColor(fts)}30`,
                marginLeft:Math.min(i*8,60)}}>
                <span style={{fontSize:10,color:'var(--color-text-tertiary)',flexShrink:0,
                  fontFamily:'monospace'}}>{'└'+'─'.repeat(Math.min(i,5))}►</span>
                <TrustGauge score={fts} size={26}/>
                <div style={{flex:1,minWidth:0}}>
                  <div style={{fontSize:11,fontFamily:'monospace',color:'var(--color-text-primary)',
                    overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{f.id}</div>
                  <div style={{fontSize:10,color:'var(--color-text-tertiary)'}}>via {ttype}</div>
                </div>
                {fts < 70 && <span style={{fontSize:9,color:'#ef4444',fontWeight:600,flexShrink:0}}>⚠ DEGRADED</span>}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

function SimulateView({ fields, trustScores, issues, setIssues, links, getImpacted }) {
  const [selField, setSelField] = useState('');
  const [issueLevel, setIssueLevel] = useState(50);
  const impacted = selField ? getImpacted(selField) : [];
  const sf = fields.find(f=>f.id===selField);

  return (
    <div>
      <div style={{padding:'14px 16px',background:'var(--color-background-secondary)',
        borderRadius:8,border:'0.5px solid var(--color-border-secondary)',marginBottom:16}}>
        <div style={{fontSize:12,fontWeight:500,color:'var(--color-text-primary)',marginBottom:10}}>
          Simulate a data issue on a source field
        </div>
        <div style={{display:'flex',gap:10,alignItems:'center',flexWrap:'wrap'}}>
          <select value={selField} onChange={e=>setSelField(e.target.value)}
            style={{padding:'5px 8px',fontSize:11,border:'1px solid var(--color-border-secondary)',
              borderRadius:6,background:'var(--color-background-primary)',color:'var(--color-text-primary)',flex:1,minWidth:200}}>
            <option value="">Pick a source field to degrade…</option>
            {fields.map(f=><option key={f.id} value={f.id}>{f.id}</option>)}
          </select>
          <div style={{display:'flex',alignItems:'center',gap:6}}>
            <label style={{fontSize:11,color:'var(--color-text-secondary)'}}>Issue severity:</label>
            <input type="range" min={0} max={80} step={5} value={issueLevel} onChange={e=>setIssueLevel(+e.target.value)}
              style={{width:120}}/>
            <span style={{fontSize:11,color:'#ef4444',fontWeight:500,minWidth:30}}>-{issueLevel}%</span>
          </div>
          <button onClick={()=>{
            if (!selField) return;
            setIssues(prev=>({...prev,[selField]:issueLevel}));
          }} style={{padding:'5px 14px',fontSize:11,borderRadius:6,cursor:'pointer',
            background:'var(--color-background-danger)',color:'var(--color-text-danger)',
            border:'1px solid var(--color-border-danger)',fontWeight:500}}>
            Simulate
          </button>
          {Object.keys(issues).length>0 && (
            <button onClick={()=>setIssues({})} style={{padding:'5px 10px',fontSize:11,borderRadius:6,cursor:'pointer',
              background:'transparent',color:'var(--color-text-secondary)',
              border:'1px solid var(--color-border-secondary)'}}>
              Reset all
            </button>
          )}
        </div>
      </div>

      {selField && impacted.length > 0 && (
        <div style={{padding:'10px 14px',background:'rgba(239,68,68,0.06)',borderRadius:8,
          border:'0.5px solid rgba(239,68,68,0.3)',marginBottom:14,fontSize:12,color:'var(--color-text-secondary)',lineHeight:1.7}}>
          <strong style={{color:'#ef4444'}}>Impact preview:</strong> If {sf?.column} loses {issueLevel}% trust,
          <strong style={{color:'var(--color-text-primary)'}}> {impacted.length} downstream fields</strong> will be degraded automatically.
          This includes any board-pack metrics, DFAST inputs, or Call Report fields that depend on this source.
        </div>
      )}

      {Object.keys(issues).length > 0 && (
        <div>
          <div style={{fontSize:11,fontWeight:600,color:'var(--color-text-primary)',marginBottom:8}}>Active issues:</div>
          {Object.entries(issues).map(([id,level])=>(
            <div key={id} style={{display:'flex',alignItems:'center',gap:8,padding:'6px 12px',
              marginBottom:4,borderRadius:6,background:'var(--color-background-primary)',
              border:'0.5px solid var(--color-border-secondary)'}}>
              <span style={{fontSize:11,fontFamily:'monospace',color:'var(--color-text-primary)',flex:1}}>{id}</span>
              <span style={{fontSize:10,color:'#ef4444',fontWeight:600}}>−{level}% trust</span>
              <button onClick={()=>setIssues(prev=>{const n={...prev};delete n[id];return n;})}
                style={{fontSize:11,background:'none',color:'var(--color-text-tertiary)',border:'none',cursor:'pointer'}}>×</button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
