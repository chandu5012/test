import { useState, useRef, useEffect } from 'react';
import { api } from '../utils/api.js';

export default function ChatPanel({ selectedFieldId, aiConfigured }) {
  const [messages, setMessages] = useState([
    { role: 'assistant', content: 'Hello! I am your lineage assistant. Ask me anything about your credit data — field origins, impact analysis, PII risks, or compliance questions. Select a node on the graph to ask field-specific questions.' }
  ]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const bottomRef = useRef(null);

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages]);

  const SUGGESTIONS = [
    'Where does CREDIT_SCORE come from?',
    'What breaks if I change CUST_ID?',
    'Which fields are PII?',
    'Show me cross-system lineage gaps',
  ];

  const send = async (text) => {
    const msg = text || input.trim();
    if (!msg) return;
    const userMsg = { role: 'user', content: msg };
    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setLoading(true);
    try {
      const history = messages.slice(-8).map(m => ({ role: m.role, content: m.content }));
      const res = await api.chat(msg, history, selectedFieldId);
      setMessages(prev => [...prev, { role: 'assistant', content: res.response }]);
    } catch {
      setMessages(prev => [...prev, { role: 'assistant', content: 'Sorry, I could not connect to the AI. Check your AI provider settings.' }]);
    }
    setLoading(false);
  };

  return (
    <div style={{ display: 'flex', flexDirection: 'column', height: '100%' }}>
      {!aiConfigured && (
        <div style={{ padding: '8px 12px', background: 'rgba(255,179,71,0.08)', border: '1px solid rgba(255,179,71,0.25)', borderRadius: 'var(--radius)', fontSize: 11, color: 'var(--amber)', marginBottom: 10 }}>
          ⚠ No AI configured — using rule-based answers. Go to Settings to enable Claude, GPT, Gemini, or Ollama.
        </div>
      )}

      {selectedFieldId && (
        <div style={{ padding: '6px 10px', background: 'rgba(108,99,255,0.1)', border: '1px solid rgba(108,99,255,0.2)', borderRadius: 'var(--radius)', fontSize: 11, color: 'var(--accent2)', marginBottom: 8 }}>
          Context: <strong>{selectedFieldId.split('.').slice(-1)[0]}</strong>
        </div>
      )}

      {/* Messages */}
      <div style={{ flex: 1, overflowY: 'auto', display: 'flex', flexDirection: 'column', gap: 10, paddingRight: 4 }}>
        {messages.map((m, i) => (
          <div key={i} style={{ display: 'flex', justifyContent: m.role === 'user' ? 'flex-end' : 'flex-start' }}>
            <div style={{
              maxWidth: '88%', padding: '9px 13px', borderRadius: m.role === 'user' ? '14px 14px 4px 14px' : '14px 14px 14px 4px',
              background: m.role === 'user' ? 'var(--accent)' : 'var(--surface)',
              border: m.role === 'assistant' ? '1px solid var(--border)' : 'none',
              color: 'var(--text)', fontSize: 12, lineHeight: 1.6,
            }}>
              {m.content.split('`').map((part, j) =>
                j % 2 === 1
                  ? <code key={j} style={{ background: 'rgba(255,255,255,0.1)', padding: '1px 5px', borderRadius: 4, fontSize: 11 }}>{part}</code>
                  : part
              )}
            </div>
          </div>
        ))}
        {loading && (
          <div style={{ display: 'flex', gap: 5, padding: '9px 13px' }}>
            {[0,1,2].map(i => <div key={i} className="pulse" style={{ width: 7, height: 7, borderRadius: '50%', background: 'var(--accent)', animationDelay: `${i*0.2}s` }} />)}
          </div>
        )}
        <div ref={bottomRef} />
      </div>

      {/* Suggestions */}
      {messages.length <= 2 && (
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginTop: 8, marginBottom: 8 }}>
          {SUGGESTIONS.map(s => (
            <button key={s} onClick={() => send(s)}
              style={{ padding: '4px 10px', background: 'var(--surface)', border: '1px solid var(--border)', borderRadius: 20, color: 'var(--text2)', fontSize: 11 }}>
              {s}
            </button>
          ))}
        </div>
      )}

      {/* Input */}
      <div style={{ display: 'flex', gap: 8, marginTop: 8 }}>
        <input value={input} onChange={e => setInput(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && !e.shiftKey && send()}
          placeholder="Ask about lineage, impact, PII, compliance…"
          style={{ flex: 1, background: 'var(--bg3)', border: '1px solid var(--border2)', borderRadius: 'var(--radius)', padding: '9px 12px', fontSize: 12 }} />
        <button onClick={() => send()} disabled={loading || !input.trim()}
          style={{ padding: '9px 16px', background: input.trim() ? 'var(--accent)' : 'var(--surface)', color: '#fff', borderRadius: 'var(--radius)', fontSize: 13, fontWeight: 600 }}>
          →
        </button>
      </div>
    </div>
  );
}
