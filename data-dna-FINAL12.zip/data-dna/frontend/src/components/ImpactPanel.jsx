import { useEffect, useState } from 'react';
import { api } from '../utils/api.js';

export default function ImpactPanel({ fieldId, onSelectField }) {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!fieldId) return;
    setLoading(true);
    api.impact(fieldId).then(setData).catch(() => setData(null)).finally(() => setLoading(false));
  }, [fieldId]);

  if (!fieldId) return <div style={{ color: 'var(--text3)', padding: 16 }}>Select a field to analyse its downstream impact.</div>;
  if (loading) return <div style={{ color: 'var(--text3)', padding: 16 }} className="pulse">Analysing impact…</div>;
  if (!data) return <div style={{ color: 'var(--text3)', padding: 16 }}>No impact data.</div>;

  const riskClass = `tag-risk-${data.risk_level}`;
  const grouped = {};
  (data.affected_fields || []).forEach(f => {
    grouped[f.system] = grouped[f.system] || [];
    grouped[f.system].push(f);
  });

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
      <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap', gap: 8 }}>
        <div>
          <div style={{ fontSize: 11, color: 'var(--text3)', marginBottom: 2 }}>Impact analysis</div>
          <div style={{ color: 'var(--text)', fontWeight: 600 }}>{fieldId.split('.').slice(-1)[0]}</div>
        </div>
        <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
          <span className={`tag ${riskClass}`}>{data.risk_level} risk</span>
          <span style={{ color: 'var(--text2)', fontSize: 11 }}>{data.affected_count} affected</span>
        </div>
      </div>

      {data.cross_system_impacts.length > 0 && (
        <div style={{ padding: '8px 12px', background: 'rgba(255,90,125,0.08)', border: '1px solid rgba(255,90,125,0.2)', borderRadius: 'var(--radius)', fontSize: 11 }}>
          <span style={{ color: 'var(--red)', fontWeight: 600 }}>⚠ Cross-system impact: </span>
          <span style={{ color: 'var(--text2)' }}>{data.cross_system_impacts.join(', ')}</span>
        </div>
      )}

      <div style={{ overflowY: 'auto', maxHeight: 340, display: 'flex', flexDirection: 'column', gap: 10 }}>
        {Object.entries(grouped).map(([sys, fields]) => (
          <div key={sys}>
            <div style={{ fontSize: 10, color: 'var(--text3)', textTransform: 'uppercase', letterSpacing: '0.08em', marginBottom: 5 }}>{sys}</div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 4 }}>
              {fields.map(f => (
                <div key={f.id} onClick={() => onSelectField?.(f.id)}
                  style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '6px 10px', background: 'var(--bg3)', borderRadius: 6, cursor: 'pointer', border: '1px solid var(--border)' }}
                  onMouseEnter={e => e.currentTarget.style.borderColor = 'var(--accent)'}
                  onMouseLeave={e => e.currentTarget.style.borderColor = 'var(--border)'}
                >
                  <div style={{ width: 6, height: 6, borderRadius: '50%', background: '#6c63ff', flexShrink: 0 }} />
                  <span style={{ color: 'var(--text2)', fontSize: 11 }}>{f.table}<span style={{ color: 'var(--text3)' }}>.</span>{f.column}</span>
                  {f.pii && <span className="tag tag-pii" style={{ marginLeft: 'auto' }}>PII</span>}
                </div>
              ))}
            </div>
          </div>
        ))}
        {data.affected_count === 0 && (
          <div style={{ color: 'var(--text3)', fontSize: 11 }}>No downstream fields affected.</div>
        )}
      </div>
    </div>
  );
}
