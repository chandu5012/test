import { useState } from 'react';
import { api } from '../utils/api.js';

const DB_TYPES = [
  { id:'sqlite',     label:'SQLite',     desc:'Local file database',        color:'#60a5fa', free:true,  conn_label:'File Path',       placeholder:'C:/data/mydb.db' },
  { id:'postgresql', label:'PostgreSQL', desc:'Open source relational DB',  color:'#336791', free:true,  conn_label:'Connection URL',  placeholder:'postgresql://user:pass@host:5432/dbname' },
  { id:'mysql',      label:'MySQL',      desc:'Popular open source DB',     color:'#4479a1', free:true,  conn_label:'Connection URL',  placeholder:'mysql://user:pass@host:3306/dbname' },
  { id:'mssql',      label:'SQL Server', desc:'Microsoft SQL Server',       color:'#cc2927', free:false, conn_label:'Connection URL',  placeholder:'mssql://user:pass@host:1433/dbname' },
  { id:'oracle',     label:'Oracle',     desc:'Enterprise Oracle DB',       color:'#f80000', free:false, conn_label:'Connection URL',  placeholder:'user/pass@host:1521/ORCL' },
  { id:'teradata',   label:'Teradata',   desc:'Enterprise data warehouse',  color:'#f96302', free:false, conn_label:'Host:Port',       placeholder:'teradata-host:1025' },
  { id:'mongodb',    label:'MongoDB',    desc:'NoSQL document database',    color:'#47a248', free:true,  conn_label:'Connection URL',  placeholder:'mongodb://user:pass@host:27017/dbname' },
  { id:'hive',       label:'Hive',       desc:'Apache big data warehouse',  color:'#fdcc15', free:true,  conn_label:'Host:Port',       placeholder:'hive-host:10000' },
];

const DB_ICONS = {
  sqlite:'🗃', postgresql:'🐘', mysql:'🐬', mssql:'🪟',
  oracle:'🔴', teradata:'🟠', mongodb:'🍃', hive:'🐝',
};

const INSTALL_NOTES = {
  oracle:   'Requires: pip install cx_Oracle  (also needs Oracle Instant Client)',
  teradata: 'Requires: pip install teradatasql',
  mongodb:  'Requires: pip install pymongo',
  hive:     'Requires: pip install pyhive thrift thrift-sasl',
};

export default function DbCrawlerPanel({ onSuccess }) {
  const [dbType,      setDbType]     = useState('');
  const [systemName,  setSystemName] = useState('');
  const [connString,  setConnString] = useState('');
  const [dbPath,      setDbPath]     = useState('');
  const [database,    setDatabase]   = useState('');
  const [result,      setResult]     = useState(null);
  const [loading,     setLoading]    = useState(false);
  const [testResult,  setTestResult] = useState(null);

  const selected = DB_TYPES.find(d => d.id === dbType);

  const crawl = async () => {
    if (!systemName.trim()) { alert('Enter a system name first'); return; }
    if (!dbType)            { alert('Select a database type first'); return; }
    setLoading(true); setResult(null); setTestResult(null);
    try {
      const payload = {
        system_name: systemName.trim(),
        db_type: dbType,
        conn_string: connString,
        db_path: dbPath,
        database,
      };
      const res = await api.crawlDb(payload);
      setResult(res);
      onSuccess?.();
    } catch (e) {
      setResult({ error: e.message || 'Connection failed' });
    }
    setLoading(false);
  };

  return (
    <div style={{ display:'flex', flexDirection:'column', gap:16 }}>

      {/* Info */}
      <div style={{ padding:'10px 14px', background:'rgba(96,165,250,0.08)', border:'1px solid rgba(96,165,250,0.2)', borderRadius:8, fontSize:12, color:'#60a5fa', lineHeight:1.6 }}>
        Connect to a real database and auto-extract all tables and columns — no SQL pasting needed.
        Supported: SQLite, PostgreSQL, MySQL, SQL Server, Oracle, Teradata, MongoDB, Hive.
      </div>

      {/* DB Type grid */}
      <div>
        <div style={{ fontSize:11, color:'var(--text3)', textTransform:'uppercase', letterSpacing:'.07em', marginBottom:10 }}>Database Type</div>
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:8 }}>
          {DB_TYPES.map(db => {
            const isSelected = dbType === db.id;
            return (
              <button key={db.id} onClick={() => { setDbType(db.id); setConnString(''); setDbPath(''); setDatabase(''); setResult(null); }}
                style={{ padding:'10px 14px', background: isSelected ? `${db.color}20` : 'var(--bg3)',
                  border:`1.5px solid ${isSelected ? db.color : 'var(--border)'}`,
                  borderRadius:9, textAlign:'left', cursor:'pointer', transition:'all .15s' }}>
                <div style={{ display:'flex', alignItems:'center', gap:8, marginBottom:4 }}>
                  <span style={{ fontSize:18 }}>{DB_ICONS[db.id]}</span>
                  <span style={{ fontSize:13, fontWeight:700, color: isSelected ? db.color : 'var(--text)' }}>{db.label}</span>
                  {db.free
                    ? <span style={{ fontSize:9, padding:'1px 6px', borderRadius:20, background:'rgba(74,222,128,0.12)', color:'var(--green)', border:'1px solid rgba(74,222,128,0.3)', marginLeft:'auto' }}>Free</span>
                    : <span style={{ fontSize:9, padding:'1px 6px', borderRadius:20, background:'rgba(255,179,71,0.1)', color:'var(--amber)', border:'1px solid rgba(255,179,71,0.3)', marginLeft:'auto' }}>Paid</span>
                  }
                </div>
                <div style={{ fontSize:11, color: isSelected ? db.color : 'var(--text3)', paddingLeft:26, opacity:.85 }}>{db.desc}</div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Install note for drivers */}
      {dbType && INSTALL_NOTES[dbType] && (
        <div style={{ padding:'8px 12px', background:'rgba(255,179,71,0.07)', border:'1px solid rgba(255,179,71,0.25)', borderRadius:7, fontSize:11, color:'var(--amber)', fontFamily:'var(--font-mono)' }}>
          ⚠ {INSTALL_NOTES[dbType]}
        </div>
      )}

      {/* System name */}
      <div>
        <div style={{ fontSize:11, color:'var(--text3)', textTransform:'uppercase', letterSpacing:'.07em', marginBottom:6 }}>System Name</div>
        <input value={systemName} onChange={e => setSystemName(e.target.value)}
          placeholder="e.g. CBS_SYSTEM, LOS_DB, CRM_PROD"
          style={{ width:'100%', background:'var(--bg3)', border:'1px solid var(--border2)', borderRadius:8, padding:'9px 12px', fontSize:12, color:'var(--text)' }}/>
        <div style={{ fontSize:10, color:'var(--text3)', marginTop:4 }}>This name appears in the graph as the system identifier</div>
      </div>

      {/* Connection fields — conditional on db type */}
      {dbType === 'sqlite' && (
        <div>
          <div style={{ fontSize:11, color:'var(--text3)', textTransform:'uppercase', letterSpacing:'.07em', marginBottom:6 }}>SQLite File Path</div>
          <input value={dbPath} onChange={e => setDbPath(e.target.value)}
            placeholder="C:\path\to\your_db.db  or  /home/user/mydb.sqlite"
            style={{ width:'100%', background:'var(--bg3)', border:'1px solid var(--border2)', borderRadius:8, padding:'9px 12px', fontSize:12, color:'var(--text)', fontFamily:'var(--font-mono)' }}/>
        </div>
      )}

      {dbType && dbType !== 'sqlite' && (
        <div>
          <div style={{ fontSize:11, color:'var(--text3)', textTransform:'uppercase', letterSpacing:'.07em', marginBottom:6 }}>
            {selected?.conn_label || 'Connection String'}
          </div>
          <input value={connString} onChange={e => setConnString(e.target.value)}
            placeholder={selected?.placeholder || ''}
            style={{ width:'100%', background:'var(--bg3)', border:'1px solid var(--border2)', borderRadius:8, padding:'9px 12px', fontSize:12, color:'var(--text)', fontFamily:'var(--font-mono)' }}/>
        </div>
      )}

      {/* Database/Schema name (optional for most) */}
      {dbType && dbType !== 'sqlite' && (
        <div>
          <div style={{ fontSize:11, color:'var(--text3)', textTransform:'uppercase', letterSpacing:'.07em', marginBottom:6 }}>
            Database / Schema Name <span style={{ textTransform:'none', fontWeight:400 }}>(optional)</span>
          </div>
          <input value={database} onChange={e => setDatabase(e.target.value)}
            placeholder={dbType === 'mongodb' ? 'my_database' : dbType === 'hive' ? 'default' : dbType === 'oracle' ? 'HR (schema)' : 'my_database'}
            style={{ width:'100%', background:'var(--bg3)', border:'1px solid var(--border2)', borderRadius:8, padding:'9px 12px', fontSize:12, color:'var(--text)' }}/>
        </div>
      )}

      {/* Action buttons */}
      {dbType && (
        <button onClick={crawl} disabled={loading}
          style={{ padding:'12px', background: loading ? 'var(--surface)' : 'var(--accent)', color:'#fff',
            borderRadius:9, fontWeight:700, fontSize:13, transition:'all .15s',
            display:'flex', alignItems:'center', justifyContent:'center', gap:8 }}>
          {loading
            ? <><span className="pulse">⟳</span> Crawling {systemName || 'database'} schema…</>
            : `⟳ Auto-crawl Schema${systemName ? ' — ' + systemName : ''}`}
        </button>
      )}

      {/* Result */}
      {result && (
        <div className="fade-in" style={{ padding:'12px 14px',
          background: result.error ? 'rgba(255,90,125,0.08)' : 'rgba(0,212,170,0.08)',
          border: `1px solid ${result.error ? 'rgba(255,90,125,0.3)' : 'rgba(0,212,170,0.3)'}`,
          borderRadius:8, fontSize:12 }}>
          {result.error ? (
            <div style={{ color:'var(--red)' }}>
              <div style={{ fontWeight:700, marginBottom:4 }}>⚠ Connection failed</div>
              <div style={{ fontFamily:'var(--font-mono)', fontSize:11, opacity:.8 }}>{result.error}</div>
              <div style={{ marginTop:8, color:'var(--text3)' }}>Check: connection string format · firewall rules · database driver installed</div>
            </div>
          ) : (
            <div>
              <div style={{ color:'var(--teal)', fontWeight:700, marginBottom:6 }}>
                ✓ Crawled {result.system_name} — {result.fields_discovered} fields from {result.tables_found} tables
              </div>
              <div style={{ color:'var(--text2)', fontSize:11 }}>
                Fields added to graph. Go to the Graph tab to visualise, or Metadata tab to browse and add descriptions.
              </div>
              {result.warnings?.length > 0 && (
                <div style={{ marginTop:6, color:'var(--amber)', fontSize:11 }}>
                  ⚠ {result.warnings.length} warnings — {result.warnings[0]}
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* Help section */}
      {!dbType && (
        <div style={{ padding:'14px', background:'var(--bg3)', borderRadius:8, border:'1px solid var(--border)', fontSize:12, color:'var(--text3)', lineHeight:1.8 }}>
          <div style={{ fontWeight:600, color:'var(--text2)', marginBottom:6 }}>How it works:</div>
          <div>1. Select your database type above</div>
          <div>2. Enter a system name (e.g. CBS_PROD, LOS_DB)</div>
          <div>3. Enter connection details</div>
          <div>4. Click Auto-crawl — it reads all tables and columns automatically</div>
          <div style={{ marginTop:8, color:'var(--text3)', fontSize:11 }}>
            After crawling, go to Metadata tab to add descriptions, or Lineage Map tab to discover relationships between systems.
          </div>
        </div>
      )}
    </div>
  );
}
