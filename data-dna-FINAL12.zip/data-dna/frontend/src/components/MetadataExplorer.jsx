/**
 * MetadataExplorer v4 — Enterprise grade
 * LEFT PANEL: Systems tree → Tables → click to filter
 * TABLE: System, Table, Column, Data Type, Length, Precision, Scale,
 *        Nullable, PK, FK, Index, PII, Sensitivity, DQ Score, Description
 * Stats header: erwin-style gauges
 */
import { useState, useEffect, useCallback, useRef, useMemo } from 'react';

const BASE = 'http://localhost:8000';
const SC = {
  CBS:'#00d4aa',LOS:'#00b896',CRM:'#26c6da',BUREAU:'#4fc3f7',
  RISK:'#7c6fff',FRAUD:'#ab47bc',COLLECTIONS:'#ec407a',
  MIS:'#ffb347',DWH:'#ff8f00',REGULATOR:'#ff5a7d',
  CREDIT_CORE:'#00d4aa',RISK_ENGINE:'#7c6fff',REPORTING:'#ffb347',
};
const sc = s => SC[s] || '#8b85ff';
const sl = s => ({CBS:0,LOS:0,CRM:0,BUREAU:0,CREDIT_CORE:0,RISK:1,FRAUD:1,COLLECTIONS:1,RISK_ENGINE:1,MIS:2,DWH:2,REGULATOR:2,REPORTING:2}[s]??1);

const dqScore = f => {
  let s = 35;
  if (f.description) s += 30;
  if (f.data_type)   s += 10;
  if (f.nullable !== undefined) s += 5;
  if (f.is_primary_key !== undefined) s += 5;
  if (f.length || f.precision) s += 5;
  if (f.tags?.length) s += 5;
  if (f.is_indexed !== undefined) s += 5;
  return Math.min(100, s);
};

/* ── DQ Gauge ────────────────────────────────────────────────── */
function DQGauge({ score }) {
  const c = score >= 80 ? '#22c55e' : score >= 50 ? '#f59e0b' : '#ef4444';
  const r = 10, circ = 2*Math.PI*r;
  return (
    <div style={{display:'flex',alignItems:'center',gap:4}}>
      <svg width="26" height="26" style={{transform:'rotate(-90deg)'}}>
        <circle cx="13" cy="13" r={r} fill="none" stroke="var(--color-border-tertiary)" strokeWidth="2.5"/>
        <circle cx="13" cy="13" r={r} fill="none" stroke={c} strokeWidth="2.5"
          strokeDasharray={`${(score/100)*circ} ${circ}`} strokeLinecap="round"/>
      </svg>
      <span style={{fontSize:11,fontWeight:500,color:c,minWidth:28}}>{score}%</span>
    </div>
  );
}

/* ── Sensitivity Badge ───────────────────────────────────────── */
function SensBadge({ pii, column }) {
  const col = (column||'').toUpperCase();
  let level = 'Public', color = '#22c55e', bg = 'rgba(34,197,94,0.1)';
  if (pii || ['PAN','AADHAAR','MOBILE','EMAIL','DOB','CUST_NAME','BANK_ACCT','PASSWORD'].some(k=>col.includes(k))) {
    level='Restricted'; color='#ef4444'; bg='rgba(239,68,68,0.1)';
  } else if (['INCOME','SALARY','NPA','DPD','OUTSTANDING','PROVISION','CREDIT_SCORE','WRITE_OFF'].some(k=>col.includes(k))) {
    level='Confidential'; color='#f59e0b'; bg='rgba(245,158,11,0.1)';
  }
  return (
    <span style={{fontSize:9,padding:'2px 6px',borderRadius:4,background:bg,color,fontWeight:600,border:`1px solid ${color}30`,whiteSpace:'nowrap'}}>
      {level}
    </span>
  );
}

/* ── Inline description cell ─────────────────────────────────── */
function DescCell({ field, onSave, aiEnabled }) {
  const [editing, setEditing] = useState(false);
  const [val, setVal] = useState(field.description||'');
  const [loading, setLoading] = useState(false);
  const ref = useRef();
  useEffect(()=>setVal(field.description||''), [field.description]);
  useEffect(()=>{ if(editing&&ref.current) ref.current.focus(); }, [editing]);
  const save = async()=>{
    setEditing(false);
    if(val.trim()===(field.description||'').trim()) return;
    try { await fetch(`${BASE}/lineage/field/${encodeURIComponent(field.id)}/description`,{method:'PATCH',headers:{'Content-Type':'application/json'},body:JSON.stringify({description:val})}); onSave(field.id,val); } catch{}
  };
  const auto = async e=>{
    e.stopPropagation(); setLoading(true);
    try { const r=await fetch(`${BASE}/lineage/field/${encodeURIComponent(field.id)}/describe`,{method:'POST'}).then(r=>r.json()); if(r.description){setVal(r.description);onSave(field.id,r.description);} } catch{}
    setLoading(false);
  };
  if(editing) return(
    <div style={{display:'flex',gap:4}} onClick={e=>e.stopPropagation()}>
      <input ref={ref} value={val} onChange={e=>setVal(e.target.value)} onBlur={save}
        onKeyDown={e=>{if(e.key==='Enter')save();if(e.key==='Escape'){setEditing(false);setVal(field.description||'');}}}
        style={{flex:1,fontSize:11,border:'1px solid var(--color-border-info)',borderRadius:4,padding:'2px 6px',
          background:'var(--color-background-primary)',color:'var(--color-text-primary)'}}/>
      <button onClick={save} style={{fontSize:10,color:'var(--color-text-success)',background:'none',padding:'1px 5px',border:'1px solid var(--color-border-success)',borderRadius:3}}>✓</button>
    </div>
  );
  return(
    <div style={{display:'flex',gap:4,alignItems:'center',minHeight:20}}>
      <span style={{flex:1,fontSize:11,color:val?'var(--color-text-secondary)':'var(--color-text-tertiary)',
        fontStyle:val?'normal':'italic',cursor:'text',lineHeight:1.4}}
        onClick={e=>{e.stopPropagation();setEditing(true);}}>
        {val||'—'}
      </span>
      <div style={{display:'flex',gap:2,flexShrink:0}}>
        <button onClick={e=>{e.stopPropagation();setEditing(true);}} style={{fontSize:9,color:'var(--color-text-tertiary)',background:'none',padding:'1px 4px',border:'1px solid var(--color-border-tertiary)',borderRadius:3}}>✎</button>
        <button onClick={auto} disabled={loading} style={{fontSize:9,color:aiEnabled?'var(--color-text-warning)':'var(--color-text-info)',background:'none',padding:'1px 4px',border:`1px solid ${aiEnabled?'var(--color-border-warning)':'var(--color-border-info)'}`,borderRadius:3}}>{loading?'⟳':aiEnabled?'✦':'⚙'}</button>
      </div>
    </div>
  );
}

/* ── Left navigation panel ───────────────────────────────────── */
function NavPanel({ fields, filterSys, filterTbl, onFilter }) {
  const [expanded, setExpanded] = useState(new Set());
  const [search, setSearch] = useState('');

  const tree = useMemo(() => {
    const t = {};
    fields.forEach(f => {
      if (!t[f.system]) t[f.system] = {};
      if (!t[f.system][f.table]) t[f.system][f.table] = { count:0, described:0, pii:0 };
      t[f.system][f.table].count++;
      if (f.description) t[f.system][f.table].described++;
      if (f.pii) t[f.system][f.table].pii++;
    });
    return t;
  }, [fields]);

  const layerOrder = (s) => sl(s);

  const sysByLayer = useMemo(() => {
    const all = Object.keys(tree).sort((a,b)=>layerOrder(a)-layerOrder(b));
    const layers = [[],[],[]];
    all.forEach(s => layers[layerOrder(s)].push(s));
    return layers;
  }, [tree]);

  const matchSearch = (s, t) => {
    if (!search) return true;
    const q = search.toLowerCase();
    return s.toLowerCase().includes(q) || t.toLowerCase().includes(q);
  };

  return (
    <div style={{width:200,flexShrink:0,display:'flex',flexDirection:'column',height:'100%',
      borderRight:'1px solid var(--color-border-tertiary)',background:'var(--color-background-secondary)'}}>
      <div style={{padding:'10px 10px 8px',borderBottom:'1px solid var(--color-border-tertiary)'}}>
        <div style={{fontSize:11,fontWeight:600,color:'var(--color-text-primary)',marginBottom:6}}>Data Catalog</div>
        <input value={search} onChange={e=>setSearch(e.target.value)}
          placeholder="Filter…"
          style={{width:'100%',padding:'4px 7px',fontSize:10,border:'1px solid var(--color-border-secondary)',
            borderRadius:5,background:'var(--color-background-primary)',color:'var(--color-text-primary)'}}/>
        <div style={{fontSize:9,color:'var(--color-text-tertiary)',marginTop:4}}>
          {Object.keys(tree).length} systems · {fields.length} columns
        </div>
      </div>
      {/* All */}
      <div onClick={()=>onFilter('ALL','ALL')} style={{display:'flex',alignItems:'center',gap:6,
        padding:'6px 10px',cursor:'pointer',borderBottom:'1px solid var(--color-border-tertiary)',
        background:filterSys==='ALL'?'var(--color-background-info)':'transparent'}}>
        <span style={{fontSize:10,color:filterSys==='ALL'?'var(--color-text-info)':'var(--color-text-secondary)',fontWeight:filterSys==='ALL'?600:400}}>All systems</span>
        <span style={{fontSize:9,color:'var(--color-text-tertiary)',marginLeft:'auto'}}>{fields.length}</span>
      </div>
      <div style={{flex:1,overflow:'auto'}}>
        {sysByLayer.map((sysList, li) => sysList.length===0 ? null : (
          <div key={li}>
            <div style={{padding:'4px 10px 3px',fontSize:9,fontWeight:700,
              color:['#00d4aa','#7c6fff','#ffb347'][li],textTransform:'uppercase',letterSpacing:'0.1em',
              background:'var(--color-background-tertiary)',
              borderBottom:'1px solid var(--color-border-tertiary)',
              borderTop: li>0?'2px solid var(--color-border-tertiary)':undefined}}>
              {['Source','Middle','Reporting'][li]}
            </div>
            {sysList.filter(s=>!search||Object.keys(tree[s]||{}).some(t=>matchSearch(s,t))).map(sys=>{
              const sysData = tree[sys]||{};
              const isExp = expanded.has(sys);
              const isSelSys = filterSys===sys;
              const color = sc(sys);
              const totalCols = Object.values(sysData).reduce((a,t)=>a+t.count,0);
              return (
                <div key={sys}>
                  <div onClick={()=>{
                    setExpanded(prev=>{const n=new Set(prev);n.has(sys)?n.delete(sys):n.add(sys);return n;});
                    onFilter(sys,'ALL');
                  }} style={{display:'flex',alignItems:'center',gap:5,padding:'5px 10px',cursor:'pointer',
                    borderBottom:'1px solid var(--color-border-tertiary)',
                    background:isSelSys&&filterTbl==='ALL'?`${color}12`:'transparent'}}>
                    <span style={{color,fontSize:8,transition:'transform .15s',display:'inline-block',transform:isExp?'rotate(90deg)':'rotate(0)'}}>▶</span>
                    <div style={{width:7,height:7,borderRadius:'50%',background:color,flexShrink:0}}/>
                    <span style={{fontSize:10,fontWeight:500,color,flex:1,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{sys}</span>
                    <span style={{fontSize:9,color:'var(--color-text-tertiary)',flexShrink:0}}>{totalCols}</span>
                  </div>
                  {isExp && Object.entries(sysData).filter(([t])=>matchSearch(sys,t)).sort().map(([tbl,info])=>{
                    const isSelTbl = filterSys===sys && filterTbl===tbl;
                    const pct = info.count>0 ? Math.round(info.described/info.count*100) : 0;
                    return(
                      <div key={tbl} onClick={()=>onFilter(sys,tbl)}
                        style={{display:'flex',alignItems:'center',gap:5,padding:'4px 8px 4px 26px',cursor:'pointer',
                          borderBottom:'1px solid var(--color-border-tertiary)',
                          background:isSelTbl?`${color}15`:'transparent'}}>
                        <svg width="10" height="10" viewBox="0 0 10 10" style={{flexShrink:0}}>
                          <rect x="1" y="1" width="8" height="8" rx="1" fill="none" stroke={isSelTbl?color:'var(--color-border-secondary)'} strokeWidth="1"/>
                          <line x1="1" y1="4" x2="9" y2="4" stroke={isSelTbl?color:'var(--color-border-secondary)'} strokeWidth="0.8"/>
                          <line x1="1" y1="7" x2="9" y2="7" stroke={isSelTbl?color:'var(--color-border-secondary)'} strokeWidth="0.8"/>
                        </svg>
                        <span style={{fontSize:10,color:isSelTbl?color:'var(--color-text-secondary)',
                          flex:1,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{tbl}</span>
                        <div style={{display:'flex',flexDirection:'column',alignItems:'flex-end',gap:1,flexShrink:0}}>
                          <span style={{fontSize:8,color:'var(--color-text-tertiary)'}}>{info.count}</span>
                          <div style={{width:24,height:2,background:'var(--color-border-tertiary)',borderRadius:1}}>
                            <div style={{width:`${pct}%`,height:'100%',background:pct>=80?'#22c55e':pct>=50?'#f59e0b':'#ef4444',borderRadius:1}}/>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              );
            })}
          </div>
        ))}
      </div>
    </div>
  );
}

/* ── Main ────────────────────────────────────────────────────── */
export default function MetadataExplorer() {
  const [fields,       setFields]       = useState([]);
  const [loading,      setLoading]      = useState(true);
  const [filterSys,    setFilterSys]    = useState('ALL');
  const [filterTbl,    setFilterTbl]    = useState('ALL');
  const [search,       setSearch]       = useState('');
  const [filterPii,    setFilterPii]    = useState(false);
  const [filterNoDesc, setFilterNoDesc] = useState(false);
  const [expanded,     setExpanded]     = useState(null);
  const [aiStatus,     setAiStatus]     = useState(null);
  const [uploading,    setUploading]    = useState(false);
  const [uploadResult, setUploadResult] = useState(null);
  const [showBulk,     setShowBulk]     = useState(false);
  const [sortCol,      setSortCol]      = useState('system');
  const [sortDir,      setSortDir]      = useState(1);
  const fileRef = useRef();

  const load = useCallback(async()=>{
    setLoading(true);
    try{ const d=await fetch(`${BASE}/lineage/fields`).then(r=>r.json()); setFields(d); }catch{}
    setLoading(false);
  },[]);

  useEffect(()=>{ load(); fetch(`${BASE}/settings/ai-status`).then(r=>r.json()).then(setAiStatus).catch(()=>{}); },[load]);

  const updateDesc=(id,desc)=>setFields(prev=>prev.map(f=>f.id===id?{...f,description:desc}:f));

  const filtered = useMemo(()=>fields
    .filter(f=>filterSys==='ALL'||f.system===filterSys)
    .filter(f=>filterTbl==='ALL'||f.table===filterTbl)
    .filter(f=>!filterPii||f.pii)
    .filter(f=>!filterNoDesc||!f.description)
    .filter(f=>{ if(!search.trim())return true; const q=search.toLowerCase(); return f.column.toLowerCase().includes(q)||f.table.toLowerCase().includes(q)||f.system.toLowerCase().includes(q)||(f.description||'').toLowerCase().includes(q); })
    .sort((a,b)=>{ const av=(a[sortCol]||'').toString().toLowerCase(),bv=(b[sortCol]||'').toString().toLowerCase(); return av<bv?-sortDir:av>bv?sortDir:0; })
  ,[fields,filterSys,filterTbl,filterPii,filterNoDesc,search,sortCol,sortDir]);

  const noDesc=fields.filter(f=>!f.description).length;
  const piiCnt=fields.filter(f=>f.pii).length;
  const avgDQ=fields.length?Math.round(fields.reduce((a,f)=>a+dqScore(f),0)/fields.length):0;
  const tables=[...new Set(fields.filter(f=>filterSys==='ALL'||f.system===filterSys).map(f=>f.table))];

  const onSort=col=>{if(sortCol===col)setSortDir(d=>-d);else{setSortCol(col);setSortDir(1);}};
  const si=col=>sortCol===col?(sortDir===1?'↑':'↓'):'';

  const uploadExcel=async e=>{
    const file=e.target.files?.[0];if(!file)return;
    setUploading(true);setUploadResult(null);
    const fd=new FormData();fd.append('file',file);
    try{const d=await fetch(`${BASE}/lineage/ingest/excel`,{method:'POST',body:fd}).then(r=>r.json());setUploadResult(d);if(d.nodes_created>0)load();}
    catch(ex){setUploadResult({error:ex.message});}
    setUploading(false);e.target.value='';
  };

  const TH=({col,label,w,center})=>(
    <th onClick={()=>onSort(col)}
      style={{padding:'8px 8px',textAlign:center?'center':'left',fontSize:9,fontWeight:700,
        color:'var(--color-text-tertiary)',textTransform:'uppercase',letterSpacing:'.08em',
        cursor:'pointer',whiteSpace:'nowrap',width:w,userSelect:'none',
        borderBottom:'2px solid var(--color-border-secondary)',
        background:'var(--color-background-secondary)',position:'sticky',top:0,zIndex:2}}>
      {label}{si(col)?` ${si(col)}`:''}
    </th>
  );

  // Auto-describe bulk panel (simplified)
  const BulkPanel = () => {
    const [sys, setSys] = useState('ALL');
    const [overwrite, setOv] = useState(false);
    const [loading, setL] = useState(false);
    const [res, setRes] = useState(null);
    const systems = [...new Set(fields.map(f=>f.system))].sort();
    const run = async()=>{
      setL(true);setRes(null);
      const url=new URL(`${BASE}/lineage/fields/describe-all`);
      if(sys!=='ALL')url.searchParams.set('system',sys);
      if(overwrite)url.searchParams.set('overwrite','true');
      try{const d=await fetch(url,{method:'POST'}).then(r=>r.json());setRes(d);load();}catch(e){setRes({error:e.message});}
      setL(false);
    };
    return(
      <div style={{padding:'12px 14px',background:'var(--color-background-secondary)',border:'1px solid var(--color-border-tertiary)',borderRadius:10,marginBottom:10}}>
        <div style={{display:'flex',gap:8,alignItems:'center',flexWrap:'wrap'}}>
          <span style={{fontSize:12,fontWeight:500,color:'var(--color-text-primary)'}}>Auto-describe</span>
          <select value={sys} onChange={e=>setSys(e.target.value)}
            style={{padding:'4px 8px',fontSize:11,border:'1px solid var(--color-border-secondary)',borderRadius:6,background:'var(--color-background-primary)',color:'var(--color-text-primary)'}}>
            <option value="ALL">All systems</option>
            {systems.map(s=><option key={s} value={s}>{s}</option>)}
          </select>
          <label style={{display:'flex',alignItems:'center',gap:5,fontSize:11,color:'var(--color-text-secondary)',cursor:'pointer'}}>
            <input type="checkbox" checked={overwrite} onChange={e=>setOv(e.target.checked)} style={{accentColor:'var(--color-text-warning)'}}/>
            Overwrite existing
          </label>
          <button onClick={run} disabled={loading}
            style={{padding:'5px 14px',fontSize:11,borderRadius:6,cursor:'pointer',
              background:aiStatus?.configured?'var(--color-background-warning)':'var(--color-background-info)',
              color:aiStatus?.configured?'var(--color-text-warning)':'var(--color-text-info)',
              border:`1px solid ${aiStatus?.configured?'var(--color-border-warning)':'var(--color-border-info)'}`,fontWeight:500}}>
            {loading?'⟳ Running…':aiStatus?.configured?'✦ AI describe':'⚙ Auto-describe'}
          </button>
          {res&&<span style={{fontSize:11,color:res.error?'var(--color-text-danger)':'var(--color-text-success)'}}>
            {res.error?`⚠ ${res.error}`:`✓ ${res.enriched} described · ${res.already_had_description||0} skipped`}
          </span>}
        </div>
      </div>
    );
  };

  return(
    <div style={{display:'flex',height:'100%',overflow:'hidden'}}>
      <NavPanel fields={fields} filterSys={filterSys} filterTbl={filterTbl}
        onFilter={(s,t)=>{ setFilterSys(s); setFilterTbl(t); }}/>

      <div style={{flex:1,display:'flex',flexDirection:'column',overflow:'hidden'}}>

        {/* Stats header */}
        <div style={{padding:'10px 14px 0',flexShrink:0}}>
          <div style={{display:'flex',gap:8,marginBottom:10,flexWrap:'wrap',alignItems:'center'}}>
            {[
              {label:'Total tables',  value:tables.length,  color:'var(--color-text-info)'},
              {label:'Total columns', value:filtered.length, color:'var(--color-text-primary)'},
              {label:'PII fields',    value:piiCnt,          color:'#ef4444'},
              {label:'Missing desc',  value:noDesc,          color:'#f59e0b'},
            ].map((s,i)=>(
              <div key={i} style={{padding:'8px 14px',background:'var(--color-background-secondary)',
                border:'1px solid var(--color-border-tertiary)',borderRadius:8,textAlign:'center',minWidth:80}}>
                <div style={{fontSize:20,fontWeight:600,color:s.color}}>{s.value}</div>
                <div style={{fontSize:9,color:'var(--color-text-tertiary)',whiteSpace:'nowrap'}}>{s.label}</div>
              </div>
            ))}
            <div style={{padding:'8px 10px',background:'var(--color-background-secondary)',
              border:'1px solid var(--color-border-tertiary)',borderRadius:8,display:'flex',alignItems:'center',gap:8}}>
              <div style={{position:'relative',width:44,height:44}}>
                <svg width="44" height="44" style={{transform:'rotate(-90deg)'}}>
                  <circle cx="22" cy="22" r="16" fill="none" stroke="var(--color-border-tertiary)" strokeWidth="4"/>
                  <circle cx="22" cy="22" r="16" fill="none"
                    stroke={avgDQ>=80?'#22c55e':avgDQ>=50?'#f59e0b':'#ef4444'} strokeWidth="4"
                    strokeDasharray={`${(avgDQ/100)*100.5} 100.5`} strokeLinecap="round"/>
                </svg>
                <span style={{position:'absolute',top:'50%',left:'50%',transform:'translate(-50%,-50%)',
                  fontSize:10,fontWeight:600,color:avgDQ>=80?'#22c55e':avgDQ>=50?'#f59e0b':'#ef4444'}}>{avgDQ}%</span>
              </div>
              <div style={{fontSize:9,color:'var(--color-text-tertiary)'}}>DQ<br/>score</div>
            </div>
            <div style={{marginLeft:'auto',display:'flex',gap:6,flexWrap:'wrap',alignItems:'center'}}>
              <button onClick={()=>setShowBulk(v=>!v)}
                style={{padding:'6px 12px',fontSize:11,borderRadius:7,cursor:'pointer',
                  background:showBulk?'var(--color-background-info)':'var(--color-background-secondary)',
                  color:showBulk?'var(--color-text-info)':'var(--color-text-secondary)',
                  border:`1px solid ${showBulk?'var(--color-border-info)':'var(--color-border-secondary)'}`,fontWeight:showBulk?500:400}}>
                {aiStatus?.configured?'✦':'⚙'} Auto-describe
              </button>
              <a href={`${BASE}/lineage/ingest/excel/template`} download
                style={{padding:'6px 10px',fontSize:11,background:'var(--color-background-secondary)',border:'1px solid var(--color-border-secondary)',color:'var(--color-text-secondary)',borderRadius:7,textDecoration:'none'}}>↓ Template</a>
              <input ref={fileRef} type="file" accept=".xlsx,.xls,.csv" onChange={uploadExcel} style={{display:'none'}}/>
              <button onClick={()=>fileRef.current.click()} disabled={uploading}
                style={{padding:'6px 10px',fontSize:11,background:uploading?'var(--color-background-secondary)':'var(--color-background-info)',color:uploading?'var(--color-text-tertiary)':'var(--color-text-info)',border:'1px solid var(--color-border-info)',borderRadius:7,cursor:'pointer'}}>
                {uploading?'⟳':'↑ Upload'}
              </button>
              <a href={`${BASE}/export/fields/csv`} download
                style={{padding:'6px 10px',fontSize:11,background:'var(--color-background-secondary)',border:'1px solid var(--color-border-secondary)',color:'var(--color-text-secondary)',borderRadius:7,textDecoration:'none'}}>↓ CSV</a>
            </div>
          </div>

          {showBulk && <BulkPanel/>}
          {uploadResult && (
            <div style={{marginBottom:8,padding:'6px 12px',borderRadius:7,fontSize:11,
              background:uploadResult.error?'var(--color-background-danger)':'var(--color-background-success)',
              border:`.5px solid ${uploadResult.error?'var(--color-border-danger)':'var(--color-border-success)'}`,
              color:uploadResult.error?'var(--color-text-danger)':'var(--color-text-success)',
              display:'flex',alignItems:'center',gap:8}}>
              {uploadResult.error?`⚠ ${uploadResult.error}`:`✓ ${uploadResult.nodes_created} fields uploaded`}
              <button onClick={()=>setUploadResult(null)} style={{marginLeft:'auto',background:'none',fontSize:12,color:'inherit'}}>×</button>
            </div>
          )}

          {/* Filter bar */}
          <div style={{display:'flex',gap:6,alignItems:'center',flexWrap:'wrap',marginBottom:8}}>
            {filterSys!=='ALL'&&(
              <div style={{display:'flex',alignItems:'center',gap:4,padding:'3px 8px',borderRadius:20,
                background:`${sc(filterSys)}15`,border:`1px solid ${sc(filterSys)}40`}}>
                <div style={{width:6,height:6,borderRadius:'50%',background:sc(filterSys)}}/>
                <span style={{fontSize:11,color:sc(filterSys),fontWeight:500}}>{filterSys}</span>
                {filterTbl!=='ALL'&&<><span style={{fontSize:11,color:sc(filterSys),opacity:.6}}> · </span><span style={{fontSize:11,color:sc(filterSys)}}>{filterTbl}</span></>}
                <button onClick={()=>{ setFilterSys('ALL');setFilterTbl('ALL'); }} style={{background:'none',fontSize:12,color:sc(filterSys),marginLeft:2,lineHeight:1}}>×</button>
              </div>
            )}
            <div style={{position:'relative',flex:1,minWidth:140}}>
              <input value={search} onChange={e=>setSearch(e.target.value)} placeholder="Search columns, tables…"
                style={{width:'100%',padding:'5px 8px 5px 24px',fontSize:11,border:'1px solid var(--color-border-secondary)',
                  borderRadius:6,background:'var(--color-background-secondary)',color:'var(--color-text-primary)'}}/>
              <span style={{position:'absolute',left:7,top:'50%',transform:'translateY(-50%)',fontSize:11,color:'var(--color-text-tertiary)'}}>⌕</span>
            </div>
            <button onClick={()=>setFilterPii(v=>!v)}
              style={{padding:'4px 9px',fontSize:10,borderRadius:20,cursor:'pointer',
                background:filterPii?'rgba(239,68,68,0.12)':'transparent',
                border:`1px solid ${filterPii?'rgba(239,68,68,.4)':'var(--color-border-secondary)'}`,
                color:filterPii?'#ef4444':'var(--color-text-secondary)'}}>
              PII ({piiCnt})
            </button>
            <button onClick={()=>setFilterNoDesc(v=>!v)}
              style={{padding:'4px 9px',fontSize:10,borderRadius:20,cursor:'pointer',
                background:filterNoDesc?'var(--color-background-warning)':'transparent',
                border:`1px solid ${filterNoDesc?'var(--color-border-warning)':'var(--color-border-secondary)'}`,
                color:filterNoDesc?'var(--color-text-warning)':'var(--color-text-secondary)'}}>
              No desc ({noDesc})
            </button>
            <span style={{marginLeft:'auto',fontSize:10,color:'var(--color-text-tertiary)'}}>{filtered.length} columns</span>
          </div>
        </div>

        {/* Table */}
        <div style={{flex:1,overflow:'auto'}}>
          {loading
            ?<div style={{display:'flex',alignItems:'center',justifyContent:'center',height:200,color:'var(--color-text-tertiary)',fontSize:13}}>Loading…</div>
            :(
            <table style={{width:'100%',borderCollapse:'collapse',tableLayout:'fixed',fontSize:11}}>
              <colgroup>
                <col style={{width:90}}/><col style={{width:130}}/><col style={{width:140}}/><col style={{width:100}}/>
                <col style={{width:46}}/><col style={{width:46}}/><col style={{width:40}}/>
                <col style={{width:30}}/><col style={{width:30}}/><col style={{width:30}}/><col style={{width:30}}/>
                <col style={{width:80}}/><col style={{width:70}}/><col/><col style={{width:30}}/>
              </colgroup>
              <thead>
                <tr>
                  <TH col="system"    label="System"    w={90}/>
                  <TH col="table"     label="Table"     w={130}/>
                  <TH col="column"    label="Column"    w={140}/>
                  <TH col="data_type" label="Data type" w={100}/>
                  <TH col="length"    label="Len"       w={46}  center/>
                  <TH col="precision" label="Prec"      w={46}  center/>
                  <TH col="scale"     label="Scale"     w={40}  center/>
                  <th style={{padding:'8px 4px',textAlign:'center',fontSize:9,fontWeight:700,color:'var(--color-text-tertiary)',textTransform:'uppercase',letterSpacing:'.08em',borderBottom:'2px solid var(--color-border-secondary)',background:'var(--color-background-secondary)',position:'sticky',top:0,zIndex:2,whiteSpace:'nowrap',width:30}} title="Primary Key">PK</th>
                  <th style={{padding:'8px 4px',textAlign:'center',fontSize:9,fontWeight:700,color:'var(--color-text-tertiary)',textTransform:'uppercase',letterSpacing:'.08em',borderBottom:'2px solid var(--color-border-secondary)',background:'var(--color-background-secondary)',position:'sticky',top:0,zIndex:2,whiteSpace:'nowrap',width:30}} title="Foreign Key">FK</th>
                  <th style={{padding:'8px 4px',textAlign:'center',fontSize:9,fontWeight:700,color:'var(--color-text-tertiary)',textTransform:'uppercase',letterSpacing:'.08em',borderBottom:'2px solid var(--color-border-secondary)',background:'var(--color-background-secondary)',position:'sticky',top:0,zIndex:2,whiteSpace:'nowrap',width:30}} title="Not Null">NN</th>
                  <th style={{padding:'8px 4px',textAlign:'center',fontSize:9,fontWeight:700,color:'var(--color-text-tertiary)',textTransform:'uppercase',letterSpacing:'.08em',borderBottom:'2px solid var(--color-border-secondary)',background:'var(--color-background-secondary)',position:'sticky',top:0,zIndex:2,whiteSpace:'nowrap',width:30}} title="Indexed">IDX</th>
                  <TH col="sens"        label="Sensitivity" w={80}/>
                  <TH col="dq"          label="DQ score"    w={70} center/>
                  <TH col="description" label="Description"/>
                  <th style={{padding:'8px 4px',borderBottom:'2px solid var(--color-border-secondary)',background:'var(--color-background-secondary)',position:'sticky',top:0,zIndex:2,width:30}}/>
                </tr>
              </thead>
              <tbody>
                {filtered.length===0&&<tr><td colSpan={15} style={{padding:40,textAlign:'center',color:'var(--color-text-tertiary)',fontSize:13}}>No columns match filters</td></tr>}
                {filtered.map((f,i)=>{
                  const isExp = expanded===f.id;
                  const dq = dqScore(f);
                  const color = sc(f.system);
                  return[
                    <tr key={f.id} onClick={()=>setExpanded(isExp?null:f.id)}
                      style={{cursor:'pointer',borderBottom:'1px solid var(--color-border-tertiary)',
                        background:isExp?`${color}08`:(i%2===0?'transparent':'var(--color-background-secondary)')}}>
                      {/* System */}
                      <td style={{padding:'6px 8px'}}>
                        <div style={{display:'flex',alignItems:'center',gap:4}}>
                          <div style={{width:6,height:6,borderRadius:'50%',background:color,flexShrink:0}}/>
                          <span style={{fontSize:10,fontWeight:600,color,overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}}>{f.system}</span>
                        </div>
                      </td>
                      {/* Table */}
                      <td style={{padding:'6px 8px',fontSize:10,color:'var(--color-text-secondary)',overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}} title={f.table}>{f.table}</td>
                      {/* Column */}
                      <td style={{padding:'6px 8px'}}>
                        <div style={{display:'flex',alignItems:'center',gap:4}}>
                          {f.is_primary_key
                            ?<svg width="10" height="10" viewBox="0 0 10 10" style={{flexShrink:0}}><circle cx="4" cy="4" r="2.5" fill="none" stroke="#f59e0b" strokeWidth="1.2"/><line x1="5.8" y1="5.8" x2="9.5" y2="9.5" stroke="#f59e0b" strokeWidth="1.2" strokeLinecap="round"/></svg>
                            :f.is_foreign_key
                            ?<svg width="10" height="10" viewBox="0 0 10 10" style={{flexShrink:0}}><circle cx="4" cy="4" r="2.5" fill="none" stroke="#3b82f6" strokeWidth="1.2" strokeDasharray="1.5,0.8"/></svg>
                            :<div style={{width:4,height:4,borderRadius:'50%',background:'var(--color-border-secondary)',flexShrink:0}}/>
                          }
                          <span style={{fontSize:11,fontWeight:f.is_primary_key?600:400,color:'var(--color-text-primary)',overflow:'hidden',textOverflow:'ellipsis',whiteSpace:'nowrap'}} title={f.column}>{f.column}</span>
                        </div>
                      </td>
                      {/* Data type */}
                      <td style={{padding:'6px 8px',fontSize:10,color:'var(--color-text-tertiary)',fontFamily:'monospace',whiteSpace:'nowrap',overflow:'hidden',textOverflow:'ellipsis'}} title={f.data_type}>{f.data_type||'—'}</td>
                      {/* Length */}
                      <td style={{padding:'6px 4px',textAlign:'center',fontSize:10,color:'var(--color-text-secondary)'}}>{f.length||'—'}</td>
                      {/* Precision */}
                      <td style={{padding:'6px 4px',textAlign:'center',fontSize:10,color:'var(--color-text-secondary)'}}>{f.precision||'—'}</td>
                      {/* Scale */}
                      <td style={{padding:'6px 4px',textAlign:'center',fontSize:10,color:'var(--color-text-secondary)'}}>{f.scale||'—'}</td>
                      {/* PK */}
                      <td style={{padding:'6px 4px',textAlign:'center'}}>
                        {f.is_primary_key&&<span style={{fontSize:10,color:'#f59e0b',fontWeight:700}}>PK</span>}
                      </td>
                      {/* FK */}
                      <td style={{padding:'6px 4px',textAlign:'center'}}>
                        {f.is_foreign_key&&<span style={{fontSize:10,color:'#3b82f6',fontWeight:700}}>FK</span>}
                      </td>
                      {/* Not null */}
                      <td style={{padding:'6px 4px',textAlign:'center'}}>
                        {f.nullable===false
                          ?<span style={{fontSize:9,color:'#f59e0b',fontWeight:600}}>NN</span>
                          :<span style={{fontSize:9,color:'var(--color-text-tertiary)'}}>—</span>}
                      </td>
                      {/* Index */}
                      <td style={{padding:'6px 4px',textAlign:'center'}}>
                        {f.is_indexed&&<span style={{fontSize:9,color:'#7c6fff',fontWeight:600}}>IDX</span>}
                      </td>
                      {/* Sensitivity */}
                      <td style={{padding:'6px 8px'}}><SensBadge pii={f.pii} column={f.column}/></td>
                      {/* DQ */}
                      <td style={{padding:'6px 4px'}}><DQGauge score={dq}/></td>
                      {/* Description */}
                      <td style={{padding:'6px 8px'}}><DescCell field={f} onSave={updateDesc} aiEnabled={aiStatus?.configured}/></td>
                      {/* Expand */}
                      <td style={{padding:'6px 4px',textAlign:'center',fontSize:10,color:'var(--color-text-tertiary)'}}>{isExp?'▲':'▼'}</td>
                    </tr>,
                    isExp&&(
                      <tr key={`${f.id}-exp`} style={{borderBottom:`2px solid ${color}40`}}>
                        <td colSpan={15} style={{padding:'10px 16px',background:`${color}06`}}>
                          <div style={{display:'flex',gap:24,flexWrap:'wrap',fontSize:11}}>
                            <div>
                              <div style={{color:'var(--color-text-tertiary)',fontSize:9,textTransform:'uppercase',letterSpacing:'.07em',marginBottom:3}}>Full ID</div>
                              <code style={{color:'var(--color-text-info)',fontSize:10}}>{f.id}</code>
                            </div>
                            {f.foreign_key_ref&&<div>
                              <div style={{color:'var(--color-text-tertiary)',fontSize:9,textTransform:'uppercase',letterSpacing:'.07em',marginBottom:3}}>FK References</div>
                              <code style={{color:'#3b82f6',fontSize:10}}>{f.foreign_key_ref}</code>
                            </div>}
                            {f.index_name&&<div>
                              <div style={{color:'var(--color-text-tertiary)',fontSize:9,textTransform:'uppercase',letterSpacing:'.07em',marginBottom:3}}>Index</div>
                              <code style={{color:'#7c6fff',fontSize:10}}>{f.index_name}</code>
                            </div>}
                            {f.default_value&&<div>
                              <div style={{color:'var(--color-text-tertiary)',fontSize:9,textTransform:'uppercase',letterSpacing:'.07em',marginBottom:3}}>Default</div>
                              <code style={{color:'var(--color-text-secondary)',fontSize:10}}>{f.default_value}</code>
                            </div>}
                            {f.tags?.length>0&&<div>
                              <div style={{color:'var(--color-text-tertiary)',fontSize:9,textTransform:'uppercase',letterSpacing:'.07em',marginBottom:3}}>Tags</div>
                              <div style={{display:'flex',gap:4}}>{f.tags.map(t=><span key={t} style={{padding:'1px 7px',borderRadius:20,fontSize:9,background:'var(--color-background-secondary)',color:'var(--color-text-secondary)',border:'.5px solid var(--color-border-secondary)'}}>{t}</span>)}</div>
                            </div>}
                            <div style={{marginLeft:'auto',display:'flex',gap:6}}>
                              <a href={`${BASE}/lineage/path/${encodeURIComponent(f.id)}`} target="_blank" rel="noreferrer"
                                style={{padding:'3px 9px',fontSize:10,background:'transparent',border:'.5px solid var(--color-border-secondary)',color:'var(--color-text-secondary)',borderRadius:6,textDecoration:'none'}}>⇢ Lineage</a>
                              <a href={`${BASE}/impact/${encodeURIComponent(f.id)}`} target="_blank" rel="noreferrer"
                                style={{padding:'3px 9px',fontSize:10,background:'transparent',border:'.5px solid var(--color-border-secondary)',color:'var(--color-text-secondary)',borderRadius:6,textDecoration:'none'}}>⚡ Impact</a>
                            </div>
                          </div>
                        </td>
                      </tr>
                    )
                  ];
                })}
              </tbody>
            </table>
          )}
        </div>

        {/* Footer */}
        <div style={{flexShrink:0,padding:'6px 14px',borderTop:'1px solid var(--color-border-tertiary)',
          background:'var(--color-background-secondary)',display:'flex',gap:12,
          fontSize:10,color:'var(--color-text-tertiary)',alignItems:'center',flexWrap:'wrap'}}>
          <span style={{color:avgDQ>=80?'#22c55e':avgDQ>=50?'#f59e0b':'#ef4444',fontWeight:500}}>DQ {avgDQ}%</span>
          <span>{fields.filter(f=>f.description).length}/{fields.length} described</span>
          <span>{piiCnt} PII fields</span>
          <span>{fields.filter(f=>f.is_primary_key).length} primary keys · {fields.filter(f=>f.is_foreign_key).length} foreign keys</span>
          {aiStatus?.configured?<span style={{color:'var(--color-text-success)'}}>✦ AI ({aiStatus.provider})</span>:<span>⚙ Rule-based</span>}
          <span style={{marginLeft:'auto'}}>Click row to expand · ✎ edit description · ⚙/✦ auto-generate</span>
        </div>
      </div>
    </div>
  );
}
