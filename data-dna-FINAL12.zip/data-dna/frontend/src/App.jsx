import { useState, useEffect, useCallback } from 'react';
import { api } from './utils/api.js';
import LineageGraph from './components/LineageGraph.jsx';
import DataLieDetector from './components/DataLieDetector.jsx';
import LineageTimeMachine from './components/LineageTimeMachine.jsx';
import TrustPropagation from './components/TrustPropagation.jsx';
import RegulationRadar from './components/RegulationRadar.jsx';
import DNAFingerprint from './components/DNAFingerprint.jsx';
import ModelExplainability from './components/ModelExplainability.jsx';
import SearchPanel from './components/SearchPanel.jsx';
import ImpactPanel from './components/ImpactPanel.jsx';
import AuditTrail from './components/AuditTrail.jsx';
import ChatPanel from './components/ChatPanel.jsx';
import SettingsPanel from './components/SettingsPanel.jsx';
import DbCrawlerPanel from './components/DbCrawlerPanel.jsx';
import TimelineView from './components/TimelineView.jsx';
import Dashboard from './components/Dashboard.jsx';
import MultiSourceInfer from './components/MultiSourceInfer.jsx';
import ManualMapper from './components/ManualMapper.jsx';
import MetadataExplorer from './components/MetadataExplorer.jsx';

/* ─────────────────── Tab definitions ────────────────────────────── */
const TAB_GROUPS = [
  {
    label: 'Explore',
    tabs: [
      { id:'graph',     icon:'⬡', label:'Graph',      desc:'Interactive lineage graph' },
      { id:'timeline',  icon:'⇢', label:'Timeline',   desc:'Left-to-right flow view' },
      { id:'dashboard', icon:'▦', label:'Dashboard',  desc:'Health & completeness' },
    ]
  },
  {
    label: 'Discover',
    tabs: [
      { id:'search',    icon:'⌕', label:'Search',     desc:'Natural language search' },
      { id:'infer',     icon:'◈', label:'Lineage Map', desc:'Source→target discovery' },
      { id:'mapper',    icon:'⟶', label:'Map Fields', desc:'Manually map fields with different names' },
      { id:'impact',    icon:'⚡', label:'Impact',     desc:'Downstream impact analysis' },
      { id:'audit',     icon:'⊕', label:'Audit',      desc:'Provenance & compliance' },
      { id:'chat',      icon:'◎', label:'AI Chat',    desc:'Ask about your data' },
    ]
  },
  {
    label: 'Manage',
    tabs: [
      { id:'ingest',    icon:'↑', label:'Ingest',     desc:'SQL / JSON schema' },
      { id:'crawler',   icon:'⟳', label:'DB Connect', desc:'Auto-crawl database' },
      { id:'metadata',  icon:'⊞', label:'Metadata',   desc:'Browse & edit all field metadata' },
      { id:'settings',  icon:'⚙', label:'Settings',   desc:'AI provider config' },
    ]
  },
  {
    label: 'Intelligence',
    tabs: [
      { id:'lie_detector',    icon:'⚠', label:'Lie Detector',   desc:'Detect conflicting metric definitions' },
      { id:'time_machine',    icon:'◷', label:'Time Machine',    desc:'Point-in-time lineage replay' },
      { id:'trust',           icon:'★', label:'Trust Score',     desc:'Trust propagation through lineage' },
      { id:'regulation',      icon:'⊛', label:'Reg Radar',       desc:'DFAST/HMDA/CRA regulatory mapping' },
      { id:'dna_fingerprint', icon:'⬡', label:'DNA Fingerprint', desc:'Detect duplicate & ghost fields' },
      { id:'model_explain',   icon:'◈', label:'Model Trail',     desc:'AI model explainability for ECOA/SR11-7' },
    ]
  },
];
const ALL_TABS = TAB_GROUPS.flatMap(g => g.tabs);

/* ─────────────────── Stat card ─────────────────────────────────── */
function StatCard({ label, value, color, sub }) {
  return (
    <div style={{ padding:'10px 16px', background:'var(--surface)', border:'1px solid var(--border)',
      borderRadius:'var(--radius)', minWidth:88, flexShrink:0 }}>
      <div style={{ fontSize:9, color:'var(--text3)', textTransform:'uppercase', letterSpacing:'.07em', marginBottom:4 }}>{label}</div>
      <div style={{ fontSize:20, fontWeight:800, color:color||'var(--text)', fontFamily:'var(--font-head)', lineHeight:1 }}>{value??'–'}</div>
      {sub&&<div style={{ fontSize:9, color:'var(--text3)', marginTop:2 }}>{sub}</div>}
    </div>
  );
}

/* ─────────────────── Ingest panel ──────────────────────────────── */
function IngestPanel({ onSuccess }) {
  const [mode, setMode] = useState('sql');
  const [system, setSystem] = useState('');
  const [sql, setSql] = useState('');
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);
  const EXAMPLE = `CREATE TABLE CBS_ACCOUNT (\n  ACCT_ID VARCHAR(20),\n  CUST_ID VARCHAR(20),\n  LOAN_AMT DECIMAL(15,2),\n  STATUS VARCHAR(10)\n);\n\nINSERT INTO REPORTING.LOAN_SUMMARY (ACCOUNT_ID, AMOUNT)\nSELECT ACCT_ID, LOAN_AMT FROM CBS_ACCOUNT;`;
  const doIngest = async () => {
    if (!system.trim()) { alert('Enter system name'); return; }
    setLoading(true);
    try {
      let payload = { system_name: system.trim() };
      if (mode==='sql') payload.sql=sql;
      else { try { payload.schema_json=JSON.parse(sql); } catch { alert('Invalid JSON'); setLoading(false); return; } }
      const res = await api.ingest(payload);
      setResult(res); onSuccess?.();
    } catch(e) { setResult({ error: e.message }); }
    setLoading(false);
  };
  return (
    <div style={{ display:'flex', flexDirection:'column', gap:14, height:'100%' }}>
      <div style={{ display:'flex', gap:8, alignItems:'center' }}>
        <input value={system} onChange={e=>setSystem(e.target.value)} placeholder="System name (e.g. CBS, LOS, CRM)"
          style={{ flex:1, background:'var(--bg3)', border:'1px solid var(--border2)', borderRadius:'var(--radius)', padding:'9px 12px', fontSize:12 }} />
        <div style={{ display:'flex', background:'var(--bg3)', border:'1px solid var(--border)', borderRadius:'var(--radius)', overflow:'hidden' }}>
          {['sql','json'].map(m=>(
            <button key={m} onClick={()=>setMode(m)}
              style={{ padding:'7px 14px', background:mode===m?'var(--accent)':'transparent', color:mode===m?'#fff':'var(--text2)', fontSize:11 }}>{m.toUpperCase()}</button>
          ))}
        </div>
      </div>
      <textarea value={sql} onChange={e=>setSql(e.target.value)} placeholder={mode==='sql'?EXAMPLE:'{"tables":{"MY_TABLE":{"columns":{"ID":"VARCHAR"}}}}'}
        style={{ flex:1, background:'var(--bg3)', border:'1px solid var(--border)', borderRadius:'var(--radius)', padding:'10px 12px', fontSize:11, resize:'none', lineHeight:1.7, minHeight:160 }}/>
      <div style={{ display:'flex', gap:8 }}>
        <button onClick={doIngest} disabled={loading}
          style={{ padding:'9px 20px', background:loading?'var(--surface)':'var(--accent)', color:'#fff', borderRadius:'var(--radius)', fontWeight:600, fontSize:12 }}>
          {loading?'Ingesting…':'↑ Ingest'}
        </button>
        <button onClick={()=>{setSql(EXAMPLE);setSystem('CBS_SYSTEM');setMode('sql');}}
          style={{ padding:'9px 14px', background:'var(--surface)', border:'1px solid var(--border)', color:'var(--text2)', borderRadius:'var(--radius)', fontSize:11 }}>
          Load example
        </button>
        <a href={api.exportFieldsCsv()} download
          style={{ marginLeft:'auto', padding:'9px 14px', background:'var(--surface)', border:'1px solid var(--border)', color:'var(--text2)', borderRadius:'var(--radius)', fontSize:11, textDecoration:'none', display:'flex', alignItems:'center' }}>
          ↓ Export CSV
        </a>
      </div>
      {result&&(
        <div className="fade-in" style={{ padding:'10px 14px', background:result.error?'rgba(255,90,125,0.08)':'rgba(0,212,170,0.08)', border:`1px solid ${result.error?'rgba(255,90,125,0.3)':'rgba(0,212,170,0.3)'}`, borderRadius:'var(--radius)', fontSize:12 }}>
          {result.error?<span style={{color:'var(--red)'}}>Error: {result.error}</span>
            :<><span style={{color:'var(--teal)',fontWeight:600}}>✓ Ingested </span><span style={{color:'var(--text2)'}}>{result.nodes_created} fields, {result.edges_created} edges</span></>}
        </div>
      )}
    </div>
  );
}

/* ─────────────────── Main App ───────────────────────────────────── */
export default function App() {
  const [tab, setTab] = useState('graph');
  const [stats, setStats] = useState(null);
  const [graphData, setGraphData] = useState({ nodes:[], links:[] });
  const [selectedNode, setSelectedNode] = useState(null);
  const [highlightPath, setHighlightPath] = useState(null);
  const [detailFieldId, setDetailFieldId] = useState(null);
  const [showInferred, setShowInferred] = useState(true);
  const [sideTab, setSideTab] = useState('detail');
  const [connected, setConnected] = useState(null);
  const [aiStatus, setAiStatus] = useState(null);
  const [sidebarOpen, setSidebarOpen] = useState(true);

  const loadGraph = useCallback(async () => {
    try {
      const [g,s,ai] = await Promise.all([api.graph(), api.stats(), api.getAIStatus()]);
      const filtered = showInferred ? g : { ...g, links:g.links.filter(l=>l.type==='authoritative') };
      setGraphData(filtered); setStats(s); setAiStatus(ai); setConnected(true);
    } catch { setConnected(false); }
  }, [showInferred]);

  useEffect(() => { loadGraph(); }, [loadGraph]);

  const handleNodeClick = useCallback(async (node) => {
    setSelectedNode(node);
    if (!node) { setHighlightPath(null); setDetailFieldId(null); return; }
    setDetailFieldId(node.id);
    try { const path = await api.lineage(node.id,3,'both',showInferred); setHighlightPath(path); }
    catch { setHighlightPath(null); }
  }, [showInferred]);

  const currentTab = ALL_TABS.find(t=>t.id===tab);

  return (
    <div style={{ display:'flex', flexDirection:'column', height:'100vh', background:'var(--bg)', overflow:'hidden' }}>

      {/* ══ HEADER ══════════════════════════════════════════════════ */}
      <header style={{
        display:'flex', alignItems:'stretch', height:52,
        background:'var(--bg2)', borderBottom:'1px solid var(--border)',
        flexShrink:0, zIndex:20
      }}>
        {/* Logo */}
        <div style={{ display:'flex', alignItems:'center', gap:9, padding:'0 20px', borderRight:'1px solid var(--border)', flexShrink:0 }}>
          <svg width="24" height="24" viewBox="0 0 24 24">
            <polygon points="12,2 22,7 22,17 12,22 2,17 2,7" fill="none" stroke="var(--accent)" strokeWidth="1.5"/>
            <polygon points="12,6 18,9.5 18,16.5 12,20 6,16.5 6,9.5" fill="var(--accent)" fillOpacity="0.12" stroke="var(--teal)" strokeWidth="1"/>
            <circle cx="12" cy="13" r="2.5" fill="var(--accent)"/>
          </svg>
          <span style={{ fontFamily:'var(--font-head)', fontWeight:800, fontSize:16, letterSpacing:'-0.02em', color:'var(--text)' }}>
            Data<span style={{color:'var(--accent)'}}>-</span>DNA
          </span>
        </div>

        {/* ── All tabs flat — no group label blocking ── */}
        <nav style={{ display:'flex', alignItems:'stretch', flex:1, overflowX:'auto', gap:0 }}>
          {TAB_GROUPS.map((group, gi) => (
            <div key={group.label} style={{ display:'flex', alignItems:'stretch', position:'relative', borderRight: gi < TAB_GROUPS.length-1 ? '1px solid var(--border)' : 'none', paddingRight: gi < TAB_GROUPS.length-1 ? 4 : 0, marginRight: gi < TAB_GROUPS.length-1 ? 4 : 0 }}>
              {/* Tiny group label sits at top-left of group, never blocks click */}
              <div style={{ position:'absolute', top:4, left:6, fontSize:8, fontWeight:700, color:'var(--text3)', textTransform:'uppercase', letterSpacing:'.1em', pointerEvents:'none', userSelect:'none', opacity:0.6 }}>{group.label}</div>
              {group.tabs.map(t => (
                <button key={t.id}
                  onClick={() => setTab(t.id)}
                  title={t.desc}
                  className={`tab-nav-btn${tab===t.id?' active':''}`}>
                  <span className="tab-icon">{t.icon}</span>
                  <span>{t.label}</span>
                  {t.id==='chat' && aiStatus?.configured && (
                    <div style={{ width:5, height:5, borderRadius:'50%', background:'var(--teal)', marginLeft:2, flexShrink:0 }}/>
                  )}
                  {t.id==='settings' && !aiStatus?.configured && (
                    <div style={{ width:5, height:5, borderRadius:'50%', background:'var(--amber)', marginLeft:2, flexShrink:0 }}/>
                  )}
                </button>
              ))}
            </div>
          ))}
        </nav>

        {/* Right controls */}
        <div style={{ display:'flex', alignItems:'center', gap:12, padding:'0 16px', borderLeft:'1px solid var(--border)', flexShrink:0 }}>
          {tab==='graph' && (
            <label style={{ display:'flex', alignItems:'center', gap:6, fontSize:11, color:'var(--text3)', cursor:'pointer', userSelect:'none' }}>
              <div onClick={()=>setShowInferred(v=>!v)}
                style={{ width:28, height:16, background:showInferred?'var(--accent)':'var(--surface)', borderRadius:8, position:'relative', transition:'background .2s', border:'1px solid var(--border2)', cursor:'pointer' }}>
                <div style={{ position:'absolute', top:2, left:showInferred?14:2, width:10, height:10, background:'#fff', borderRadius:'50%', transition:'left .2s' }}/>
              </div>
              <span style={{ color: showInferred ? 'var(--text2)' : 'var(--text3)' }}>Inferred</span>
            </label>
          )}
          {/* AI badge */}
          {aiStatus?.configured && (
            <div style={{ display:'flex', alignItems:'center', gap:5, padding:'4px 10px', background:'rgba(0,212,170,0.08)', border:'1px solid rgba(0,212,170,0.2)', borderRadius:20 }}>
              <div style={{ width:6, height:6, borderRadius:'50%', background:'var(--teal)' }}/>
              <span style={{ fontSize:10, color:'var(--teal)' }}>{aiStatus.provider}</span>
            </div>
          )}
          {/* Connection status */}
          <div style={{ display:'flex', alignItems:'center', gap:5, fontSize:11 }}>
            <div style={{ width:7, height:7, borderRadius:'50%', background: connected===null?'var(--text3)':connected?'var(--teal)':'var(--red)' }} className={connected===null?'pulse':''}/>
            <span style={{ color: connected===null?'var(--text3)':connected?'var(--teal)':'var(--red)' }}>
              {connected===null?'…':connected?'online':'offline'}
            </span>
          </div>
        </div>
      </header>

      {/* ══ STATS BAR ════════════════════════════════════════════════ */}
      {stats && (
        <div style={{ display:'flex', gap:8, padding:'7px 16px', background:'var(--bg2)', borderBottom:'1px solid var(--border)', flexShrink:0, overflowX:'auto', alignItems:'center' }}>
          <StatCard label="Fields"    value={stats.total_fields}          color="var(--text)" />
          <StatCard label="Auth edges" value={stats.authoritative_edges}  color="var(--teal)" />
          <StatCard label="Inferred"   value={stats.inferred_edges}        color="var(--accent2)" />
          <StatCard label="Systems"    value={stats.systems?.length}       color="var(--amber)" />
          <StatCard label="DAG"
            value={stats.is_dag ? '✓' : '✗'}
            color={stats.is_dag ? 'var(--green)' : 'var(--red)'}
            onClick={!stats.is_dag ? async () => {
              if (window.confirm('Fix DAG? This removes cycle-causing edges.')) {
                const r = await fetch('http://localhost:8000/lineage/fix-dag', {method:'POST'}).then(x=>x.json());
                alert(r.removed > 0
                  ? 'Fixed! Removed ' + r.removed + ' cycle-causing edge(s). Refreshing...'
                  : 'No cycles found — DAG is already valid.');
                loadGraph();
              }
            } : undefined}
            title={stats.is_dag ? 'DAG valid' : 'Click to fix cycles'}
          />
          {/* Current tab label */}
          <div style={{ marginLeft:'auto', fontSize:11, color:'var(--text3)', display:'flex', alignItems:'center', gap:6 }}>
            <span style={{ fontSize:15 }}>{currentTab?.icon}</span>
            <span>{currentTab?.label}</span>
            <span style={{ color:'var(--text3)', opacity:0.5 }}>—</span>
            <span style={{ color:'var(--text3)', fontSize:10 }}>{currentTab?.desc}</span>
          </div>
        </div>
      )}

      {/* ══ MAIN CONTENT ═════════════════════════════════════════════ */}
      <div style={{ flex:1, overflow:'hidden', display:'flex', position:'relative' }}>

        {/* GRAPH */}
        {tab==='graph' && (
          <>
            <div style={{ flex:1, position:'relative', overflow:'hidden' }}>
              {connected===false && (
                <div style={{ position:'absolute', inset:0, display:'flex', alignItems:'center', justifyContent:'center', flexDirection:'column', gap:12, color:'var(--text3)' }}>
                  <div style={{ fontSize:40, opacity:0.2 }}>⬡</div>
                  <div style={{ fontSize:13 }}>Backend not connected</div>
                  <button onClick={loadGraph} style={{ padding:'8px 16px', background:'var(--surface)', border:'1px solid var(--border2)', color:'var(--text2)', borderRadius:'var(--radius)', fontSize:12 }}>Retry</button>
                </div>
              )}
              <LineageGraph data={graphData} onNodeClick={handleNodeClick} selectedNode={selectedNode} highlightPath={highlightPath}/>
            </div>
            {/* Sidebar */}
            {sidebarOpen && (
              <div style={{ width:300, background:'var(--bg2)', borderLeft:'1px solid var(--border)', display:'flex', flexDirection:'column', flexShrink:0 }}>
                <div style={{ display:'flex', borderBottom:'1px solid var(--border)' }}>
                  {[['detail','Node'],['audit','Audit'],['chat','Chat']].map(([k,l])=>(
                    <button key={k} onClick={()=>setSideTab(k)}
                      style={{ flex:1, padding:'10px', background:sideTab===k?'var(--surface)':'transparent', color:sideTab===k?'var(--text)':'var(--text3)', fontSize:11, borderBottom:sideTab===k?'2px solid var(--accent)':'2px solid transparent', transition:'all .15s', fontWeight:sideTab===k?600:400 }}>
                      {l}
                    </button>
                  ))}
                  <button onClick={()=>setSidebarOpen(false)} style={{ padding:'10px 12px', background:'transparent', color:'var(--text3)', fontSize:16 }}>×</button>
                </div>
                <div style={{ flex:1, overflowY:'auto', padding:12 }}>
                  {sideTab==='detail' && (
                    selectedNode ? (
                      <div className="fade-in">
                        <div style={{ fontSize:9, color:'var(--text3)', textTransform:'uppercase', letterSpacing:'.07em', marginBottom:4 }}>{selectedNode.system}</div>
                        <div style={{ fontSize:15, fontWeight:700, color:'var(--text)', fontFamily:'var(--font-head)', marginBottom:4 }}>{selectedNode.table}.{selectedNode.column}</div>
                        {selectedNode.data_type&&<div style={{ fontSize:11, color:'var(--text3)', marginBottom:8 }}>{selectedNode.data_type}</div>}
                        <div style={{ display:'flex', gap:6, flexWrap:'wrap', marginBottom:12 }}>
                          {selectedNode.pii&&<span className="tag tag-pii">PII</span>}
                        </div>
                        <div style={{ display:'flex', flexDirection:'column', gap:6 }}>
                          {[['⚡ Impact','impact'],['⊕ Audit','audit']].map(([label,t])=>(
                            <button key={t} onClick={()=>{ setDetailFieldId(selectedNode.id); setTab(t); }}
                              style={{ padding:'8px 12px', background:'transparent', border:'1px solid var(--border2)', color:'var(--text2)', borderRadius:'var(--radius)', fontSize:11, textAlign:'left' }}>
                              {label} →
                            </button>
                          ))}
                          <a href={api.auditPdfUrl(selectedNode.id)} download
                            style={{ padding:'8px 12px', background:'transparent', border:'1px solid rgba(0,212,170,0.3)', color:'var(--teal)', borderRadius:'var(--radius)', fontSize:11, textDecoration:'none', display:'block' }}>
                            ↓ Export Audit PDF
                          </a>
                        </div>
                      </div>
                    ) : <div style={{ color:'var(--text3)', padding:16, textAlign:'center', marginTop:40 }}><div style={{ fontSize:32, opacity:.2, marginBottom:8 }}>⬡</div>Click a node</div>
                  )}
                  {sideTab==='audit'&&<AuditTrail fieldId={selectedNode?.id}/>}
                  {sideTab==='chat'&&<ChatPanel selectedFieldId={selectedNode?.id} aiConfigured={aiStatus?.configured}/>}
                </div>
              </div>
            )}
            {!sidebarOpen&&(
              <button onClick={()=>setSidebarOpen(true)}
                style={{ position:'absolute', right:0, top:'50%', transform:'translateY(-50%)', padding:'12px 6px', background:'var(--surface)', border:'1px solid var(--border)', borderRadius:'var(--radius) 0 0 var(--radius)', color:'var(--text2)', fontSize:12, zIndex:5 }}>
                ‹
              </button>
            )}
          </>
        )}

        {/* TIMELINE */}
        {tab==='timeline'&&<div style={{ flex:1, overflow:'hidden' }}><TimelineView onSelectField={id=>{setDetailFieldId(id);setTab('graph');}}/></div>}

        {/* DASHBOARD */}
        {tab==='dashboard'&&<div style={{ flex:1, overflow:'hidden' }}><Dashboard onSelectField={id=>{setDetailFieldId(id);setTab('impact');}}/></div>}

        {/* SEARCH */}
        {tab==='search'&&(
          <div style={{ flex:1, padding:24, maxWidth:700, margin:'0 auto', overflow:'hidden', display:'flex', flexDirection:'column' }}>
            <h2 style={{ fontFamily:'var(--font-head)', fontWeight:700, marginBottom:16, color:'var(--text)' }}>⌕ Natural language search</h2>
            <SearchPanel onSelect={id=>{setDetailFieldId(id);setTab('graph');}}/>
          </div>
        )}

        {/* INFER */}
        {tab==='infer'&&<div style={{ flex:1, overflow:'hidden' }}><MultiSourceInfer onGraphRefresh={loadGraph}/></div>}

        {/* MANUAL MAPPER */}
        {tab==='mapper'&&<div style={{ flex:1, overflow:'hidden' }}><ManualMapper onMapped={loadGraph}/></div>}

        {/* IMPACT */}
        {tab==='impact'&&(
          <div style={{ flex:1, padding:24, maxWidth:720, margin:'0 auto', overflow:'auto' }}>
            <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:16 }}>
              <h2 style={{ fontFamily:'var(--font-head)', fontWeight:700, color:'var(--text)' }}>⚡ Impact analysis</h2>
              {detailFieldId&&<a href={api.auditPdfUrl(detailFieldId)} download style={{ fontSize:11, color:'var(--teal)', textDecoration:'none', padding:'6px 12px', border:'1px solid rgba(0,212,170,0.3)', borderRadius:'var(--radius)' }}>↓ PDF</a>}
            </div>
            {!detailFieldId&&(
              <div style={{ display:'flex', flexWrap:'wrap', gap:6, marginBottom:16 }}>
                {['CREDIT_CORE.CUSTOMER.CUST_ID','CREDIT_CORE.ACCOUNT.CREDIT_LIMIT','RISK_ENGINE.RISK_SCORE.COMPOSITE_SCORE'].map(f=>(
                  <button key={f} onClick={()=>setDetailFieldId(f)}
                    style={{ padding:'5px 12px', background:'var(--surface)', border:'1px solid var(--border)', borderRadius:20, color:'var(--text2)', fontSize:11 }}>
                    {f.split('.').slice(-1)[0]}
                  </button>
                ))}
              </div>
            )}
            <ImpactPanel fieldId={detailFieldId} onSelectField={setDetailFieldId}/>
          </div>
        )}

        {/* AUDIT */}
        {tab==='audit'&&(
          <div style={{ flex:1, padding:24, maxWidth:720, margin:'0 auto', overflow:'auto' }}>
            <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:16 }}>
              <h2 style={{ fontFamily:'var(--font-head)', fontWeight:700, color:'var(--text)' }}>⊕ Audit trail</h2>
              {detailFieldId&&<a href={api.auditPdfUrl(detailFieldId)} download style={{ fontSize:11, color:'var(--teal)', textDecoration:'none', padding:'6px 12px', border:'1px solid rgba(0,212,170,0.3)', borderRadius:'var(--radius)' }}>↓ Export PDF</a>}
            </div>
            {!detailFieldId&&(
              <div style={{ display:'flex', flexWrap:'wrap', gap:6, marginBottom:16 }}>
                {['REPORTING.CREDIT_REPORT_SUMMARY.CLIENT_ID','REPORTING.CREDIT_REPORT_SUMMARY.CREDIT_SCORE'].map(f=>(
                  <button key={f} onClick={()=>setDetailFieldId(f)}
                    style={{ padding:'5px 12px', background:'var(--surface)', border:'1px solid var(--border)', borderRadius:20, color:'var(--text2)', fontSize:11 }}>
                    {f.split('.').slice(-1)[0]}
                  </button>
                ))}
              </div>
            )}
            <AuditTrail fieldId={detailFieldId}/>
          </div>
        )}

        {/* CHAT */}
        {tab==='chat'&&(
          <div style={{ flex:1, padding:24, maxWidth:720, margin:'0 auto', display:'flex', flexDirection:'column', overflow:'hidden' }}>
            <div style={{ display:'flex', alignItems:'center', justifyContent:'space-between', marginBottom:16 }}>
              <h2 style={{ fontFamily:'var(--font-head)', fontWeight:700, color:'var(--text)' }}>◎ Lineage AI Chat</h2>
              <button onClick={()=>setTab('settings')} style={{ fontSize:11, color:'var(--accent2)', background:'transparent', padding:0 }}>
                {aiStatus?.configured?`● ${aiStatus.provider}`:'⚙ Configure AI →'}
              </button>
            </div>
            <ChatPanel selectedFieldId={detailFieldId} aiConfigured={aiStatus?.configured}/>
          </div>
        )}

        {/* INGEST */}
        {tab==='ingest'&&(
          <div style={{ flex:1, padding:24, maxWidth:700, margin:'0 auto', overflow:'auto', display:'flex', flexDirection:'column' }}>
            <h2 style={{ fontFamily:'var(--font-head)', fontWeight:700, marginBottom:4, color:'var(--text)' }}>↑ Ingest SQL / Schema</h2>
            <p style={{ color:'var(--text3)', fontSize:12, marginBottom:16 }}>Paste SQL DDL/DML or JSON schema to extract field-level lineage.</p>
            <IngestPanel onSuccess={loadGraph}/>
          </div>
        )}


        {/* METADATA EXPLORER */}
        {tab==='metadata'&&<div style={{ flex:1, overflow:'hidden', display:'flex', flexDirection:'column' }}><MetadataExplorer/></div>}

        {/* DB CRAWLER */}
        {tab==='crawler'&&(
          <div style={{ flex:1, padding:24, maxWidth:700, margin:'0 auto', overflow:'auto' }}>
            <h2 style={{ fontFamily:'var(--font-head)', fontWeight:700, marginBottom:4, color:'var(--text)' }}>⟳ Connect Real Database</h2>
            <p style={{ color:'var(--text3)', fontSize:12, marginBottom:16 }}>Auto-crawl your actual database schema.</p>
            <DbCrawlerPanel onSuccess={loadGraph}/>
          </div>
        )}

        {/* SETTINGS */}
        {tab==='lie_detector'&&<div style={{ flex:1, overflow:'hidden', display:'flex', flexDirection:'column' }}><DataLieDetector/></div>}
        {tab==='time_machine'&&<div style={{ flex:1, overflow:'hidden', display:'flex', flexDirection:'column' }}><LineageTimeMachine/></div>}
        {tab==='trust'&&<div style={{ flex:1, overflow:'hidden', display:'flex', flexDirection:'column' }}><TrustPropagation/></div>}
        {tab==='regulation'&&<div style={{ flex:1, overflow:'hidden', display:'flex', flexDirection:'column' }}><RegulationRadar/></div>}
        {tab==='dna_fingerprint'&&<div style={{ flex:1, overflow:'hidden', display:'flex', flexDirection:'column' }}><DNAFingerprint/></div>}
        {tab==='model_explain'&&<div style={{ flex:1, overflow:'hidden', display:'flex', flexDirection:'column' }}><ModelExplainability/></div>}
        {tab==='settings'&&(
          <div style={{ flex:1, padding:24, maxWidth:620, margin:'0 auto', overflow:'auto' }}>
            <h2 style={{ fontFamily:'var(--font-head)', fontWeight:700, marginBottom:4, color:'var(--text)' }}>⚙ AI Provider Settings</h2>
            <p style={{ color:'var(--text3)', fontSize:12, marginBottom:16 }}>Choose your AI — Claude, GPT, Gemini, GitHub Copilot, or Ollama (free/local).</p>
            <SettingsPanel onConfigured={()=>api.getAIStatus().then(setAiStatus)}/>
          </div>
        )}

      </div>
    </div>
  );
}
