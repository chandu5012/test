const BASE = 'http://localhost:8000';
const req = async (path, opts = {}) => {
  const r = await fetch(`${BASE}${path}`, { headers: {'Content-Type':'application/json'}, ...opts });
  if (!r.ok) throw new Error(`${r.status}: ${await r.text()}`);
  return r.json();
};
export const api = {
  health: () => req('/health'),
  stats: () => req('/lineage/stats'),
  fields: (sys) => req(`/lineage/fields${sys?`?system=${sys}`:''}`),
  field: (id) => req(`/lineage/field/${encodeURIComponent(id)}`),
  graph: () => req('/lineage/graph'),
  lineage: (id,hops=3,dir='both',inc=true) => req(`/lineage/path/${encodeURIComponent(id)}?hops=${hops}&direction=${dir}&include_inferred=${inc}`),
  impact: (id) => req(`/impact/${encodeURIComponent(id)}`),
  audit: (id) => req(`/audit/${encodeURIComponent(id)}`),
  search: (q,k=8,sf) => req('/search/',{method:'POST',body:JSON.stringify({query:q,top_k:k,system_filter:sf})}),
  aliases: () => req('/search/aliases'),
  ingest: (p) => req('/lineage/ingest',{method:'POST',body:JSON.stringify(p)}),
  inferLineage: (src,tgt) => req(`/audit/infer?source_system=${src}&target_system=${tgt}`,{method:'POST'}),
  // AI provider
  getProviders: () => req('/settings/providers'),
  getAIStatus: () => req('/settings/ai-provider'),
  configureAI: (cfg) => req('/settings/ai-provider',{method:'POST',body:JSON.stringify(cfg)}),
  // Chat
  chat: (message,history,fieldId) => req('/chat/',{method:'POST',body:JSON.stringify({message,history,field_id:fieldId||null})}),
  // Export
  auditPdfUrl: (id) => `${BASE}/export/audit/${encodeURIComponent(id)}/pdf`,
  exportFieldsCsv: () => `${BASE}/export/fields/csv`,
  // DB Crawler
  crawlDb: (p) => req('/crawler/connect',{method:'POST',body:JSON.stringify(p)}),
};

// Field enrichment
export const enrichField = (id) => fetch(`http://localhost:8000/lineage/field/${encodeURIComponent(id)}/enrich`, {method:'POST'}).then(r=>r.json());
export const enrichAll = (sys) => fetch(`http://localhost:8000/lineage/enrich-all${sys?`?system=${sys}`:''}`, {method:'POST'}).then(r=>r.json());
