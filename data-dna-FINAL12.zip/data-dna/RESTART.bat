@echo off
title Data-DNA Restart
echo ============================================
echo   Data-DNA v9 - Clean Restart
echo ============================================
echo.

set BACKEND=%~dp0backend
set FRONTEND=%~dp0frontend

echo [Step 1] Killing old servers on ports 8000 and 3000...
for /f "tokens=5" %%a in ('netstat -aon 2^>nul ^| find ":8000 "') do (
    taskkill /F /PID %%a >nul 2>&1
)
for /f "tokens=5" %%a in ('netstat -aon 2^>nul ^| find ":3000 "') do (
    taskkill /F /PID %%a >nul 2>&1
)
for /f "tokens=5" %%a in ('netstat -aon 2^>nul ^| find ":5173 "') do (
    taskkill /F /PID %%a >nul 2>&1
)
timeout /t 2 /nobreak >nul
echo Done.
echo.

echo [Step 2] Clearing Vite cache...
if exist "%FRONTEND%\node_modules\.vite" (
    rd /s /q "%FRONTEND%\node_modules\.vite" >nul 2>&1
)
if exist "%FRONTEND%\.vite_cache" (
    rd /s /q "%FRONTEND%\.vite_cache" >nul 2>&1
)
echo Done.
echo.

echo [Step 3] Setting up database...
cd /d "%BACKEND%"
python setup_db.py
echo.

echo [Step 4] Checking Python environment...
if not exist "%BACKEND%\venv\Scripts\activate.bat" (
    echo Creating virtual environment...
    python -m venv venv
    call venv\Scripts\activate.bat
    echo Installing Python packages (first time, takes 2-3 mins)...
    pip install -r requirements.txt -q
    echo Done.
) else (
    call venv\Scripts\activate.bat
    echo Using existing venv.
)
echo.

echo [Step 5] Checking Node packages...
if not exist "%FRONTEND%\node_modules\vite" (
    echo node_modules not found - running npm install (takes 1-2 mins)...
    cd /d "%FRONTEND%"
    npm install
    echo Done.
) else (
    echo node_modules already installed.
)
echo.

echo [Step 6] Starting backend server...
start "DataDNA-Backend" cmd /k "title DataDNA-Backend && cd /d "%BACKEND%" && call venv\Scripts\activate.bat && uvicorn app.main:app --reload --port 8000"
echo Waiting for backend to start...
timeout /t 6 /nobreak >nul
echo.

echo [Step 7] Starting frontend server...
start "DataDNA-Frontend" cmd /k "title DataDNA-Frontend && cd /d "%FRONTEND%" && npm run dev"
echo Waiting for frontend to compile...
timeout /t 10 /nobreak >nul
echo.

echo [Step 8] Opening browser...
start http://localhost:3000
echo.
echo ============================================
echo   DONE!
echo   Backend:  http://localhost:8000
echo   Frontend: http://localhost:3000
echo   
echo   If browser shows old data, press Ctrl+Shift+R
echo ============================================
pause
