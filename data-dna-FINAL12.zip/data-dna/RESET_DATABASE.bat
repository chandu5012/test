@echo off
echo ============================================
echo   Data-DNA — Reset Database
echo ============================================
echo.
echo This will delete the existing database and
echo reload 755 fields from scratch.
echo.
set /p CONFIRM=Are you sure? (yes/no): 
if /i not "%CONFIRM%"=="yes" (
    echo Cancelled.
    pause
    exit /b 0
)

REM Delete the fixed DB location
set DB_FILE=%LOCALAPPDATA%\DataDNA\data_dna.json
if exist "%DB_FILE%" (
    del "%DB_FILE%"
    echo Deleted: %DB_FILE%
) else (
    echo No database found at: %DB_FILE%
)

REM Also delete any local data_dna.json in backend folder
set LOCAL_DB=%~dp0backend\data_dna.json
if exist "%LOCAL_DB%" (
    del "%LOCAL_DB%"
    echo Deleted: %LOCAL_DB%
)

echo.
echo Database reset complete.
echo Run START.bat to restart with fresh 755 fields.
pause
