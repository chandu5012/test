"""
Lineage Graph Store — NetworkX-backed directed graph with domain methods.

Production swap: replace NetworkX with Neo4j by reimplementing this class.
All graph algorithms (BFS, impact analysis, audit chain) live here.
"""
import hashlib
from collections import defaultdict
from datetime import datetime

import networkx as nx

from core.models import (
    EdgeType, FieldNode, GraphMetrics, ImpactAnalysis,
    LineageEdge, LineagePath, SourceType
)


class LineageGraph:
    """
    Central lineage graph. Wraps a NetworkX DiGraph.

    Nodes represent FieldNode instances.
    Directed edges represent LineageEdge (source → target = data flows from source to target).
    """

    def __init__(self):
        self._graph = nx.DiGraph()
        self._fields: dict[str, FieldNode] = {}
        self._edges: dict[str, LineageEdge] = {}

    # ── Ingestion ──────────────────────────────────────────────────────────

    def add_field(self, node: FieldNode) -> None:
        """Add or update a field node."""
        self._fields[node.id] = node
        self._graph.add_node(node.id, **{
            "system": node.system,
            "table": node.table,
            "field": node.field,
            "data_type": node.data_type,
            "tags": node.tags,
        })

    def add_edge(self, edge: LineageEdge) -> bool:
        """
        Add a lineage edge. Returns False if an AUTHORITATIVE edge already
        exists for this pair (prevents AI inference from overwriting truth).
        """
        src, tgt = edge.source_field_id, edge.target_field_id

        # Auto-create stub nodes if not present
        for fid in [src, tgt]:
            if fid not in self._fields:
                parts = fid.split(".")
                if len(parts) >= 3:
                    self.add_field(FieldNode(
                        id=fid, system=parts[0], table=parts[1], field=parts[2],
                        data_type="unknown"
                    ))

        # Conflict guard: authoritative wins
        if self._graph.has_edge(src, tgt):
            existing_edge_id = self._graph[src][tgt].get("edge_id")
            if existing_edge_id:
                existing = self._edges.get(existing_edge_id)
                if existing and existing.source_type == SourceType.AUTHORITATIVE:
                    return False  # Don't overwrite with inferred

        self._edges[edge.id] = edge
        self._graph.add_edge(src, tgt, edge_id=edge.id, **{
            "edge_type": edge.edge_type.value,
            "source_type": edge.source_type.value,
            "confidence": edge.confidence,
        })
        return True

    def bulk_ingest(self, nodes: list[FieldNode], edges: list[LineageEdge]) -> dict:
        """Ingest a batch of nodes and edges, return summary stats."""
        added_nodes = 0
        added_edges = 0
        skipped_edges = 0

        for node in nodes:
            if node.id not in self._fields:
                self.add_field(node)
                added_nodes += 1

        for edge in edges:
            if self.add_edge(edge):
                added_edges += 1
            else:
                skipped_edges += 1

        return {
            "added_nodes": added_nodes,
            "added_edges": added_edges,
            "skipped_edges": skipped_edges,
        }

    # ── Query ──────────────────────────────────────────────────────────────

    def get_lineage(
        self,
        field_id: str,
        direction: str = "both",
        max_hops: int = 5
    ) -> LineagePath | None:
        """
        Traverse lineage graph from a field, up to max_hops.
        direction: "upstream" | "downstream" | "both"
        """
        if field_id not in self._graph:
            return None

        collected_edges: list[LineageEdge] = []
        collected_node_ids: set[str] = {field_id}

        if direction in ("downstream", "both"):
            try:
                descendants = nx.bfs_edges(self._graph, field_id, depth_limit=max_hops)
                for src, tgt in descendants:
                    edge_id = self._graph[src][tgt].get("edge_id")
                    if edge_id and edge_id in self._edges:
                        collected_edges.append(self._edges[edge_id])
                    collected_node_ids.update([src, tgt])
            except Exception:
                pass

        if direction in ("upstream", "both"):
            try:
                reversed_g = self._graph.reverse()
                ancestors = nx.bfs_edges(reversed_g, field_id, depth_limit=max_hops)
                for src, tgt in ancestors:
                    # In reversed graph, src is actually downstream of tgt
                    edge_id = self._graph[tgt][src].get("edge_id")
                    if edge_id and edge_id in self._edges:
                        collected_edges.append(self._edges[edge_id])
                    collected_node_ids.update([src, tgt])
            except Exception:
                pass

        # Deduplicate edges
        seen_ids = set()
        unique_edges = []
        for e in collected_edges:
            if e.id not in seen_ids:
                unique_edges.append(e)
                seen_ids.add(e.id)

        nodes = [self._fields[nid] for nid in collected_node_ids if nid in self._fields]
        systems = list({n.system for n in nodes})
        has_inferred = any(e.source_type == SourceType.INFERRED for e in unique_edges)
        confidence = LineagePath.compute_confidence(unique_edges)

        return LineagePath(
            field_id=field_id,
            hops=unique_edges,
            nodes=nodes,
            total_confidence=confidence,
            crosses_systems=systems,
            has_inferred_hops=has_inferred,
            direction=direction,
        )

    def get_impact(self, field_id: str) -> ImpactAnalysis | None:
        """Downstream impact analysis — what breaks if this field changes?"""
        if field_id not in self._graph:
            return None

        try:
            downstream_ids = list(nx.descendants(self._graph, field_id))
        except Exception:
            downstream_ids = []

        downstream_fields = [self._fields[fid] for fid in downstream_ids if fid in self._fields]
        downstream_edges = []
        for src, tgt, data in self._graph.edges(data=True):
            if src in downstream_ids or src == field_id:
                edge_id = data.get("edge_id")
                if edge_id and edge_id in self._edges:
                    downstream_edges.append(self._edges[edge_id])

        systems = {f.system for f in downstream_fields}
        has_inferred = any(e.source_type == SourceType.INFERRED for e in downstream_edges)

        # Risk heuristic
        if len(downstream_fields) > 10 or len(systems) > 2:
            risk = "HIGH"
        elif len(downstream_fields) > 4 or len(systems) > 1:
            risk = "MEDIUM"
        else:
            risk = "LOW"

        return ImpactAnalysis(
            field_id=field_id,
            downstream_fields=downstream_fields,
            downstream_edges=downstream_edges,
            system_count=len(systems),
            has_inferred_paths=has_inferred,
            risk_level=risk,
        )

    def get_audit_chain(self, field_id: str) -> list[dict]:
        """Full authoritative-only provenance for compliance/audit."""
        if field_id not in self._graph:
            return []

        chain = []
        reversed_g = self._graph.reverse()
        try:
            for src, tgt in nx.bfs_edges(reversed_g, field_id):
                edge_id = self._graph[tgt][src].get("edge_id")
                if edge_id and edge_id in self._edges:
                    e = self._edges[edge_id]
                    if e.source_type == SourceType.AUTHORITATIVE:
                        chain.append({
                            "from": tgt,
                            "to": src,
                            "type": e.edge_type.value,
                            "reason": e.reason,
                            "sql": e.transformation_sql,
                            "discovered_at": e.discovered_at.isoformat(),
                        })
        except Exception:
            pass

        return chain

    def search_fields(self, query: str, limit: int = 20) -> list[FieldNode]:
        """Simple text search on field names and descriptions."""
        q = query.lower()
        results = []
        for node in self._fields.values():
            score = 0
            if q in node.field.lower():
                score += 2
            if node.description and q in node.description.lower():
                score += 1
            if any(q in tag.lower() for tag in node.tags):
                score += 1
            if score > 0:
                results.append((score, node))
        results.sort(key=lambda x: x[0], reverse=True)
        return [r[1] for r in results[:limit]]

    def get_all_fields(self) -> list[FieldNode]:
        return list(self._fields.values())

    def get_field(self, field_id: str) -> FieldNode | None:
        return self._fields.get(field_id)

    def get_metrics(self) -> GraphMetrics:
        total = len(self._fields)
        edges = list(self._edges.values())
        auth = sum(1 for e in edges if e.source_type == SourceType.AUTHORITATIVE)
        inferred = sum(1 for e in edges if e.source_type == SourceType.INFERRED)
        systems = list({n.system for n in self._fields.values()})
        avg_conf = sum(e.confidence for e in edges) / len(edges) if edges else 0.0
        cross = sum(1 for e in edges if e.system_boundary)

        fields_with_edges = set()
        for e in edges:
            fields_with_edges.add(e.source_field_id)
            fields_with_edges.add(e.target_field_id)
        coverage = len(fields_with_edges) / total if total else 0.0
        orphans = total - len(fields_with_edges)

        return GraphMetrics(
            total_fields=total,
            total_edges=len(edges),
            authoritative_edges=auth,
            inferred_edges=inferred,
            systems=systems,
            avg_confidence=round(avg_conf, 4),
            lineage_coverage_pct=round(coverage * 100, 1),
            cross_system_edges=cross,
            orphan_fields=orphans,
        )
