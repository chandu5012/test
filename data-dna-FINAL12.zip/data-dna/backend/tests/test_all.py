"""
Data-DNA Test Suite
Tests cover: models, SQL parser, graph operations, AI discovery, API endpoints.
Run: pytest tests/ -v
"""
import hashlib
import sys
import os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

import pytest
from datetime import datetime

from core.models import (
    EdgeType, FieldNode, LineageEdge, LineagePath, SourceType
)
from core.sql_parser import SQLParser
from core.schema_crawler import MockCreditAdapter, MockRiskEngineAdapter, SchemaIngester
from graph.lineage_graph import LineageGraph
from ai.discovery import SemanticSearchEngine, SemanticResolver, LineageInferencer


# ── Fixtures ───────────────────────────────────────────────────────────────

@pytest.fixture
def sample_field():
    return FieldNode(
        id="credit_core.accounts.balance",
        system="credit_core",
        table="accounts",
        field="balance",
        data_type="DECIMAL(10,2)",
        description="Outstanding account balance",
        tags=["financial", "PII"],
    )


@pytest.fixture
def sample_edge():
    return LineageEdge(
        id="edge001",
        source_field_id="credit_core.accounts.balance",
        target_field_id="credit_core.scores.payment_component",
        edge_type=EdgeType.TRANSFORM,
        source_type=SourceType.AUTHORITATIVE,
        confidence=1.0,
        reason="Computed from balance in ETL",
    )


@pytest.fixture
def populated_graph():
    g = LineageGraph()
    nodes = [
        FieldNode(id="sys.a.f1", system="sys", table="a", field="f1", data_type="INT"),
        FieldNode(id="sys.a.f2", system="sys", table="a", field="f2", data_type="INT"),
        FieldNode(id="sys.b.f3", system="sys", table="b", field="f3", data_type="INT"),
        FieldNode(id="sys.b.f4", system="sys", table="b", field="f4", data_type="INT"),
        FieldNode(id="sys2.c.f5", system="sys2", table="c", field="f5", data_type="INT"),
    ]
    edges = [
        LineageEdge(id="e1", source_field_id="sys.a.f1", target_field_id="sys.a.f2",
                    edge_type=EdgeType.COPY, source_type=SourceType.AUTHORITATIVE,
                    confidence=1.0, reason="direct copy"),
        LineageEdge(id="e2", source_field_id="sys.a.f2", target_field_id="sys.b.f3",
                    edge_type=EdgeType.TRANSFORM, source_type=SourceType.AUTHORITATIVE,
                    confidence=1.0, reason="transform"),
        LineageEdge(id="e3", source_field_id="sys.b.f3", target_field_id="sys.b.f4",
                    edge_type=EdgeType.AGGREGATE, source_type=SourceType.AUTHORITATIVE,
                    confidence=1.0, reason="aggregation"),
        LineageEdge(id="e4", source_field_id="sys.b.f4", target_field_id="sys2.c.f5",
                    edge_type=EdgeType.COPY, source_type=SourceType.INFERRED,
                    confidence=0.82, reason="AI inferred", system_boundary=True),
    ]
    for n in nodes:
        g.add_field(n)
    for e in edges:
        g.add_edge(e)
    return g


# ── Model Tests ────────────────────────────────────────────────────────────

class TestModels:
    def test_field_node_id_generation(self):
        fid = FieldNode.make_id("system", "table", "field")
        assert fid == "system.table.field"

    def test_field_node_display_name(self, sample_field):
        assert "accounts.balance" in sample_field.display_name()
        assert "credit_core" in sample_field.display_name()

    def test_lineage_path_confidence_single(self):
        edge = LineageEdge(
            id="x", source_field_id="a", target_field_id="b",
            edge_type=EdgeType.COPY, source_type=SourceType.AUTHORITATIVE,
            confidence=0.9, reason="test"
        )
        conf = LineagePath.compute_confidence([edge])
        assert conf == 0.9

    def test_lineage_path_confidence_multi_hop(self):
        edges = [
            LineageEdge(id=str(i), source_field_id="a", target_field_id="b",
                        edge_type=EdgeType.COPY, source_type=SourceType.AUTHORITATIVE,
                        confidence=c, reason="test")
            for i, c in enumerate([0.9, 0.9, 0.8])
        ]
        conf = LineagePath.compute_confidence(edges)
        expected = round(0.9 * 0.9 * 0.8, 4)
        assert conf == expected

    def test_confidence_empty_path(self):
        assert LineagePath.compute_confidence([]) == 1.0

    def test_edge_types_are_valid(self):
        for et in EdgeType:
            assert et.value  # each has a string value

    def test_source_types(self):
        assert SourceType.AUTHORITATIVE != SourceType.INFERRED


# ── SQL Parser Tests ───────────────────────────────────────────────────────

class TestSQLParser:
    def setup_method(self):
        self.parser = SQLParser("test_system")

    def test_parse_insert_select(self):
        sql = "INSERT INTO target (col1) SELECT col1 FROM source"
        nodes, edges = self.parser.parse_sql(sql)
        assert len(edges) >= 0  # At minimum no crash

    def test_parser_returns_authoritative_edges(self):
        sql = "INSERT INTO b (score) SELECT balance FROM a"
        nodes, edges = self.parser.parse_sql(sql)
        for e in edges:
            assert e.source_type == SourceType.AUTHORITATIVE
            assert e.confidence == 1.0

    def test_parser_no_crash_on_invalid_sql(self):
        nodes, edges = self.parser.parse_sql("THIS IS NOT SQL AT ALL!!!")
        assert isinstance(nodes, list)
        assert isinstance(edges, list)

    def test_parser_empty_string(self):
        nodes, edges = self.parser.parse_sql("")
        assert nodes == []
        assert edges == []


# ── Schema Crawler Tests ───────────────────────────────────────────────────

class TestSchemaCrawler:
    def test_mock_credit_adapter_tables(self):
        adapter = MockCreditAdapter()
        tables = adapter.get_tables()
        assert len(tables) >= 5
        names = [t.name for t in tables]
        assert "customer_profile" in names
        assert "credit_score" in names

    def test_mock_credit_adapter_fields(self):
        adapter = MockCreditAdapter()
        fields = adapter.get_fields("customer_profile")
        assert len(fields) >= 4
        field_names = [f.field for f in fields]
        assert "customer_id" in field_names
        assert "annual_income" in field_names

    def test_mock_credit_adapter_foreign_keys(self):
        adapter = MockCreditAdapter()
        fks = adapter.get_foreign_keys()
        assert len(fks) >= 3

    def test_schema_ingester_produces_nodes_and_edges(self):
        ingester = SchemaIngester()
        nodes, edges = ingester.ingest([MockCreditAdapter()])
        assert len(nodes) > 0
        assert len(edges) > 0

    def test_schema_ingester_multi_adapter(self):
        ingester = SchemaIngester()
        nodes, edges = ingester.ingest([MockCreditAdapter(), MockRiskEngineAdapter()])
        systems = {n.system for n in nodes}
        assert "credit_core" in systems
        assert "risk_engine" in systems

    def test_all_nodes_have_required_fields(self):
        ingester = SchemaIngester()
        nodes, _ = ingester.ingest([MockCreditAdapter()])
        for node in nodes:
            assert node.id
            assert node.system
            assert node.table
            assert node.field
            assert node.data_type


# ── Lineage Graph Tests ────────────────────────────────────────────────────

class TestLineageGraph:
    def test_add_field(self, sample_field):
        g = LineageGraph()
        g.add_field(sample_field)
        assert g.get_field(sample_field.id) is not None

    def test_add_edge(self, sample_field, sample_edge):
        g = LineageGraph()
        g.add_field(sample_field)
        target = FieldNode(id="credit_core.scores.payment_component",
                           system="credit_core", table="scores",
                           field="payment_component", data_type="DECIMAL")
        g.add_field(target)
        result = g.add_edge(sample_edge)
        assert result is True

    def test_authoritative_prevents_inferred_overwrite(self, populated_graph):
        g = populated_graph
        # Try to overwrite e1 (AUTHORITATIVE) with inferred
        inferred_edge = LineageEdge(
            id="inferred_overwrite",
            source_field_id="sys.a.f1",
            target_field_id="sys.a.f2",
            edge_type=EdgeType.COPY,
            source_type=SourceType.INFERRED,
            confidence=0.9,
            reason="AI guess",
        )
        result = g.add_edge(inferred_edge)
        assert result is False  # Should be blocked

    def test_get_lineage_downstream(self, populated_graph):
        path = populated_graph.get_lineage("sys.a.f1", direction="downstream")
        assert path is not None
        assert len(path.nodes) >= 2
        assert len(path.hops) >= 1

    def test_get_lineage_upstream(self, populated_graph):
        path = populated_graph.get_lineage("sys.b.f4", direction="upstream")
        assert path is not None

    def test_get_lineage_nonexistent_field(self):
        g = LineageGraph()
        result = g.get_lineage("does.not.exist")
        assert result is None

    def test_get_impact_returns_downstream(self, populated_graph):
        impact = populated_graph.get_impact("sys.a.f1")
        assert impact is not None
        downstream_ids = [f.id for f in impact.downstream_fields]
        assert "sys.a.f2" in downstream_ids

    def test_impact_risk_levels(self, populated_graph):
        impact = populated_graph.get_impact("sys.a.f1")
        assert impact.risk_level in ("LOW", "MEDIUM", "HIGH")

    def test_get_audit_chain_authoritative_only(self, populated_graph):
        chain = populated_graph.get_audit_chain("sys2.c.f5")
        # Should not include the inferred edge e4
        for item in chain:
            assert "AI inferred" not in item.get("reason", "")

    def test_bulk_ingest_stats(self, populated_graph):
        g = LineageGraph()
        nodes = [FieldNode(id=f"s.t.f{i}", system="s", table="t",
                           field=f"f{i}", data_type="INT") for i in range(5)]
        edges = [LineageEdge(id=f"e{i}", source_field_id=f"s.t.f{i}",
                             target_field_id=f"s.t.f{i+1}",
                             edge_type=EdgeType.COPY, source_type=SourceType.AUTHORITATIVE,
                             confidence=1.0, reason="test")
                 for i in range(4)]
        result = g.bulk_ingest(nodes, edges)
        assert result["added_nodes"] == 5
        assert result["added_edges"] == 4

    def test_metrics(self, populated_graph):
        m = populated_graph.get_metrics()
        assert m.total_fields == 5
        assert m.total_edges == 4
        assert m.authoritative_edges == 3
        assert m.inferred_edges == 1
        assert m.lineage_coverage_pct == 100.0

    def test_text_search(self, populated_graph):
        results = populated_graph.search_fields("f1")
        assert len(results) >= 1

    def test_has_inferred_detection(self, populated_graph):
        path = populated_graph.get_lineage("sys.a.f1", direction="downstream")
        assert path.has_inferred_hops is True


# ── AI Discovery Tests ─────────────────────────────────────────────────────

class TestSemanticSearch:
    def setup_method(self):
        self.engine = SemanticSearchEngine()
        self.fields = [
            FieldNode(id="s.t.customer_id", system="s", table="t",
                      field="customer_id", data_type="VARCHAR",
                      description="Unique customer identifier", tags=["key", "PII"]),
            FieldNode(id="s.t.credit_score", system="s", table="t",
                      field="credit_score", data_type="INTEGER",
                      description="FICO credit score", tags=["financial"]),
            FieldNode(id="s.t.annual_income", system="s", table="t",
                      field="annual_income", data_type="DECIMAL",
                      description="Yearly income", tags=["financial"]),
        ]
        self.engine.index_fields(self.fields)

    def test_keyword_search_finds_match(self):
        results = self.engine.search("credit score")
        assert len(results) >= 1

    def test_search_returns_search_results(self):
        results = self.engine.search("income")
        for r in results:
            assert hasattr(r, "field")
            assert hasattr(r, "similarity_score")
            assert hasattr(r, "match_reason")

    def test_search_empty_index(self):
        engine = SemanticSearchEngine()
        results = engine.search("anything")
        assert results == []


class TestSemanticResolver:
    def test_finds_cross_system_aliases(self):
        engine = SemanticSearchEngine()
        fields = [
            FieldNode(id="sys1.t.customer_id", system="sys1", table="t",
                      field="customer_id", data_type="VARCHAR",
                      description="Customer identifier", tags=["key"]),
            FieldNode(id="sys2.t.cust_id", system="sys2", table="t",
                      field="cust_id", data_type="VARCHAR",
                      description="Customer identifier in risk system", tags=["key"]),
        ]
        engine.index_fields(fields)
        resolver = SemanticResolver(engine)
        edges = resolver.resolve_aliases(fields)
        # Should find that customer_id ≈ cust_id
        assert isinstance(edges, list)


class TestLineageInferencer:
    def setup_method(self):
        self.inferencer = LineageInferencer()

    def test_heuristic_inference_same_name(self):
        src = FieldNode(id="a.t.score_value", system="a", table="t",
                        field="score_value", data_type="INTEGER",
                        description="Credit score", tags=["financial"])
        tgt = FieldNode(id="b.t.fico_score", system="b", table="t",
                        field="fico_score", data_type="INTEGER",
                        description="Credit score snapshot", tags=["financial"])
        result = self.inferencer.infer_relationship(src, tgt)
        assert hasattr(result, "related")
        assert 0.0 <= result.confidence <= 1.0
        assert result.reason

    def test_inference_unrelated_fields(self):
        src = FieldNode(id="a.t.created_at", system="a", table="t",
                        field="created_at", data_type="TIMESTAMP",
                        tags=[])
        tgt = FieldNode(id="b.t.risk_grade", system="b", table="t",
                        field="risk_grade", data_type="CHAR",
                        tags=["risk"])
        result = self.inferencer.infer_relationship(src, tgt)
        # Unrelated fields should have low confidence
        assert result.confidence < 0.8

    def test_bulk_infer_returns_edges(self):
        pairs = []
        for i in range(3):
            src = FieldNode(id=f"a.t.field{i}", system="a", table="t",
                            field=f"field{i}", data_type="INT", tags=["financial"])
            tgt = FieldNode(id=f"b.t.field{i}", system="b", table="t",
                            field=f"field{i}", data_type="INT", tags=["financial"])
            pairs.append((src, tgt))

        edges = self.inferencer.bulk_infer(pairs)
        assert isinstance(edges, list)
        for e in edges:
            assert e.source_type == SourceType.INFERRED
            assert e.system_boundary is True


# ── Integration Tests ──────────────────────────────────────────────────────

class TestEndToEndPipeline:
    def test_full_ingestion_pipeline(self):
        """Full pipeline: crawl → parse SQL → graph → query."""
        g = LineageGraph()
        ingester = SchemaIngester()
        nodes, edges = ingester.ingest([MockCreditAdapter()])
        result = g.bulk_ingest(nodes, edges)
        assert result["added_nodes"] > 0
        assert result["added_edges"] > 0

        # Verify we can query lineage
        all_fields = g.get_all_fields()
        assert len(all_fields) > 0

        # Add a SQL-derived edge
        parser = SQLParser("credit_core")
        sql_nodes, sql_edges = parser.parse_sql(
            "INSERT INTO credit_score (payment_component) "
            "SELECT days_late FROM payment_history"
        )
        g.bulk_ingest(sql_nodes, sql_edges)

        metrics = g.get_metrics()
        assert metrics.total_fields > 0
        assert metrics.lineage_coverage_pct >= 0

    def test_search_after_ingestion(self):
        """Search engine finds fields after ingestion."""
        engine = SemanticSearchEngine()
        ingester = SchemaIngester()
        nodes, _ = ingester.ingest([MockCreditAdapter()])
        engine.index_fields(nodes)

        results = engine.search("credit score")
        assert len(results) >= 0  # May or may not find depending on embeddings

    def test_impact_analysis_cross_system(self):
        """Impact analysis crosses system boundaries via cross-system edges."""
        g = LineageGraph()
        n1 = FieldNode(id="sys1.t.source", system="sys1", table="t",
                       field="source", data_type="INT")
        n2 = FieldNode(id="sys2.t.target", system="sys2", table="t",
                       field="target", data_type="INT")
        g.add_field(n1)
        g.add_field(n2)
        e = LineageEdge(
            id="cross1", source_field_id="sys1.t.source",
            target_field_id="sys2.t.target", edge_type=EdgeType.COPY,
            source_type=SourceType.AUTHORITATIVE, confidence=1.0,
            reason="ETL", system_boundary=True
        )
        g.add_edge(e)

        impact = g.get_impact("sys1.t.source")
        assert impact is not None
        assert len(impact.downstream_fields) == 1
        assert impact.system_count == 1  # sys2 is downstream
