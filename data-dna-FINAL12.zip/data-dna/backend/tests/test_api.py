"""
Integration tests for all FastAPI endpoints.
Uses TestClient with demo data seeded via fixture.
"""
import pytest
from fastapi.testclient import TestClient
from app.main import app
from app.services.ingestion import ingestion_service
from app.core.graph import graph
from app.ai.nl_search import search_engine


@pytest.fixture(autouse=True, scope="module")
def seed_data():
    """Seed demo data once for all API tests."""
    ingestion_service.seed_demo_data()
    yield


client = TestClient(app)


class TestHealthEndpoints:
    def test_root(self):
        r = client.get("/")
        assert r.status_code == 200
        assert "Data-DNA" in r.json()["name"]

    def test_health(self):
        r = client.get("/health")
        assert r.status_code == 200
        data = r.json()
        assert data["status"] == "ok"
        assert "graph" in data


class TestLineageEndpoints:
    def test_get_stats(self):
        r = client.get("/lineage/stats")
        assert r.status_code == 200
        data = r.json()
        assert "total_fields" in data
        assert data["total_fields"] > 0

    def test_list_fields(self):
        r = client.get("/lineage/fields")
        assert r.status_code == 200
        fields = r.json()
        assert len(fields) > 0

    def test_list_fields_by_system(self):
        r = client.get("/lineage/fields?system=CBS")
        assert r.status_code == 200
        fields = r.json()
        assert all(f["system"] == "CBS" for f in fields)

    def test_get_field(self):
        r = client.get("/lineage/field/CBS.CBS_CUSTOMER.CUST_ID")
        assert r.status_code == 200
        data = r.json()
        assert data["column"] == "CUST_ID"
        assert data["system"] == "CBS"

    def test_get_field_not_found(self):
        r = client.get("/lineage/field/NO.SUCH.FIELD")
        assert r.status_code == 404

    def test_get_lineage_path(self):
        r = client.get("/lineage/path/CBS.CBS_CUSTOMER.CUST_ID?direction=downstream&hops=3")
        assert r.status_code == 200
        data = r.json()
        assert "nodes" in data
        assert "edges" in data
        assert "hops" in data

    def test_get_lineage_upstream(self):
        r = client.get("/lineage/path/MIS.MIS_CUSTOMER_SCORECARD.CUST_ID?direction=upstream")
        assert r.status_code == 200

    def test_get_full_graph(self):
        r = client.get("/lineage/graph")
        assert r.status_code == 200
        data = r.json()
        assert "nodes" in data
        assert "links" in data
        assert len(data["nodes"]) > 0

    def test_ingest_sql(self):
        payload = {
            "system_name": "TEST_INGEST",
            "sql": "CREATE TABLE TEST_TBL (ID VARCHAR(10), AMT DECIMAL(10,2))"
        }
        r = client.post("/lineage/ingest", json=payload)
        assert r.status_code == 200
        data = r.json()
        assert data["nodes_created"] == 2

    def test_ingest_schema_json(self):
        payload = {
            "system_name": "JSON_SYS",
            "schema_json": {
                "tables": {
                    "ACCOUNTS": {
                        "columns": {
                            "ACCT_ID": {"type": "VARCHAR"},
                            "BALANCE": {"type": "DECIMAL"},
                        }
                    }
                }
            }
        }
        r = client.post("/lineage/ingest", json=payload)
        assert r.status_code == 200
        assert r.json()["nodes_created"] == 2


class TestSearchEndpoints:
    def test_search_by_field_name(self):
        r = client.post("/search/", json={"query": "customer id", "top_k": 5})
        assert r.status_code == 200
        data = r.json()
        assert "results" in data
        assert data["query"] == "customer id"

    def test_search_returns_scored_results(self):
        r = client.post("/search/", json={"query": "credit limit", "top_k": 5})
        assert r.status_code == 200
        results = r.json()["results"]
        if results:
            assert all("score" in res for res in results)
            assert all("match_reason" in res for res in results)

    def test_search_with_system_filter(self):
        r = client.post("/search/", json={
            "query": "account balance",
            "top_k": 5,
            "system_filter": "CREDIT_CORE"
        })
        assert r.status_code == 200
        results = r.json()["results"]
        assert all(res["system"] == "CREDIT_CORE" for res in results)

    def test_aliases_endpoint(self):
        r = client.get("/search/aliases")
        assert r.status_code == 200
        assert isinstance(r.json(), list)


class TestImpactEndpoints:
    def test_impact_analysis(self):
        r = client.get("/impact/CBS.CBS_CUSTOMER.CUST_ID")
        assert r.status_code == 200
        data = r.json()
        assert "affected_fields" in data
        assert "risk_level" in data
        assert data["risk_level"] in ("low", "medium", "high")

    def test_impact_not_found(self):
        r = client.get("/impact/NO.SUCH.FIELD")
        assert r.status_code == 404


class TestAuditEndpoints:
    def test_audit_trail(self):
        r = client.get("/audit/MIS.MIS_CUSTOMER_SCORECARD.CUST_ID")
        assert r.status_code == 200
        data = r.json()
        assert "field_id" in data
        assert "completeness_score" in data
        assert "conflicts" in data
        assert 0.0 <= data["completeness_score"] <= 1.0

    def test_audit_not_found(self):
        r = client.get("/audit/NO.SUCH.FIELD")
        assert r.status_code == 404
