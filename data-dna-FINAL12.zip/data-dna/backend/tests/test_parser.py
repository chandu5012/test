"""Tests for SQL and Schema parsers."""
import pytest
from app.core.parser import SQLLineageParser, SchemaParser
from app.models.lineage import SourceType


@pytest.fixture
def parser():
    return SQLLineageParser("TEST_SYS")


class TestSQLParser:
    def test_parse_create_table(self, parser):
        sql = """
        CREATE TABLE CUSTOMER (
            CUST_ID VARCHAR(20),
            CUST_NAME VARCHAR(100),
            DOB DATE,
            CREDIT_LIMIT DECIMAL(15,2)
        )
        """
        nodes = parser.parse_create_table(sql)
        cols = {n.column for n in nodes}
        assert "CUST_ID" in cols
        assert "CUST_NAME" in cols
        assert "DOB" in cols
        assert "CREDIT_LIMIT" in cols

    def test_pii_detection(self, parser):
        sql = """
        CREATE TABLE CUSTOMER (
            CUST_ID VARCHAR(20),
            EMAIL VARCHAR(100),
            CREDIT_LIMIT DECIMAL(15,2)
        )
        """
        nodes = parser.parse_create_table(sql)
        node_map = {n.column: n for n in nodes}
        assert node_map["EMAIL"].pii is True
        assert node_map["CUST_ID"].pii is False
        assert node_map["CREDIT_LIMIT"].pii is False

    def test_parse_insert_select(self, parser):
        sql = """
        INSERT INTO TARGET_TABLE (ID, AMOUNT, NAME)
        SELECT SOURCE_ID, TXN_AMT, CUST_NAME FROM SOURCE_TABLE
        """
        nodes, edges = parser.parse_insert_select(sql)
        assert len(edges) == 3
        assert all(e.source_type == SourceType.AUTHORITATIVE for e in edges)
        assert all(e.confidence == 1.0 for e in edges)

    def test_parse_create_view(self, parser):
        sql = """
        CREATE VIEW REPORTING_VIEW AS
        SELECT CUST_ID AS CLIENT_ID, CREDIT_LIMIT AS LIMIT
        FROM ACCOUNT
        """
        nodes, edges = parser.parse_view_or_ctas(sql)
        assert len(edges) >= 1
        assert all(e.source_type == SourceType.AUTHORITATIVE for e in edges)

    def test_parse_multi_statement(self, parser):
        sql = """
        CREATE TABLE A (COL1 VARCHAR(10), COL2 INT);
        CREATE TABLE B (COL3 VARCHAR(10), COL4 INT);
        """
        nodes, edges = parser.parse(sql)
        tables = {n.table for n in nodes}
        assert "A" in tables
        assert "B" in tables

    def test_field_id_format(self, parser):
        sql = "CREATE TABLE MYTABLE (MYCOLUMN VARCHAR(10))"
        nodes = parser.parse_create_table(sql)
        assert nodes[0].id == "TEST_SYS.MYTABLE.MYCOLUMN"

    def test_system_boundary_tracking(self, parser):
        sql = """
        INSERT INTO TARGET (ID) SELECT SRC_ID FROM SOURCE
        """
        nodes, edges = parser.parse_insert_select(sql)
        # All edges within same system — no system boundary
        assert all(e.system_boundary is False for e in edges)


class TestSchemaParser:
    def test_parse_json_schema(self):
        parser = SchemaParser("RISK_SYS")
        schema = {
            "tables": {
                "RISK_SCORE": {
                    "columns": {
                        "CUST_ID": {"type": "VARCHAR", "description": "Customer identifier"},
                        "SCORE": {"type": "INT", "pii": False},
                        "PAN": {"type": "VARCHAR", "pii": True},
                    }
                }
            }
        }
        nodes = parser.parse(schema)
        assert len(nodes) == 3
        node_map = {n.column: n for n in nodes}
        assert node_map["PAN"].pii is True
        assert node_map["SCORE"].pii is False
        assert node_map["CUST_ID"].description == "Customer identifier"

    def test_all_nodes_have_system(self):
        parser = SchemaParser("MY_SYS")
        schema = {"tables": {"TBL": {"columns": {"COL": "VARCHAR"}}}}
        nodes = parser.parse(schema)
        assert all(n.system == "MY_SYS" for n in nodes)
