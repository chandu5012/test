"""Tests for AI modules — search, resolver, discoverer."""
import pytest
from app.ai.nl_search import NLSearchEngine
from app.ai.resolver import SemanticResolver
from app.ai.discoverer import LineageDiscoverer
from app.models.lineage import FieldNode
from app.models.search import SearchRequest


def make_field(system, table, col, desc=None):
    return FieldNode(
        id=f"{system}.{table}.{col}",
        system=system, table=table, column=col, description=desc
    )


class TestNLSearch:
    def test_exact_column_match(self):
        engine = NLSearchEngine()
        f = make_field("SYS", "TBL", "CUSTOMER_ID", desc="Unique customer identifier")
        engine.index_field(f)
        resp = engine.search(SearchRequest(query="customer id", top_k=5))
        assert len(resp.results) > 0
        assert resp.results[0].field_id == f.id

    def test_description_match(self):
        engine = NLSearchEngine()
        f = make_field("SYS", "TBL", "UTIL_PCT", desc="credit utilization percentage ratio")
        engine.index_field(f)
        resp = engine.search(SearchRequest(query="utilization percentage", top_k=5))
        assert len(resp.results) > 0

    def test_system_filter(self):
        engine = NLSearchEngine()
        f1 = make_field("CORE", "T", "AMOUNT")
        f2 = make_field("RISK", "T", "AMOUNT")
        engine.index_field(f1)
        engine.index_field(f2)
        resp = engine.search(SearchRequest(query="amount", top_k=5, system_filter="RISK"))
        assert all(r.system == "RISK" for r in resp.results)

    def test_no_results_for_unknown_term(self):
        engine = NLSearchEngine()
        f = make_field("SYS", "TBL", "CUST_ID")
        engine.index_field(f)
        resp = engine.search(SearchRequest(query="xyzabc123", top_k=5))
        assert len(resp.results) == 0

    def test_ranking_by_relevance(self):
        engine = NLSearchEngine()
        f1 = make_field("SYS", "TBL", "CREDIT_LIMIT", desc="maximum credit limit")
        f2 = make_field("SYS", "TBL", "OUTSTANDING_BAL", desc="current outstanding balance")
        engine.index_field(f1)
        engine.index_field(f2)
        resp = engine.search(SearchRequest(query="credit limit maximum", top_k=5))
        assert resp.results[0].field_id == f1.id

    def test_top_k_respected(self):
        engine = NLSearchEngine()
        for i in range(10):
            engine.index_field(make_field("SYS", "TBL", f"BALANCE_{i}", desc="balance field"))
        resp = engine.search(SearchRequest(query="balance", top_k=3))
        assert len(resp.results) <= 3

    def test_match_reason_populated(self):
        engine = NLSearchEngine()
        f = make_field("SYS", "T", "CUST_ID")
        engine.index_field(f)
        resp = engine.search(SearchRequest(query="customer", top_k=1))
        if resp.results:
            assert resp.results[0].match_reason != ""


class TestSemanticResolver:
    def test_rule_based_alias_detection(self):
        resolver = SemanticResolver()
        # No API key in tests — uses rule-based
        fields = [
            make_field("SYS_A", "T", "CUST_ID"),
            make_field("SYS_B", "T", "CUSTOMER_ID"),
            make_field("SYS_C", "T", "CLIENT_ID"),
        ]
        groups = resolver._resolve_with_rules(fields)
        # Should group cust_id, customer_id, client_id together
        assert len(groups) >= 1
        all_aliases = [a for g in groups for a in g.aliases]
        assert any("CUST_ID" in all_aliases or "CUSTOMER_ID" in all_aliases for _ in [1])

    def test_groups_have_required_fields(self):
        resolver = SemanticResolver()
        fields = [
            make_field("A", "T", "ACCT_ID"),
            make_field("B", "T", "ACCOUNT_ID"),
        ]
        groups = resolver._resolve_with_rules(fields)
        for g in groups:
            assert g.canonical_name
            assert isinstance(g.aliases, list)
            assert isinstance(g.systems, list)
            assert 0.0 <= g.confidence <= 1.0
            assert g.reasoning


class TestLineageDiscoverer:
    def test_rule_based_discovery(self):
        discoverer = LineageDiscoverer()
        src = [make_field("SRC", "T", "CUST_ID"), make_field("SRC", "T", "AMOUNT")]
        tgt = [make_field("TGT", "T", "CUST_ID"), make_field("TGT", "T", "BALANCE")]
        edges = discoverer._discover_with_rules(src, tgt)
        # CUST_ID matches exactly
        assert len(edges) >= 1
        matched = [e for e in edges if "CUST_ID" in e.source_field and "CUST_ID" in e.target_field]
        assert len(matched) == 1

    def test_inferred_edges_tagged_correctly(self):
        from app.models.lineage import SourceType
        discoverer = LineageDiscoverer()
        src = [make_field("A", "T", "X")]
        tgt = [make_field("B", "T", "X")]
        edges = discoverer._discover_with_rules(src, tgt)
        assert all(e.source_type == SourceType.INFERRED for e in edges)

    def test_confidence_range(self):
        discoverer = LineageDiscoverer()
        src = [make_field("A", "T", "SCORE")]
        tgt = [make_field("B", "T", "SCORE")]
        edges = discoverer._discover_with_rules(src, tgt)
        assert all(0.0 <= e.confidence <= 1.0 for e in edges)

    def test_system_boundary_flagged(self):
        discoverer = LineageDiscoverer()
        src = [make_field("SYSTEM_A", "T", "ID")]
        tgt = [make_field("SYSTEM_B", "T", "ID")]
        edges = discoverer._discover_with_rules(src, tgt)
        assert all(e.system_boundary is True for e in edges)

    def test_empty_inputs_return_empty(self):
        discoverer = LineageDiscoverer()
        assert discoverer.discover([], []) == []
        assert discoverer.discover([make_field("A", "T", "C")], []) == []
