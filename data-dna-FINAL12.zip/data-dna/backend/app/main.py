"""Data-DNA — Production FastAPI application."""
import logging
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.api import lineage, search, impact, audit
from app.api import settings as settings_api
from app.api import chat_api, export, crawler
from app.api import mcp_server
from app.services.ingestion import ingestion_service
from app.core.graph import graph
from app.core.persistence import persistence
from app.models.lineage import FieldNode, LineageEdge
from app.ai.nl_search import search_engine

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

REQUIRED_SYSTEMS = {'CBS', 'RISK', 'LOS', 'MIS', 'BUREAU'}
MIN_FIELDS = 500


def restore_from_db():
    nodes = persistence.load_all_nodes()
    edges = persistence.load_all_edges()
    loaded = 0
    for n in nodes:
        try:
            node = FieldNode(**{k: v for k, v in n.items() if k != '_id'})
            graph.add_field(node)
            search_engine.index_field(node)
            loaded += 1
        except Exception:
            pass
    for e in edges:
        try:
            edge = LineageEdge(**{k: v for k, v in e.items() if k != '_id'})
            graph.add_lineage(edge)
        except Exception:
            pass
    return loaded


def ensure_full_dataset():
    current_systems = set(graph.stats().get('systems', []))
    missing = REQUIRED_SYSTEMS - current_systems
    total = graph.stats()['total_fields']

    if missing or total < MIN_FIELDS:
        logger.info(f"⚡ Seeding: missing={missing}, fields={total} < {MIN_FIELDS}")
        ingestion_service.seed_large_data()
        _persist_all()


def _persist_all():
    for node in graph.list_fields():
        persistence.save_node(node.model_dump())
    for edge in graph._edges.values():
        persistence.save_edge(edge.model_dump())


@asynccontextmanager
async def lifespan(app: FastAPI):
    logger.info("🧬 Data-DNA starting...")
    logger.info(f"💾 Database: {persistence.stats()['db_path']}")
    restored = restore_from_db()
    logger.info(f"📦 Restored {restored} records")
    ensure_full_dataset()
    s = graph.stats()
    logger.info(f"🚀 Ready — {s['total_fields']} fields, {s['total_edges']} edges, systems: {s['systems']}")
    yield
    logger.info("Data-DNA shutting down.")


app = FastAPI(title="Data-DNA", version="3.0.0", lifespan=lifespan)

app.add_middleware(CORSMiddleware, allow_origins=["*"],
                   allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

app.include_router(lineage.router)
app.include_router(search.router)
app.include_router(impact.router)
app.include_router(audit.router)
app.include_router(settings_api.router)
app.include_router(chat_api.router)
app.include_router(export.router)
app.include_router(crawler.router)
app.include_router(mcp_server.router)


@app.get("/health")
def health():
    from app.ai.provider import AIConfig
    return {"status": "ok", "version": "3.0.0",
            "graph": graph.stats(), "ai": AIConfig.status()}

@app.get("/")
def root():
    return {"name": "Data-DNA", "version": "3.0.0", "docs": "/docs"}

@app.get("/version")
def version():
    """Quick check — if you see this, new code is running."""
    s = graph.stats()
    return {
        "version": "3.0.0",
        "fields": s["total_fields"],
        "systems": s["systems"],
        "db_path": persistence.stats()["db_path"],
        "message": "NEW CODE IS RUNNING" if s["total_fields"] >= 500 else "OLD DATA - restart needed"
    }
