"""DB Crawler API endpoint."""
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from typing import Optional
from app.core.db_crawler import crawl_database
from app.core.graph import graph
from app.ai.nl_search import search_engine

router = APIRouter(prefix="/crawler", tags=["crawler"])


class CrawlRequest(BaseModel):
    system_name: str
    db_type: str        # sqlite | postgres | mysql | sqlserver
    conn_string: Optional[str] = ""
    db_path: Optional[str] = ""
    database: Optional[str] = ""


@router.post("/connect")
def crawl_db(req: CrawlRequest):
    try:
        nodes = crawl_database(req.db_type, req.system_name,
                                req.conn_string, req.db_path, req.database)
        for n in nodes:
            graph.add_field(n)
            search_engine.index_field(n)
        return {"fields_discovered": len(nodes),
                "system": req.system_name,
                "fields": [n.id for n in nodes[:20]]}
    except Exception as e:
        raise HTTPException(400, detail=str(e))
