"""Export API — PDF audit reports, CSV field catalog."""
from fastapi import APIRouter, HTTPException
from fastapi.responses import Response, StreamingResponse
from app.services.pdf_export import generate_audit_pdf
from app.core.graph import graph
import csv, io

router = APIRouter(prefix="/export", tags=["export"])


@router.get("/audit/{field_id:path}/pdf")
def export_audit_pdf(field_id: str):
    f = graph.get_field(field_id)
    if not f:
        raise HTTPException(404, detail="Field not found")
    pdf_bytes = generate_audit_pdf(field_id)
    filename = field_id.replace(".", "_") + "_audit.pdf"
    return Response(content=pdf_bytes, media_type="application/pdf",
                    headers={"Content-Disposition": f'attachment; filename="{filename}"'})


@router.get("/fields/csv")
def export_fields_csv(system: str = None):
    fields = graph.list_fields(system=system)
    buf = io.StringIO()
    writer = csv.writer(buf)
    writer.writerow(["Field ID","System","Table","Column","Data Type","PII","Tags"])
    for f in fields:
        writer.writerow([f.id, f.system, f.table, f.column,
                         f.data_type or "", f.pii, ",".join(f.tags)])
    return Response(content=buf.getvalue(), media_type="text/csv",
                    headers={"Content-Disposition": "attachment; filename=fields.csv"})


@router.get("/graph/json")
def export_graph_json():
    return graph.export_for_visualization()
