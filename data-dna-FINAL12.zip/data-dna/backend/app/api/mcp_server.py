"""
Data-DNA MCP Server — Full Feature Set
All 20+ tools covering every Data-DNA capability via MCP protocol.
"""
import json
import asyncio
import io
import base64
from fastapi import APIRouter, Request
from fastapi.responses import StreamingResponse, JSONResponse
from app.core.graph import graph
from app.core.persistence import persistence

router = APIRouter(prefix="/mcp", tags=["mcp"])

# ── Tool Definitions ──────────────────────────────────────────────────────
TOOLS = [
    # ── DISCOVERY ─────────────────────────────────────────────────────
    {
        "name": "get_stats",
        "description": "Get Data-DNA graph statistics — total fields, edges, systems, DAG status",
        "inputSchema": {"type": "object", "properties": {}}
    },
    {
        "name": "list_systems",
        "description": "List all systems with field counts, table counts, PII counts and description coverage",
        "inputSchema": {"type": "object", "properties": {}}
    },
    {
        "name": "list_tables",
        "description": "List all tables in a system with field counts and description coverage",
        "inputSchema": {
            "type": "object",
            "properties": {
                "system": {"type": "string", "description": "System name: CBS, RISK, LOS, MIS, BUREAU"}
            },
            "required": ["system"]
        }
    },
    {
        "name": "search_fields",
        "description": "Search fields by name, table, system, description or data type. Returns matching fields with full metadata.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Search keyword e.g. 'credit score', 'NPA', 'CUST_ID'"},
                "system": {"type": "string", "description": "Optional: filter by system"},
                "pii_only": {"type": "boolean", "description": "Optional: return only PII fields"},
                "no_description": {"type": "boolean", "description": "Optional: return only fields missing descriptions"}
            },
            "required": ["query"]
        }
    },
    {
        "name": "get_field_detail",
        "description": "Get complete metadata for a specific field — description, type, PII, tags, lineage edges",
        "inputSchema": {
            "type": "object",
            "properties": {
                "field_id": {"type": "string", "description": "Full field ID e.g. CBS.CBS_CUSTOMER.CUST_ID"}
            },
            "required": ["field_id"]
        }
    },
    {
        "name": "get_system_fields",
        "description": "List all fields in a system grouped by table. Shows field name, type, description and PII flag.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "system": {"type": "string", "description": "System name: CBS, RISK, LOS, MIS, BUREAU"},
                "table": {"type": "string", "description": "Optional: filter by specific table name"}
            },
            "required": ["system"]
        }
    },

    # ── LINEAGE ────────────────────────────────────────────────────────
    {
        "name": "get_field_lineage",
        "description": "Get complete upstream and downstream lineage for a field. Shows transformation type and logic.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "field_id": {"type": "string", "description": "Field ID e.g. CBS.CBS_CUSTOMER.CUST_ID"},
                "direction": {"type": "string", "description": "upstream, downstream, or both (default: both)"},
                "hops": {"type": "integer", "description": "Max hops to traverse (default: 5)"}
            },
            "required": ["field_id"]
        }
    },
    {
        "name": "get_source_to_target",
        "description": "Get complete lineage path from a source system to a target system showing all field mappings",
        "inputSchema": {
            "type": "object",
            "properties": {
                "source_system": {"type": "string", "description": "Source system e.g. CBS"},
                "target_system": {"type": "string", "description": "Target system e.g. MIS"}
            },
            "required": ["source_system", "target_system"]
        }
    },
    {
        "name": "get_all_edges",
        "description": "Get all lineage edges in the graph with source, target, transformation type and logic",
        "inputSchema": {
            "type": "object",
            "properties": {
                "source_system": {"type": "string", "description": "Optional: filter by source system"},
                "target_system": {"type": "string", "description": "Optional: filter by target system"},
                "transformation_type": {"type": "string", "description": "Optional: direct, renamed, aggregated, derived, filtered, joined"}
            }
        }
    },
    {
        "name": "map_fields",
        "description": "Create a lineage mapping between two fields (when names differ across systems)",
        "inputSchema": {
            "type": "object",
            "properties": {
                "source_field": {"type": "string", "description": "Source field ID e.g. CBS.CBS_CUSTOMER.CUST_ID"},
                "target_field": {"type": "string", "description": "Target field ID e.g. RISK.RISK_CUSTOMER_SCORE.CUSTOMER_ID"},
                "transformation_type": {"type": "string", "description": "direct, renamed, aggregated, derived, filtered, joined (default: direct)"},
                "transformation_logic": {"type": "string", "description": "Description of how value is computed/mapped"}
            },
            "required": ["source_field", "target_field"]
        }
    },
    {
        "name": "suggest_mappings",
        "description": "Get smart field mapping suggestions between two systems based on name similarity",
        "inputSchema": {
            "type": "object",
            "properties": {
                "source_system": {"type": "string", "description": "Source system"},
                "target_system": {"type": "string", "description": "Target system"},
                "threshold": {"type": "number", "description": "Minimum similarity score 0-1 (default: 0.6)"}
            },
            "required": ["source_system", "target_system"]
        }
    },

    # ── IMPACT & AUDIT ─────────────────────────────────────────────────
    {
        "name": "get_impact",
        "description": "Full impact analysis — what downstream fields, tables and reports break if this field changes",
        "inputSchema": {
            "type": "object",
            "properties": {
                "field_id": {"type": "string", "description": "Field ID to analyse impact for"}
            },
            "required": ["field_id"]
        }
    },
    {
        "name": "get_audit_trail",
        "description": "Get complete audit/provenance trail for a field — where did it come from, what transformed it",
        "inputSchema": {
            "type": "object",
            "properties": {
                "field_id": {"type": "string", "description": "Field ID to get audit trail for"}
            },
            "required": ["field_id"]
        }
    },

    # ── METADATA MANAGEMENT ────────────────────────────────────────────
    {
        "name": "update_description",
        "description": "Update the business description of a field. Use this to document what a field means.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "field_id": {"type": "string", "description": "Field ID to update"},
                "description": {"type": "string", "description": "New business description for the field"}
            },
            "required": ["field_id", "description"]
        }
    },
    {
        "name": "update_descriptions_bulk",
        "description": "Update descriptions for multiple fields at once. Pass a list of {field_id, description} objects.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "updates": {
                    "type": "array",
                    "description": "List of field updates",
                    "items": {
                        "type": "object",
                        "properties": {
                            "field_id": {"type": "string"},
                            "description": {"type": "string"}
                        }
                    }
                }
            },
            "required": ["updates"]
        }
    },
    {
        "name": "auto_describe_field",
        "description": (
            "Auto-generate a business description for a single field using rule-based engine. "
            "Works without AI. Triggered by: 'auto-describe field X', 'generate description for X', "
            "'describe CBS.CBS_CUSTOMER.CUST_ID'. Field ID format: SYSTEM.TABLE.COLUMN"
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "field_id": {"type": "string", "description": "Field ID e.g. CBS.CBS_CUSTOMER.CUST_ID"}
            },
            "required": ["field_id"]
        }
    },
    {
        "name": "auto_describe_system",
        "description": (
            "Auto-generate descriptions for all fields in a system using rule-based engine. "
            "Triggered by phrases like: 'auto-describe all fields in CBS', "
            "'auto describe CBS system', 'generate descriptions for RISK', "
            "'describe all RISK fields', 'fill descriptions in LOS', "
            "'auto describe all fields in the CBS system'. "
            "System name can be CBS, RISK, LOS, MIS, or BUREAU."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "system": {"type": "string", "description": "System name: CBS, RISK, LOS, MIS, BUREAU"},
                "overwrite": {"type": "boolean", "description": "Overwrite existing descriptions (default: false)"}
            },
            "required": ["system"]
        }
    },
    {
        "name": "upload_metadata_csv",
        "description": "Upload field metadata from a CSV string. Columns: system,table,column,description,pii,tags",
        "inputSchema": {
            "type": "object",
            "properties": {
                "csv_content": {"type": "string", "description": "CSV content with headers: system,table,column,description,pii,tags"},
                "overwrite": {"type": "boolean", "description": "Overwrite existing descriptions (default: false)"}
            },
            "required": ["csv_content"]
        }
    },
    {
        "name": "get_metadata_export",
        "description": "Export all field metadata as CSV — system, table, column, type, description, PII, lineage info",
        "inputSchema": {
            "type": "object",
            "properties": {
                "system": {"type": "string", "description": "Optional: export only one system"}
            }
        }
    },

    # ── PII & COMPLIANCE ───────────────────────────────────────────────
    {
        "name": "get_pii_fields",
        "description": "Get all PII (Personally Identifiable Information) fields across all systems or a specific system",
        "inputSchema": {
            "type": "object",
            "properties": {
                "system": {"type": "string", "description": "Optional: filter by system"}
            }
        }
    },
    {
        "name": "get_missing_descriptions",
        "description": "List all fields that have no description — useful for data quality tracking",
        "inputSchema": {
            "type": "object",
            "properties": {
                "system": {"type": "string", "description": "Optional: filter by system"}
            }
        }
    },

    {
        "name": "auto_describe",
        "description": (
            "Universal auto-describe tool. Handles field, table, or system level in one call. "
            "Use this for ALL auto-describe requests. Examples: "
            "'auto-describe all fields in the CBS system' → system=CBS, "
            "'auto describe CBS_CUSTOMER table' → system=CBS, table=CBS_CUSTOMER, "
            "'auto describe field CBS.CBS_CUSTOMER.CUST_ID' → field_id=CBS.CBS_CUSTOMER.CUST_ID, "
            "'auto describe all fields in CBS, RISK and LOS' → call once per system, "
            "'fill in missing descriptions for RISK' → system=RISK. "
            "Rule-based engine — works instantly without any AI API key."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "system":   {"type": "string",  "description": "System name: CBS, RISK, LOS, MIS, BUREAU (required for system or table level)"},
                "table":    {"type": "string",  "description": "Table name e.g. CBS_CUSTOMER (optional — if given, only this table is described)"},
                "field_id": {"type": "string",  "description": "Full field ID e.g. CBS.CBS_CUSTOMER.CUST_ID (optional — if given, only this field)"},
                "overwrite":{"type": "boolean", "description": "Overwrite existing descriptions (default: false)"}
            }
        }
    },

    # ── INGEST ─────────────────────────────────────────────────────────
    {
        "name": "ingest_sql",
        "description": "Ingest SQL DDL/DML to extract fields and lineage. Parses CREATE TABLE and INSERT/SELECT statements.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "system_name": {"type": "string", "description": "System name for ingested fields"},
                "sql": {"type": "string", "description": "SQL DDL/DML to parse"}
            },
            "required": ["system_name", "sql"]
        }
    },
]


# ── Tool Implementation ───────────────────────────────────────────────────
def _call_tool(name: str, args: dict) -> str:
    try:
        return _dispatch(name, args)
    except Exception as e:
        return f"ERROR in {name}: {e}"


def _dispatch(name: str, args: dict) -> str:
    fields_all = graph.list_fields()

    # ── get_stats ──────────────────────────────────────────────────────
    if name == "get_stats":
        s = graph.stats()
        with_desc = sum(1 for f in fields_all if f.description)
        pii = sum(1 for f in fields_all if f.pii)
        return (
            f"Data-DNA Graph Statistics\n"
            f"{'─'*40}\n"
            f"Total fields:      {s['total_fields']}\n"
            f"Total edges:       {s['total_edges']}\n"
            f"Systems:           {', '.join(sorted(s['systems']))}\n"
            f"With descriptions: {with_desc}/{s['total_fields']} "
            f"({100*with_desc//max(s['total_fields'],1)}%)\n"
            f"PII fields:        {pii}\n"
            f"DAG valid:         {s.get('is_dag', True)}"
        )

    # ── list_systems ───────────────────────────────────────────────────
    elif name == "list_systems":
        from collections import Counter
        sys_data = {}
        for f in fields_all:
            s = f.system
            if s not in sys_data:
                sys_data[s] = {"fields":0,"tables":set(),"pii":0,"desc":0}
            sys_data[s]["fields"] += 1
            sys_data[s]["tables"].add(f.table)
            if f.pii: sys_data[s]["pii"] += 1
            if f.description: sys_data[s]["desc"] += 1
        lines = ["Systems in Data-DNA:", "─"*50]
        for s, d in sorted(sys_data.items()):
            pct = 100*d["desc"]//d["fields"]
            lines.append(
                f"  {s:<15} {d['fields']:>4} fields | "
                f"{len(d['tables']):>2} tables | "
                f"{d['pii']:>2} PII | "
                f"{pct}% described"
            )
        return "\n".join(lines)

    # ── list_tables ────────────────────────────────────────────────────
    elif name == "list_tables":
        system = args["system"].upper()
        tbl_data = {}
        for f in fields_all:
            if f.system.upper() != system: continue
            t = f.table
            if t not in tbl_data:
                tbl_data[t] = {"fields":0,"desc":0,"pii":0}
            tbl_data[t]["fields"] += 1
            if f.description: tbl_data[t]["desc"] += 1
            if f.pii: tbl_data[t]["pii"] += 1
        if not tbl_data:
            return f"No tables found for system '{system}'"
        lines = [f"Tables in {system}:", "─"*50]
        for t, d in sorted(tbl_data.items()):
            pct = 100*d["desc"]//d["fields"]
            lines.append(
                f"  {t:<35} {d['fields']:>3} fields | "
                f"{d['pii']:>2} PII | {pct}% described"
            )
        return "\n".join(lines)

    # ── search_fields ──────────────────────────────────────────────────
    elif name == "search_fields":
        q = args["query"].lower()
        sys_filter = args.get("system","").upper()
        pii_only = args.get("pii_only", False)
        no_desc = args.get("no_description", False)

        results = []
        for f in fields_all:
            if sys_filter and f.system.upper() != sys_filter: continue
            if pii_only and not f.pii: continue
            if no_desc and f.description: continue
            if (q in f.column.lower() or q in f.table.lower() or
                q in f.system.lower() or q in (f.description or "").lower() or
                q in (f.data_type or "").lower()):
                results.append(f)

        if not results:
            return f"No fields found matching '{args['query']}'"
        lines = [f"Found {len(results)} fields matching '{args['query']}':","─"*60]
        for f in results[:30]:
            pii_tag = " [PII]" if f.pii else ""
            desc = (f.description[:70]+"...") if f.description and len(f.description)>70 else (f.description or "⚠ No description")
            lines.append(f"  {f.id}{pii_tag}")
            lines.append(f"    Type: {f.data_type} | {desc}")
        if len(results) > 30:
            lines.append(f"  ... and {len(results)-30} more")
        return "\n".join(lines)

    # ── get_field_detail ───────────────────────────────────────────────
    elif name == "get_field_detail":
        fid = args["field_id"]
        f = graph.get_field(fid)
        if not f:
            return f"Field not found: {fid}\nTip: use search_fields to find the correct ID"
        upstream = [e for e in graph._edges.values() if e.target_field == fid]
        downstream = [e for e in graph._edges.values() if e.source_field == fid]
        lines = [
            f"Field: {f.id}","─"*60,
            f"System:      {f.system}",
            f"Table:       {f.table}",
            f"Column:      {f.column}",
            f"Data Type:   {f.data_type or 'unknown'}",
            f"PII:         {'YES ⚠' if f.pii else 'No'}",
            f"Tags:        {', '.join(f.tags) if f.tags else 'none'}",
            f"Description: {f.description or '⚠ Missing — use update_description to add one'}",
            "",
            f"Upstream ({len(upstream)} sources):"
        ]
        for e in upstream:
            lines.append(f"  ← {e.source_field}")
            lines.append(f"    Type: {e.transformation_type} | {e.transformation_logic or ''}")
        lines.append(f"Downstream ({len(downstream)} targets):")
        for e in downstream:
            lines.append(f"  → {e.target_field}")
            lines.append(f"    Type: {e.transformation_type} | {e.transformation_logic or ''}")
        return "\n".join(lines)

    # ── get_system_fields ──────────────────────────────────────────────
    elif name == "get_system_fields":
        system = args["system"].upper()
        tbl_filter = args.get("table","").upper()
        flds = [f for f in fields_all
                if f.system.upper()==system and
                (not tbl_filter or f.table.upper()==tbl_filter)]
        if not flds:
            return f"No fields for {system}{'.'+tbl_filter if tbl_filter else ''}"
        tables = {}
        for f in flds:
            tables.setdefault(f.table, []).append(f)
        lines = [f"{system} — {len(flds)} fields across {len(tables)} tables:","─"*60]
        for tbl, tbl_fields in sorted(tables.items()):
            lines.append(f"\n  {tbl} ({len(tbl_fields)} fields):")
            for f in tbl_fields:
                pii = "[PII]" if f.pii else ""
                desc = (f.description[:50]+"...") if f.description and len(f.description)>50 else (f.description or "no description")
                lines.append(f"    {f.column:<30} {f.data_type:<15} {pii}")
                lines.append(f"      → {desc}")
        return "\n".join(lines)

    # ── get_field_lineage ──────────────────────────────────────────────
    elif name == "get_field_lineage":
        fid = args["field_id"]
        direction = args.get("direction","both")
        hops = args.get("hops", 5)
        f = graph.get_field(fid)
        if not f:
            return f"Field not found: {fid}"

        def bfs(start, follow_source):
            visited, levels = {}, {start: 0}
            queue = [start]
            while queue:
                curr = queue.pop(0)
                if levels[curr] >= hops: continue
                for e in graph._edges.values():
                    nxt = e.source_field if follow_source else e.target_field
                    prev = e.target_field if follow_source else e.source_field
                    if prev == curr and nxt not in levels:
                        levels[nxt] = levels[curr]+1
                        visited[nxt] = e
                        queue.append(nxt)
            return visited

        lines = [f"Lineage for: {fid}",
                 f"Description: {f.description or 'No description'}","─"*60]

        if direction in ("upstream","both"):
            up = bfs(fid, True)
            lines.append(f"\nUPSTREAM ({len(up)} sources):")
            if not up: lines.append("  (no upstream — this is a root/source field)")
            for nxt, e in up.items():
                src_f = graph.get_field(nxt)
                lines.append(f"  ← {nxt}")
                lines.append(f"     Transform: {e.transformation_type}")
                if e.transformation_logic:
                    lines.append(f"     Logic: {e.transformation_logic}")
                if src_f and src_f.description:
                    lines.append(f"     Desc: {src_f.description[:60]}")

        if direction in ("downstream","both"):
            down = bfs(fid, False)
            lines.append(f"\nDOWNSTREAM ({len(down)} targets):")
            if not down: lines.append("  (no downstream — this is a leaf/output field)")
            for nxt, e in down.items():
                tgt_f = graph.get_field(nxt)
                lines.append(f"  → {nxt}")
                lines.append(f"     Transform: {e.transformation_type}")
                if e.transformation_logic:
                    lines.append(f"     Logic: {e.transformation_logic}")
                if tgt_f and tgt_f.description:
                    lines.append(f"     Desc: {tgt_f.description[:60]}")
        return "\n".join(lines)

    # ── get_source_to_target ───────────────────────────────────────────
    elif name == "get_source_to_target":
        src_sys = args["source_system"].upper()
        tgt_sys = args["target_system"].upper()
        edges = [e for e in graph._edges.values()
                 if e.source_field.startswith(src_sys+".") and
                    e.target_field.startswith(tgt_sys+".")]
        if not edges:
            return f"No direct lineage edges found from {src_sys} → {tgt_sys}"
        lines = [f"Lineage: {src_sys} → {tgt_sys} ({len(edges)} mappings)","─"*70]
        for e in sorted(edges, key=lambda x: x.source_field):
            src_col = e.source_field.split(".")[-1]
            tgt_col = e.target_field.split(".")[-1]
            src_f = graph.get_field(e.source_field)
            tgt_f = graph.get_field(e.target_field)
            lines.append(f"\n  {e.source_field}")
            lines.append(f"    ↓ [{e.transformation_type}]"
                         + (f" {e.transformation_logic}" if e.transformation_logic else ""))
            lines.append(f"  {e.target_field}")
            if src_f and src_f.description:
                lines.append(f"    Source desc: {src_f.description[:60]}")
            if tgt_f and tgt_f.description:
                lines.append(f"    Target desc: {tgt_f.description[:60]}")
        return "\n".join(lines)

    # ── get_all_edges ──────────────────────────────────────────────────
    elif name == "get_all_edges":
        src_sys = args.get("source_system","").upper()
        tgt_sys = args.get("target_system","").upper()
        ttype = args.get("transformation_type","").lower()
        edges = list(graph._edges.values())
        if src_sys: edges = [e for e in edges if e.source_field.upper().startswith(src_sys+".")]
        if tgt_sys: edges = [e for e in edges if e.target_field.upper().startswith(tgt_sys+".")]
        if ttype: edges = [e for e in edges if e.transformation_type.lower()==ttype]
        lines = [f"Lineage Edges ({len(edges)} total):", "─"*70]
        for e in sorted(edges, key=lambda x: x.source_field):
            lines.append(f"  {e.source_field}")
            lines.append(f"    → {e.target_field}  [{e.transformation_type}]"
                         + (f"  {e.transformation_logic}" if e.transformation_logic else ""))
        return "\n".join(lines)

    # ── map_fields ─────────────────────────────────────────────────────
    elif name == "map_fields":
        import uuid
        from app.models.lineage import LineageEdge, SourceType, TransformationType
        src = args["source_field"]
        tgt = args["target_field"]
        if not graph.get_field(src):
            return f"Source field not found: {src}"
        if not graph.get_field(tgt):
            return f"Target field not found: {tgt}"
        tmap = {"direct":TransformationType.DIRECT,"renamed":TransformationType.RENAMED,
                "aggregated":TransformationType.AGGREGATED,"derived":TransformationType.DERIVED,
                "filtered":TransformationType.FILTERED,"joined":TransformationType.JOINED}
        tt = tmap.get(args.get("transformation_type","direct").lower(), TransformationType.DIRECT)
        edge = LineageEdge(
            id=str(uuid.uuid4()), source_field=src, target_field=tgt,
            transformation_type=tt,
            transformation_logic=args.get("transformation_logic",""),
            source_type=SourceType.AUTHORITATIVE, confidence=1.0,
            system_boundary=src.split(".")[0] != tgt.split(".")[0]
        )
        graph.add_lineage(edge)
        persistence.save_edge(edge.model_dump())
        return (f"✓ Mapping created:\n"
                f"  {src}\n"
                f"  → {tgt}\n"
                f"  Type: {args.get('transformation_type','direct')}\n"
                f"  Logic: {args.get('transformation_logic','')}")

    # ── suggest_mappings ───────────────────────────────────────────────
    elif name == "suggest_mappings":
        from difflib import SequenceMatcher
        src_sys = args["source_system"].upper()
        tgt_sys = args["target_system"].upper()
        threshold = args.get("threshold", 0.6)
        src_fields = [f for f in fields_all if f.system.upper()==src_sys]
        tgt_fields = [f for f in fields_all if f.system.upper()==tgt_sys]
        if not src_fields: return f"No fields for {src_sys}"
        if not tgt_fields: return f"No fields for {tgt_sys}"
        suggestions = []
        for sf in src_fields:
            best, best_score = None, 0
            for tf in tgt_fields:
                if sf.column.upper() == tf.column.upper():
                    score = 1.0
                else:
                    score = SequenceMatcher(None, sf.column.lower(), tf.column.lower()).ratio()
                if score > best_score:
                    best_score, best = score, tf
            if best and best_score >= threshold:
                already = any(e.source_field==sf.id and e.target_field==best.id
                              for e in graph._edges.values())
                suggestions.append((best_score, sf.column, sf.id, best.column, best.id, already))
        suggestions.sort(reverse=True, key=lambda x: x[0])
        lines = [f"Mapping suggestions: {src_sys} → {tgt_sys} "
                 f"(threshold={threshold}, found {len(suggestions)})", "─"*70]
        for score, sf_col, sf_id, tf_col, tf_id, mapped in suggestions[:25]:
            status = "✓ already mapped" if mapped else "← use map_fields to create"
            lines.append(f"  {score:.0%}  {sf_col:<30} → {tf_col:<30}  {status}")
            lines.append(f"        {sf_id} → {tf_id}")
        return "\n".join(lines)

    # ── get_impact ─────────────────────────────────────────────────────
    elif name == "get_impact":
        fid = args["field_id"]
        f = graph.get_field(fid)
        if not f: return f"Field not found: {fid}"
        visited, queue, levels = {}, [fid], {fid: 0}
        while queue:
            curr = queue.pop(0)
            for e in graph._edges.values():
                if e.source_field==curr and e.target_field not in levels:
                    levels[e.target_field] = levels[curr]+1
                    visited[e.target_field] = e
                    queue.append(e.target_field)
        if not visited:
            return f"✓ {fid} has NO downstream dependents — safe to change."
        sys_impact = {}
        for fld in visited:
            s = fld.split(".")[0]
            sys_impact.setdefault(s, []).append(fld)
        lines = [
            f"Impact Analysis: {fid}",
            f"Description: {f.description or 'no description'}","─"*60,
            f"Total impacted fields: {len(visited)}",
            f"Impacted systems: {', '.join(sorted(sys_impact.keys()))}", ""
        ]
        for sys_name, sys_flds in sorted(sys_impact.items()):
            lines.append(f"  {sys_name} ({len(sys_flds)} fields):")
            for fld in sorted(sys_flds):
                fobj = graph.get_field(fld)
                edge = visited[fld]
                lines.append(f"    → {fld}  [{edge.transformation_type}]")
                if fobj and fobj.description:
                    lines.append(f"       {fobj.description[:60]}")
        risk = "HIGH" if len(visited) > 10 else "MEDIUM" if len(visited) > 3 else "LOW"
        lines.append(f"\nRisk Level: {risk}")
        return "\n".join(lines)

    # ── get_audit_trail ────────────────────────────────────────────────
    elif name == "get_audit_trail":
        fid = args["field_id"]
        f = graph.get_field(fid)
        if not f: return f"Field not found: {fid}"
        # Walk upstream fully
        chain = []
        visited_up = set()
        def walk_up(curr_id, depth=0):
            if depth > 10 or curr_id in visited_up: return
            visited_up.add(curr_id)
            for e in graph._edges.values():
                if e.target_field == curr_id:
                    chain.append((depth, e))
                    walk_up(e.source_field, depth+1)
        walk_up(fid)
        lines = [f"Audit Trail / Provenance: {fid}",
                 f"Description: {f.description or 'no description'}","─"*60]
        if not chain:
            lines.append("This is a ROOT field — data originates here (no upstream sources).")
        else:
            lines.append(f"Data provenance chain ({len(chain)} hops):")
            for depth, e in sorted(chain, key=lambda x: -x[0]):
                indent = "  " * (depth+1)
                src_f = graph.get_field(e.source_field)
                lines.append(f"{indent}{e.source_field}")
                if src_f and src_f.description:
                    lines.append(f"{indent}  Desc: {src_f.description[:60]}")
                lines.append(f"{indent}  ↓ [{e.transformation_type}]"
                             + (f" {e.transformation_logic}" if e.transformation_logic else ""))
            lines.append(f"  → {fid}  (current field)")
        return "\n".join(lines)

    # ── update_description ─────────────────────────────────────────────
    elif name == "update_description":
        fid = args["field_id"]
        desc = args["description"].strip()
        f = graph.get_field(fid)
        if not f: return f"Field not found: {fid}"
        f.description = desc
        graph.add_field(f)
        persistence.save_node(f.model_dump())
        return f"✓ Updated description for {fid}:\n  {desc}"

    # ── update_descriptions_bulk ───────────────────────────────────────
    elif name == "update_descriptions_bulk":
        updates = args.get("updates", [])
        done, failed = [], []
        for u in updates:
            fid = u.get("field_id","")
            desc = u.get("description","").strip()
            f = graph.get_field(fid)
            if not f:
                failed.append(fid)
                continue
            f.description = desc
            graph.add_field(f)
            persistence.save_node(f.model_dump())
            done.append(fid)
        lines = [f"Bulk update complete: {len(done)} updated, {len(failed)} failed"]
        if failed:
            lines.append(f"Not found: {', '.join(failed[:10])}")
        return "\n".join(lines)

    # ── auto_describe_field ────────────────────────────────────────────
    elif name == "auto_describe_field":
        fid = args["field_id"]
        f = graph.get_field(fid)
        if not f: return f"Field not found: {fid}"
        from app.api.lineage import _rule_description
        desc = _rule_description(f.system, f.table, f.column, f.data_type)
        f.description = desc
        graph.add_field(f)
        persistence.save_node(f.model_dump())
        return f"✓ Auto-described {fid}:\n  {desc}"

    # ── auto_describe_system ───────────────────────────────────────────
    elif name == "auto_describe_system":
        from app.api.lineage import _rule_description
        system = args["system"].upper()
        overwrite = args.get("overwrite", False)
        flds = [f for f in fields_all if f.system.upper()==system]
        if not flds: return f"No fields found for system '{system}'"
        done, skipped = 0, 0
        for f in flds:
            if f.description and not overwrite:
                skipped += 1
                continue
            desc = _rule_description(f.system, f.table, f.column, f.data_type)
            if desc:
                f.description = desc
                graph.add_field(f)
                persistence.save_node(f.model_dump())
                done += 1
        return (f"✓ Auto-described {system}:\n"
                f"  Described: {done} fields\n"
                f"  Skipped (already had description): {skipped} fields\n"
                f"  Total: {len(flds)} fields")

    # ── upload_metadata_csv ────────────────────────────────────────────
    elif name == "upload_metadata_csv":
        import csv
        csv_content = args["csv_content"]
        overwrite = args.get("overwrite", False)
        reader = csv.DictReader(io.StringIO(csv_content))
        updated, not_found, skipped = 0, 0, 0
        for row in reader:
            system = row.get("system","").strip().upper()
            table  = row.get("table","").strip().upper()
            column = row.get("column","").strip().upper()
            desc   = row.get("description","").strip()
            if not system or not table or not column: continue
            fid = f"{system}.{table}.{column}"
            f = graph.get_field(fid)
            if not f:
                not_found += 1
                continue
            if f.description and not overwrite:
                skipped += 1
                continue
            if desc:
                f.description = desc
                if row.get("pii","").strip().upper() in ("Y","YES","TRUE","1"):
                    f.pii = True
                graph.add_field(f)
                persistence.save_node(f.model_dump())
                updated += 1
        return (f"✓ CSV metadata upload complete:\n"
                f"  Updated: {updated} fields\n"
                f"  Not found: {not_found} fields\n"
                f"  Skipped (already described): {skipped} fields\n\n"
                f"CSV format required: system,table,column,description,pii,tags")

    # ── get_metadata_export ────────────────────────────────────────────
    elif name == "get_metadata_export":
        system = args.get("system","").upper()
        flds = [f for f in fields_all if not system or f.system.upper()==system]
        lines = ["system,table,column,data_type,description,pii,upstream_count,downstream_count"]
        for f in sorted(flds, key=lambda x: (x.system, x.table, x.column)):
            up = sum(1 for e in graph._edges.values() if e.target_field==f.id)
            dn = sum(1 for e in graph._edges.values() if e.source_field==f.id)
            desc = (f.description or "").replace(",",";" ).replace("\n"," ")
            lines.append(f"{f.system},{f.table},{f.column},{f.data_type or ''},"
                         f"{desc},{'Y' if f.pii else 'N'},{up},{dn}")
        return "\n".join(lines)

    # ── get_pii_fields ─────────────────────────────────────────────────
    elif name == "get_pii_fields":
        system = args.get("system","").upper()
        pii_flds = [f for f in fields_all
                    if f.pii and (not system or f.system.upper()==system)]
        if not pii_flds:
            return f"No PII fields found{' for '+system if system else ''}."
        lines = [f"PII Fields ({len(pii_flds)} total):", "─"*60]
        by_sys = {}
        for f in pii_flds:
            by_sys.setdefault(f.system, []).append(f)
        for sys_name, sys_flds in sorted(by_sys.items()):
            lines.append(f"\n  {sys_name}:")
            for f in sys_flds:
                lines.append(f"    ⚠ {f.id} ({f.data_type})")
                if f.description:
                    lines.append(f"      {f.description[:70]}")
        return "\n".join(lines)

    # ── get_missing_descriptions ───────────────────────────────────────
    elif name == "get_missing_descriptions":
        system = args.get("system","").upper()
        missing = [f for f in fields_all
                   if not f.description and
                   (not system or f.system.upper()==system)]
        if not missing:
            return f"✓ All fields have descriptions{' in '+system if system else ''}!"
        lines = [f"Fields missing descriptions: {len(missing)}", "─"*50]
        by_sys = {}
        for f in missing:
            by_sys.setdefault(f.system, []).append(f)
        for sys_name, sys_flds in sorted(by_sys.items()):
            lines.append(f"\n  {sys_name} ({len(sys_flds)} missing):")
            for f in sys_flds[:10]:
                lines.append(f"    {f.id} ({f.data_type})")
            if len(sys_flds) > 10:
                lines.append(f"    ... and {len(sys_flds)-10} more")
        lines.append(f"\nTip: use auto_describe_system to fix all at once")
        return "\n".join(lines)

    # ── auto_describe (universal — field / table / system) ────────────
    elif name == "auto_describe":
        from app.api.lineage import _rule_description
        field_id = args.get("field_id", "").strip()
        system   = args.get("system", "").strip().upper()
        table    = args.get("table", "").strip().upper()
        overwrite = args.get("overwrite", False)

        # ── Single field ──────────────────────────────────────────────
        if field_id:
            f = graph.get_field(field_id)
            if not f:
                # Try to find by partial match
                matches = [x for x in fields_all
                           if field_id.upper() in x.id.upper()]
                if matches:
                    f = matches[0]
                else:
                    return f"Field not found: {field_id}\nTip: use search_fields to find exact ID"
            if f.description and not overwrite:
                return (f"ℹ {f.id} already has a description:\n"
                        f"  {f.description}\n"
                        f"  Use overwrite=true to replace it.")
            desc = _rule_description(f.system, f.table, f.column, f.data_type)
            f.description = desc
            graph.add_field(f)
            persistence.save_node(f.model_dump())
            return f"✓ Described {f.id}:\n  {desc}"

        # ── Table level ───────────────────────────────────────────────
        elif system and table:
            flds = [f for f in fields_all
                    if f.system.upper() == system and
                    f.table.upper() == table]
            if not flds:
                # Try partial table match
                flds = [f for f in fields_all
                        if f.system.upper() == system and
                        table in f.table.upper()]
            if not flds:
                avail = sorted(set(f.table for f in fields_all if f.system.upper()==system))
                return (f"Table '{table}' not found in {system}.\n"
                        f"Available tables: {', '.join(avail)}")
            done, skipped = 0, 0
            for f in flds:
                if f.description and not overwrite:
                    skipped += 1
                    continue
                desc = _rule_description(f.system, f.table, f.column, f.data_type)
                if desc:
                    f.description = desc
                    graph.add_field(f)
                    persistence.save_node(f.model_dump())
                    done += 1
            return (
                f"✓ Auto-described table {system}.{flds[0].table}:\n"
                f"  Described : {done} fields\n"
                f"  Skipped   : {skipped} fields (already had description)\n"
                f"  Total     : {len(flds)} fields\n"
                f"\nGo to the Metadata tab in Data-DNA to review the descriptions."
            )

        # ── System level ──────────────────────────────────────────────
        elif system:
            flds = [f for f in fields_all if f.system.upper() == system]
            if not flds:
                avail = sorted(set(f.system for f in fields_all))
                return (f"System '{system}' not found.\n"
                        f"Available systems: {', '.join(avail)}")
            # Group by table for a nice summary
            tables_done = {}
            total_done, total_skipped = 0, 0
            for f in flds:
                if f.description and not overwrite:
                    total_skipped += 1
                    tables_done.setdefault(f.table, {"done":0,"skip":0})["skip"] += 1
                    continue
                desc = _rule_description(f.system, f.table, f.column, f.data_type)
                if desc:
                    f.description = desc
                    graph.add_field(f)
                    persistence.save_node(f.model_dump())
                    total_done += 1
                    tables_done.setdefault(f.table, {"done":0,"skip":0})["done"] += 1

            lines = [
                f"✓ Auto-described all fields in {system}",
                f"{'─'*45}",
                f"  Total fields : {len(flds)}",
                f"  Described    : {total_done}",
                f"  Skipped      : {total_skipped} (already had description)",
                f"",
                f"  Per table:"
            ]
            for tbl, counts in sorted(tables_done.items()):
                lines.append(f"    {tbl:<35} {counts['done']:>3} described, {counts['skip']:>3} skipped")
            lines.append("")
            lines.append("Go to the Metadata tab in Data-DNA to review all descriptions.")
            return "\n".join(lines)

        else:
            return (
                "Please specify what to describe:\n"
                "  • System level : system='CBS'\n"
                "  • Table level  : system='CBS', table='CBS_CUSTOMER'\n"
                "  • Field level  : field_id='CBS.CBS_CUSTOMER.CUST_ID'\n"
                "\nExample: auto-describe all fields in the CBS system"
            )

    # ── ingest_sql ─────────────────────────────────────────────────────
    elif name == "ingest_sql":
        from app.services.ingestion import ingestion_service
        result = ingestion_service.ingest_sql(
            system_name=args["system_name"],
            sql=args["sql"]
        )
        return (f"✓ SQL ingestion complete for {args['system_name']}:\n"
                f"  Fields created: {result.get('nodes_created', 0)}\n"
                f"  Edges created:  {result.get('edges_created', 0)}\n"
                f"  Tables found:   {result.get('tables_found', 0)}")

    else:
        return f"Unknown tool: {name}. Available: {[t['name'] for t in TOOLS]}"


# ── MCP HTTP Transport ────────────────────────────────────────────────────
@router.get("")
@router.get("/")
async def mcp_sse(request: Request):
    """MCP SSE transport endpoint for VS Code / Claude Desktop."""
    async def event_stream():
        info = {
            "jsonrpc": "2.0",
            "method": "notifications/initialized",
            "params": {
                "protocolVersion": "2024-11-05",
                "serverInfo": {"name": "data-dna", "version": "2.0.0"},
                "capabilities": {"tools": {}}
            }
        }
        yield f"data: {json.dumps(info)}\n\n"
        await asyncio.sleep(0.1)
        tools_msg = {
            "jsonrpc": "2.0", "id": "tools-list",
            "result": {"tools": TOOLS}
        }
        yield f"data: {json.dumps(tools_msg)}\n\n"
        while True:
            if await request.is_disconnected():
                break
            yield ": keepalive\n\n"
            await asyncio.sleep(15)

    return StreamingResponse(
        event_stream(),
        media_type="text/event-stream",
        headers={"Cache-Control":"no-cache","X-Accel-Buffering":"no",
                 "Access-Control-Allow-Origin":"*"}
    )


@router.post("")
@router.post("/")
async def mcp_post(request: Request):
    """Handle MCP JSON-RPC requests."""
    try:
        body = await request.json()
    except Exception:
        return JSONResponse({"error": "Invalid JSON"}, status_code=400)

    method  = body.get("method", "")
    req_id  = body.get("id")
    params  = body.get("params", {})

    if method == "initialize":
        return JSONResponse({"jsonrpc":"2.0","id":req_id,"result":{
            "protocolVersion":"2024-11-05",
            "serverInfo":{"name":"data-dna","version":"2.0.0"},
            "capabilities":{"tools":{}}
        }})

    elif method == "tools/list":
        return JSONResponse({"jsonrpc":"2.0","id":req_id,
                             "result":{"tools":TOOLS}})

    elif method == "tools/call":
        tool_name = params.get("name","")
        tool_args = params.get("arguments",{})
        result_text = _call_tool(tool_name, tool_args)
        return JSONResponse({"jsonrpc":"2.0","id":req_id,"result":{
            "content":[{"type":"text","text":result_text}],
            "isError":False
        }})

    elif method in ("notifications/initialized","ping"):
        return JSONResponse({"jsonrpc":"2.0","id":req_id,"result":{}})

    else:
        return JSONResponse({"jsonrpc":"2.0","id":req_id,
            "error":{"code":-32601,"message":f"Method not found: {method}"}})
