"""Audit trail API — multi-source lineage support."""
from fastapi import APIRouter, HTTPException, Query
from typing import List, Optional
from app.core.graph import graph
from app.models.lineage import AuditEntry
from app.ai.discoverer import discoverer
from app.core.persistence import persistence
import json

router = APIRouter(prefix="/audit", tags=["audit"])


@router.get("/{field_id:path}", response_model=AuditEntry)
def get_audit(field_id: str):
    try:
        return graph.get_audit(field_id)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))


@router.post("/infer")
def infer_lineage(
    source_system: str = Query(...),
    target_system: str = Query(...),
    context: str = Query("Credit data platform"),
):
    src_fields = graph.list_fields(system=source_system)
    tgt_fields = graph.list_fields(system=target_system)
    if not src_fields:
        raise HTTPException(404, detail=f"No fields for source: {source_system}")
    if not tgt_fields:
        raise HTTPException(404, detail=f"No fields for target: {target_system}")

    edges = discoverer.discover(src_fields, tgt_fields, context=context)
    added, skipped = 0, 0
    for edge in edges:
        try:
            graph.add_lineage(edge)
            persistence.save_edge(edge.model_dump())
            added += 1
        except ValueError:
            skipped += 1

    return {
        "source_system": source_system,
        "target_system": target_system,
        "context": context,
        "inferred_edges": added,
        "skipped": skipped,
        "edges": [e.model_dump() for e in edges],
    }


@router.post("/infer-multi")
def infer_multi_source(
    source_systems: str = Query(..., description="Comma-separated source systems e.g. CBS,CDS,CBODS"),
    target_system: str = Query(...),
    context: str = Query("Credit data platform"),
):
    """
    Multi-source lineage discovery.
    One target system can have data flowing from MULTIPLE source systems.
    Processes each source→target pair and returns a unified lineage chain.
    E.g.  CBS → CDS → CBODS → CCODS (chain)
    or    CBS + CRM + BUREAU → REPORTING (fan-in)
    """
    sources = [s.strip() for s in source_systems.split(",") if s.strip()]
    if not sources:
        raise HTTPException(400, detail="Provide at least one source system")

    tgt_fields = graph.list_fields(system=target_system)
    if not tgt_fields:
        raise HTTPException(404, detail=f"No fields for target: {target_system}")

    all_results = []
    total_added = 0

    for src_sys in sources:
        src_fields = graph.list_fields(system=src_sys)
        if not src_fields:
            all_results.append({"source": src_sys, "error": "No fields found", "edges": []})
            continue

        edges = discoverer.discover(src_fields, tgt_fields, context=context)
        added = 0
        for edge in edges:
            try:
                graph.add_lineage(edge)
                persistence.save_edge(edge.model_dump())
                added += 1
                total_added += 1
            except ValueError:
                pass

        all_results.append({
            "source": src_sys,
            "edges_found": added,
            "edges": [e.model_dump() for e in edges],
        })

    return {
        "target_system": target_system,
        "source_systems": sources,
        "total_edges": total_added,
        "results": all_results,
    }


@router.get("/lineage-chain/resolve")
def resolve_lineage_chain(
    systems: str = Query(..., description="Ordered chain: CBS,CDS,CBODS,CCODS"),
):
    """
    Resolve a lineage chain between ordered systems.
    CBS → CDS → CBODS → CCODS
    Shows the complete multi-hop path with all intermediate transformations.
    """
    chain = [s.strip() for s in systems.split(",") if s.strip()]
    if len(chain) < 2:
        raise HTTPException(400, detail="Provide at least 2 systems in the chain")

    result = {"chain": chain, "hops": []}
    for i in range(len(chain) - 1):
        src, tgt = chain[i], chain[i+1]
        # Get existing edges between these two systems
        src_fields = {f.id for f in graph.list_fields(system=src)}
        edges = [
            e for e in graph._edges.values()
            if e.source_field in src_fields
            and e.target_field.split(".")[0] == tgt
        ]
        result["hops"].append({
            "from": src,
            "to": tgt,
            "hop_number": i + 1,
            "edges": [e.model_dump() for e in edges],
            "edge_count": len(edges),
            "has_lineage": len(edges) > 0,
        })

    # Identify root (first system with no inbound edges from other chain members)
    result["root_system"] = chain[0]
    result["leaf_system"] = chain[-1]
    result["complete"] = all(h["has_lineage"] for h in result["hops"])
    return result
