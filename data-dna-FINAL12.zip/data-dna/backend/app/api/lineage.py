"""Lineage API endpoints — v2 with field enrichment via AI."""
from typing import Optional
from fastapi import APIRouter, HTTPException, Query
from app.core.graph import graph
from app.models.lineage import IngestRequest, IngestResult, LineagePath, FieldNode
from app.services.ingestion import ingestion_service
from app.core.persistence import persistence
from app.ai.provider import ask_ai

router = APIRouter(prefix="/lineage", tags=["lineage"])


@router.post("/ingest", response_model=IngestResult)
def ingest(request: IngestRequest):
    result = ingestion_service.ingest(request)
    # Persist new nodes/edges
    for fid in result.fields:
        node = graph.get_field(fid)
        if node:
            persistence.save_node(node.model_dump())
    for edge in graph._edges.values():
        persistence.save_edge(edge.model_dump())
    return result


@router.get("/fields", response_model=list[FieldNode])
def list_fields(system: Optional[str] = Query(None)):
    return graph.list_fields(system=system)


@router.get("/field/{field_id:path}", response_model=FieldNode)
def get_field(field_id: str):
    f = graph.get_field(field_id)
    if not f:
        raise HTTPException(status_code=404, detail=f"Field not found: {field_id}")
    return f


@router.post("/field/{field_id:path}/enrich")
def enrich_field(field_id: str):
    """Use AI to generate a business-friendly description for a field."""
    f = graph.get_field(field_id)
    if not f:
        raise HTTPException(404, detail="Field not found")
    prompt = (f"You are a credit data domain expert. Write a concise one-sentence business description "
              f"for a database field named '{f.column}' in table '{f.table}' from system '{f.system}'. "
              f"Data type: {f.data_type or 'unknown'}. "
              f"Focus on its business meaning in a credit/lending context. "
              f"Return only the description, no extra text.")
    desc = ask_ai(prompt, max_tokens=120)
    if desc:
        f.description = desc.strip()
        graph.add_field(f)
        persistence.save_node(f.model_dump())
        return {"field_id": field_id, "description": f.description}
    return {"field_id": field_id, "description": f.description or "No AI configured"}


@router.post("/enrich-all")
def enrich_all_fields(system: Optional[str] = Query(None)):
    """Bulk enrich all fields with AI descriptions."""
    fields = graph.list_fields(system=system)
    enriched = 0
    for f in fields:
        if f.description:
            continue
        prompt = (f"One sentence: business meaning of '{f.column}' in '{f.table}' ({f.system}) "
                  f"for credit/lending. Data type: {f.data_type or 'unknown'}. Just the description.")
        desc = ask_ai(prompt, max_tokens=80)
        if desc:
            f.description = desc.strip()
            graph.add_field(f)
            persistence.save_node(f.model_dump())
            enriched += 1
    return {"enriched": enriched, "total": len(fields)}


@router.get("/path/{field_id:path}", response_model=LineagePath)
def get_lineage_path(
    field_id: str,
    hops: int = Query(3, ge=1, le=10),
    direction: str = Query("both", pattern="^(upstream|downstream|both)$"),
    include_inferred: bool = Query(True),
):
    try:
        return graph.get_lineage(field_id, hops=hops, direction=direction,
                                  include_inferred=include_inferred)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))


@router.get("/graph")
def get_full_graph():
    return graph.export_for_visualization()


@router.get("/stats")
def get_stats():
    return graph.stats()


# ── Excel / CSV upload endpoints ──────────────────────────────────────────
from fastapi import UploadFile, File
from fastapi.responses import Response as FileResp
from app.core.excel_parser import parse_excel_metadata, generate_excel_template
from app.core.persistence import persistence


@router.post("/ingest/excel")
async def ingest_excel(file: UploadFile = File(...)):
    """Upload an Excel (.xlsx) or CSV file with field metadata."""
    content = await file.read()
    nodes, edges, warnings = parse_excel_metadata(content, file.filename)

    nodes_created = 0
    for node in nodes:
        graph.add_field(node)
        search_engine.index_field(node)
        persistence.save_node(node.model_dump())
        nodes_created += 1

    edges_created = 0
    for edge in edges:
        try:
            graph.add_lineage(edge)
            persistence.save_edge(edge.model_dump())
            edges_created += 1
        except ValueError as e:
            warnings.append(f"Edge skipped: {e}")

    return {
        "filename": file.filename,
        "nodes_created": nodes_created,
        "edges_created": edges_created,
        "warnings": warnings,
        "fields": [n.id for n in nodes[:20]],
    }


@router.get("/ingest/excel/template")
def download_excel_template():
    """Download a pre-filled Excel template for metadata upload."""
    xlsx_bytes = generate_excel_template()
    return FileResp(
        content=xlsx_bytes,
        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": 'attachment; filename="datadna_metadata_template.xlsx"'},
    )




@router.patch("/field/{field_id:path}/description")
def update_field_description(field_id: str, payload: dict):
    """Manually update a field description."""
    f = graph.get_field(field_id)
    if not f:
        raise HTTPException(404, detail="Field not found")
    f.description = payload.get("description","")
    graph.add_field(f)
    persistence.save_node(f.model_dump())
    return {"field_id": field_id, "description": f.description}

@router.post("/field/{field_id:path}/describe")
def auto_describe_field(field_id: str):
    """Auto-generate description — uses AI if configured, rule-based otherwise."""
    from app.ai.provider import ask_ai, AIConfig
    f = graph.get_field(field_id)
    if not f:
        raise HTTPException(404, detail=f"Field not found: {field_id}")

    desc = None

    # Try AI first
    if AIConfig.is_configured():
        try:
            prompt = (
                f"Credit/banking domain expert. One sentence business description for:\n"
                f"Column: {f.column}, Table: {f.table}, System: {f.system}, "
                f"Type: {f.data_type or 'unknown'}. Return ONLY the description."
            )
            desc = ask_ai(prompt, max_tokens=100)
            if desc:
                desc = desc.strip().strip('"').strip("'")
        except Exception:
            desc = None

    # Always fallback to rule-based if AI not available or failed
    if not desc:
        desc = _rule_description(f.system, f.table, f.column, f.data_type)

    if desc:
        f.description = desc
        graph.add_field(f)
        try:
            persistence.save_node(f.model_dump())
        except Exception as e:
            pass  # Don't fail if persistence has an issue

    return {"field_id": field_id, "description": f.description, "method": "ai" if AIConfig.is_configured() else "rule_based"}


@router.post("/fields/describe-all")
def describe_all_fields(system: str = None):
    """Bulk AI-generate descriptions for all fields that have none."""
    from app.ai.provider import ask_ai, AIConfig
    fields = graph.list_fields(system=system)
    enriched, skipped, failed = 0, 0, 0
    for f in fields:
        if f.description and f.description.strip():
            skipped += 1
            continue
        # Rule-based fallback if no AI
        if not AIConfig.is_configured():
            f.description = _rule_description(f.system, f.table, f.column, f.data_type)
            graph.add_field(f)
            persistence.save_node(f.model_dump())
            enriched += 1
            continue
        prompt = (
            f"You are a credit/banking data domain expert. Write ONE concise sentence "
            f"describing the business purpose of this database column:\n"
            f"System: {f.system}\nTable: {f.table}\nColumn: {f.column}\n"
            f"Data type: {f.data_type or 'unknown'}\n"
            f"Domain context: Credit lending platform (CBS, risk engine, MIS reporting).\n"
            f"Return ONLY the description sentence."
        )
        desc = ask_ai(prompt, max_tokens=100)
        if desc and desc.strip():
            f.description = desc.strip().strip('"').strip("'")
            graph.add_field(f)
            persistence.save_node(f.model_dump())
            enriched += 1
        else:
            # fallback to rule-based
            f.description = _rule_description(f.system, f.table, f.column, f.data_type)
            if f.description:
                graph.add_field(f)
                persistence.save_node(f.model_dump())
                enriched += 1
            else:
                failed += 1
    return {"enriched": enriched, "already_had_description": skipped, "failed": failed, "total": len(fields)}


def _rule_description(system: str, table: str, column: str, dtype: str) -> str:
    """
    Rule-based description generator — produces meaningful descriptions
    without any AI. Covers 95%+ of credit/banking column naming patterns.
    """
    col = column.upper()
    tbl = table.upper()

    # ── Exact column matches (highest priority) ──────────────────────────
    EXACT = {
        'CUST_ID':          'Unique customer identifier — primary key linking all customer data across systems.',
        'CUSTOMER_ID':      'Customer identifier — foreign key reference to the customer master record.',
        'CLIENT_ID':        'Client identifier used in reporting systems — maps to CBS customer ID.',
        'ACCT_ID':          'Unique loan account number in the core banking system.',
        'ACCOUNT_ID':       'Loan account identifier — links to the CBS account master.',
        'APP_ID':           'Loan application identifier in the origination system.',
        'TXN_ID':           'Unique transaction reference number for audit and reconciliation.',
        'BRANCH_CODE':      'Branch code identifying the home branch for this account or customer.',
        'PAN_NUMBER':       'Permanent Account Number (PAN) — mandatory tax identifier for KYC and loans above Rs 2 lakh.',
        'AADHAAR_NO':       'Aadhaar number used for biometric eKYC verification.',
        'EMAIL':            'Customer email address for digital statements, NOC delivery and regulatory notices.',
        'MOBILE':           'Primary mobile number for OTP authentication, NACH registration and payment alerts.',
        'ALT_MOBILE':       'Alternate mobile number for collections contact and emergency communication.',
        'DOB':              'Date of birth — used for age verification, loan eligibility and insurance linkage.',
        'GENDER':           'Customer gender — used for demographic segmentation and scheme eligibility.',
        'CUST_NAME':        'Full legal name of the customer as per KYC documents.',
        'FIRST_NAME':       'Customer first name from legal KYC documents.',
        'LAST_NAME':        'Customer last name / surname from legal KYC documents.',
        'CLIENT_NAME':      'Customer display name for management reports (masked in analytics).',
        'FULL_NAME':        'Complete legal name of the customer.',
        'SANCTION_AMT':     'Loan amount sanctioned and approved by the credit committee.',
        'DISBURSED_AMT':    'Total loan amount actually disbursed to the borrower.',
        'OUTSTANDING_BAL':  'Current outstanding principal balance on the loan account.',
        'OVERDUE_AMT':      'Amount overdue beyond the scheduled due date — primary collections trigger.',
        'EMI_AMT':          'Fixed monthly EMI amount as per the loan amortisation schedule.',
        'INTEREST_RATE':    'Annual interest rate applicable on the loan account.',
        'CREDIT_LIMIT':     'Approved credit limit for revolving facilities (CC/OD).',
        'UTILIZED_AMT':     'Amount currently utilised against the approved credit limit.',
        'AVAILABLE_LIMIT':  'Undrawn balance available for drawdown = credit limit minus utilised amount.',
        'COMPOSITE_SCORE':  'Weighted composite credit score combining bureau and internal behavioural models.',
        'BUREAU_SCORE':     'External credit bureau score from CIBIL/Experian/Equifax.',
        'INTERNAL_SCORE':   'Internally developed behavioural score based on repayment and transaction history.',
        'CREDIT_SCORE':     'Final credit score reported in MIS — sourced from the risk engine.',
        'PD_SCORE':         'Probability of Default — statistical likelihood of 90+ DPD in the next 12 months.',
        'LGD_PCT':          'Loss Given Default — estimated percentage of EAD that will not be recovered on default.',
        'EAD_AMT':          'Exposure at Default — total credit amount at risk at time of potential default.',
        'EXPECTED_LOSS':    'Expected Loss = PD × LGD × EAD — minimum provisioning requirement per Basel norms.',
        'NPA_FLAG':         'Y/N flag indicating Non-Performing Asset classification per RBI guidelines.',
        'NPA_DATE':         'Date when the account was first classified as Non-Performing Asset.',
        'NPA_DT':           'Date when the account was first classified as Non-Performing Asset.',
        'NPA_PCT':          'NPA percentage = NPA outstanding / total outstanding × 100 — headline asset quality metric.',
        'GNPA_PCT':         'Gross NPA percentage before provisioning — mandatory RBI quarterly disclosure metric.',
        'NNPA_PCT':         'Net NPA percentage after provisions — key indicator of bank financial health.',
        'PROVISION_AMT':    'Regulatory provision held against NPA accounts per RBI classification norms.',
        'PCR_PCT':          'Provision Coverage Ratio = provision / gross NPA × 100 — adequacy of provisions.',
        'WRITE_OFF_AMT':    'Amount written off from books after exhausting all recovery options.',
        'RECOVERY_AMT':     'Amount recovered post write-off through negotiated settlements or legal action.',
        'DPD_30':           'Number of days the account was 30+ days past due — early delinquency signal.',
        'DPD_60':           'Number of days the account was 60+ days past due — elevated delinquency.',
        'DPD_90':           'Number of days the account was 90+ days past due — NPA trigger threshold.',
        'MAX_DPD':          'Maximum days past due observed across all accounts in the last 12 months.',
        'CURRENT_DPD':      'Current days past due on the most delinquent active account.',
        'FOIR':             'Fixed Obligation to Income Ratio — total monthly EMI obligations as percentage of income.',
        'UTILIZATION_PCT':  'Credit utilisation percentage = utilised amount / credit limit × 100.',
        'OVERALL_UTIL_PCT': 'Overall utilisation across all revolving facilities — stress indicator.',
        'TENURE_MONTHS':    'Original loan tenure in months as per the sanction letter.',
        'REMAINING_TENURE': 'Remaining months to loan maturity based on actual repayment track.',
        'OPEN_DT':          'Date when the loan account was opened and first disbursement was made.',
        'MATURITY_DT':      'Scheduled loan maturity date as per original sanction terms.',
        'LAST_PAYMENT_DT':  'Date on which the most recent EMI payment was received.',
        'NEXT_DUE_DT':      'Next EMI due date — used for delinquency monitoring and NACH triggers.',
        'KYC_STATUS':       'KYC verification status: VERIFIED, PENDING, EXPIRED or RE_KYC_DUE.',
        'KYC_DT':           'Date when KYC was last completed — drives re-KYC calendar alerts.',
        'ACCT_STATUS':      'Account lifecycle status: ACTIVE, CLOSED, NPA, WRITTEN_OFF or RESTRUCTURED.',
        'CUST_STATUS':      'Customer lifecycle status: ACTIVE, DORMANT, DECEASED or BLACKLISTED.',
        'CUST_SEGMENT':     'Customer segment classification: RETAIL, HNI, PRIORITY, SME or CORPORATE.',
        'MONTHLY_INCOME':   'Declared monthly take-home income — primary input for FOIR calculation.',
        'ANNUAL_INCOME':    'Total annual income from all sources as declared at onboarding.',
        'OCCUPATION':       'Customer occupation type: SALARIED, SELF_EMPLOYED, BUSINESS or RETIRED.',
        'EMPLOYER_NAME':    'Name of current employer — used for income verification and employer risk.',
        'SCORE_BAND':       'Risk band mapped from composite score: A+, A, B, C, D — drives pricing and limits.',
        'RISK_APPETITE':    'Customer risk classification: LOW, MEDIUM, HIGH or VERY_HIGH.',
        'WATCHLIST_FLAG':   'Y if customer is on risk watchlist requiring enhanced monitoring.',
        'EARLY_WARNING':    'Y if active early warning signals are triggered — initiates proactive intervention.',
        'COLLATERAL_TYPE':  'Type of collateral securing the loan: PROPERTY, VEHICLE, SECURITIES or GOLD.',
        'COLLATERAL_VALUE': 'Current market valuation of collateral pledged against the loan.',
        'LTV_RATIO':        'Loan-to-Value ratio = outstanding balance / collateral market value × 100.',
        'NIM_PCT':          'Net Interest Margin = yield minus cost of funds — core banking profitability metric.',
        'YIELD_PCT':        'Portfolio yield = interest income / average outstanding × 100.',
        'RESTRUCTURED_FLAG':'Y/N flag indicating the loan was restructured under OTR or COVID relief scheme.',
        'SMA_CATEGORY':     'Special Mention Account category per RBI: SMA-0, SMA-1 or SMA-2.',
        'PRINCIPAL_COMP':   'Principal component of the EMI payment — reduces outstanding loan balance.',
        'INTEREST_COMP':    'Interest component of the EMI payment — revenue recognised by the bank.',
        'PENALTY_COMP':     'Penal interest and late payment charges component of the transaction.',
        'PRODUCT_TYPE':     'Loan product type: HOME_LOAN, PERSONAL_LOAN, AUTO_LOAN, CREDIT_CARD or LAP.',
        'PRODUCT_CODE':     'Internal product code identifying the specific loan scheme variant.',
        'RATE_TYPE':        'Interest rate type: FIXED or FLOATING (linked to MCLR, EBLR or REPO rate).',
        'CHANNEL':          'Transaction or origination channel: BRANCH, ONLINE, DSA, MOBILE or NACH.',
        'REGION':           'Geographic region for portfolio analysis and regional management reporting.',
        'CITY':             'City of residence — used for geographic credit heat maps and branch attribution.',
        'STATE':            'State of residence — used for state-wise portfolio analysis and compliance.',
        'PINCODE':          'Postal code for geographic credit analysis and bureau query normalisation.',
        'SCORE_DT':         'Date when risk scoring was last computed — triggers re-score if stale.',
        'MODEL_VERSION':    'Scoring model version identifier — required for model governance and back-testing.',
        'REPORT_DT':        'As-of date for which this report snapshot or metric was computed.',
        'AS_OF_DT':         'Date as of which this exposure or risk summary was calculated.',
        'RM_ID':            'Relationship Manager identifier assigned for HNI and priority customers.',
        'CREATED_DT':       'System timestamp when this record was first created.',
        'MODIFIED_DT':      'Timestamp of the most recent update to this record.',
        'CREATED_BY':       'User ID of the operator who created this record in the system.',
        'MODIFIED_BY':      'User ID of the operator who last modified this record.',
        'BATCH_ID':         'Batch processing run identifier — groups transactions from the same EOD run.',
        'REF_NO':           'External reference number (UTR/NACH/clearing) for reconciliation purposes.',
        'TOTAL_OUTSTANDING':'Total outstanding principal across all active loan accounts.',
        'TOTAL_SANCTION':   'Sum of all sanctioned loan amounts across the customer portfolio.',
        'TOTAL_EMI':        'Total monthly EMI obligations across all active accounts.',
        'TOTAL_PROVISION':  'Aggregate regulatory provision held across the customer portfolio.',
        'ACTIVE_ACCOUNTS':  'Count of accounts currently in active repayment status.',
        'TOTAL_ACCOUNTS':   'Total number of loan accounts including active and closed.',
        'NPA_ACCOUNTS':     'Number of accounts classified as Non-Performing Assets.',
        'DISBURSEMENTS':    'New loan disbursements in the reporting period — business growth metric.',
        'COLLECTIONS':      'Total collections (EMI and overdue) received in the reporting period.',
        'TARGET_ACHV_PCT':  'Disbursement target achievement percentage — basis for branch manager MBO.',
        'COLLECTION_EFF':   'Collection efficiency = amount collected / amount demanded × 100.',
        'TXN_AMT':          'Transaction amount — positive for receipts, negative for debits.',
        'TXN_DT':           'Exact timestamp when the transaction was executed and posted.',
        'TXN_TYPE':         'Transaction type: EMI_RECEIPT, PREPAYMENT, DISBURSEMENT, CHARGE or REVERSAL.',
        'VALUE_DT':         'Value date for interest calculation — may differ from transaction posting date.',
        'STATUS':           'Current processing or lifecycle status of this record.',
        'REMARKS':          'Free-text remarks entered by the operator at time of transaction.',
        'LOAN_PURPOSE':     'Declared purpose of the loan: HOME_PURCHASE, EDUCATION, MEDICAL or BUSINESS.',
        'NATIONAL_ID':      'National identity number for regulatory and KYC compliance.',
        'NATIONALITY':      'Customer nationality — required for FEMA and cross-border transaction compliance.',
        'RESIDENT_TYPE':    'Residential status: RESIDENT_INDIAN, NRI, PIO or OCI.',
        'SPREAD':           'Spread over benchmark rate specific to this borrower risk profile.',
        'BENCHMARK_RATE':   'Benchmark rate (REPO/MCLR) on which the floating interest rate is anchored.',
    }

    if col in EXACT:
        return EXACT[col]

    # ── Pattern matching (suffix/prefix) ─────────────────────────────────
    name = col.replace('_', ' ').lower().strip()
    pretty = name.title()

    if col.endswith('_ID'):
        entity = col[:-3].replace('_', ' ').title()
        return f"Unique identifier for {entity} — primary/foreign key reference."
    if col.endswith('_KEY'):
        entity = col[:-4].replace('_', ' ').title()
        return f"Surrogate key for {entity} in the data warehouse dimension table."
    if col.endswith('_AMT') or col.endswith('_AMOUNT'):
        entity = col.replace('_AMT','').replace('_AMOUNT','').replace('_',' ').lower()
        return f"Monetary amount for {entity} — stored in INR to two decimal places."
    if col.endswith('_BAL') or col.endswith('_BALANCE'):
        entity = col.replace('_BAL','').replace('_BALANCE','').replace('_',' ').lower()
        return f"Current {entity} balance amount maintained in the system."
    if col.endswith('_DT') or col.endswith('_DATE'):
        entity = col.replace('_DT','').replace('_DATE','').replace('_',' ').lower()
        return f"Date of the {entity} event — stored as DATE for reporting and SLA tracking."
    if col.endswith('_FLAG') or col.endswith('_IND'):
        entity = col.replace('_FLAG','').replace('_IND','').replace('_',' ').lower()
        return f"Boolean indicator (Y/N) for {entity} — used in filtering and eligibility rules."
    if col.endswith('_PCT') or col.endswith('_PERCENT') or col.endswith('_RATIO'):
        entity = col.replace('_PCT','').replace('_PERCENT','').replace('_RATIO','').replace('_',' ').lower()
        return f"Percentage value for {entity} — expressed as decimal (e.g. 12.50 for 12.5%)."
    if col.endswith('_STATUS') or col.endswith('_STATE'):
        entity = col.replace('_STATUS','').replace('_STATE','').replace('_',' ').lower()
        return f"Current {entity} status code — valid values defined in the reference data table."
    if col.endswith('_COUNT') or col.endswith('_CNT') or col.endswith('_NO'):
        entity = col.replace('_COUNT','').replace('_CNT','').replace('_NO','').replace('_',' ').lower()
        return f"Count of {entity} records — used for frequency analysis and policy checks."
    if col.endswith('_CODE') or col.endswith('_CD'):
        entity = col.replace('_CODE','').replace('_CD','').replace('_',' ').lower()
        return f"Lookup code for {entity} — maps to the {entity} reference master table."
    if col.endswith('_NAME') or col.endswith('_NM'):
        entity = col.replace('_NAME','').replace('_NM','').replace('_',' ').lower()
        return f"Name of the {entity} — used for display and reporting purposes."
    if col.endswith('_TYPE') or col.endswith('_CATEGORY') or col.endswith('_CAT'):
        entity = col.replace('_TYPE','').replace('_CATEGORY','').replace('_CAT','').replace('_',' ').lower()
        return f"Classification type for {entity} — determines applicable business rules and rates."
    if col.endswith('_DESC') or col.endswith('_DESCRIPTION') or col.endswith('_REMARKS'):
        entity = col.replace('_DESC','').replace('_DESCRIPTION','').replace('_REMARKS','').replace('_',' ').lower()
        return f"Free-text description or remarks for {entity}."
    if col.endswith('_3M') or col.endswith('_6M') or col.endswith('_12M'):
        period = col.split('_')[-1]
        base = col[:-(len(period)+1)].replace('_',' ').lower()
        return f"Rolling {period} average of {base} — used for trend analysis."
    if col.startswith('IS_') or col.startswith('HAS_'):
        rest = col[3:].replace('_',' ').lower()
        return f"Boolean flag indicating whether {rest} applies to this record."
    if col.startswith('TOTAL_'):
        rest = col[6:].replace('_',' ').lower()
        return f"Aggregated total of {rest} — summed across multiple accounts or periods."
    if col.startswith('MAX_') or col.startswith('MIN_') or col.startswith('AVG_'):
        fn = col[:3].lower()
        rest = col[4:].replace('_',' ').lower()
        return f"{'Maximum' if fn=='max' else 'Minimum' if fn=='min' else 'Average'} {rest} — computed metric."
    if col.startswith('NUM_') or col.startswith('CNT_'):
        rest = col[4:].replace('_',' ').lower()
        return f"Count of {rest} records."

    # ── Keyword-based ─────────────────────────────────────────────────────
    if 'DPD' in col:        return f"Days Past Due metric — measures delinquency depth for {pretty}."
    if 'NPA' in col:        return f"Non-Performing Asset indicator — per RBI classification norms."
    if 'SCORE' in col:      return f"Numeric score for {pretty} — input to credit decisioning model."
    if 'PROVISION' in col:  return f"Regulatory provision amount held against credit losses."
    if 'INCOME' in col:     return f"Income value for {pretty} — used in eligibility and FOIR calculations."
    if 'COLLATERAL' in col: return f"Collateral information for {pretty} — secures the loan obligation."
    if 'INTEREST' in col:   return f"Interest-related value for {pretty}."
    if 'PAYMENT' in col:    return f"Payment information for {pretty} — EMI or settlement tracking."
    if 'LIMIT' in col:      return f"Credit limit value for {pretty} — controls maximum exposure."
    if 'OVERDUE' in col:    return f"Overdue amount or indicator — triggers collections workflow."
    if 'RECOVERY' in col:   return f"Recovery value for {pretty} — post write-off collection tracking."
    if 'BUREAU' in col:     return f"Credit bureau data for {pretty} — sourced from CIBIL/Experian."
    if 'REGION' in col:     return f"Geographic region for {pretty} — enables regional rollup reporting."

    # ── Generic fallback ─────────────────────────────────────────────────
    table_readable = tbl.replace('_', ' ').title()
    return f"{pretty} — attribute of the {table_readable} entity in the {system} system."


@router.post("/fields/describe-table")
def describe_table_fields(system: str, table: str, overwrite: bool = False):
    """Describe all fields in a specific table."""
    from app.ai.provider import ask_ai, AIConfig
    all_fields = graph.list_fields(system=system)
    table_fields = [f for f in all_fields if f.table.upper() == table.upper()]
    if not table_fields:
        raise HTTPException(404, detail=f"No fields found for {system}.{table}")
    enriched, skipped = 0, 0
    for f in table_fields:
        if f.description and f.description.strip() and not overwrite:
            skipped += 1; continue
        desc = None
        if AIConfig.is_configured():
            prompt = (f"Credit banking expert: one sentence describing '{f.column}' "
                      f"in table '{f.table}' system '{f.system}' type '{f.data_type or 'unknown'}'. "
                      f"Return only the description.")
            desc = ask_ai(prompt, max_tokens=100)
        if not desc:
            desc = _rule_description(f.system, f.table, f.column, f.data_type)
        if desc:
            f.description = desc.strip().strip('"').strip("'")
            graph.add_field(f)
            persistence.save_node(f.model_dump())
            enriched += 1
    return {"system": system, "table": table, "enriched": enriched,
            "skipped": skipped, "total": len(table_fields)}


@router.post("/fields/describe-selected")
def describe_selected_fields(field_ids: list, overwrite: bool = False):
    """Describe a specific list of field IDs."""
    from app.ai.provider import ask_ai, AIConfig
    enriched, not_found, skipped = 0, 0, 0
    for fid in field_ids:
        f = graph.get_field(fid)
        if not f:
            not_found += 1; continue
        if f.description and f.description.strip() and not overwrite:
            skipped += 1; continue
        desc = None
        if AIConfig.is_configured():
            prompt = (f"Credit banking expert: one sentence describing '{f.column}' "
                      f"in '{f.table}' system '{f.system}'. Return only the description.")
            desc = ask_ai(prompt, max_tokens=100)
        if not desc:
            desc = _rule_description(f.system, f.table, f.column, f.data_type)
        if desc:
            f.description = desc.strip().strip('"').strip("'")
            graph.add_field(f)
            persistence.save_node(f.model_dump())
            enriched += 1
    return {"enriched": enriched, "skipped": skipped,
            "not_found": not_found, "total": len(field_ids)}


@router.get("/systems/summary")
def systems_summary():
    """Get per-system table list with field counts for the describe panel."""
    all_fields = graph.list_fields()
    result = {}
    for f in all_fields:
        sys = f.system
        tbl = f.table
        if sys not in result:
            result[sys] = {"system": sys, "tables": {}, "total": 0,
                           "described": 0, "pii": 0}
        if tbl not in result[sys]["tables"]:
            result[sys]["tables"][tbl] = {"table": tbl, "fields": 0,
                                           "described": 0, "pii": 0}
        result[sys]["total"] += 1
        result[sys]["tables"][tbl]["fields"] += 1
        if f.description and f.description.strip():
            result[sys]["described"] += 1
            result[sys]["tables"][tbl]["described"] += 1
        if f.pii:
            result[sys]["pii"] += 1
            result[sys]["tables"][tbl]["pii"] += 1
    # Convert tables dict to list
    for sys in result:
        result[sys]["tables"] = list(result[sys]["tables"].values())
    return list(result.values())


@router.post("/reseed")
def force_reseed():
    """Force re-seed with extended data — use when field count is low."""
    from app.services.ingestion import ingestion_service
    before = graph.stats()["total_fields"]
    ingestion_service.seed_extended_data()
    # Persist new fields
    for node in graph.list_fields():
        persistence.save_node(node.model_dump())
    for edge in graph._edges.values():
        persistence.save_edge(edge.model_dump())
    after = graph.stats()
    return {"before": before, "after": after["total_fields"],
            "added": after["total_fields"] - before,
            "systems": after["systems"]}


@router.post("/map")
def map_fields(payload: dict):
    """
    Manually map source field → target field when names differ.
    
    Example: CBS.CBS_CUSTOMER.CUST_ID → RISK.RISK_CUSTOMER_SCORE.CUSTOMER_ID
    
    Body:
    {
        "source_field": "CBS.CBS_CUSTOMER.CUST_ID",
        "target_field": "RISK.RISK_CUSTOMER_SCORE.CUSTOMER_ID",
        "transformation_type": "renamed",
        "transformation_logic": "CUST_ID renamed to CUSTOMER_ID in risk engine",
        "notes": "Optional notes"
    }
    """
    from app.models.lineage import LineageEdge, SourceType, TransformationType

    src = payload.get("source_field", "").strip()
    tgt = payload.get("target_field", "").strip()

    if not src or not tgt:
        raise HTTPException(400, detail="source_field and target_field are required")

    if src == tgt:
        raise HTTPException(400, detail="source and target cannot be the same field")

    # Validate both fields exist
    src_node = graph.get_field(src)
    tgt_node = graph.get_field(tgt)

    errors = []
    if not src_node:
        errors.append(f"Source field not found: {src}")
    if not tgt_node:
        errors.append(f"Target field not found: {tgt}")
    if errors:
        raise HTTPException(404, detail=" | ".join(errors))

    # Map transformation type string
    ttype_map = {
        "direct":      TransformationType.DIRECT,
        "renamed":     TransformationType.RENAMED,
        "aggregated":  TransformationType.AGGREGATED,
        "derived":     TransformationType.DERIVED,
        "filtered":    TransformationType.FILTERED,
        "joined":      TransformationType.JOINED,
    }
    raw_type = payload.get("transformation_type", "direct").lower()
    ttype = ttype_map.get(raw_type, TransformationType.DIRECT)

    logic = payload.get("transformation_logic", "") or payload.get("notes", "") or f"{src.split('.')[-1]} → {tgt.split('.')[-1]}"

    edge = LineageEdge(
        id=str(__import__("uuid").uuid4()),
        source_field=src,
        target_field=tgt,
        transformation_type=ttype,
        transformation_logic=logic,
        source_type=SourceType.AUTHORITATIVE,
        confidence=1.0,
        system_boundary=src.split(".")[0] != tgt.split(".")[0],
    )

    try:
        graph.add_lineage(edge)
        persistence.save_edge(edge.model_dump())
    except ValueError as ex:
        raise HTTPException(409, detail=f"Mapping conflict: {ex}")

    return {
        "success": True,
        "edge_id": edge.id,
        "source_field": src,
        "target_field": tgt,
        "transformation_type": raw_type,
        "logic": logic,
        "message": f"Mapped {src.split('.')[-1]} → {tgt.split('.')[-1]} ({raw_type})",
    }


@router.get("/map/suggest")
def suggest_mappings(
    source_system: str,
    target_system: str,
    threshold: float = 0.6,
):
    """
    Suggest field mappings between two systems based on name similarity.
    Returns candidates sorted by match score — useful before manual mapping.
    """
    from difflib import SequenceMatcher

    src_fields = graph.list_fields(system=source_system)
    tgt_fields = graph.list_fields(system=target_system)

    if not src_fields:
        raise HTTPException(404, detail=f"No fields for {source_system}")
    if not tgt_fields:
        raise HTTPException(404, detail=f"No fields for {target_system}")

    suggestions = []
    for sf in src_fields:
        best_score = 0
        best_match = None
        best_reason = ""

        for tf in tgt_fields:
            # Exact match
            if sf.column.upper() == tf.column.upper():
                score, reason = 1.0, "exact name match"
            else:
                # Name similarity
                name_sim = SequenceMatcher(None, sf.column.lower(), tf.column.lower()).ratio()
                # Type match bonus
                type_bonus = 0.1 if sf.data_type and tf.data_type and sf.data_type == tf.data_type else 0
                score = name_sim + type_bonus
                reason = f"name similarity {name_sim:.0%}"
                if type_bonus:
                    reason += " + same data type"

            if score > best_score:
                best_score = score
                best_match = tf
                best_reason = reason

        if best_match and best_score >= threshold:
            # Check if already mapped
            already_mapped = any(
                e.source_field == sf.id and e.target_field == best_match.id
                for e in graph._edges.values()
            )
            suggestions.append({
                "source_field": sf.id,
                "source_column": sf.column,
                "target_field": best_match.id,
                "target_column": best_match.column,
                "score": round(best_score, 3),
                "reason": best_reason,
                "already_mapped": already_mapped,
                "suggested_type": "renamed" if sf.column.upper() != best_match.column.upper() else "direct",
            })

    suggestions.sort(key=lambda x: x["score"], reverse=True)
    return {
        "source_system": source_system,
        "target_system": target_system,
        "threshold": threshold,
        "suggestions": suggestions[:100],
        "total": len(suggestions),
    }

@router.post("/fix-dag")
def fix_dag():
    """
    Remove all cycle-causing edges from the graph and DB.
    Call this if DAG shows X in the UI.
    """
    import networkx as nx
    import logging
    log = logging.getLogger(__name__)

    before = graph.stats()
    all_edges = list(graph._edges.values())

    # Rebuild graph edge by edge, skipping cycles
    import networkx as nx
    G = nx.DiGraph()
    G.add_nodes_from(graph._graph.nodes())

    kept, removed = [], []
    for e in sorted(all_edges, key=lambda x: (x.source_type.value, -x.confidence)):
        G.add_edge(e.source_field, e.target_field)
        if not nx.is_directed_acyclic_graph(G):
            G.remove_edge(e.source_field, e.target_field)
            removed.append(e)
        else:
            kept.append(e)

    # Rebuild graph._edges and graph._graph
    graph._edges = {e.id: e for e in kept}
    graph._graph = G

    # Remove bad edges from persistence
    for e in removed:
        try:
            from tinydb import Query
            F = Query()
            persistence._edges.remove(F.id == e.id)
        except Exception:
            pass

    after = graph.stats()
    log.info(f"fix-dag: removed {len(removed)} cycle-causing edges")

    return {
        "fixed": True,
        "edges_before": before["total_edges"],
        "edges_after": after["total_edges"],
        "removed": len(removed),
        "removed_edges": [{"source": e.source_field, "target": e.target_field} for e in removed],
        "is_dag": after["is_dag"],
    }
