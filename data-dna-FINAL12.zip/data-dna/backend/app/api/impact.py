"""Impact analysis API endpoints."""
from fastapi import APIRouter, HTTPException
from app.core.graph import graph
from app.models.lineage import ImpactResult

router = APIRouter(prefix="/impact", tags=["impact"])


@router.get("/{field_id:path}", response_model=ImpactResult)
def get_impact(field_id: str):
    """
    What downstream fields are affected if this field changes?
    Returns affected fields, cross-system impacts, and risk level.
    """
    try:
        return graph.get_impact(field_id)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=str(e))
