"""Search API endpoints."""
from fastapi import APIRouter, HTTPException
from app.ai.nl_search import search_engine
from app.ai.resolver import resolver
from app.core.graph import graph
from app.models.search import SearchRequest, SearchResponse, AliasGroup
from typing import List

router = APIRouter(prefix="/search", tags=["search"])


@router.post("/", response_model=SearchResponse)
def search(request: SearchRequest):
    """Natural language search over the field catalog."""
    return search_engine.search(request)


@router.get("/aliases", response_model=List[AliasGroup])
def get_aliases(system: str = None):
    """Detect alias/synonym groups across systems using AI."""
    fields = graph.list_fields(system=system)
    if not fields:
        return []
    return resolver.resolve_aliases(fields)
