"""Chat API endpoint."""
from fastapi import APIRouter
from pydantic import BaseModel
from typing import List, Dict, Optional
from app.ai.chat import chat

router = APIRouter(prefix="/chat", tags=["chat"])


class ChatRequest(BaseModel):
    message: str
    history: List[Dict] = []
    field_id: Optional[str] = None


@router.post("/")
def chat_endpoint(req: ChatRequest):
    response = chat(req.message, req.history, req.field_id)
    return {"response": response, "field_id": req.field_id}
