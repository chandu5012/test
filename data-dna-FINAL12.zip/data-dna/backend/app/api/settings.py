"""Settings API — AI provider config, persistence stats."""
from fastapi import APIRouter
from pydantic import BaseModel
from typing import Optional
from app.ai.provider import AIConfig, AIProvider

router = APIRouter(prefix="/settings", tags=["settings"])


class AIProviderConfig(BaseModel):
    provider: AIProvider
    api_key: Optional[str] = ""
    model: Optional[str] = ""
    base_url: Optional[str] = ""


@router.post("/ai-provider")
def configure_ai(config: AIProviderConfig):
    """Configure which AI provider to use."""
    AIConfig.configure(
        provider=config.provider,
        api_key=config.api_key or "",
        model=config.model or "",
        base_url=config.base_url or "",
    )
    return {"status": "configured", **AIConfig.status()}


@router.get("/ai-provider")
def get_ai_status():
    """Get current AI provider status."""
    return AIConfig.status()


@router.get("/providers")
def list_providers():
    """List all supported AI providers with setup instructions."""
    return {
        "providers": [
            {"id": "anthropic", "name": "Anthropic Claude",
             "models": ["claude-sonnet-4-20250514", "claude-haiku-4-5-20251001"],
             "key_url": "https://console.anthropic.com/"},
            {"id": "openai", "name": "OpenAI GPT",
             "models": ["gpt-4o", "gpt-4o-mini", "gpt-3.5-turbo"],
             "key_url": "https://platform.openai.com/api-keys"},
            {"id": "gemini", "name": "Google Gemini",
             "models": ["gemini-1.5-pro", "gemini-1.5-flash"],
             "key_url": "https://aistudio.google.com/app/apikey"},
            {"id": "github_copilot", "name": "GitHub Copilot",
             "models": ["gpt-4o", "gpt-4o-mini"],
             "key_url": "https://github.com/settings/tokens"},
            {"id": "ollama", "name": "Ollama (Local, Free)",
             "models": ["llama3", "mistral", "phi3", "codellama"],
             "key_url": "https://ollama.com/download"},
            {"id": "none", "name": "No AI (Rule-based)",
             "models": [],
             "key_url": ""},
        ]
    }
