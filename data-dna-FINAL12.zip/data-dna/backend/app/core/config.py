from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    app_name: str = "Data-DNA"
    anthropic_api_key: str = ""
    graph_persist_path: str = "lineage_graph.json"
    log_level: str = "INFO"

    class Config:
        env_file = ".env"

settings = Settings()
