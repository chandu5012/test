"""
LineageGraph: Core graph store using NetworkX.
Manages all field nodes and lineage edges.
Strictly separates authoritative vs inferred edges.
"""
import json
import time
import uuid
from typing import List, Optional, Dict, Any, Tuple
import networkx as nx

from app.models.lineage import (
    FieldNode, LineageEdge, LineagePath, ImpactResult,
    AuditEntry, SourceType, TransformationType
)


class LineageGraph:
    """
    Directed graph where:
    - Nodes = FieldNode (system.table.column)
    - Edges = LineageEdge (transformation with metadata)
    
    Key invariant: authoritative edges always take precedence.
    AI-inferred edges are stored separately and never override authoritative ones.
    """

    def __init__(self):
        self._graph = nx.DiGraph()
        self._nodes: Dict[str, FieldNode] = {}
        self._edges: Dict[str, LineageEdge] = {}

    # ─── Node Operations ────────────────────────────────────────────────────

    def add_field(self, node: FieldNode) -> FieldNode:
        """Add or update a field node. Idempotent."""
        self._nodes[node.id] = node
        self._graph.add_node(node.id, **node.model_dump())
        return node

    def get_field(self, field_id: str) -> Optional[FieldNode]:
        return self._nodes.get(field_id)

    def list_fields(self, system: Optional[str] = None) -> List[FieldNode]:
        fields = list(self._nodes.values())
        if system:
            fields = [f for f in fields if f.system == system]
        return fields

    # ─── Edge Operations ────────────────────────────────────────────────────

    def add_lineage(self, edge: LineageEdge) -> LineageEdge:
        """
        Add a lineage edge.
        Rejects self-loops, duplicate edges, and cycle-creating edges.
        If an authoritative edge already exists between the same pair,
        inferred edges are stored but flagged as superseded.
        """
        import logging
        _log = logging.getLogger(__name__)

        # Reject self-loops
        if edge.source_field == edge.target_field:
            return edge

        # Validate nodes exist (add as stubs if missing — for flexibility)
        for fid in (edge.source_field, edge.target_field):
            if fid not in self._nodes:
                self._graph.add_node(fid)

        # Reject duplicate edges (same src→tgt already exists)
        if self._get_edge(edge.source_field, edge.target_field):
            return edge

        # Check for existing authoritative edge
        existing = self._get_edge(edge.source_field, edge.target_field)
        if existing and existing.source_type == SourceType.AUTHORITATIVE:
            if edge.source_type == SourceType.INFERRED:
                edge.metadata["superseded_by_authoritative"] = True

        # Cycle guard — test before committing
        self._graph.add_edge(
            edge.source_field,
            edge.target_field,
            edge_id=edge.id,
            source_type=edge.source_type.value,
            confidence=edge.confidence,
        )
        if not nx.is_directed_acyclic_graph(self._graph):
            self._graph.remove_edge(edge.source_field, edge.target_field)
            _log.warning(
                f"Edge REJECTED — would create a cycle: "
                f"{edge.source_field} -> {edge.target_field}"
            )
            return edge

        self._edges[edge.id] = edge
        return edge

    def _get_edge(self, src: str, tgt: str) -> Optional[LineageEdge]:
        for e in self._edges.values():
            if e.source_field == src and e.target_field == tgt:
                return e
        return None

    # ─── Lineage Traversal ──────────────────────────────────────────────────

    def get_lineage(
        self,
        field_id: str,
        hops: int = 3,
        direction: str = "upstream",
        include_inferred: bool = True,
    ) -> LineagePath:
        """
        Traverse the lineage graph from a field node.
        direction: "upstream" (ancestors) | "downstream" (descendants) | "both"
        """
        if field_id not in self._nodes:
            raise ValueError(f"Field not found: {field_id}")

        visited_nodes = set()
        visited_edges = []

        def traverse(node_id: str, depth: int, graph: nx.DiGraph):
            if depth == 0 or node_id in visited_nodes:
                return
            visited_nodes.add(node_id)
            for neighbor in graph.neighbors(node_id):
                edge_data = graph.get_edge_data(node_id, neighbor)
                edge_id = edge_data.get("edge_id")
                edge = self._edges.get(edge_id)
                if edge:
                    if not include_inferred and edge.source_type == SourceType.INFERRED:
                        continue
                    visited_edges.append(edge)
                    traverse(neighbor, depth - 1, graph)

        if direction in ("upstream", "both"):
            traverse(field_id, hops, self._graph.reverse())
        if direction in ("downstream", "both"):
            traverse(field_id, hops, self._graph)

        nodes = [self._nodes[n] for n in visited_nodes if n in self._nodes]
        has_inferred = any(e.source_type == SourceType.INFERRED for e in visited_edges)

        return LineagePath(
            nodes=nodes,
            edges=visited_edges,
            hops=hops,
            has_inferred=has_inferred,
        )

    # ─── Impact Analysis ────────────────────────────────────────────────────

    def get_impact(self, field_id: str) -> ImpactResult:
        """
        What downstream fields are affected if this field changes?
        """
        if field_id not in self._nodes:
            raise ValueError(f"Field not found: {field_id}")

        descendants = list(nx.descendants(self._graph, field_id))
        affected = [self._nodes[d] for d in descendants if d in self._nodes]

        source_system = self._nodes[field_id].system
        cross_system = list({f.system for f in affected if f.system != source_system})

        risk = "low"
        if len(affected) > 20 or len(cross_system) > 2:
            risk = "high"
        elif len(affected) > 5 or len(cross_system) > 0:
            risk = "medium"

        return ImpactResult(
            source_field=field_id,
            affected_fields=affected,
            affected_count=len(affected),
            cross_system_impacts=cross_system,
            risk_level=risk,
        )

    # ─── Audit Trail ────────────────────────────────────────────────────────

    def get_audit(self, field_id: str) -> AuditEntry:
        """Full provenance chain with conflict detection."""
        path = self.get_lineage(field_id, hops=10, direction="upstream", include_inferred=True)

        authoritative = [
            e.source_field for e in path.edges
            if e.source_type == SourceType.AUTHORITATIVE
        ]
        inferred = [e for e in path.edges if e.source_type == SourceType.INFERRED]

        # Detect conflicts: inferred edge contradicted by authoritative
        conflicts = []
        for ie in inferred:
            if ie.metadata.get("superseded_by_authoritative"):
                conflicts.append(
                    f"Inferred edge {ie.source_field} → {ie.target_field} "
                    f"superseded by authoritative source"
                )

        total = len(path.edges)
        completeness = len(authoritative) / total if total > 0 else 0.0

        return AuditEntry(
            field_id=field_id,
            lineage_path=path,
            authoritative_sources=authoritative,
            inferred_links=inferred,
            completeness_score=round(completeness, 2),
            conflicts=conflicts,
        )

    # ─── Stats ──────────────────────────────────────────────────────────────

    def stats(self) -> Dict[str, Any]:
        auth_edges = sum(1 for e in self._edges.values() if e.source_type == SourceType.AUTHORITATIVE)
        inf_edges = sum(1 for e in self._edges.values() if e.source_type == SourceType.INFERRED)
        return {
            "total_fields": len(self._nodes),
            "total_edges": len(self._edges),
            "authoritative_edges": auth_edges,
            "inferred_edges": inf_edges,
            "systems": list({n.system for n in self._nodes.values()}),
            "is_dag": nx.is_directed_acyclic_graph(self._graph),
        }

    # ─── Serialization ──────────────────────────────────────────────────────

    def to_dict(self) -> Dict[str, Any]:
        return {
            "nodes": [n.model_dump() for n in self._nodes.values()],
            "edges": [e.model_dump() for e in self._edges.values()],
        }

    def export_for_visualization(self) -> Dict[str, Any]:
        """D3-compatible format with node/link arrays."""
        nodes = []
        for n in self._nodes.values():
            nodes.append({
                "id": n.id,
                "label": f"{n.table}.{n.column}",
                "system": n.system,
                "table": n.table,
                "column": n.column,
                "data_type": n.data_type,
                "pii": n.pii,
                "tags": n.tags,
            })
        links = []
        for e in self._edges.values():
            links.append({
                "id": e.id,
                "source": e.source_field,
                "target": e.target_field,
                "type": e.source_type.value,
                "confidence": e.confidence,
                "transformation": e.transformation_type.value,
                "logic": e.transformation_logic,
                "reasoning": e.reasoning,
            })
        return {"nodes": nodes, "links": links}


# ─── Singleton instance ────────────────────────────────────────────────────
graph = LineageGraph()
