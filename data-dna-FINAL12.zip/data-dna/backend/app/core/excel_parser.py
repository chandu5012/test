"""
Excel Metadata Parser
Accepts uploaded Excel files with field metadata.
Expected columns (flexible — matches by header name):
  system, table, column/field, data_type/type, description, pii, tags, source_system, transformation
"""
import io
from typing import List, Tuple, Dict, Optional
from app.models.lineage import FieldNode, LineageEdge, SourceType, TransformationType
import uuid


COLUMN_ALIASES = {
    "system":            ["system","system_name","source_system","application"],
    "table":             ["table","table_name","entity","object","sheet"],
    "column":            ["column","column_name","field","field_name","attribute"],
    "data_type":         ["data_type","type","datatype","data type","col_type"],
    "description":       ["description","desc","business_description","business desc","definition","meaning","purpose"],
    "pii":               ["pii","is_pii","sensitive","personal_data","personal data"],
    "tags":              ["tags","tag","category","domain","subject_area"],
    "source_table":      ["source_table","source table","source","from_table"],
    "source_column":     ["source_column","source column","from_column","from_field"],
    "transformation":    ["transformation","transform","logic","etl_logic","mapping_logic"],
}

PII_PATTERNS = ["ssn","social","dob","birth","email","phone","mobile","address",
                "name","pan","aadhaar","passport","license","card","nric","sin",
                "account_no","credit_card"]


def _is_pii(col: str, pii_cell=None) -> bool:
    if pii_cell is not None:
        val = str(pii_cell).strip().lower()
        return val in ("yes","true","1","y","✓")
    c = col.lower()
    return any(p in c for p in PII_PATTERNS)


def _find_col(headers: List[str], field: str) -> Optional[int]:
    """Find column index by fuzzy header matching."""
    aliases = COLUMN_ALIASES.get(field, [field])
    for i, h in enumerate(headers):
        if h.lower().strip() in aliases:
            return i
    return None


def parse_excel_metadata(file_bytes: bytes, filename: str) -> Tuple[List[FieldNode], List[LineageEdge], List[str]]:
    """
    Parse Excel/CSV file into FieldNodes and LineageEdges.
    Returns (nodes, edges, warnings).
    """
    try:
        import openpyxl
    except ImportError:
        return [], [], ["openpyxl not installed. Run: pip install openpyxl"]

    nodes: List[FieldNode] = []
    edges: List[LineageEdge] = []
    warnings: List[str] = []

    try:
        wb = openpyxl.load_workbook(io.BytesIO(file_bytes), read_only=True, data_only=True)
    except Exception as e:
        # Try CSV fallback
        try:
            return _parse_csv(file_bytes, warnings)
        except Exception:
            return [], [], [f"Cannot read file: {e}"]

    for sheet_name in wb.sheetnames:
        ws = wb[sheet_name]
        rows = list(ws.iter_rows(values_only=True))
        if not rows:
            continue

        # Find header row (first non-empty row)
        header_row_idx = 0
        for i, row in enumerate(rows):
            if any(cell is not None for cell in row):
                header_row_idx = i
                break

        headers = [str(c).strip() if c is not None else "" for c in rows[header_row_idx]]

        # Map column indices
        idx = {f: _find_col(headers, f) for f in COLUMN_ALIASES}

        if idx["system"] is None and idx["table"] is None and idx["column"] is None:
            warnings.append(f"Sheet '{sheet_name}': cannot find system/table/column headers. Expected headers: system, table, column, data_type, description, pii, tags")
            continue

        seen_ids = set()
        for row in rows[header_row_idx + 1:]:
            if not any(c is not None for c in row):
                continue

            def cell(field):
                i = idx.get(field)
                return str(row[i]).strip() if i is not None and i < len(row) and row[i] is not None else ""

            system  = cell("system") or sheet_name
            table   = cell("table")
            column  = cell("column")

            if not system or not table or not column:
                continue

            # Normalise
            system = system.upper().replace(" ","_")
            table  = table.upper().replace(" ","_")
            column = column.upper().replace(" ","_")

            field_id = f"{system}.{table}.{column}"
            if field_id in seen_ids:
                continue
            seen_ids.add(field_id)

            pii_val = cell("pii")
            pii = _is_pii(column, pii_val if pii_val else None)

            tags_raw = cell("tags")
            tags = [t.strip() for t in tags_raw.split(",") if t.strip()] if tags_raw else []

            node = FieldNode(
                id=field_id, system=system, table=table, column=column,
                data_type=cell("data_type") or None,
                description=cell("description") or None,
                pii=pii, tags=tags,
            )
            nodes.append(node)

            # Build lineage edges if source columns provided
            src_table  = cell("source_table")
            src_column = cell("source_column")
            transform  = cell("transformation")
            if src_table and src_column:
                src_id = f"{system}.{src_table.upper()}.{src_column.upper()}"
                ttype_map = {
                    "direct": TransformationType.DIRECT,
                    "renamed": TransformationType.RENAMED,
                    "aggregated": TransformationType.AGGREGATED,
                    "derived": TransformationType.DERIVED,
                    "filtered": TransformationType.FILTERED,
                    "joined": TransformationType.JOINED,
                }
                ttype = ttype_map.get(transform.lower() if transform else "", TransformationType.DIRECT)
                edges.append(LineageEdge(
                    id=str(uuid.uuid4()),
                    source_field=src_id,
                    target_field=field_id,
                    transformation_type=ttype,
                    transformation_logic=transform or "From Excel mapping",
                    source_type=SourceType.AUTHORITATIVE,
                    confidence=1.0,
                ))

    return nodes, edges, warnings


def _parse_csv(file_bytes: bytes, warnings: List[str]):
    import csv
    nodes, edges = [], []
    try:
        text = file_bytes.decode("utf-8-sig")
        reader = csv.DictReader(io.StringIO(text))
        for row in reader:
            # Normalise keys
            r = {k.lower().strip(): v for k,v in row.items() if v}
            system = r.get("system","UNKNOWN").upper()
            table  = r.get("table", r.get("table_name","UNKNOWN")).upper()
            column = r.get("column", r.get("field","UNKNOWN")).upper()
            fid = f"{system}.{table}.{column}"
            nodes.append(FieldNode(
                id=fid, system=system, table=table, column=column,
                data_type=r.get("data_type") or r.get("type"),
                description=r.get("description") or r.get("desc"),
                pii=_is_pii(column),
                tags=[t.strip() for t in r.get("tags","").split(",") if t.strip()],
            ))
    except Exception as e:
        warnings.append(f"CSV parse error: {e}")
    return nodes, edges, warnings


def generate_excel_template() -> bytes:
    """Generate a sample Excel template for users to fill in."""
    import openpyxl
    from openpyxl.styles import Font, PatternFill, Alignment

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Field Metadata"

    headers = ["system","table","column","data_type","description","pii","tags","source_table","source_column","transformation"]
    header_fill = PatternFill("solid", fgColor="1a1a2e")
    header_font = Font(color="00d4aa", bold=True, size=11)

    for col_idx, h in enumerate(headers, 1):
        cell = ws.cell(row=1, column=col_idx, value=h.upper())
        cell.fill = header_fill
        cell.font = header_font
        cell.alignment = Alignment(horizontal="center")

    # Sample data rows
    samples = [
        ["CBS","CBS_CUSTOMER","CUST_ID","VARCHAR(20)","Unique customer identifier for the CBS system","No","core,identity","","",""],
        ["CBS","CBS_CUSTOMER","EMAIL","VARCHAR(100)","Customer email address for communication","Yes","contact,pii","","",""],
        ["CBS","CBS_LOAN_ACCOUNT","OUTSTANDING_BAL","DECIMAL(15,2)","Current outstanding loan balance","No","financial,balance","","",""],
        ["RISK","RISK_SCORE","COMPOSITE_SCORE","INT","Composite credit risk score combining bureau and internal models","No","risk,score","CBS_LOAN_ACCOUNT","OUTSTANDING_BAL","derived"],
        ["MIS","CUSTOMER_SCORECARD","CREDIT_SCORE","INT","Final credit score shown in management reporting","No","reporting,score","RISK_SCORE","COMPOSITE_SCORE","direct"],
    ]
    for r_idx, row in enumerate(samples, 2):
        for c_idx, val in enumerate(row, 1):
            ws.cell(row=r_idx, column=c_idx, value=val)

    # Column widths
    widths = [15,25,25,15,50,8,20,25,25,20]
    for i, w in enumerate(widths, 1):
        ws.column_dimensions[ws.cell(row=1,column=i).column_letter].width = w

    # Instructions sheet
    ws2 = wb.create_sheet("Instructions")
    instructions = [
        ["Column","Required","Description","Example"],
        ["system","YES","Your system/application name","CBS, LOS, RISK"],
        ["table","YES","Table or entity name","CBS_CUSTOMER, LOAN_ACCOUNT"],
        ["column","YES","Column or field name","CUST_ID, EMAIL, BALANCE"],
        ["data_type","NO","SQL data type","VARCHAR(20), DECIMAL(15,2), INT, DATE"],
        ["description","NO","Business description (AI fills if blank)","Unique customer identifier used across all systems"],
        ["pii","NO","Is this a PII field? Yes/No","Yes, No, true, false, 1, 0"],
        ["tags","NO","Comma-separated tags","finance, customer, core"],
        ["source_table","NO","Source table for lineage (optional)","CBS_LOAN_ACCOUNT"],
        ["source_column","NO","Source column for lineage (optional)","OUTSTANDING_BAL"],
        ["transformation","NO","How the data is transformed","direct, renamed, aggregated, derived"],
    ]
    for r_idx, row in enumerate(instructions, 1):
        for c_idx, val in enumerate(row, 1):
            cell = ws2.cell(row=r_idx, column=c_idx, value=val)
            if r_idx == 1:
                cell.font = Font(bold=True)
        ws2.column_dimensions[ws2.cell(row=1,column=1).column_letter].width = 18
        ws2.column_dimensions[ws2.cell(row=1,column=3).column_letter].width = 45

    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()
