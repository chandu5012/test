"""
TinyDB persistence — stores data in a FIXED user-level location.

Windows: C:\\Users\\<user>\\AppData\\Local\\DataDNA\\data_dna.json
Linux/Mac: ~/.datadna/data_dna.json

This means the database survives regardless of which folder the project
is extracted to. Extract to Downloads, Desktop, D:\\projects — doesn't matter.
"""
import os
import sys
import shutil
import logging
from pathlib import Path
from tinydb import TinyDB, Query

logger = logging.getLogger(__name__)


def get_db_path() -> Path:
    # Explicit override (Docker, CI, custom deployment)
    if os.getenv("DB_PATH"):
        return Path(os.getenv("DB_PATH"))

    # Fixed user-level location
    if sys.platform == "win32":
        base = Path(os.environ.get("LOCALAPPDATA", Path.home() / "AppData" / "Local"))
        db_dir = base / "DataDNA"
    else:
        db_dir = Path.home() / ".datadna"

    db_dir.mkdir(parents=True, exist_ok=True)
    return db_dir / "data_dna.json"


def _bootstrap_if_needed(db_path: Path):
    """
    If the DB is empty or missing, copy the bundled seed file.
    The seed file (seed_data_dna.json) ships inside the backend/ folder.
    """
    import json

    # Find seed file relative to THIS file's location
    this_dir = Path(__file__).parent          # app/core/
    backend_dir = this_dir.parent.parent      # backend/
    seed_candidates = [
        backend_dir / "seed_data_dna.json",
        backend_dir / "data_dna.json",
    ]
    seed_file = next((p for p in seed_candidates if p.exists()), None)

    if not seed_file:
        logger.info("No seed file found — will generate data on first start")
        return

    # Check if DB needs seeding
    needs_seed = True
    if db_path.exists():
        try:
            with open(db_path) as f:
                existing = json.load(f)
            count = len(existing.get("nodes", {}))
            if count >= 500:
                logger.info(f"✓ Database has {count} fields — no seeding needed")
                needs_seed = False
            else:
                logger.info(f"⚡ Database has only {count} fields — replacing with full seed")
        except Exception:
            logger.info("⚡ Database file corrupt — replacing with seed")

    if needs_seed:
        shutil.copy2(seed_file, db_path)
        with open(db_path) as f:
            d = json.load(f)
        logger.info(f"✓ Seeded database: {len(d.get('nodes', {}))} fields from {seed_file.name}")


DB_PATH = get_db_path()
_bootstrap_if_needed(DB_PATH)


class PersistenceManager:
    def __init__(self):
        logger.info(f"💾 Database: {DB_PATH}")
        self._db       = TinyDB(str(DB_PATH))
        self._nodes    = self._db.table("nodes")
        self._edges    = self._db.table("edges")
        self._settings = self._db.table("settings")

    def save_node(self, node_dict: dict):
        F = Query()
        self._nodes.upsert(node_dict, F.id == node_dict["id"])

    def save_edge(self, edge_dict: dict):
        F = Query()
        self._edges.upsert(edge_dict, F.id == edge_dict["id"])

    def load_all_nodes(self):
        return self._nodes.all()

    def load_all_edges(self):
        return self._edges.all()

    def save_setting(self, key: str, value):
        F = Query()
        self._settings.upsert({"key": key, "value": value}, F.key == key)

    def get_setting(self, key: str, default=None):
        F = Query()
        r = self._settings.get(F.key == key)
        return r["value"] if r else default

    def clear_all(self):
        self._nodes.truncate()
        self._edges.truncate()

    def stats(self):
        return {
            "nodes": len(self._nodes),
            "edges": len(self._edges),
            "db_path": str(DB_PATH),
        }


persistence = PersistenceManager()
