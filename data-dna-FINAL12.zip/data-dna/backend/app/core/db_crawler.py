"""
Database Auto-Crawler
Connects to real databases and extracts schema automatically.
Supports: SQL Server, PostgreSQL, MySQL, SQLite, Oracle
"""
import sqlite3
from typing import List, Optional, Dict, Any
from app.models.lineage import FieldNode


PII_PATTERNS = ["ssn","social","dob","birth","email","phone","mobile","address",
                "name","pan","aadhaar","passport","license","card","nric","sin"]

def is_pii(col: str) -> bool:
    c = col.lower()
    return any(p in c for p in PII_PATTERNS)


def crawl_sqlite(db_path: str, system_name: str) -> List[FieldNode]:
    """Crawl a SQLite database file."""
    nodes = []
    conn = sqlite3.connect(db_path)
    cursor = conn.cursor()
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
    tables = [r[0] for r in cursor.fetchall()]
    for table in tables:
        cursor.execute(f"PRAGMA table_info({table})")
        for row in cursor.fetchall():
            col = row[1].upper()
            dtype = row[2]
            nodes.append(FieldNode(
                id=f"{system_name}.{table.upper()}.{col}",
                system=system_name, table=table.upper(),
                column=col, data_type=dtype, pii=is_pii(col)
            ))
    conn.close()
    return nodes


def crawl_postgres(conn_string: str, system_name: str) -> List[FieldNode]:
    """Crawl a PostgreSQL database."""
    try:
        import psycopg2
        conn = psycopg2.connect(conn_string)
        cursor = conn.cursor()
        cursor.execute("""
            SELECT table_name, column_name, data_type
            FROM information_schema.columns
            WHERE table_schema = 'public'
            ORDER BY table_name, ordinal_position
        """)
        nodes = []
        for table, col, dtype in cursor.fetchall():
            nodes.append(FieldNode(
                id=f"{system_name}.{table.upper()}.{col.upper()}",
                system=system_name, table=table.upper(),
                column=col.upper(), data_type=dtype, pii=is_pii(col)
            ))
        conn.close()
        return nodes
    except ImportError:
        raise ValueError("psycopg2 not installed. Run: pip install psycopg2-binary")


def crawl_mysql(conn_string: str, system_name: str, database: str) -> List[FieldNode]:
    """Crawl a MySQL database."""
    try:
        import mysql.connector
        conn = mysql.connector.connect(host=conn_string, database=database)
        cursor = conn.cursor()
        cursor.execute(f"""
            SELECT TABLE_NAME, COLUMN_NAME, DATA_TYPE
            FROM INFORMATION_SCHEMA.COLUMNS
            WHERE TABLE_SCHEMA = '{database}'
        """)
        nodes = []
        for table, col, dtype in cursor.fetchall():
            nodes.append(FieldNode(
                id=f"{system_name}.{table.upper()}.{col.upper()}",
                system=system_name, table=table.upper(),
                column=col.upper(), data_type=dtype, pii=is_pii(col)
            ))
        conn.close()
        return nodes
    except ImportError:
        raise ValueError("mysql-connector-python not installed.")


def crawl_sqlserver(conn_string: str, system_name: str) -> List[FieldNode]:
    """Crawl a SQL Server database."""
    try:
        import pyodbc
        conn = pyodbc.connect(conn_string)
        cursor = conn.cursor()
        cursor.execute("""
            SELECT TABLE_NAME, COLUMN_NAME, DATA_TYPE
            FROM INFORMATION_SCHEMA.COLUMNS
            ORDER BY TABLE_NAME, ORDINAL_POSITION
        """)
        nodes = []
        for table, col, dtype in cursor.fetchall():
            nodes.append(FieldNode(
                id=f"{system_name}.{table.upper()}.{col.upper()}",
                system=system_name, table=table.upper(),
                column=col.upper(), data_type=dtype, pii=is_pii(col)
            ))
        conn.close()
        return nodes
    except ImportError:
        raise ValueError("pyodbc not installed. Run: pip install pyodbc")


def crawl_database(db_type: str, system_name: str,
                   conn_string: str = "", db_path: str = "",
                   database: str = "") -> List[FieldNode]:
    """Unified crawler entry point."""
    db_type = db_type.lower()
    if db_type == "sqlite":
        return crawl_sqlite(db_path or conn_string, system_name)
    elif db_type in ("postgres", "postgresql"):
        return crawl_postgres(conn_string, system_name)
    elif db_type == "mysql":
        return crawl_mysql(conn_string, system_name, database)
    elif db_type in ("sqlserver", "mssql"):
        return crawl_sqlserver(conn_string, system_name)
    else:
        raise ValueError(f"Unsupported db_type: {db_type}. Use sqlite/postgres/mysql/sqlserver")


def crawl_oracle(conn_string: str, system_name: str, schema: str = None) -> List[FieldNode]:
    """Crawl Oracle database schema."""
    try:
        import cx_Oracle
        conn = cx_Oracle.connect(conn_string)
        cursor = conn.cursor()
        schema_filter = f"AND OWNER = '{schema.upper()}'" if schema else ""
        cursor.execute(f"""
            SELECT TABLE_NAME, COLUMN_NAME, DATA_TYPE
            FROM ALL_TAB_COLUMNS
            WHERE 1=1 {schema_filter}
            ORDER BY TABLE_NAME, COLUMN_ID
        """)
        nodes = []
        for table, col, dtype in cursor.fetchall():
            nodes.append(FieldNode(
                id=f"{system_name}.{table}.{col}",
                system=system_name, table=table,
                column=col, data_type=dtype, pii=is_pii(col)
            ))
        conn.close()
        return nodes
    except ImportError:
        raise ValueError("cx_Oracle not installed. Run: pip install cx_Oracle")


def crawl_teradata(conn_string: str, system_name: str, database: str = None) -> List[FieldNode]:
    """Crawl Teradata database schema."""
    try:
        import teradatasql
        conn = teradatasql.connect(conn_string)
        cursor = conn.cursor()
        db_filter = f"WHERE DatabaseName = '{database}'" if database else ""
        cursor.execute(f"""
            SELECT TableName, ColumnName, ColumnType
            FROM DBC.ColumnsV
            {db_filter}
            ORDER BY TableName, ColumnId
        """)
        nodes = []
        for table, col, dtype in cursor.fetchall():
            nodes.append(FieldNode(
                id=f"{system_name}.{table.strip()}.{col.strip()}",
                system=system_name, table=table.strip(),
                column=col.strip(), data_type=dtype, pii=is_pii(col.strip())
            ))
        conn.close()
        return nodes
    except ImportError:
        raise ValueError("teradatasql not installed. Run: pip install teradatasql")


def crawl_mongodb(conn_string: str, system_name: str, database: str = None) -> List[FieldNode]:
    """
    Crawl MongoDB collections.
    Samples documents to infer schema (MongoDB is schema-less).
    """
    try:
        from pymongo import MongoClient
        client = MongoClient(conn_string)
        db = client[database] if database else client.get_default_database()
        nodes = []
        for collection_name in db.list_collection_names():
            # Sample 10 documents to infer fields
            sample = list(db[collection_name].find({}, {"_id": 0}).limit(10))
            if not sample:
                continue
            # Collect all keys across samples
            all_keys = set()
            for doc in sample:
                all_keys.update(_flatten_keys(doc))
            for key in all_keys:
                col = key.upper().replace(".", "_")
                nodes.append(FieldNode(
                    id=f"{system_name}.{collection_name.upper()}.{col}",
                    system=system_name, table=collection_name.upper(),
                    column=col, data_type="BSON", pii=is_pii(col)
                ))
        client.close()
        return nodes
    except ImportError:
        raise ValueError("pymongo not installed. Run: pip install pymongo")


def _flatten_keys(doc: dict, prefix: str = "") -> list:
    """Flatten nested MongoDB document keys."""
    keys = []
    for k, v in doc.items():
        full_key = f"{prefix}.{k}" if prefix else k
        keys.append(full_key)
        if isinstance(v, dict) and len(full_key.split(".")) < 3:
            keys.extend(_flatten_keys(v, full_key))
    return keys


def crawl_hive(conn_string: str, system_name: str, database: str = "default") -> List[FieldNode]:
    """Crawl Apache Hive schema via PyHive."""
    try:
        from pyhive import hive
        # conn_string format: "host:port"
        host, port = conn_string.split(":") if ":" in conn_string else (conn_string, 10000)
        conn = hive.connect(host=host, port=int(port), database=database)
        cursor = conn.cursor()
        cursor.execute("SHOW TABLES")
        tables = [r[0] for r in cursor.fetchall()]
        nodes = []
        for table in tables:
            try:
                cursor.execute(f"DESCRIBE {table}")
                for row in cursor.fetchall():
                    if row[0].startswith("#") or not row[0].strip():
                        continue
                    col = row[0].strip().upper()
                    dtype = row[1].strip() if row[1] else "STRING"
                    nodes.append(FieldNode(
                        id=f"{system_name}.{table.upper()}.{col}",
                        system=system_name, table=table.upper(),
                        column=col, data_type=dtype, pii=is_pii(col)
                    ))
            except Exception:
                pass
        conn.close()
        return nodes
    except ImportError:
        raise ValueError("PyHive not installed. Run: pip install pyhive thrift")


# Update the main crawl_database function to include new types
_ORIG_CRAWL = crawl_database

def crawl_database(db_type: str, system_name: str,
                   conn_string: str = "", db_path: str = "",
                   database: str = "", schema: str = "") -> List[FieldNode]:
    db_type = db_type.lower()
    if db_type == "oracle":
        return crawl_oracle(conn_string, system_name, schema or database)
    elif db_type == "teradata":
        return crawl_teradata(conn_string, system_name, database)
    elif db_type in ("mongodb", "mongo"):
        return crawl_mongodb(conn_string, system_name, database)
    elif db_type in ("hive", "apache_hive"):
        return crawl_hive(conn_string, system_name, database)
    else:
        return _ORIG_CRAWL(db_type, system_name, conn_string, db_path, database)
