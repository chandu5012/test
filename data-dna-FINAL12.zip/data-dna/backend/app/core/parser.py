"""
SQL & Schema Parser — deterministic metadata extraction.
Parses SQL DDL/DML to extract field-level lineage (authoritative edges).
"""
import re
import uuid
from typing import List, Tuple, Dict, Any, Optional

try:
    import sqlglot
    import sqlglot.expressions as exp
    HAS_SQLGLOT = True
except ImportError:
    HAS_SQLGLOT = False

from app.models.lineage import FieldNode, LineageEdge, SourceType, TransformationType


class SQLLineageParser:
    """
    Parses SQL statements to extract:
    - Tables/columns referenced (FieldNodes)
    - Column-level lineage (LineageEdges) from SELECT, INSERT, CREATE AS SELECT
    """

    def __init__(self, system_name: str):
        self.system = system_name

    def _make_field_id(self, table: str, column: str) -> str:
        return f"{self.system}.{table}.{column}"

    def parse_create_table(self, sql: str) -> List[FieldNode]:
        """Extract field nodes from CREATE TABLE DDL."""
        nodes = []
        # Simple regex-based DDL parser (fallback when sqlglot not available)
        table_match = re.search(
            r"CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?`?(\w+)`?",
            sql, re.IGNORECASE
        )
        if not table_match:
            return nodes
        table_name = table_match.group(1)

        # Extract column definitions
        col_block = re.search(r"\((.*)\)", sql, re.DOTALL)
        if not col_block:
            return nodes

        for line in col_block.group(1).split(","):
            line = line.strip()
            col_match = re.match(r"`?(\w+)`?\s+([\w()]+)", line)
            if col_match:
                col_name = col_match.group(1).upper()
                data_type = col_match.group(2).upper()
                if col_name in ("PRIMARY", "UNIQUE", "KEY", "INDEX", "CONSTRAINT", "FOREIGN"):
                    continue
                node = FieldNode(
                    id=self._make_field_id(table_name, col_name),
                    system=self.system,
                    table=table_name,
                    column=col_name,
                    data_type=data_type,
                    pii=self._is_pii(col_name),
                )
                nodes.append(node)
        return nodes

    def parse_insert_select(self, sql: str) -> Tuple[List[FieldNode], List[LineageEdge]]:
        """
        Parse INSERT INTO target SELECT col1, col2 FROM source
        Returns (new_nodes, edges)
        """
        nodes: List[FieldNode] = []
        edges: List[LineageEdge] = []

        insert_match = re.search(
            r"INSERT\s+INTO\s+`?(\w+)`?\s*\(([^)]+)\)",
            sql, re.IGNORECASE
        )
        from_match = re.search(r"FROM\s+`?(\w+)`?", sql, re.IGNORECASE)
        select_match = re.search(
            r"SELECT\s+(.*?)\s+FROM", sql, re.IGNORECASE | re.DOTALL
        )

        if not (insert_match and from_match and select_match):
            return nodes, edges

        target_table = insert_match.group(1)
        target_cols = [c.strip().strip("`") for c in insert_match.group(2).split(",")]
        source_table = from_match.group(1)
        select_cols_raw = [c.strip() for c in select_match.group(1).split(",")]

        for i, (tgt_col, src_expr) in enumerate(zip(target_cols, select_cols_raw)):
            # Extract source column (handle "col AS alias", functions, etc.)
            src_col_match = re.match(r"`?(\w+)`?(?:\s+AS\s+\w+)?$", src_expr.strip(), re.IGNORECASE)
            if src_col_match:
                src_col = src_col_match.group(1).upper()
                ttype = TransformationType.DIRECT
            else:
                # Expression / derived
                src_col = f"EXPR_{i}"
                ttype = TransformationType.DERIVED

            src_id = self._make_field_id(source_table, src_col)
            tgt_id = self._make_field_id(target_table, tgt_col.upper())

            for fid, tbl, col in [(src_id, source_table, src_col), (tgt_id, target_table, tgt_col.upper())]:
                nodes.append(FieldNode(
                    id=fid, system=self.system, table=tbl, column=col,
                    pii=self._is_pii(col)
                ))

            edges.append(LineageEdge(
                id=str(uuid.uuid4()),
                source_field=src_id,
                target_field=tgt_id,
                transformation_type=ttype,
                transformation_logic=src_expr.strip(),
                source_type=SourceType.AUTHORITATIVE,
                confidence=1.0,
            ))

        return nodes, edges

    def parse_view_or_ctas(self, sql: str) -> Tuple[List[FieldNode], List[LineageEdge]]:
        """Parse CREATE VIEW / CREATE TABLE AS SELECT."""
        nodes: List[FieldNode] = []
        edges: List[LineageEdge] = []

        view_match = re.search(
            r"CREATE\s+(?:OR\s+REPLACE\s+)?(?:VIEW|TABLE)\s+`?(\w+)`?\s+AS",
            sql, re.IGNORECASE
        )
        from_match = re.search(r"FROM\s+`?(\w+)`?", sql, re.IGNORECASE)
        select_match = re.search(r"SELECT\s+(.*?)\s+FROM", sql, re.IGNORECASE | re.DOTALL)

        if not (view_match and from_match and select_match):
            return nodes, edges

        target = view_match.group(1)
        source = from_match.group(1)
        cols_raw = [c.strip() for c in select_match.group(1).split(",")]

        for expr in cols_raw:
            alias_match = re.search(r"(?:AS\s+)?`?(\w+)`?$", expr, re.IGNORECASE)
            src_match = re.match(r"(?:\w+\.)?`?(\w+)`?", expr)
            if alias_match and src_match:
                tgt_col = alias_match.group(1).upper()
                src_col = src_match.group(1).upper()
                src_id = self._make_field_id(source, src_col)
                tgt_id = self._make_field_id(target, tgt_col)
                for fid, tbl, col in [(src_id, source, src_col), (tgt_id, target, tgt_col)]:
                    nodes.append(FieldNode(id=fid, system=self.system, table=tbl, column=col, pii=self._is_pii(col)))
                ttype = TransformationType.DIRECT if src_col == tgt_col else TransformationType.RENAMED
                edges.append(LineageEdge(
                    id=str(uuid.uuid4()),
                    source_field=src_id,
                    target_field=tgt_id,
                    transformation_type=ttype,
                    transformation_logic=expr,
                    source_type=SourceType.AUTHORITATIVE,
                    confidence=1.0,
                ))

        return nodes, edges

    def _is_pii(self, col_name: str) -> bool:
        pii_patterns = ["ssn", "social", "dob", "birth", "email", "phone", "address",
                        "name", "pan", "aadhaar", "passport", "license", "credit_card", "card_number"]
        lower = col_name.lower()
        return any(p in lower for p in pii_patterns)

    def parse(self, sql: str) -> Tuple[List[FieldNode], List[LineageEdge]]:
        """Auto-detect SQL type and parse accordingly."""
        sql_upper = sql.upper().strip()
        nodes, edges = [], []

        statements = [s.strip() for s in sql.split(";") if s.strip()]
        for stmt in statements:
            upper = stmt.upper()
            if "CREATE TABLE" in upper and "SELECT" not in upper:
                nodes.extend(self.parse_create_table(stmt))
            elif "INSERT INTO" in upper and "SELECT" in upper:
                n, e = self.parse_insert_select(stmt)
                nodes.extend(n); edges.extend(e)
            elif ("CREATE VIEW" in upper or "CREATE TABLE" in upper) and "AS" in upper and "SELECT" in upper:
                n, e = self.parse_view_or_ctas(stmt)
                nodes.extend(n); edges.extend(e)

        # Deduplicate nodes by id
        seen = {}
        for n in nodes:
            seen[n.id] = n
        return list(seen.values()), edges


class SchemaParser:
    """Parse JSON schema definitions to create FieldNodes."""

    def __init__(self, system_name: str):
        self.system = system_name

    def parse(self, schema: Dict[str, Any]) -> List[FieldNode]:
        nodes = []
        tables = schema.get("tables", schema.get("entities", {}))
        for table_name, table_def in tables.items():
            columns = table_def.get("columns", table_def.get("fields", {}))
            for col_name, col_def in columns.items():
                if isinstance(col_def, str):
                    col_def = {"type": col_def}
                node = FieldNode(
                    id=f"{self.system}.{table_name}.{col_name.upper()}",
                    system=self.system,
                    table=table_name,
                    column=col_name.upper(),
                    data_type=col_def.get("type"),
                    description=col_def.get("description"),
                    tags=col_def.get("tags", []),
                    pii=col_def.get("pii", False),
                )
                nodes.append(node)
        return nodes
