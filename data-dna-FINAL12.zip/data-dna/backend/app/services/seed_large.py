"""
Large seed: 1000+ fields across 5 deep credit systems.
CBS (300), RISK (250), MIS (200), LOS (150), BUREAU (100)
Each field has a production-quality description.
"""
import uuid
from app.models.lineage import FieldNode, LineageEdge, SourceType, TransformationType

def _node(system, table, column, dtype, desc, pii=False, tags=None):
    import re
    # Parse length/precision from type e.g. VARCHAR(20), DECIMAL(15,2)
    length, precision, scale = None, None, None
    m = re.match(r'[A-Z]+\((\d+)(?:,(\d+))?\)', (dtype or '').upper())
    if m:
        length = int(m.group(1))
        if m.group(2): precision = length; scale = int(m.group(2)); length = None

    # Infer PK/FK/index from column name patterns
    col_up = column.upper()
    is_pk = col_up in ('ID', 'KEY') or (col_up.endswith('_ID') and not col_up.startswith('FOREIGN') and '_' not in col_up.replace('_ID',''))
    is_fk = col_up.endswith('_ID') and not is_pk
    is_idx = is_pk or is_fk or col_up.endswith('_KEY') or col_up.endswith('_NO')
    nullable = not is_pk  # PKs are NOT NULL

    fk_ref = None
    if is_fk:
        # Guess the referenced table from column name
        ref_table = col_up.replace('_ID','').title()
        fk_ref = f"{system}.{ref_table}.ID"

    # Column order based on position in typical schema
    col_order_map = {
        'ID':1,'_ID':2,'_KEY':3,'_NO':4,'_CODE':5,'_NAME':6,'_TYPE':7,
        '_STATUS':8,'_FLAG':9,'_DT':10,'_DATE':11,'_AMT':12,'_BAL':13
    }
    col_order = next((v for k,v in col_order_map.items() if col_up.endswith(k)), 99)

    return FieldNode(
        id=f"{system}.{table}.{column}",
        system=system, table=table, column=column,
        data_type=dtype, description=desc, pii=pii, tags=tags or [],
        length=length, precision=precision, scale=scale,
        nullable=nullable,
        is_primary_key=is_pk,
        is_foreign_key=is_fk,
        foreign_key_ref=fk_ref,
        is_indexed=is_idx,
        column_order=col_order
    )

def _edge(src, tgt, ttype=TransformationType.DIRECT, logic=""):
    return LineageEdge(
        id=str(uuid.uuid4()),
        source_field=src, target_field=tgt,
        transformation_type=ttype, transformation_logic=logic,
        source_type=SourceType.AUTHORITATIVE, confidence=1.0,
        system_boundary=True,
    )

# ── Helpers ────────────────────────────────────────────────────────────────
def amt(s,t,c,n): return _node(s,t,c,"DECIMAL(15,2)",f"Monetary amount for {n} stored in INR to two decimal places.")
def pct(s,t,c,n): return _node(s,t,c,"DECIMAL(5,2)",f"Percentage value for {n} — expressed as decimal (e.g. 12.50 for 12.5%).")
def dt(s,t,c,n):  return _node(s,t,c,"DATE",f"Date of the {n} event.")
def ts(s,t,c,n):  return _node(s,t,c,"TIMESTAMP",f"Exact timestamp when {n} occurred — stored in UTC.")
def vc(s,t,col,l,n,pii=False,tags=None): return _node(s,t,col,f"VARCHAR({l})",n,pii,tags or [])
def num(s,t,c,n): return _node(s,t,c,"INT",n)
def flag(s,t,c,n): return _node(s,t,c,"VARCHAR(1)",f"Y/N flag indicating {n}.")
def dec(s,t,c,p,n): return _node(s,t,c,f"DECIMAL({p})",n)


def build_all_nodes():
    nodes = []

    # ══════════════════════════════════════════════════════════════════
    # CBS — CORE BANKING SYSTEM (300 fields)
    # ══════════════════════════════════════════════════════════════════
    S = "CBS"

    # CBS_CUSTOMER (45 fields)
    T = "CBS_CUSTOMER"
    nodes += [
        _node(S,T,"CUST_ID","VARCHAR(20)","Unique CBS customer identifier — primary key across all CBS tables and the source of truth for customer identification.",False,["core","identity"]),
        _node(S,T,"CUST_REF_NO","VARCHAR(20)","Customer reference number used in correspondence, statements and external communications."),
        _node(S,T,"CUST_NAME","VARCHAR(100)","Full legal name of customer as per KYC documents — PAN, Aadhaar or passport.",True,["pii","kyc"]),
        _node(S,T,"FIRST_NAME","VARCHAR(50)","Customer first name extracted from full legal name.",True,["pii"]),
        _node(S,T,"MIDDLE_NAME","VARCHAR(50)","Customer middle name — optional, used in legal and property documents.",True,["pii"]),
        _node(S,T,"LAST_NAME","VARCHAR(50)","Customer surname / last name as per KYC documents.",True,["pii"]),
        _node(S,T,"DOB","DATE","Date of birth — used for age verification, loan eligibility, insurance linkage and age-based schemes.",True,["pii"]),
        _node(S,T,"GENDER","VARCHAR(10)","Customer gender (Male/Female/Other) — used for demographic segmentation and scheme eligibility."),
        _node(S,T,"MARITAL_STATUS","VARCHAR(15)","Marital status — affects joint account eligibility and property loan processing."),
        _node(S,T,"PAN_NUMBER","VARCHAR(10)","Permanent Account Number — mandatory tax identifier for all loans above Rs 2 lakh per IT Act.",True,["pii","kyc","tax"]),
        _node(S,T,"AADHAAR_NO","VARCHAR(12)","Aadhaar number used for biometric eKYC, CKYC and direct benefit transfer linkage.",True,["pii","kyc"]),
        _node(S,T,"PASSPORT_NO","VARCHAR(20)","Passport number for NRI/OCI customers — alternative KYC document.",True,["pii","kyc"]),
        _node(S,T,"VOTER_ID","VARCHAR(20)","Voter ID card number used as secondary KYC identity proof.",True,["pii","kyc"]),
        _node(S,T,"DRIVING_LIC","VARCHAR(20)","Driving licence number used as secondary KYC identity proof.",True,["pii","kyc"]),
        _node(S,T,"MOBILE","VARCHAR(15)","Primary mobile number for OTP authentication, NACH registration and payment alerts.",True,["pii","contact"]),
        _node(S,T,"ALT_MOBILE","VARCHAR(15)","Alternate mobile number for collections contact and emergency communication.",True,["pii","contact"]),
        _node(S,T,"EMAIL","VARCHAR(100)","Email address for digital statements, NOC delivery, regulatory notices and eNACH.",True,["pii","contact"]),
        _node(S,T,"ADDRESS_LINE1","VARCHAR(100)","Primary residential address line 1 — used for KYC, legal notices and property verification.",True,["pii","address"]),
        _node(S,T,"ADDRESS_LINE2","VARCHAR(100)","Primary residential address line 2 (locality/area).",True,["pii","address"]),
        _node(S,T,"CITY","VARCHAR(50)","City of residence — used for geographic segmentation and regional portfolio reporting."),
        _node(S,T,"STATE","VARCHAR(30)","State of residence — used for state-wise portfolio analysis and SARFAESI compliance."),
        _node(S,T,"PINCODE","VARCHAR(10)","Postal code for geographic credit heat maps, bureau query normalisation and branch proximity."),
        _node(S,T,"COUNTRY","VARCHAR(30)","Country of residence — required for FEMA compliance and NRI/OCI identification."),
        _node(S,T,"NATIONALITY","VARCHAR(30)","Customer nationality — required for FEMA, FATCA, CRS and cross-border transaction limits."),
        _node(S,T,"RESIDENT_TYPE","VARCHAR(20)","Residential status: RESIDENT_INDIAN, NRI, PIO, OCI — drives tax treatment and product eligibility."),
        _node(S,T,"KYC_STATUS","VARCHAR(20)","KYC verification status: VERIFIED, PENDING, EXPIRED, RE_KYC_DUE — regulatory compliance indicator."),
        dt(S,T,"KYC_DT","KYC was last completed"),
        dt(S,T,"KYC_EXPIRY_DT","KYC validity expiry — triggers re-KYC workflow"),
        _node(S,T,"CKYC_NO","VARCHAR(14)","Central KYC registry number assigned after CKYC verification with CERSAI."),
        _node(S,T,"CUST_SEGMENT","VARCHAR(20)","Customer segment: RETAIL, HNI, PRIORITY, SME, CORPORATE, AGRI — drives product pricing and SLA."),
        _node(S,T,"CUST_CATEGORY","VARCHAR(20)","Sub-category within segment based on AUM and relationship value for tiered service delivery."),
        _node(S,T,"OCCUPATION","VARCHAR(50)","Occupation type: SALARIED, SELF_EMPLOYED, BUSINESS, RETIRED, STUDENT — income verification basis."),
        _node(S,T,"EMPLOYER_NAME","VARCHAR(100)","Name of current employer — used for income verification, employer risk and salary credit tracking."),
        _node(S,T,"EMPLOYER_CATEGORY","VARCHAR(30)","Employer category: GOVT, PSU, MNC, PRIVATE, STARTUP — affects income stability scoring."),
        dec(S,T,"MONTHLY_INCOME","12,2","Declared monthly take-home income — primary input for FOIR and maximum EMI calculation."),
        dec(S,T,"ANNUAL_INCOME","15,2","Total annual income from all sources — used for tax compliance and higher-ticket loan eligibility."),
        _node(S,T,"INCOME_SOURCE","VARCHAR(30)","Primary income source: SALARY, BUSINESS, RENTAL, INVESTMENT, PENSION."),
        _node(S,T,"RELATIONSHIP_DT","DATE","Date when customer first established a relationship with the bank."),
        _node(S,T,"RM_ID","VARCHAR(20)","Assigned relationship manager ID — accountability for HNI and priority customers."),
        _node(S,T,"BRANCH_CODE","VARCHAR(10)","Home branch code where customer was originally onboarded."),
        _node(S,T,"CUST_STATUS","VARCHAR(10)","Customer lifecycle status: ACTIVE, DORMANT, DECEASED, BLACKLISTED."),
        flag(S,T,"POLITICALLY_EXPOSED","customer is a politically exposed person requiring enhanced due diligence"),
        ts(S,T,"CREATED_DT","customer record was first created in CBS"),
        ts(S,T,"MODIFIED_DT","customer record was last modified"),
        _node(S,T,"CREATED_BY","VARCHAR(50)","User ID who created the customer record in CBS."),
    ]

    # CBS_LOAN_ACCOUNT (50 fields)
    T = "CBS_LOAN_ACCOUNT"
    nodes += [
        vc(S,T,"ACCT_ID",20,"Unique loan account number in CBS — primary identifier for all loan servicing operations."),
        vc(S,T,"CUST_ID",20,"Foreign key to CBS_CUSTOMER — links loan account to the borrower."),
        vc(S,T,"PRODUCT_CODE",10,"Internal product code identifying the specific loan scheme variant and pricing tier."),
        vc(S,T,"PRODUCT_TYPE",30,"Loan product category: HOME_LOAN, PERSONAL_LOAN, AUTO_LOAN, CREDIT_CARD, LAP, OD, AGRI."),
        vc(S,T,"LOAN_PURPOSE",50,"Stated purpose of borrowing: HOME_PURCHASE, RENOVATION, EDUCATION, MEDICAL, BUSINESS, VEHICLE."),
        vc(S,T,"SUB_TYPE",30,"Product sub-type for detailed product analytics and regulator reporting."),
        amt(S,T,"SANCTION_AMT","sanctioned loan approved by credit committee"),
        amt(S,T,"DISBURSED_AMT","total disbursed to borrower across all tranches"),
        amt(S,T,"OUTSTANDING_BAL","current outstanding principal balance on the account"),
        amt(S,T,"OVERDUE_AMT","amount overdue past scheduled due date — primary collections trigger"),
        amt(S,T,"PRINCIPAL_PAID","cumulative principal repaid since disbursement"),
        amt(S,T,"INTEREST_PAID","cumulative interest collected since disbursement"),
        amt(S,T,"PENAL_INTEREST","penal interest charged on overdue amount per loan agreement"),
        amt(S,T,"CHARGES_OUTSTANDING","outstanding processing fees and charges yet to be recovered"),
        amt(S,T,"EMI_AMT","fixed monthly EMI as per amortisation schedule"),
        pct(S,T,"INTEREST_RATE","annual interest rate applicable on this account"),
        vc(S,T,"RATE_TYPE",10,"Interest rate type: FIXED or FLOATING (linked to MCLR, EBLR, REPO rate)."),
        pct(S,T,"BENCHMARK_RATE","benchmark rate (REPO/MCLR) on which floating rate is anchored"),
        pct(S,T,"SPREAD","spread over benchmark rate specific to this borrower credit profile"),
        num(S,T,"TENURE_MONTHS","original loan tenure in months as per sanction terms"),
        num(S,T,"REMAINING_TENURE","remaining months to maturity based on actual repayment track"),
        num(S,T,"EMI_PAID_COUNT","number of EMIs successfully paid since disbursement"),
        num(S,T,"EMI_BOUNCE_COUNT","number of EMI bounces in loan lifetime — delinquency frequency metric"),
        dt(S,T,"OPEN_DT","loan account was opened and first disbursed"),
        dt(S,T,"MATURITY_DT","scheduled loan maturity as per sanction terms"),
        dt(S,T,"LAST_PAYMENT_DT","most recent EMI payment was received"),
        dt(S,T,"NEXT_DUE_DT","next EMI is due — used for NACH triggers and delinquency monitoring"),
        dt(S,T,"FIRST_DISB_DT","first disbursement was made to borrower"),
        dt(S,T,"LAST_DISB_DT","most recent disbursement was made (for tranche-based loans)"),
        vc(S,T,"ACCT_STATUS",10,"Account status: ACTIVE, CLOSED, NPA, WRITTEN_OFF, RESTRUCTURED, SMA, FORECLOSURE."),
        vc(S,T,"SMA_CATEGORY",5,"Special Mention Account category per RBI: SMA-0, SMA-1, SMA-2."),
        dt(S,T,"NPA_DT","account was first classified as Non-Performing Asset"),
        vc(S,T,"NPA_CATEGORY",20,"NPA classification per RBI: SUB_STANDARD, DOUBTFUL_1, DOUBTFUL_2, DOUBTFUL_3, LOSS."),
        vc(S,T,"COLLATERAL_TYPE",30,"Type of collateral: PROPERTY, VEHICLE, SECURITIES, FD, GOLD, GUARANTEE."),
        amt(S,T,"COLLATERAL_VALUE","current market valuation of collateral pledged"),
        pct(S,T,"LTV_RATIO","loan-to-value ratio = outstanding / collateral value × 100"),
        amt(S,T,"PROVISION_AMT","regulatory provision held per RBI NPA norms"),
        amt(S,T,"WRITE_OFF_AMT","amount written off from books after exhausting recovery"),
        amt(S,T,"RECOVERY_AMT","amount recovered post write-off via settlement or legal action"),
        vc(S,T,"BRANCH_CODE",10,"Branch maintaining this loan account for regional attribution."),
        vc(S,T,"RM_ID",20,"Relationship manager responsible for this loan account."),
        vc(S,T,"CHANNEL",20,"Origination channel: BRANCH, ONLINE, DSA, MOBILE, REFERRAL, AGGREGATOR."),
        flag(S,T,"RESTRUCTURED_FLAG","loan was restructured under OTR, COVID relief or standard restructuring scheme"),
        flag(S,T,"MORATORIUM_FLAG","account availed RBI-approved COVID moratorium"),
        flag(S,T,"SUBVENTION_FLAG","loan is under interest subvention scheme (PMAY, PMEGP, etc.)"),
        vc(S,T,"CREATED_BY",50,"User ID who opened this loan account in CBS."),
        ts(S,T,"CREATED_DT","loan account was created"),
        ts(S,T,"MODIFIED_DT","loan account record was last updated"),
        pct(S,T,"INSURANCE_RATE","insurance premium rate linked to this loan account"),
        amt(S,T,"INSURANCE_PREMIUM","monthly insurance premium collected along with EMI"),
    ]

    # CBS_TRANSACTION (30 fields)
    T = "CBS_TRANSACTION"
    nodes += [
        vc(S,T,"TXN_ID",30,"Unique transaction reference for audit trail and dispute resolution."),
        vc(S,T,"ACCT_ID",20,"Loan account on which this transaction was posted."),
        vc(S,T,"BATCH_ID",30,"EOD batch run ID grouping transactions processed in the same cycle."),
        ts(S,T,"TXN_DT","transaction was executed and posted to the account"),
        dt(S,T,"VALUE_DT","value date for interest calculation — may differ from posting date"),
        amt(S,T,"TXN_AMT","transaction amount — positive for receipts, negative for charges and debits"),
        vc(S,T,"TXN_TYPE",20,"Transaction type: EMI_RECEIPT, PREPAYMENT, DISBURSEMENT, CHARGE, REVERSAL, FORECLOSURE."),
        amt(S,T,"PRINCIPAL_COMP","principal component of EMI — reduces outstanding balance"),
        amt(S,T,"INTEREST_COMP","interest component of EMI — revenue recognised by the bank"),
        amt(S,T,"PENALTY_COMP","penal interest and late payment charges component"),
        amt(S,T,"INSURANCE_COMP","insurance premium component collected along with EMI"),
        amt(S,T,"CHARGE_COMP","processing fee and other charges component"),
        vc(S,T,"CHANNEL",20,"Payment channel: NEFT, NACH, RTGS, CHEQUE, CASH, UPI, DEBIT_MANDATE, ESCROW."),
        vc(S,T,"REF_NO",30,"External UTR/NACH/clearing reference number for reconciliation."),
        vc(S,T,"STATUS",10,"Transaction status: SUCCESS, FAILED, PENDING, REVERSED, HOLD, PARTIAL."),
        vc(S,T,"FAILURE_REASON",100,"Reason for transaction failure — populated for FAILED and REVERSED transactions."),
        vc(S,T,"REMARKS",200,"Free-text remarks entered by operator at time of posting."),
        vc(S,T,"POSTED_BY",50,"User ID or system process that posted the transaction."),
        vc(S,T,"APPROVED_BY",50,"Authorising officer ID for high-value transactions requiring dual control."),
        vc(S,T,"BANK_CODE",11,"IFSC code of remitting bank for NEFT/RTGS transactions."),
        vc(S,T,"INSTRUMENT_NO",20,"Cheque or demand draft instrument number for instrument-based payments."),
        dt(S,T,"INSTRUMENT_DT","instrument (cheque/DD) date — differs from posting date"),
        vc(S,T,"CLEARING_STATUS",20,"Clearing status for instrument-based transactions: PRESENTED, CLEARED, BOUNCED, RETURNED."),
        amt(S,T,"BOUNCE_CHARGES","cheque/NACH bounce charges levied on the account"),
        vc(S,T,"MANDATE_ID",20,"NACH mandate ID linked to this transaction for auto-debit tracking."),
        vc(S,T,"PAYMENT_MODE",20,"Detailed payment mode: UPI_BHIM, UPI_PHONEPE, GPAY, PAYTM, etc."),
        vc(S,T,"MERCHANT_REF",30,"Merchant or payment gateway reference for digital payment transactions."),
        ts(S,T,"RECONCILED_DT","transaction was reconciled with bank statement"),
        flag(S,T,"RECONCILED_FLAG","transaction has been successfully reconciled"),
        vc(S,T,"REVERSAL_REASON",100,"Reason for transaction reversal — audit trail for reversed entries."),
    ]

    # CBS_COLLATERAL (25 fields)
    T = "CBS_COLLATERAL"
    nodes += [
        vc(S,T,"COLLATERAL_ID",20,"Unique collateral record identifier."),
        vc(S,T,"ACCT_ID",20,"Loan account this collateral is pledged against."),
        vc(S,T,"CUST_ID",20,"Customer who owns the collateral."),
        vc(S,T,"COLLATERAL_TYPE",30,"Type: PROPERTY, VEHICLE, SHARES, FD, NSC, GOLD, MACHINERY, STOCK."),
        vc(S,T,"COLLATERAL_DESC",200,"Detailed description of the collateral asset."),
        amt(S,T,"CURRENT_VALUE","current market or assessed value of collateral"),
        amt(S,T,"ORIGINAL_VALUE","original value at time of pledge"),
        dt(S,T,"VALUATION_DT","last valuation of the collateral was conducted"),
        dt(S,T,"NEXT_VALUATION_DT","next scheduled valuation is due"),
        vc(S,T,"VALUATION_AGENCY",100,"Name of the approved valuation agency that assessed this collateral."),
        vc(S,T,"CHARGE_TYPE",20,"Charge type: FIRST_CHARGE, SECOND_CHARGE, PARI_PASSU."),
        vc(S,T,"CHARGE_STATUS",20,"Status of charge registration: REGISTERED, PENDING, RELEASED, SATISFIED."),
        dt(S,T,"CHARGE_DT","charge was registered with ROC or sub-registrar"),
        vc(S,T,"PROPERTY_ADDRESS",200,"Full address of property collateral — used for legal notices."),
        vc(S,T,"SURVEY_NO",50,"Survey/plot number of property collateral."),
        vc(S,T,"TITLE_DEED_NO",30,"Title deed number for property — legal ownership document reference."),
        vc(S,T,"VEHICLE_REG_NO",20,"Vehicle registration number for auto loan collateral."),
        vc(S,T,"CHASSIS_NO",25,"Vehicle chassis number for auto loan collateral."),
        vc(S,T,"ENGINE_NO",25,"Vehicle engine number for auto loan collateral."),
        vc(S,T,"INSURANCE_POLICY_NO",30,"Insurance policy number for the collateral asset."),
        dt(S,T,"INSURANCE_EXPIRY_DT","collateral insurance policy expires — triggers renewal alert"),
        vc(S,T,"INSURANCE_COMPANY",100,"Name of insurance company providing collateral coverage."),
        flag(S,T,"TITLE_CLEAR","property title is clear and marketable"),
        flag(S,T,"ENCUMBRANCE_FREE","collateral is free of prior encumbrances"),
        dt(S,T,"RELEASE_DT","collateral was released after loan closure or settlement"),
    ]

    # CBS_EMI_SCHEDULE (15 fields)
    T = "CBS_EMI_SCHEDULE"
    nodes += [
        vc(S,T,"SCHEDULE_ID",30,"Unique EMI schedule record identifier."),
        vc(S,T,"ACCT_ID",20,"Loan account this schedule belongs to."),
        num(S,T,"EMI_NUMBER","sequential EMI number in the repayment schedule"),
        dt(S,T,"DUE_DT","this EMI instalment is due"),
        amt(S,T,"EMI_AMT","total EMI amount due for this instalment"),
        amt(S,T,"PRINCIPAL_COMP","principal component of this EMI instalment"),
        amt(S,T,"INTEREST_COMP","interest component of this EMI instalment"),
        amt(S,T,"OPENING_BAL","opening outstanding balance at start of this period"),
        amt(S,T,"CLOSING_BAL","closing outstanding balance after this EMI payment"),
        vc(S,T,"STATUS",10,"EMI status: PAID, DUE, OVERDUE, PARTIAL, WAIVED."),
        dt(S,T,"PAID_DT","this EMI was actually paid"),
        amt(S,T,"PAID_AMT","amount actually paid for this EMI (may differ if partial)"),
        num(S,T,"DPD","days past due for this EMI instalment"),
        amt(S,T,"PENAL_CHARGED","penal interest charged on this overdue instalment"),
        vc(S,T,"TXN_ID",30,"Transaction ID of payment against this EMI instalment."),
    ]

    # CBS_NACH_MANDATE (15 fields)
    T = "CBS_NACH_MANDATE"
    nodes += [
        vc(S,T,"MANDATE_ID",20,"Unique NACH mandate identifier for auto-debit setup."),
        vc(S,T,"ACCT_ID",20,"Loan account for which mandate is registered."),
        vc(S,T,"CUST_ID",20,"Customer who authorised the NACH mandate."),
        vc(S,T,"BANK_ACCT_NO",20,"Customer bank account number for NACH debit — PII.",True,["pii"]),
        vc(S,T,"BANK_IFSC",11,"IFSC code of customer bank account for NACH."),
        vc(S,T,"BANK_NAME",100,"Name of customer bank for NACH debit."),
        amt(S,T,"MANDATE_AMT","maximum debit amount authorised per NACH mandate"),
        dt(S,T,"MANDATE_START_DT","NACH mandate is effective from"),
        dt(S,T,"MANDATE_END_DT","NACH mandate expires — coincides with loan maturity"),
        vc(S,T,"MANDATE_STATUS",20,"Mandate status: ACTIVE, INACTIVE, CANCELLED, REJECTED, EXPIRED."),
        vc(S,T,"UMRN",20,"Unique Mandate Reference Number assigned by NPCI."),
        dt(S,T,"REGISTRATION_DT","mandate was registered with NPCI/bank"),
        dt(S,T,"LAST_DEBIT_DT","last successful NACH debit was executed"),
        num(S,T,"BOUNCE_COUNT","number of NACH bounces in mandate lifetime"),
        flag(S,T,"ENACH_FLAG","mandate is electronic (eNACH) rather than physical"),
    ]

    # CBS_CHARGES (15 fields)
    T = "CBS_CHARGES"
    nodes += [
        vc(S,T,"CHARGE_ID",20,"Unique charge transaction identifier."),
        vc(S,T,"ACCT_ID",20,"Loan account on which charge is levied."),
        vc(S,T,"CHARGE_TYPE",30,"Type: PROCESSING_FEE, PENAL_INTEREST, PREPAYMENT_PENALTY, LEGAL_CHARGES, VALUATION_FEE."),
        amt(S,T,"CHARGE_AMT","charge amount levied on the account"),
        dt(S,T,"CHARGE_DT","charge was levied on the account"),
        amt(S,T,"WAIVER_AMT","amount waived off from the original charge"),
        amt(S,T,"COLLECTED_AMT","amount actually collected from the charge levied"),
        vc(S,T,"STATUS",10,"Charge status: PENDING, COLLECTED, WAIVED, PARTIAL."),
        dt(S,T,"COLLECTION_DT","charge was collected from the customer"),
        vc(S,T,"WAIVER_REASON",100,"Reason documented for charge waiver — requires approval."),
        vc(S,T,"APPROVED_BY",50,"Officer who approved the charge waiver."),
        vc(S,T,"GST_NO",20,"GST invoice number for the charge — required for input tax credit."),
        pct(S,T,"GST_RATE","GST rate applicable on this charge type"),
        amt(S,T,"GST_AMT","GST amount included in the charge"),
        ts(S,T,"CREATED_DT","charge record was created in CBS"),
    ]

    # CBS_DISBURSEMENT (20 fields)
    T = "CBS_DISBURSEMENT"
    nodes += [
        vc(S,T,"DISB_ID",20,"Unique disbursement record identifier."),
        vc(S,T,"ACCT_ID",20,"Loan account against which disbursement is made."),
        vc(S,T,"TRANCHE_NO",5,"Disbursement tranche number — for construction/stage-based loans."),
        amt(S,T,"DISB_AMT","amount disbursed in this tranche"),
        dt(S,T,"DISB_DT","disbursement was made to borrower or developer"),
        vc(S,T,"DISB_MODE",20,"Disbursement mode: NEFT, RTGS, CHEQUE, DD, DIRECT_CREDIT."),
        vc(S,T,"BENEFICIARY_ACCT",20,"Beneficiary bank account for disbursement — builder/dealer/borrower.",True,["pii"]),
        vc(S,T,"BENEFICIARY_IFSC",11,"IFSC of beneficiary bank for disbursement credit."),
        vc(S,T,"BENEFICIARY_NAME",100,"Name of disbursement beneficiary — builder/dealer/borrower.",True,["pii"]),
        vc(S,T,"UTR_NO",30,"UTR number of NEFT/RTGS for disbursement reconciliation."),
        vc(S,T,"STATUS",10,"Disbursement status: PROCESSED, FAILED, REVERSED, PARTIAL."),
        amt(S,T,"DEDUCTIONS","upfront deductions from disbursement: processing fee, insurance."),
        amt(S,T,"NET_DISB_AMT","net amount credited after deductions"),
        vc(S,T,"PURPOSE",50,"Purpose of this disbursement tranche."),
        vc(S,T,"APPROVED_BY",50,"Credit officer who approved this disbursement."),
        ts(S,T,"APPROVED_DT","disbursement was approved for processing"),
        vc(S,T,"STAGE_CODE",20,"Construction stage code for staged disbursements (FOUNDATION, SLAB, ROOF, etc.)."),
        pct(S,T,"COMPLETION_PCT","construction completion percentage at time of this tranche"),
        vc(S,T,"INSPECTOR_ID",20,"Field inspector who verified completion for this tranche."),
        dt(S,T,"INSPECTION_DT","field inspection was conducted"),
    ]

    # CBS_LIMIT_MASTER (15 fields)
    T = "CBS_LIMIT_MASTER"
    nodes += [
        vc(S,T,"LIMIT_ID",20,"Unique limit record identifier."),
        vc(S,T,"CUST_ID",20,"Customer for whom credit limit is set."),
        vc(S,T,"ACCT_ID",20,"Account for revolving facility limit."),
        vc(S,T,"FACILITY_TYPE",20,"Facility type: CC, OD, WORKING_CAPITAL, KISAN_CC, CASH_CREDIT."),
        amt(S,T,"SANCTIONED_LIMIT","original sanctioned limit approved by credit committee"),
        amt(S,T,"CURRENT_LIMIT","current operative limit — may be reduced due to reviews"),
        amt(S,T,"UTILIZED_AMT","current drawdown against the limit"),
        amt(S,T,"AVAILABLE_LIMIT","undrawn balance = current limit minus utilised amount"),
        pct(S,T,"UTILIZATION_PCT","current utilisation percentage = utilised / limit × 100"),
        dt(S,T,"SANCTION_DT","limit was sanctioned by credit committee"),
        dt(S,T,"EXPIRY_DT","limit facility expires and requires renewal"),
        dt(S,T,"LAST_REVIEW_DT","limit was last reviewed by credit team"),
        dt(S,T,"NEXT_REVIEW_DT","next scheduled limit review is due"),
        vc(S,T,"REVIEW_STATUS",20,"Limit review status: ACTIVE, UNDER_REVIEW, ENHANCED, REDUCED, CANCELLED."),
        flag(S,T,"ADHOC_FLAG","this is an ad-hoc limit enhancement over sanctioned limit"),
    ]

    # ══════════════════════════════════════════════════════════════════
    # RISK — RISK ENGINE (250 fields)
    # ══════════════════════════════════════════════════════════════════
    S = "RISK"

    # RISK_CUSTOMER_SCORE (40 fields)
    T = "RISK_CUSTOMER_SCORE"
    nodes += [
        vc(S,T,"SCORE_ID",30,"Unique scoring run identifier for model governance and audit trail."),
        vc(S,T,"CUST_ID",20,"Customer ID — foreign key to CBS_CUSTOMER for score attribution."),
        num(S,T,"BUREAU_SCORE","external credit bureau score from CIBIL/Experian/Equifax"),
        vc(S,T,"BUREAU_SOURCE",20,"Bureau providing the score: CIBIL, EXPERIAN, EQUIFAX, CRIF_HIGHMARK."),
        dt(S,T,"BUREAU_DT","bureau score was pulled — staleness affects reliability"),
        num(S,T,"INTERNAL_SCORE","internally developed behavioural score from repayment and transaction history"),
        num(S,T,"COMPOSITE_SCORE","weighted composite combining bureau and internal scores — final credit decision input"),
        vc(S,T,"SCORE_BAND",10,"Risk band: A+ (800+), A (750-799), B (700-749), C (650-699), D (<650)."),
        dec(S,T,"PD_SCORE","8,6","Probability of Default — statistical likelihood of 90+ DPD in next 12 months."),
        pct(S,T,"LGD_PCT","Loss Given Default — estimated percentage of EAD not recovered on default"),
        amt(S,T,"EAD_AMT","Exposure at Default — total credit at risk at time of potential default"),
        amt(S,T,"EXPECTED_LOSS","Expected Loss = PD × LGD × EAD — minimum provisioning requirement per Basel"),
        amt(S,T,"UNEXPECTED_LOSS","capital buffer needed for tail risk events beyond expected loss"),
        dec(S,T,"RAROC_PCT","8,4","Risk-Adjusted Return on Capital — portfolio pricing and allocation metric."),
        vc(S,T,"RISK_APPETITE",10,"Customer risk classification: LOW, MEDIUM, HIGH, VERY_HIGH, UNACCEPTABLE."),
        flag(S,T,"WATCHLIST_FLAG","customer is on risk watchlist requiring enhanced monitoring"),
        flag(S,T,"EARLY_WARNING","active early warning signals triggering proactive intervention"),
        vc(S,T,"MODEL_VERSION",10,"Risk model version — essential for model validation and back-testing."),
        dt(S,T,"SCORE_DT","risk scoring was last computed for this customer"),
        dt(S,T,"NEXT_REVIEW_DT","next scheduled re-score based on risk band and policy"),
        flag(S,T,"OVERRIDE_FLAG","score was manually overridden by credit officer with approval"),
        vc(S,T,"OVERRIDE_REASON",100,"Documented reason for score override — mandatory audit trail."),
        vc(S,T,"APPROVED_BY",50,"Credit officer who approved the manual score override."),
        num(S,T,"DELINQUENCY_SCORE","delinquency propensity score based on historical payment behaviour"),
        num(S,T,"INCOME_VERIFICATION_SCORE","income stability score from employer category and vintage"),
        num(S,T,"COLLATERAL_SCORE","collateral quality score based on type, LTV and marketability"),
        num(S,T,"BUREAU_ENQUIRY_COUNT_3M","number of credit enquiries in last 3 months — multiple enquiries signal distress"),
        num(S,T,"BUREAU_ENQUIRY_COUNT_12M","number of credit enquiries in last 12 months"),
        num(S,T,"ACTIVE_TRADES","number of active credit trades (loans/cards) in bureau"),
        num(S,T,"DELINQUENT_TRADES","number of currently delinquent trades in bureau"),
        pct(S,T,"BUREAU_UTIL_PCT","credit utilisation across all revolving trades per bureau data"),
        num(S,T,"MONTHS_ON_BOOK","number of months since first credit account — credit vintage"),
        num(S,T,"MAX_DPD_24M","maximum DPD observed across all accounts in last 24 months"),
        num(S,T,"DPD_90_INSTANCES","count of 90+ DPD instances in last 24 months — NPA propensity"),
        dec(S,T,"NET_CREDIT_LIMIT","15,2","Total net credit limit across all trades per bureau."),
        dec(S,T,"NET_BALANCE","15,2","Total outstanding balance across all trades per bureau."),
        vc(S,T,"SCORING_ENGINE",30,"Scoring engine used: LOGISTIC_REGRESSION, GRADIENT_BOOSTING, NEURAL_NET."),
        vc(S,T,"CHAMPION_FLAG",1,"Y if this score is from champion model, N if challenger model."),
        vc(S,T,"SEGMENT_CODE",20,"Risk segment code for model-specific scoring."),
        ts(S,T,"SCORED_AT","scoring computation was completed"),
    ]

    # RISK_EXPOSURE_SUMMARY (30 fields)
    T = "RISK_EXPOSURE_SUMMARY"
    nodes += [
        vc(S,T,"CUST_ID",20,"Customer ID for cross-account exposure aggregation."),
        amt(S,T,"TOTAL_SANCTION","sum of all sanctioned limits across customer's active loan portfolio"),
        amt(S,T,"TOTAL_OUTSTANDING","aggregate outstanding principal — key credit concentration metric"),
        amt(S,T,"TOTAL_OVERDUE","total overdue amount across all accounts — primary stress signal"),
        amt(S,T,"TOTAL_EMI","sum of monthly EMIs — Fixed Obligation input for FOIR"),
        amt(S,T,"TOTAL_PROVISION","aggregate regulatory provision held for this customer"),
        pct(S,T,"FOIR","Fixed Obligation to Income Ratio = total EMI / monthly income × 100"),
        pct(S,T,"OVERALL_UTIL_PCT","overall credit utilisation across all revolving facilities"),
        num(S,T,"MAX_DPD_12M","maximum days past due across all accounts in last 12 months"),
        num(S,T,"MAX_DPD_24M","maximum days past due in last 24 months — historical depth"),
        num(S,T,"CURRENT_DPD","current days past due on most delinquent active account"),
        num(S,T,"DPD_30_COUNT","count of 30+ DPD instances in last 24 months"),
        num(S,T,"DPD_60_COUNT","count of 60+ DPD instances in last 24 months"),
        num(S,T,"DPD_90_COUNT","count of 90+ DPD — NPA trigger count in history"),
        flag(S,T,"NPA_FLAG","Y if any active account is NPA — regulatory and provisioning flag"),
        amt(S,T,"WRITTEN_OFF_AMT","lifetime written-off amount — measure of historical credit loss"),
        amt(S,T,"RECOVERY_AMT","amount recovered post write-off through settlement or legal"),
        num(S,T,"ACTIVE_ACCT_COUNT","count of currently active loan accounts — credit breadth"),
        num(S,T,"TOTAL_ACCT_COUNT","lifetime account count including closed — customer vintage"),
        num(S,T,"NPA_ACCT_COUNT","number of accounts currently classified NPA"),
        num(S,T,"RESTRUCTURED_ACCT_COUNT","count of accounts that have been restructured"),
        amt(S,T,"RESTRUCTURED_AMT","total outstanding in restructured accounts"),
        pct(S,T,"CONCENTRATION_RISK","single product type concentration as % of total exposure"),
        dt(S,T,"AS_OF_DT","date as of which this exposure summary was computed"),
        vc(S,T,"RISK_GRADE",5,"Composite risk grade: AAA, AA, A, BBB, BB, B, CCC, D."),
        amt(S,T,"CAPITAL_REQUIREMENT","regulatory capital required against this customer's exposure"),
        pct(S,T,"RISK_WEIGHT","risk weight applied to exposure for capital adequacy calculation"),
        flag(S,T,"LARGE_EXPOSURE","exposure exceeds large exposure threshold requiring board reporting"),
        num(S,T,"DAYS_SINCE_LAST_REVIEW","number of days since last risk review was conducted"),
        vc(S,T,"REVIEW_TRIGGER",50,"Trigger for last review: PERIODIC, EWS, NPA, REQUEST."),
    ]

    # RISK_EARLY_WARNING (25 fields)
    T = "RISK_EARLY_WARNING"
    nodes += [
        vc(S,T,"EWS_ID",30,"Unique early warning signal record for tracking and escalation."),
        vc(S,T,"CUST_ID",20,"Customer for whom the early warning was triggered."),
        vc(S,T,"ACCT_ID",20,"Specific account exhibiting stress behaviour."),
        vc(S,T,"SIGNAL_TYPE",30,"Warning type: EMI_BOUNCE, UTIL_SPIKE, BUREAU_ENQUIRY, INCOME_DROP, LEGAL_NOTICE, DPD_TREND."),
        dec(S,T,"SIGNAL_VALUE","10,2","Actual measured value of the signal at time of trigger."),
        dec(S,T,"THRESHOLD_VALUE","10,2","Policy threshold whose breach triggered this warning."),
        vc(S,T,"SEVERITY",10,"Alert severity: RED (immediate action), AMBER (monitor), GREEN (resolved)."),
        ts(S,T,"TRIGGERED_AT","early warning signal was first detected"),
        dt(S,T,"RESOLVED_DT","warning was resolved — cleared or escalated to collections"),
        vc(S,T,"ASSIGNED_TO",50,"RM or credit officer assigned to investigate."),
        vc(S,T,"ACTION_TAKEN",100,"Remedial action: CONTACTED_CUSTOMER, RESTRUCTURED, LIMIT_REDUCED, LEGAL."),
        vc(S,T,"REVIEWED_BY",50,"Senior credit officer who reviewed and signed off."),
        num(S,T,"DAYS_OPEN","number of days EWS has been open without resolution"),
        vc(S,T,"ESCALATION_LEVEL",10,"Escalation level: L1, L2, L3, BOARD — based on severity and days open."),
        vc(S,T,"RESOLUTION_STATUS",20,"Resolution status: OPEN, IN_PROGRESS, RESOLVED, ESCALATED, CLOSED."),
        vc(S,T,"SIGNAL_CATEGORY",20,"Category: PAYMENT, UTILISATION, BUREAU, LEGAL, BUSINESS, FINANCIAL."),
        num(S,T,"SIGNAL_FREQUENCY","count of times this signal type has triggered in last 12 months"),
        flag(S,T,"CRITICAL_FLAG","signal is critical requiring same-day action"),
        vc(S,T,"NOTES",500,"Detailed notes on investigation and action taken."),
        dt(S,T,"NEXT_FOLLOWUP_DT","next follow-up action is due"),
        vc(S,T,"FOLLOWUP_MODE",20,"Mode for next follow-up: CALL, VISIT, EMAIL, LEGAL."),
        amt(S,T,"POTENTIAL_LOSS","estimated potential credit loss if warning is not actioned"),
        vc(S,T,"MITIGATION_PLAN",200,"Mitigation plan documented by credit officer."),
        ts(S,T,"LAST_UPDATED_AT","EWS record was last modified"),
        vc(S,T,"UPDATED_BY",50,"User who last updated this EWS record."),
    ]

    # RISK_LIMIT_UTIL (20 fields)
    T = "RISK_LIMIT_UTIL"
    nodes += [
        vc(S,T,"ACCT_ID",20,"Account ID for limit utilisation tracking."),
        vc(S,T,"CUST_ID",20,"Customer owning this facility."),
        vc(S,T,"FACILITY_TYPE",20,"Facility type: TERM_LOAN, CC_LIMIT, OD_LIMIT, KISAN_CC, WC_DEMAND_LOAN."),
        amt(S,T,"CREDIT_LIMIT","approved credit limit for revolving facilities"),
        amt(S,T,"UTILIZED_AMT","current drawn amount against the credit limit"),
        amt(S,T,"AVAILABLE_LIMIT","undrawn balance = credit limit minus utilised amount"),
        pct(S,T,"UTILIZATION_PCT","utilisation percentage = utilised / limit × 100 — stress indicator"),
        pct(S,T,"AVG_UTIL_1M","one-month average utilisation for short-term trend"),
        pct(S,T,"AVG_UTIL_3M","three-month rolling average utilisation"),
        pct(S,T,"AVG_UTIL_6M","six-month rolling average for long-term pattern analysis"),
        pct(S,T,"PEAK_UTIL_12M","peak utilisation in last 12 months — seasonality indicator"),
        pct(S,T,"MIN_UTIL_12M","minimum utilisation in last 12 months — liquidity indicator"),
        dt(S,T,"LIMIT_REVIEW_DT","last credit limit review was conducted"),
        dt(S,T,"LIMIT_EXPIRY_DT","facility expires and requires renewal"),
        vc(S,T,"REVIEW_STATUS",20,"Review outcome: MAINTAINED, ENHANCED, REDUCED, CANCELLED."),
        flag(S,T,"OVERLIMIT_FLAG","account is currently over the sanctioned limit"),
        amt(S,T,"OVERLIMIT_AMT","amount by which account exceeds sanctioned limit"),
        num(S,T,"OVERLIMIT_DAYS","number of days account has been over limit"),
        dt(S,T,"AS_OF_DT","date as of which limit utilisation was computed"),
        flag(S,T,"ADHOC_LIMIT_FLAG","an ad-hoc limit enhancement is currently active"),
    ]

    # RISK_PROVISION (20 fields)
    T = "RISK_PROVISION"
    nodes += [
        vc(S,T,"PROVISION_ID",20,"Unique provision record identifier."),
        vc(S,T,"ACCT_ID",20,"Loan account against which provision is held."),
        vc(S,T,"CUST_ID",20,"Customer for provision reporting."),
        vc(S,T,"PROVISION_TYPE",20,"Provision type: SPECIFIC, GENERAL, STANDARD_ASSET, FLOATING."),
        pct(S,T,"PROVISION_RATE","provisioning rate applied per RBI asset classification norms"),
        amt(S,T,"PROVISION_AMT","amount held as regulatory provision for this account"),
        amt(S,T,"OUTSTANDING_AMT","outstanding balance on which provision is calculated"),
        vc(S,T,"NPA_CATEGORY",20,"NPA classification: SUB_STANDARD, DOUBTFUL_1, DOUBTFUL_2, DOUBTFUL_3, LOSS."),
        num(S,T,"NPA_AGE_MONTHS","number of months account has been in NPA status"),
        dt(S,T,"PROVISION_DT","provision was last calculated and booked"),
        dt(S,T,"CLASSIFICATION_DT","account was classified into current NPA category"),
        flag(S,T,"UPGRADE_ELIGIBLE","account meets criteria for NPA upgrade to standard asset"),
        amt(S,T,"COLLATERAL_COVERAGE","collateral value available against this provision"),
        pct(S,T,"PCR","provision coverage ratio for this account"),
        amt(S,T,"WRITE_OFF_AMT","amount written off from P&L"),
        dt(S,T,"WRITE_OFF_DT","write-off was approved and booked"),
        vc(S,T,"WRITE_OFF_REASON",100,"Board-approved reason for write-off."),
        flag(S,T,"TECHNICAL_WRITE_OFF","this is a technical write-off — recovery efforts continue"),
        amt(S,T,"RECOVERY_RESERVE","reserve maintained for post write-off recovery expectation"),
        ts(S,T,"COMPUTED_AT","provision computation was last run"),
    ]

    # RISK_FRAUD_ALERT (20 fields)
    T = "RISK_FRAUD_ALERT"
    nodes += [
        vc(S,T,"ALERT_ID",20,"Unique fraud alert identifier."),
        vc(S,T,"CUST_ID",20,"Customer flagged by fraud detection engine."),
        vc(S,T,"ACCT_ID",20,"Account involved in the suspected fraud event."),
        vc(S,T,"ALERT_TYPE",30,"Alert type: IDENTITY_THEFT, ACCOUNT_TAKEOVER, SYNTHETIC_FRAUD, BUST_OUT, MULE_ACCOUNT."),
        pct(S,T,"FRAUD_SCORE","fraud probability score from ML model — 0 to 100"),
        vc(S,T,"RISK_LEVEL",10,"Fraud risk level: LOW, MEDIUM, HIGH, CRITICAL."),
        ts(S,T,"ALERT_RAISED_AT","fraud alert was generated by the detection engine"),
        amt(S,T,"EXPOSED_AMT","amount exposed or at risk from this fraud event"),
        vc(S,T,"CHANNEL",20,"Channel where fraud was detected: ONLINE, MOBILE, BRANCH, ATM."),
        vc(S,T,"STATUS",20,"Alert status: OPEN, INVESTIGATING, CONFIRMED, FALSE_POSITIVE, CLOSED."),
        vc(S,T,"INVESTIGATED_BY",50,"Fraud investigation officer assigned to this case."),
        dt(S,T,"INVESTIGATION_DT","investigation was initiated"),
        vc(S,T,"FINDINGS",500,"Investigation findings and evidence documented."),
        flag(S,T,"POLICE_COMPLAINT","police complaint has been filed for this fraud case"),
        vc(S,T,"FIR_NO",30,"FIR number if police complaint filed."),
        amt(S,T,"RECOVERED_AMT","amount recovered in fraud case through legal or settlement"),
        amt(S,T,"LOSS_AMT","confirmed fraud loss after accounting for recovery"),
        vc(S,T,"FRAUD_CATEGORY",30,"Fraud category: INTERNAL, EXTERNAL, CYBER, DOCUMENT_FRAUD."),
        ts(S,T,"CLOSED_AT","fraud case was closed"),
        vc(S,T,"CLOSURE_REASON",100,"Reason for closing the fraud alert."),
    ]

    # ══════════════════════════════════════════════════════════════════
    # LOS — LOAN ORIGINATION SYSTEM (150 fields)
    # ══════════════════════════════════════════════════════════════════
    S = "LOS"

    # LOS_APPLICATION (40 fields)
    T = "LOS_APPLICATION"
    nodes += [
        vc(S,T,"APP_ID",20,"Unique loan application identifier in LOS."),
        vc(S,T,"CUST_ID",20,"Customer ID — links to existing CBS customer or new applicant."),
        dt(S,T,"APP_DT","loan application was submitted"),
        vc(S,T,"PRODUCT_TYPE",30,"Loan product applied for."),
        amt(S,T,"REQUESTED_AMT","loan amount requested by the applicant"),
        vc(S,T,"LOAN_PURPOSE",50,"Stated purpose of loan application."),
        vc(S,T,"APP_STATUS",20,"Application status: SUBMITTED, PROCESSING, SANCTIONED, REJECTED, DISBURSED, WITHDRAWN."),
        dt(S,T,"DECISION_DT","credit decision was made on this application"),
        vc(S,T,"DECISION_REASON",200,"Reason for sanction or rejection — documented for regulatory compliance."),
        amt(S,T,"SANCTIONED_AMT","amount sanctioned — may differ from requested amount"),
        pct(S,T,"SANCTIONED_RATE","interest rate sanctioned on this application"),
        num(S,T,"SANCTIONED_TENURE","loan tenure sanctioned in months"),
        vc(S,T,"REJECTION_REASON",100,"Primary rejection reason if application is declined."),
        vc(S,T,"CHANNEL",20,"Application channel: BRANCH, ONLINE, DSA, AGGREGATOR, MOBILE."),
        vc(S,T,"DSA_CODE",20,"DSA/channel partner code who sourced this application."),
        vc(S,T,"SOURCING_RM",20,"RM ID who sourced or processed this application."),
        vc(S,T,"CREDIT_ANALYST",20,"Credit analyst who evaluated this application."),
        vc(S,T,"CREDIT_MANAGER",20,"Credit manager who approved this application."),
        vc(S,T,"BRANCH_CODE",10,"Branch where application was submitted."),
        dec(S,T,"MONTHLY_INCOME","12,2","Declared monthly income at time of application."),
        dec(S,T,"ANNUAL_INCOME","15,2","Declared annual income at time of application."),
        vc(S,T,"EMPLOYER_NAME",100,"Employer name at time of application."),
        vc(S,T,"EMPLOYMENT_TYPE",30,"Employment type: SALARIED, SELF_EMPLOYED, BUSINESS."),
        pct(S,T,"FOIR_AT_APPLICATION","FOIR calculated at time of application before new loan"),
        pct(S,T,"FOIR_POST_SANCTION","FOIR calculated after including proposed new loan EMI"),
        num(S,T,"BUREAU_SCORE","bureau score at time of application — snapshot for audit"),
        pct(S,T,"LTV_REQUESTED","LTV ratio as per applicant's request"),
        pct(S,T,"LTV_SANCTIONED","LTV ratio as per sanctioned amount"),
        dt(S,T,"EXPIRY_DT","sanction letter expires — applicant must disburse before this"),
        vc(S,T,"CBS_ACCT_ID",20,"CBS account ID created after sanction and customer acceptance."),
        flag(S,T,"CO_APPLICANT_FLAG","application has a co-applicant"),
        vc(S,T,"CO_APPLICANT_ID",20,"Customer ID of co-applicant if applicable."),
        vc(S,T,"GUARANTOR_ID",20,"Customer ID of guarantor if applicable."),
        flag(S,T,"BUREAU_PULLED","credit bureau report was pulled for this application"),
        flag(S,T,"DEVIATION_FLAG","application has deviations from standard credit policy"),
        vc(S,T,"DEVIATION_TYPE",100,"Type of policy deviation approved for this application."),
        vc(S,T,"DEVIATION_APPROVER",50,"Officer who approved policy deviation."),
        ts(S,T,"CREATED_AT","application was first submitted in LOS"),
        ts(S,T,"LAST_UPDATED_AT","application record was last modified"),
        vc(S,T,"WORKFLOW_STAGE",30,"Current workflow stage: SUBMISSION, VERIFICATION, UNDERWRITING, SANCTION, DISBURSEMENT."),
    ]

    # LOS_DOCUMENT (20 fields)
    T = "LOS_DOCUMENT"
    nodes += [
        vc(S,T,"DOC_ID",20,"Unique document record identifier in LOS."),
        vc(S,T,"APP_ID",20,"Application ID this document is associated with."),
        vc(S,T,"CUST_ID",20,"Customer who submitted this document."),
        vc(S,T,"DOC_TYPE",30,"Document type: INCOME_PROOF, ID_PROOF, ADDRESS_PROOF, PROPERTY_DOCS, BANK_STATEMENT."),
        vc(S,T,"DOC_NAME",100,"Specific document name: SALARY_SLIP, FORM_16, ITRV, AADHAAR, PAN, etc."),
        vc(S,T,"DOC_STATUS",20,"Document status: SUBMITTED, VERIFIED, REJECTED, PENDING_RESUBMISSION."),
        dt(S,T,"UPLOAD_DT","document was uploaded into LOS"),
        vc(S,T,"VERIFIED_BY",50,"Officer who verified this document."),
        dt(S,T,"VERIFICATION_DT","document verification was completed"),
        vc(S,T,"REJECTION_REASON",200,"Reason document was rejected — communicated to applicant."),
        vc(S,T,"FILE_PATH",300,"Document storage path in DMS — not exposed externally."),
        vc(S,T,"FILE_SIZE",20,"Document file size for storage management."),
        vc(S,T,"FILE_FORMAT",10,"Document format: PDF, JPG, PNG, TIFF."),
        flag(S,T,"ORIGINAL_RECEIVED","original physical document has been received and verified"),
        flag(S,T,"DIGITALLY_SIGNED","document has valid digital signature"),
        dt(S,T,"EXPIRY_DT","document validity expires — for time-bound documents"),
        vc(S,T,"OCR_STATUS",20,"OCR extraction status: PENDING, COMPLETED, FAILED, MANUAL_OVERRIDE."),
        vc(S,T,"OCR_DATA",1000,"Extracted data from document via OCR — JSON format."),
        ts(S,T,"CREATED_AT","document record was created in LOS"),
        flag(S,T,"MASKED","sensitive fields in this document have been masked for privacy"),
    ]

    # LOS_CREDIT_DECISION (20 fields)
    T = "LOS_CREDIT_DECISION"
    nodes += [
        vc(S,T,"DECISION_ID",20,"Unique credit decision record identifier."),
        vc(S,T,"APP_ID",20,"Application for which decision was made."),
        vc(S,T,"DECISION_TYPE",20,"Decision type: SYSTEM_DECISION, MANUAL_OVERRIDE, ESCALATION."),
        vc(S,T,"DECISION",20,"Credit decision: APPROVE, REJECT, REFER, COUNTER_OFFER."),
        num(S,T,"SCORE_AT_DECISION","credit score at time of decision — point-in-time snapshot"),
        pct(S,T,"RISK_BAND_AT_DECISION","risk band at time of decision"),
        vc(S,T,"DECISION_REASON",500,"Detailed reasoning for credit decision — regulatory requirement."),
        vc(S,T,"POLICY_RULE_APPLIED",200,"Credit policy rules triggered in this decision."),
        flag(S,T,"POLICY_COMPLIANT","decision is within standard credit policy parameters"),
        vc(S,T,"DEVIATION_APPROVED",200,"Approved policy deviations documented."),
        vc(S,T,"DECIDED_BY",50,"Officer or system that made the credit decision."),
        ts(S,T,"DECIDED_AT","credit decision was made"),
        vc(S,T,"REVIEW_LEVEL",10,"Review level required: L1, L2, L3, CREDIT_COMMITTEE."),
        flag(S,T,"COMMITTEE_APPROVAL","credit committee approval was obtained for this decision"),
        dt(S,T,"COMMITTEE_DT","credit committee met to decide on this application"),
        vc(S,T,"COUNTER_OFFER_TERMS",300,"Counter-offer terms if decision is COUNTER_OFFER."),
        flag(S,T,"APPEAL_FLAG","applicant has appealed the rejection decision"),
        vc(S,T,"APPEAL_OUTCOME",50,"Outcome of rejection appeal: UPHELD, OVERTURNED."),
        vc(S,T,"BUREAU_REMARKS",500,"Credit analyst remarks on bureau report findings."),
        ts(S,T,"EXPIRES_AT","sanction decision validity expires"),
    ]

    # LOS_FIELD_INVESTIGATION (15 fields)
    T = "LOS_FIELD_INVESTIGATION"
    nodes += [
        vc(S,T,"FI_ID",20,"Unique field investigation record identifier."),
        vc(S,T,"APP_ID",20,"Application for which FI is being conducted."),
        vc(S,T,"FI_TYPE",20,"FI type: RESIDENCE, OFFICE, BUSINESS, COLLATERAL."),
        vc(S,T,"AGENCY_CODE",20,"Field investigation agency assigned."),
        vc(S,T,"INVESTIGATOR_ID",20,"Field investigator ID from agency."),
        dt(S,T,"ASSIGNED_DT","FI was assigned to agency"),
        dt(S,T,"VISIT_DT","field investigator visited the site"),
        vc(S,T,"OUTCOME",20,"FI outcome: POSITIVE, NEGATIVE, REFER_BACK."),
        vc(S,T,"ADDRESS_CONFIRMED","VARCHAR(1)","Y/N whether residential/office address was confirmed."),
        flag(S,T,"PERSON_MET","person met at the address during FI visit"),
        vc(S,T,"PERSON_MET_NAME",100,"Name of person met during FI visit.",True,["pii"]),
        vc(S,T,"REMARKS",500,"Detailed FI remarks and observations."),
        vc(S,T,"NEGATIVE_REASON",200,"Reason for negative FI outcome."),
        vc(S,T,"PHOTO_ATTACHED","VARCHAR(1)","Y/N whether site photographs were attached to FI report."),
        ts(S,T,"REPORT_SUBMITTED_AT","FI report was submitted by agency"),
    ]

    # LOS_REFERENCE_CHECK (15 fields)
    T = "LOS_REFERENCE_CHECK"
    nodes += [
        vc(S,T,"REF_ID",20,"Unique reference check record identifier."),
        vc(S,T,"APP_ID",20,"Application for which reference check was done."),
        vc(S,T,"REF_TYPE",20,"Reference type: PERSONAL, PROFESSIONAL, EMPLOYER, NEIGHBOUR."),
        vc(S,T,"REF_NAME",100,"Name of reference person.",True,["pii"]),
        vc(S,T,"REF_MOBILE",15,"Mobile number of reference person.",True,["pii"]),
        vc(S,T,"REF_RELATION",30,"Relationship to applicant."),
        ts(S,T,"CONTACTED_AT","reference was contacted"),
        vc(S,T,"CONTACTED_BY",50,"Officer who conducted reference check."),
        vc(S,T,"OUTCOME",20,"Reference outcome: POSITIVE, NEGATIVE, NOT_REACHABLE."),
        vc(S,T,"FEEDBACK",300,"Detailed feedback from reference check."),
        flag(S,T,"APPLICANT_KNOWN","reference confirmed knowing the applicant"),
        flag(S,T,"INCOME_CONFIRMED","reference confirmed applicant's stated income"),
        flag(S,T,"ADDRESS_CONFIRMED","reference confirmed applicant's address"),
        vc(S,T,"NEGATIVE_REMARKS",200,"Negative remarks from reference if any."),
        ts(S,T,"UPDATED_AT","reference check record was updated"),
    ]

    # ══════════════════════════════════════════════════════════════════
    # MIS — MANAGEMENT INFORMATION SYSTEM (200 fields)
    # ══════════════════════════════════════════════════════════════════
    S = "MIS"

    # MIS_PORTFOLIO_SUMMARY (40 fields)
    T = "MIS_PORTFOLIO_SUMMARY"
    nodes += [
        dt(S,T,"REPORT_DT","portfolio metrics snapshot was computed"),
        vc(S,T,"REPORT_PERIOD",10,"Reporting frequency: DAILY, WEEKLY, MONTHLY, QUARTERLY, ANNUAL."),
        vc(S,T,"PRODUCT_TYPE",30,"Loan product segment for portfolio slicing."),
        vc(S,T,"REGION",30,"Geographic region for regional MD/CEO portfolio review."),
        vc(S,T,"SEGMENT",20,"Customer segment: RETAIL, SME, CORPORATE, AGRI, MICRO_FINANCE."),
        vc(S,T,"BRANCH_CODE",10,"Branch code for branch-level portfolio reporting."),
        num(S,T,"TOTAL_ACCOUNTS","total loan accounts in portfolio segment"),
        num(S,T,"ACTIVE_ACCOUNTS","accounts in active repayment — performing portfolio count"),
        num(S,T,"CLOSED_ACCOUNTS","accounts closed in the reporting period"),
        num(S,T,"NPA_ACCOUNTS","accounts classified NPA per RBI guidelines"),
        num(S,T,"SMA_0_ACCOUNTS","accounts in SMA-0 (0-30 DPD) — early warning basket"),
        num(S,T,"SMA_1_ACCOUNTS","accounts in SMA-1 (31-60 DPD)"),
        num(S,T,"SMA_2_ACCOUNTS","accounts in SMA-2 (61-90 DPD) — pre-NPA basket"),
        amt(S,T,"TOTAL_SANCTION","total sanctioned amount — portfolio size for Board MIS"),
        amt(S,T,"TOTAL_OUTSTANDING","total outstanding principal — primary balance sheet credit line"),
        amt(S,T,"TOTAL_DISBURSEMENT","new disbursements in reporting period — growth metric"),
        amt(S,T,"TOTAL_OVERDUE","total overdue — precursor to NPA, closely monitored by management"),
        amt(S,T,"SMA_0_AMT","outstanding in SMA-0 accounts"),
        amt(S,T,"SMA_1_AMT","outstanding in SMA-1 accounts"),
        amt(S,T,"SMA_2_AMT","outstanding in SMA-2 accounts — last intervention point before NPA"),
        amt(S,T,"NPA_AMOUNT","total outstanding in NPA accounts — provisioning and capital input"),
        pct(S,T,"NPA_PCT","NPA % = NPA outstanding / total outstanding — headline asset quality"),
        pct(S,T,"GNPA_PCT","Gross NPA % before provisions — mandatory RBI quarterly disclosure"),
        pct(S,T,"NNPA_PCT","Net NPA % after provisions — key bank financial health indicator"),
        amt(S,T,"PROVISION_AMT","cumulative provision held against NPA and SMA accounts"),
        pct(S,T,"PCR_PCT","Provision Coverage Ratio — adequacy of provisions vs gross NPA"),
        pct(S,T,"YIELD_PCT","portfolio yield = interest income / average outstanding × 100"),
        pct(S,T,"COST_OF_FUNDS","average cost of funds raised to lend this portfolio"),
        pct(S,T,"NIM_PCT","Net Interest Margin = yield minus cost of funds — profitability"),
        amt(S,T,"WRITE_OFF_AMT","amount written off in the period — credit loss crystallisation"),
        amt(S,T,"RECOVERY_AMT","post write-off recovery in period — partial credit loss reversal"),
        amt(S,T,"NET_CREDIT_LOSS","net credit loss = write-offs minus recoveries — P&L charge"),
        pct(S,T,"CAR_PCT","Capital Adequacy Ratio — Basel III Pillar 1 regulatory capital metric"),
        pct(S,T,"SLRR_PCT","Statutory Liquidity Ratio — RBI mandated minimum SLR maintenance"),
        pct(S,T,"CRRR_PCT","Cash Reserve Ratio — mandatory cash reserve with RBI"),
        amt(S,T,"TOTAL_COLLECTION","total EMI and overdue collections in the period"),
        pct(S,T,"COLLECTION_EFFICIENCY","collection efficiency = collected / demanded × 100"),
        amt(S,T,"INTEREST_INCOME","total interest income recognised in the period"),
        amt(S,T,"FEE_INCOME","total fee and charge income in the period"),
        pct(S,T,"RETURN_ON_ASSETS","annualised net profit / average total assets × 100"),
    ]

    # MIS_CUSTOMER_SCORECARD (30 fields)
    T = "MIS_CUSTOMER_SCORECARD"
    nodes += [
        dt(S,T,"REPORT_DT","scorecard snapshot date for period-on-period trend analysis"),
        vc(S,T,"CUST_ID",20,"Customer ID from CBS for scorecard linkage."),
        vc(S,T,"CLIENT_NAME",100,"Customer display name for management reports.",True,["pii"]),
        num(S,T,"CREDIT_SCORE","composite risk score sourced from RISK engine for this period"),
        vc(S,T,"RISK_CATEGORY",20,"Traffic-light risk classification: GREEN, AMBER, RED, WATCH, EXIT."),
        amt(S,T,"TOTAL_EXPOSURE","total credit exposure as of report date"),
        pct(S,T,"UTILIZATION_PCT","utilisation across revolving facilities in this scorecard"),
        vc(S,T,"DPD_STATUS",20,"Delinquency status bucket: REGULAR, 1-30, 31-60, 61-90, 90+ (NPA)."),
        flag(S,T,"NPA_FLAG","NPA classification flag for management NPA review meetings"),
        amt(S,T,"PROVISION_AMT","provision allocated to this customer for period-end reporting"),
        vc(S,T,"EWS_STATUS",10,"Active early warning signal status: NONE, GREEN, AMBER, RED."),
        vc(S,T,"RM_NAME",100,"Relationship manager name for escalation and accountability."),
        vc(S,T,"BRANCH_CODE",10,"Branch responsible for this customer relationship."),
        dt(S,T,"LAST_REVIEW_DT","last credit review was conducted"),
        dt(S,T,"NEXT_REVIEW_DT","next scheduled credit review is due"),
        vc(S,T,"REVIEW_FREQUENCY",10,"Review frequency based on risk: MONTHLY, QUARTERLY, ANNUAL."),
        num(S,T,"ACTIVE_FACILITIES","number of active credit facilities in the scorecard"),
        amt(S,T,"LARGEST_EXPOSURE","amount of largest single facility — concentration indicator"),
        vc(S,T,"PRODUCT_MIX",100,"CSV of product types in portfolio: HOME_LOAN,PERSONAL_LOAN,CC."),
        pct(S,T,"SCORE_CHANGE_QOQ","change in composite score from previous quarter"),
        flag(S,T,"DETERIORATION_FLAG","score has deteriorated by more than threshold vs last period"),
        vc(S,T,"RATING_CHANGE",20,"Rating movement: UPGRADE, DOWNGRADE, STABLE."),
        vc(S,T,"COMMENTS",500,"Credit analyst comments for this scorecard period."),
        flag(S,T,"BOARD_REPORTING","exposure requires board-level reporting due to size or risk"),
        flag(S,T,"RELATED_PARTY","customer is a related party requiring special disclosure"),
        amt(S,T,"NET_WORTH","declared net worth of customer — large exposure assessment"),
        pct(S,T,"LEVERAGE_RATIO","total debt / net worth — borrower financial health metric"),
        pct(S,T,"DSCR","Debt Service Coverage Ratio for business borrowers"),
        amt(S,T,"INSURANCE_COVERAGE","total insurance coverage on credit facilities"),
        vc(S,T,"CUST_SEGMENT",20,"Customer segment classification in the scorecard."),
    ]

    # MIS_COLLECTIONS_DASHBOARD (25 fields)
    T = "MIS_COLLECTIONS_DASHBOARD"
    nodes += [
        dt(S,T,"REPORT_DT","collections dashboard snapshot date"),
        vc(S,T,"REGION",30,"Region for collections performance rollup."),
        vc(S,T,"BUCKET",10,"DPD bucket: 0-30, 31-60, 61-90, 91-180, 181-360, 360+."),
        vc(S,T,"PRODUCT_TYPE",30,"Product type for collections segmentation."),
        num(S,T,"ACCOUNTS_IN_BUCKET","count of accounts in this DPD bucket"),
        amt(S,T,"OUTSTANDING_IN_BUCKET","total outstanding in this DPD bucket"),
        amt(S,T,"OVERDUE_IN_BUCKET","total overdue amount in this DPD bucket"),
        amt(S,T,"DEMAND","total demand (EMI due) for the period"),
        amt(S,T,"COLLECTION","total amount collected in the period"),
        pct(S,T,"COLLECTION_EFFICIENCY","collection efficiency = collected / demand × 100"),
        num(S,T,"ACCOUNTS_RESOLVED","accounts that moved to regular (bucket-0) in period"),
        num(S,T,"ACCOUNTS_ESCALATED","accounts that moved to higher DPD bucket in period"),
        amt(S,T,"RECOVERY_FROM_WRITEOFF","recovery from previously written-off accounts"),
        num(S,T,"TOTAL_AGENTS","total collections agents assigned to this segment"),
        num(S,T,"CALLS_MADE","total collection calls made in the period"),
        num(S,T,"VISITS_MADE","total field visits made in the period"),
        num(S,T,"PTP_COUNT","count of Promise-to-Pay commitments received"),
        amt(S,T,"PTP_AMT","total amount committed in PTP arrangements"),
        pct(S,T,"PTP_KEPT_PCT","percentage of PTP commitments honoured"),
        num(S,T,"LEGAL_NOTICES_SENT","legal notices dispatched under SARFAESI or court proceedings"),
        amt(S,T,"LEGAL_RECOVERY","recovery through legal proceedings in the period"),
        pct(S,T,"RESOLUTION_RATE","percentage of accounts resolved vs total accounts assigned"),
        pct(S,T,"ROLL_FORWARD_RATE","percentage of accounts rolling to higher DPD bucket"),
        pct(S,T,"ROLL_BACK_RATE","percentage of accounts improving to lower DPD bucket"),
        vc(S,T,"TARGET_COLLECTION_AMT","DECIMAL(18,2)","Target collection amount set for this segment."),
    ]

    # MIS_BRANCH_PERFORMANCE (25 fields)
    T = "MIS_BRANCH_PERFORMANCE"
    nodes += [
        dt(S,T,"REPORT_DT","branch performance measurement date"),
        vc(S,T,"BRANCH_CODE",10,"Branch code for performance attribution."),
        vc(S,T,"BRANCH_NAME",100,"Branch name for performance dashboards."),
        vc(S,T,"REGION",30,"Region for regional manager rollup."),
        vc(S,T,"ZONE",20,"Zone grouping multiple regions for national reporting."),
        vc(S,T,"BRANCH_MANAGER",50,"Branch manager name for accountability reporting."),
        amt(S,T,"DISBURSEMENTS","new loan disbursements from this branch — growth metric"),
        amt(S,T,"COLLECTIONS","total EMI and overdue collections from branch portfolio"),
        amt(S,T,"NPA_AMOUNT","NPA outstanding in branch portfolio — branch risk quality metric"),
        pct(S,T,"NPA_PCT","branch NPA % — key metric in branch manager performance appraisal"),
        num(S,T,"NEW_CUSTOMERS","new customers onboarded from this branch"),
        num(S,T,"NEW_ACCOUNTS","new loan accounts opened at this branch"),
        num(S,T,"ACTIVE_ACCOUNTS","active loan accounts managed by branch"),
        pct(S,T,"TARGET_ACHV_PCT","disbursement target achievement % for MBO incentives"),
        pct(S,T,"COLLECTION_EFF","collection efficiency = collected / demanded × 100"),
        amt(S,T,"DISB_TARGET","disbursement target for this branch in the period"),
        amt(S,T,"COLLECTION_TARGET","collection target for this branch"),
        pct(S,T,"YOY_GROWTH_PCT","year-on-year disbursement growth percentage"),
        pct(S,T,"QOQ_GROWTH_PCT","quarter-on-quarter disbursement growth"),
        num(S,T,"CUSTOMER_COMPLAINTS","number of customer complaints received at branch"),
        pct(S,T,"COMPLAINT_RESOLUTION_PCT","percentage of complaints resolved within TAT"),
        pct(S,T,"CROSS_SELL_RATIO","cross-sell product penetration at branch"),
        pct(S,T,"AVERAGE_TICKET_SIZE","average loan ticket size for new disbursements"),
        num(S,T,"STAFF_COUNT","total staff count at branch for productivity metrics"),
        pct(S,T,"PRODUCTIVITY_PER_STAFF","disbursements per staff member — productivity metric"),
    ]

    # MIS_REGULATORY_REPORT (20 fields)
    T = "MIS_REGULATORY_REPORT"
    nodes += [
        vc(S,T,"REPORT_ID",20,"Unique regulatory report submission identifier."),
        dt(S,T,"REPORT_DT","reporting date for this regulatory submission"),
        vc(S,T,"REGULATOR",20,"Regulatory body: RBI, SEBI, IRDAI, NHB, SIDBI, FIU."),
        vc(S,T,"REPORT_TYPE",30,"Report type: NPA, PRIORITY_SECTOR, CRILC, FMR, SLR, CRR, CAPITAL_ADEQUACY."),
        dt(S,T,"SUBMISSION_DT","report was submitted to regulator"),
        dt(S,T,"DUE_DT","regulatory submission due date — penalty if missed"),
        vc(S,T,"STATUS",20,"Submission status: DRAFT, REVIEWED, SUBMITTED, ACCEPTED, RESUBMIT_REQUIRED."),
        vc(S,T,"PREPARED_BY",50,"User ID who prepared the regulatory report."),
        vc(S,T,"REVIEWED_BY",50,"User ID who reviewed before submission."),
        vc(S,T,"APPROVED_BY",50,"Senior officer who approved regulatory submission."),
        flag(S,T,"PENALTY_APPLICABLE","submission was late and regulatory penalty may apply"),
        amt(S,T,"PENALTY_AMT","penalty amount levied by regulator for late submission"),
        vc(S,T,"REGULATOR_REMARKS",500,"Remarks received from regulator on this submission."),
        flag(S,T,"RESUBMISSION_REQUIRED","regulator has asked for resubmission with corrections"),
        vc(S,T,"CORRECTION_NOTES",300,"Notes on corrections made for resubmission."),
        vc(S,T,"SUBMISSION_MODE",20,"Mode: XBRL, EXCEL, ONLINE_PORTAL, EMAIL."),
        vc(S,T,"ACKNOWLEDGEMENT_NO",50,"Acknowledgement number received from regulator portal."),
        vc(S,T,"REFERENCE_NO",30,"Internal reference number for this regulatory submission."),
        flag(S,T,"CONFIDENTIAL","report contains confidential supervisory information"),
        ts(S,T,"CREATED_AT","report record was created"),
    ]

    # MIS_AUDIT_TRAIL (20 fields)
    T = "MIS_AUDIT_TRAIL"
    nodes += [
        vc(S,T,"AUDIT_ID",30,"Unique audit trail record identifier."),
        vc(S,T,"ENTITY_TYPE",30,"Entity being audited: FIELD, EDGE, REPORT, USER, CONFIG."),
        vc(S,T,"ENTITY_ID",50,"ID of the entity being audited."),
        vc(S,T,"ACTION",20,"Action performed: CREATE, UPDATE, DELETE, APPROVE, REJECT."),
        vc(S,T,"OLD_VALUE",500,"Previous value before change — for data lineage audit."),
        vc(S,T,"NEW_VALUE",500,"New value after change."),
        vc(S,T,"CHANGED_BY",50,"User ID who made the change."),
        ts(S,T,"CHANGED_AT","change was made to the entity"),
        vc(S,T,"IP_ADDRESS",45,"IP address from which change was made.",True,["pii","security"]),
        vc(S,T,"SESSION_ID",50,"Session identifier for the change transaction."),
        vc(S,T,"CHANGE_REASON",200,"Business reason for the change — required for sensitive fields."),
        vc(S,T,"APPROVED_BY",50,"Approving officer for changes requiring dual control."),
        ts(S,T,"APPROVED_AT","change was approved by approving officer"),
        vc(S,T,"APPROVAL_STATUS",20,"Approval status: PENDING, APPROVED, REJECTED, AUTO_APPROVED."),
        flag(S,T,"REVERSAL_FLAG","this change was subsequently reversed"),
        vc(S,T,"REVERSAL_REASON",200,"Reason for reversal of this change."),
        vc(S,T,"SYSTEM_SOURCE",30,"System that originated this change."),
        vc(S,T,"BATCH_ID",30,"Batch run ID for batch-originated changes."),
        flag(S,T,"CRITICAL_CHANGE","change to a critical/sensitive field requiring notification"),
        vc(S,T,"NOTIFICATION_SENT",100,"Stakeholders notified of this critical change."),
    ]

    # ══════════════════════════════════════════════════════════════════
    # BUREAU — CREDIT BUREAU DATA (100 fields)
    # ══════════════════════════════════════════════════════════════════
    S = "BUREAU"

    # BUREAU_CREDIT_REPORT (40 fields)
    T = "BUREAU_CREDIT_REPORT"
    nodes += [
        vc(S,T,"REPORT_ID",30,"Unique bureau report identifier for this enquiry."),
        vc(S,T,"CUST_ID",20,"Customer ID from CBS who the bureau report belongs to."),
        vc(S,T,"PAN_NUMBER",10,"PAN number used as primary identifier for bureau query.",True,["pii","kyc"]),
        vc(S,T,"BUREAU_NAME",20,"Bureau providing the report: CIBIL, EXPERIAN, EQUIFAX, CRIF."),
        vc(S,T,"REPORT_VERSION",10,"Bureau report version — format may differ across versions."),
        dt(S,T,"REPORT_DT","bureau report was generated by the bureau"),
        dt(S,T,"ENQUIRY_DT","bureau was queried for this report"),
        vc(S,T,"ENQUIRY_PURPOSE",30,"Enquiry purpose: LOAN_APPLICATION, PERIODIC_REVIEW, MONITORING, COLLECTIONS."),
        vc(S,T,"ENQUIRY_MEMBER",50,"Member institution that made the enquiry."),
        num(S,T,"BUREAU_SCORE","credit bureau composite score at time of report pull"),
        vc(S,T,"SCORE_VERSION",10,"Bureau scoring model version used for this score."),
        vc(S,T,"RISK_GRADE",5,"Bureau risk grade: NH (No History), 1-9 (CIBIL), or letter grade."),
        num(S,T,"TOTAL_ACCOUNTS","total credit accounts reported to bureau"),
        num(S,T,"ACTIVE_ACCOUNTS","currently active accounts per bureau"),
        num(S,T,"CLOSED_ACCOUNTS","closed accounts in bureau history"),
        num(S,T,"OVERDUE_ACCOUNTS","accounts currently overdue per bureau"),
        num(S,T,"NPA_ACCOUNTS","accounts classified NPA in bureau history"),
        amt(S,T,"TOTAL_CREDIT_LIMIT","total sanctioned credit limit across all accounts"),
        amt(S,T,"TOTAL_OUTSTANDING","total outstanding balance across all bureau accounts"),
        amt(S,T,"TOTAL_OVERDUE","total overdue amount across all bureau accounts"),
        pct(S,T,"OVERALL_UTILISATION","total utilisation across all revolving accounts"),
        num(S,T,"ENQUIRY_COUNT_6M","total credit enquiries in last 6 months — shopping indicator"),
        num(S,T,"ENQUIRY_COUNT_12M","total credit enquiries in last 12 months"),
        num(S,T,"ENQUIRY_COUNT_24M","total credit enquiries in last 24 months"),
        num(S,T,"DPD_30_INSTANCES","count of 30+ DPD instances in last 24 months"),
        num(S,T,"DPD_60_INSTANCES","count of 60+ DPD instances in last 24 months"),
        num(S,T,"DPD_90_INSTANCES","count of 90+ DPD instances in bureau history"),
        num(S,T,"MAX_DPD_12M","maximum DPD observed across all accounts in last 12 months"),
        num(S,T,"MAX_DPD_24M","maximum DPD in last 24 months"),
        num(S,T,"MAX_DPD_LIFETIME","maximum DPD ever observed in bureau history"),
        num(S,T,"MONTHS_MEMBER","number of months customer has been a bureau member"),
        num(S,T,"OLDEST_ACCOUNT_AGE","age in months of oldest active account — credit vintage"),
        flag(S,T,"WRITTEN_OFF_HISTORY","customer has write-off in bureau history"),
        amt(S,T,"WRITTEN_OFF_AMT","total amount written off across all accounts in bureau"),
        flag(S,T,"SETTLED_HISTORY","customer has settled accounts (partial payment) in history"),
        vc(S,T,"DISPUTE_STATUS",20,"Bureau dispute status if customer has filed a dispute."),
        vc(S,T,"FREEZE_STATUS",20,"Account freeze status if customer has requested credit freeze."),
        num(S,T,"SECURED_ACCOUNTS","count of secured loan accounts (home, auto, LAP)"),
        num(S,T,"UNSECURED_ACCOUNTS","count of unsecured accounts (personal loan, credit card)"),
        num(S,T,"CREDIT_CARD_COUNT","number of active credit cards in bureau"),
    ]

    # BUREAU_TRADE_LINE (30 fields)
    T = "BUREAU_TRADE_LINE"
    nodes += [
        vc(S,T,"TRADE_ID",30,"Unique trade line identifier in bureau report."),
        vc(S,T,"REPORT_ID",30,"Bureau report this trade line belongs to."),
        vc(S,T,"CUST_ID",20,"Customer this trade line belongs to."),
        vc(S,T,"LENDER_NAME",100,"Name of lender who reported this trade line."),
        vc(S,T,"ACCOUNT_NUMBER",30,"Masked account number as reported to bureau.",True,["pii"]),
        vc(S,T,"ACCOUNT_TYPE",20,"Account type: HOME_LOAN, AUTO_LOAN, PL, CC, OD, AGRI."),
        dt(S,T,"OPEN_DT","account was opened"),
        dt(S,T,"CLOSE_DT","account was closed — null if active"),
        amt(S,T,"CREDIT_LIMIT","sanctioned limit on this account"),
        amt(S,T,"CURRENT_BALANCE","current outstanding balance"),
        amt(S,T,"OVERDUE_AMT","amount overdue on this account"),
        num(S,T,"EMI_AMT","monthly EMI for this account"),
        pct(S,T,"INTEREST_RATE","interest rate on this account"),
        vc(S,T,"ACCOUNT_STATUS",20,"Account status: ACTIVE, CLOSED, NPA, SETTLED, WRITTEN_OFF."),
        num(S,T,"CURRENT_DPD","current days past due on this account"),
        num(S,T,"MAX_DPD_12M","maximum DPD on this account in last 12 months"),
        num(S,T,"MAX_DPD_24M","maximum DPD on this account in last 24 months"),
        vc(S,T,"REPAYMENT_HISTORY",24,"24-month repayment history string: 0=current, 1=30DPD, 2=60DPD, etc."),
        flag(S,T,"WRITTEN_OFF","account has been written off by lender"),
        amt(S,T,"WRITTEN_OFF_AMT","amount written off on this account"),
        flag(S,T,"SETTLED","account was settled for less than full outstanding"),
        amt(S,T,"SETTLED_AMT","amount accepted in settlement"),
        num(S,T,"TENURE_MONTHS","original loan tenure"),
        num(S,T,"EMI_PAID_COUNT","EMIs paid — derived from repayment history"),
        num(S,T,"EMI_BOUNCE_COUNT","EMIs bounced in account history"),
        vc(S,T,"COLLATERAL_TYPE",20,"Collateral type securing this account."),
        vc(S,T,"OWNERSHIP",20,"Ownership: INDIVIDUAL, JOINT, GUARANTOR."),
        vc(S,T,"CREDIT_FACILITY",20,"Facility type: SECURED, UNSECURED, REVOLVING, TERM."),
        num(S,T,"SUIT_FILED","Y if legal suit has been filed against borrower on this account"),
        dt(S,T,"LAST_PAYMENT_DT","last payment was made on this account"),
    ]

    # BUREAU_ENQUIRY (15 fields)
    T = "BUREAU_ENQUIRY"
    nodes += [
        vc(S,T,"ENQUIRY_ID",30,"Unique enquiry record in bureau."),
        vc(S,T,"REPORT_ID",30,"Bureau report this enquiry belongs to."),
        vc(S,T,"MEMBER_NAME",100,"Lender/institution that made the enquiry."),
        vc(S,T,"MEMBER_ID",20,"Bureau member ID of the institution."),
        dt(S,T,"ENQUIRY_DT","enquiry was made to the bureau"),
        vc(S,T,"ENQUIRY_PURPOSE",30,"Purpose: LOAN, CREDIT_CARD, REVIEW, COLLECTION, MONITORING."),
        amt(S,T,"ENQUIRY_AMOUNT","loan amount applied for in this enquiry"),
        vc(S,T,"PRODUCT_TYPE",30,"Product type for which enquiry was made."),
        vc(S,T,"ENQUIRY_TYPE",20,"Enquiry type: HARD (affects score), SOFT (monitoring)."),
        num(S,T,"DAYS_SINCE_ENQUIRY","number of days since this enquiry was made"),
        flag(S,T,"APPROVED","Y if loan was approved following this enquiry"),
        flag(S,T,"MULTIPLE_ENQUIRY","Y if multiple enquiries within 14 days — loan shopping signal"),
        vc(S,T,"CITY",30,"City from which enquiry was made."),
        vc(S,T,"STATE",30,"State from which enquiry was made."),
        vc(S,T,"CHANNEL",20,"Enquiry channel: ONLINE, BRANCH, DSA, AGGREGATOR."),
    ]

    # BUREAU_SUMMARY_STATS (15 fields)
    T = "BUREAU_SUMMARY_STATS"
    nodes += [
        vc(S,T,"STATS_ID",20,"Unique summary statistics record identifier."),
        vc(S,T,"CUST_ID",20,"Customer for whom these statistics are computed."),
        dt(S,T,"COMPUTED_DT","bureau statistics were last computed"),
        num(S,T,"CREDIT_HISTORY_MONTHS","total length of credit history in months"),
        pct(S,T,"PAYMENT_CONSISTENCY","percentage of on-time payments in last 24 months"),
        num(S,T,"CREDIT_MIX_SCORE","diversity score based on mix of secured, unsecured and revolving"),
        pct(S,T,"UTILIZATION_TREND","change in utilisation over last 3 months — positive=worsening"),
        pct(S,T,"BALANCE_TREND","change in total outstanding over last 3 months"),
        num(S,T,"SCORE_TREND_12M","change in bureau score over last 12 months"),
        flag(S,T,"IMPROVING","bureau score has improved over last 3 months"),
        vc(S,T,"RISK_BUCKET",10,"Risk bucket: LOW, MEDIUM_LOW, MEDIUM, MEDIUM_HIGH, HIGH."),
        num(S,T,"PEER_PERCENTILE","percentile rank vs peers with similar demographics and tenure"),
        vc(S,T,"SCORE_FACTORS",500,"Top 4 score factors as returned by bureau: reason codes."),
        vc(S,T,"POSITIVE_FACTORS",300,"Positive factors improving the bureau score."),
        vc(S,T,"NEGATIVE_FACTORS",300,"Negative factors dragging down the bureau score."),
    ]

    return nodes


def build_edges():
    """Build 50+ authoritative cross-system edges."""
    E = TransformationType
    edges = []

    def e(src, tgt, tt=E.DIRECT, logic=""):
        return _edge(src, tgt, tt, logic or f"{src.split('.')[-1]} → {tgt.split('.')[-1]}")

    # CBS → RISK
    edges += [
        e("CBS.CBS_CUSTOMER.CUST_ID",           "RISK.RISK_CUSTOMER_SCORE.CUST_ID"),
        e("CBS.CBS_CUSTOMER.MONTHLY_INCOME",     "RISK.RISK_CUSTOMER_SCORE.INCOME_VERIFICATION_SCORE", E.DERIVED, "Income stability derived from monthly income and employer category"),
        e("CBS.CBS_LOAN_ACCOUNT.ACCT_ID",        "RISK.RISK_LIMIT_UTIL.ACCT_ID"),
        e("CBS.CBS_LOAN_ACCOUNT.CUST_ID",        "RISK.RISK_EXPOSURE_SUMMARY.CUST_ID"),
        e("CBS.CBS_LOAN_ACCOUNT.OUTSTANDING_BAL","RISK.RISK_EXPOSURE_SUMMARY.TOTAL_OUTSTANDING", E.AGGREGATED, "SUM(OUTSTANDING_BAL) GROUP BY CUST_ID"),
        e("CBS.CBS_LOAN_ACCOUNT.SANCTION_AMT",   "RISK.RISK_EXPOSURE_SUMMARY.TOTAL_SANCTION", E.AGGREGATED, "SUM(SANCTION_AMT) GROUP BY CUST_ID"),
        e("CBS.CBS_LOAN_ACCOUNT.OVERDUE_AMT",    "RISK.RISK_EXPOSURE_SUMMARY.TOTAL_OVERDUE", E.AGGREGATED, "SUM(OVERDUE_AMT) GROUP BY CUST_ID"),
        e("CBS.CBS_LOAN_ACCOUNT.EMI_AMT",        "RISK.RISK_EXPOSURE_SUMMARY.TOTAL_EMI", E.AGGREGATED, "SUM(EMI_AMT) GROUP BY CUST_ID"),
        e("CBS.CBS_LIMIT_MASTER.ACCT_ID",        "RISK.RISK_LIMIT_UTIL.ACCT_ID"),
        e("CBS.CBS_LIMIT_MASTER.CREDIT_LIMIT",   "RISK.RISK_LIMIT_UTIL.CREDIT_LIMIT"),
        e("CBS.CBS_LIMIT_MASTER.UTILIZED_AMT",   "RISK.RISK_LIMIT_UTIL.UTILIZED_AMT"),
        e("CBS.CBS_LOAN_ACCOUNT.PROVISION_AMT",  "RISK.RISK_PROVISION.PROVISION_AMT"),
        e("CBS.CBS_LOAN_ACCOUNT.NPA_CATEGORY",   "RISK.RISK_PROVISION.NPA_CATEGORY"),
        e("CBS.CBS_TRANSACTION.CUST_ID",         "RISK.RISK_FRAUD_ALERT.CUST_ID", E.DERIVED, "Fraud alert triggered from suspicious transaction pattern"),
        e("CBS.CBS_LOAN_ACCOUNT.ACCT_ID",        "RISK.RISK_EARLY_WARNING.ACCT_ID"),
    ]

    # BUREAU → RISK
    edges += [
        e("BUREAU.BUREAU_CREDIT_REPORT.BUREAU_SCORE","RISK.RISK_CUSTOMER_SCORE.BUREAU_SCORE"),
        e("BUREAU.BUREAU_CREDIT_REPORT.BUREAU_NAME","RISK.RISK_CUSTOMER_SCORE.BUREAU_SOURCE"),
        e("BUREAU.BUREAU_CREDIT_REPORT.MAX_DPD_24M","RISK.RISK_EXPOSURE_SUMMARY.MAX_DPD_24M"),
        e("BUREAU.BUREAU_CREDIT_REPORT.DPD_90_INSTANCES","RISK.RISK_EXPOSURE_SUMMARY.DPD_90_COUNT"),
        e("BUREAU.BUREAU_CREDIT_REPORT.TOTAL_OUTSTANDING","RISK.RISK_EXPOSURE_SUMMARY.TOTAL_OUTSTANDING", E.DERIVED, "Bureau outstanding supplements CBS data for full exposure picture"),
        e("BUREAU.BUREAU_CREDIT_REPORT.OVERALL_UTILISATION","RISK.RISK_CUSTOMER_SCORE.BUREAU_UTIL_PCT"),
        e("BUREAU.BUREAU_CREDIT_REPORT.ENQUIRY_COUNT_6M","RISK.RISK_CUSTOMER_SCORE.BUREAU_ENQUIRY_COUNT_3M", E.DERIVED, "6M enquiry count filtered to 3M window"),
        e("BUREAU.BUREAU_CREDIT_REPORT.TOTAL_ACCOUNTS","RISK.RISK_CUSTOMER_SCORE.ACTIVE_TRADES"),
    ]

    # LOS → CBS
    edges += [
        e("LOS.LOS_APPLICATION.CUST_ID",       "CBS.CBS_CUSTOMER.CUST_ID", E.DIRECT, "New applicant created as CBS customer on sanction"),
        e("LOS.LOS_APPLICATION.REQUESTED_AMT", "CBS.CBS_LOAN_ACCOUNT.SANCTION_AMT", E.RENAMED, "Approved amount becomes sanction amount in CBS"),
        e("LOS.LOS_APPLICATION.PRODUCT_TYPE",  "CBS.CBS_LOAN_ACCOUNT.PRODUCT_TYPE"),
        e("LOS.LOS_APPLICATION.APP_ID",        "CBS.CBS_LOAN_ACCOUNT.ACCT_ID", E.DERIVED, "New CBS account created from sanctioned application"),
        e("LOS.LOS_APPLICATION.SANCTIONED_RATE","CBS.CBS_LOAN_ACCOUNT.INTEREST_RATE"),
        e("LOS.LOS_APPLICATION.SANCTIONED_TENURE","CBS.CBS_LOAN_ACCOUNT.TENURE_MONTHS"),
        e("LOS.LOS_CREDIT_DECISION.DECIDED_BY","CBS.CBS_LOAN_ACCOUNT.CREATED_BY", E.RENAMED, "Credit approver becomes account creator"),
    ]

    # RISK → MIS
    edges += [
        e("RISK.RISK_CUSTOMER_SCORE.COMPOSITE_SCORE","MIS.MIS_CUSTOMER_SCORECARD.CREDIT_SCORE"),
        e("RISK.RISK_CUSTOMER_SCORE.CUST_ID",         "MIS.MIS_CUSTOMER_SCORECARD.CUST_ID"),
        e("RISK.RISK_CUSTOMER_SCORE.RISK_APPETITE",   "MIS.MIS_CUSTOMER_SCORECARD.RISK_CATEGORY", E.RENAMED, "Risk appetite maps to traffic-light risk category"),
        e("RISK.RISK_CUSTOMER_SCORE.EARLY_WARNING",   "MIS.MIS_CUSTOMER_SCORECARD.EWS_STATUS", E.RENAMED, "EWS flag converted to status string"),
        e("RISK.RISK_EXPOSURE_SUMMARY.TOTAL_OUTSTANDING","MIS.MIS_CUSTOMER_SCORECARD.TOTAL_EXPOSURE"),
        e("RISK.RISK_EXPOSURE_SUMMARY.NPA_FLAG",      "MIS.MIS_CUSTOMER_SCORECARD.NPA_FLAG"),
        e("RISK.RISK_PROVISION.PROVISION_AMT",        "MIS.MIS_CUSTOMER_SCORECARD.PROVISION_AMT"),
        e("RISK.RISK_EXPOSURE_SUMMARY.TOTAL_OUTSTANDING","MIS.MIS_PORTFOLIO_SUMMARY.TOTAL_OUTSTANDING", E.AGGREGATED, "SUM across all customers for portfolio total"),
        e("RISK.RISK_PROVISION.PROVISION_AMT",        "MIS.MIS_PORTFOLIO_SUMMARY.PROVISION_AMT", E.AGGREGATED, "SUM of provisions for portfolio-level"),
        e("RISK.RISK_EXPOSURE_SUMMARY.NPA_FLAG",      "MIS.MIS_PORTFOLIO_SUMMARY.NPA_ACCOUNTS", E.AGGREGATED, "COUNT(NPA_FLAG='Y') for portfolio NPA count"),
        e("RISK.RISK_EARLY_WARNING.EWS_ID",          "MIS.MIS_COLLECTIONS_DASHBOARD.REPORT_DT", E.DERIVED, "EWS signals feed collections workqueue"),
    ]

    # CBS → MIS
    edges += [
        e("CBS.CBS_LOAN_ACCOUNT.OUTSTANDING_BAL","MIS.MIS_PORTFOLIO_SUMMARY.TOTAL_OUTSTANDING", E.AGGREGATED, "Direct aggregation for daily MIS"),
        e("CBS.CBS_LOAN_ACCOUNT.ACCT_STATUS",    "MIS.MIS_PORTFOLIO_SUMMARY.NPA_ACCOUNTS", E.AGGREGATED, "COUNT where ACCT_STATUS='NPA'"),
        e("CBS.CBS_TRANSACTION.TXN_AMT",         "MIS.MIS_COLLECTIONS_DASHBOARD.COLLECTION", E.AGGREGATED, "SUM of receipt transactions in period"),
        e("CBS.CBS_LOAN_ACCOUNT.BRANCH_CODE",    "MIS.MIS_BRANCH_PERFORMANCE.BRANCH_CODE"),
        e("CBS.CBS_LOAN_ACCOUNT.SANCTION_AMT",   "MIS.MIS_BRANCH_PERFORMANCE.DISBURSEMENTS", E.AGGREGATED, "SUM new disbursements per branch"),
    ]

    return edges
