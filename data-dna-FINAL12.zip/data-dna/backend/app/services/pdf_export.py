"""
PDF Audit Report Generator
Produces a professional, regulator-ready audit trail PDF for any field.
"""
import io
import time
from typing import Optional
from app.core.graph import graph
from app.models.lineage import AuditEntry


def generate_audit_pdf(field_id: str) -> bytes:
    """Generate a complete audit report PDF for a field."""
    from reportlab.lib.pagesizes import A4
    from reportlab.lib import colors
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.units import mm
    from reportlab.platypus import (SimpleDocTemplate, Paragraph, Spacer,
                                     Table, TableStyle, HRFlowable)

    audit = graph.get_audit(field_id)
    impact = graph.get_impact(field_id)
    field = graph.get_field(field_id)
    buf = io.BytesIO()

    doc = SimpleDocTemplate(buf, pagesize=A4,
                             rightMargin=20*mm, leftMargin=20*mm,
                             topMargin=20*mm, bottomMargin=20*mm)

    styles = getSampleStyleSheet()
    title_style = ParagraphStyle("title", fontSize=18, fontName="Helvetica-Bold",
                                  textColor=colors.HexColor("#1a1a2e"), spaceAfter=6)
    h2_style = ParagraphStyle("h2", fontSize=12, fontName="Helvetica-Bold",
                               textColor=colors.HexColor("#6c63ff"), spaceBefore=12, spaceAfter=4)
    body_style = ParagraphStyle("body", fontSize=9, leading=14,
                                 textColor=colors.HexColor("#333344"))
    label_style = ParagraphStyle("label", fontSize=8, textColor=colors.HexColor("#888899"))

    PURPLE = colors.HexColor("#6c63ff")
    TEAL = colors.HexColor("#00d4aa")
    LIGHT = colors.HexColor("#f4f4f8")
    RED = colors.HexColor("#ff5a7d")
    GREEN = colors.HexColor("#4ade80")

    story = []

    # Header
    story.append(Paragraph("Data-DNA — Lineage Audit Report", title_style))
    story.append(Paragraph(f"Generated: {time.strftime('%Y-%m-%d %H:%M:%S UTC')}", label_style))
    story.append(HRFlowable(width="100%", thickness=2, color=PURPLE, spaceAfter=10))

    # Field summary
    story.append(Paragraph("Field Summary", h2_style))
    summary_data = [
        ["Field ID", field_id],
        ["System", field.system if field else "—"],
        ["Table", field.table if field else "—"],
        ["Column", field.column if field else "—"],
        ["Data Type", (field.data_type or "—") if field else "—"],
        ["PII Flagged", "YES ⚠" if (field and field.pii) else "No"],
    ]
    summary_table = Table(summary_data, colWidths=[50*mm, 120*mm])
    summary_table.setStyle(TableStyle([
        ("BACKGROUND", (0,0), (0,-1), LIGHT),
        ("FONTNAME", (0,0), (0,-1), "Helvetica-Bold"),
        ("FONTSIZE", (0,0), (-1,-1), 9),
        ("GRID", (0,0), (-1,-1), 0.5, colors.HexColor("#ddddee")),
        ("ROWBACKGROUNDS", (0,0), (-1,-1), [colors.white, LIGHT]),
        ("TEXTCOLOR", (1,5), (1,5), RED if (field and field.pii) else GREEN),
        ("PADDING", (0,0), (-1,-1), 5),
    ]))
    story.append(summary_table)

    # Lineage completeness
    story.append(Paragraph("Lineage Completeness", h2_style))
    pct = int(audit.completeness_score * 100)
    auth_count = len(audit.authoritative_sources)
    inf_count = len(audit.inferred_links)
    comp_data = [
        ["Completeness Score", f"{pct}%"],
        ["Authoritative Sources", str(auth_count)],
        ["AI-Inferred Links", str(inf_count)],
        ["Conflicts Detected", str(len(audit.conflicts))],
    ]
    comp_table = Table(comp_data, colWidths=[50*mm, 120*mm])
    comp_table.setStyle(TableStyle([
        ("BACKGROUND", (0,0), (0,-1), LIGHT),
        ("FONTNAME", (0,0), (0,-1), "Helvetica-Bold"),
        ("FONTSIZE", (0,0), (-1,-1), 9),
        ("GRID", (0,0), (-1,-1), 0.5, colors.HexColor("#ddddee")),
        ("PADDING", (0,0), (-1,-1), 5),
    ]))
    story.append(comp_table)

    # Authoritative lineage edges
    story.append(Paragraph("Authoritative Lineage Chain", h2_style))
    auth_edges = [e for e in audit.lineage_path.edges if e.source_type.value == "authoritative"]
    if auth_edges:
        edge_data = [["Source Field", "Target Field", "Transformation", "Logic"]]
        for e in auth_edges:
            edge_data.append([
                e.source_field.split(".")[-1],
                e.target_field.split(".")[-1],
                e.transformation_type.value,
                (e.transformation_logic or "—")[:40],
            ])
        edge_table = Table(edge_data, colWidths=[40*mm, 40*mm, 30*mm, 60*mm])
        edge_table.setStyle(TableStyle([
            ("BACKGROUND", (0,0), (-1,0), PURPLE),
            ("TEXTCOLOR", (0,0), (-1,0), colors.white),
            ("FONTNAME", (0,0), (-1,0), "Helvetica-Bold"),
            ("FONTSIZE", (0,0), (-1,-1), 8),
            ("GRID", (0,0), (-1,-1), 0.5, colors.HexColor("#ddddee")),
            ("ROWBACKGROUNDS", (0,1), (-1,-1), [colors.white, LIGHT]),
            ("PADDING", (0,0), (-1,-1), 4),
        ]))
        story.append(edge_table)
    else:
        story.append(Paragraph("No authoritative lineage edges found upstream.", body_style))

    # AI inferred links
    if audit.inferred_links:
        story.append(Paragraph("AI-Inferred Links (requires verification)", h2_style))
        inf_data = [["Source", "Target", "Confidence", "AI Reasoning"]]
        for e in audit.inferred_links[:8]:
            inf_data.append([
                e.source_field.split(".")[-1],
                e.target_field.split(".")[-1],
                f"{int(e.confidence*100)}%",
                (e.reasoning or "—")[:50],
            ])
        inf_table = Table(inf_data, colWidths=[35*mm, 35*mm, 20*mm, 80*mm])
        inf_table.setStyle(TableStyle([
            ("BACKGROUND", (0,0), (-1,0), colors.HexColor("#5a52cc")),
            ("TEXTCOLOR", (0,0), (-1,0), colors.white),
            ("FONTNAME", (0,0), (-1,0), "Helvetica-Bold"),
            ("FONTSIZE", (0,0), (-1,-1), 8),
            ("GRID", (0,0), (-1,-1), 0.5, colors.HexColor("#ddddee")),
            ("ROWBACKGROUNDS", (0,1), (-1,-1), [colors.white, colors.HexColor("#f0f0ff")]),
            ("PADDING", (0,0), (-1,-1), 4),
        ]))
        story.append(inf_table)

    # Downstream impact
    story.append(Paragraph("Downstream Impact Analysis", h2_style))
    risk_color = {"high": RED, "medium": colors.HexColor("#ffb347"), "low": GREEN}.get(impact.risk_level, PURPLE)
    impact_data = [
        ["Risk Level", impact.risk_level.upper()],
        ["Affected Fields", str(impact.affected_count)],
        ["Cross-System Impact", ", ".join(impact.cross_system_impacts) or "None"],
    ]
    imp_table = Table(impact_data, colWidths=[50*mm, 120*mm])
    imp_table.setStyle(TableStyle([
        ("BACKGROUND", (0,0), (0,-1), LIGHT),
        ("FONTNAME", (0,0), (0,-1), "Helvetica-Bold"),
        ("TEXTCOLOR", (1,0), (1,0), risk_color),
        ("FONTSIZE", (0,0), (-1,-1), 9),
        ("GRID", (0,0), (-1,-1), 0.5, colors.HexColor("#ddddee")),
        ("PADDING", (0,0), (-1,-1), 5),
    ]))
    story.append(imp_table)

    # Conflicts
    if audit.conflicts:
        story.append(Paragraph("Conflicts Detected", h2_style))
        for c in audit.conflicts:
            story.append(Paragraph(f"• {c}", body_style))

    # Footer
    story.append(Spacer(1, 10*mm))
    story.append(HRFlowable(width="100%", thickness=1, color=PURPLE))
    story.append(Paragraph("Generated by Data-DNA Lineage Platform — Confidential", label_style))

    doc.build(story)
    return buf.getvalue()
