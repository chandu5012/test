"""
Ingestion Service v3 — Rich credit domain demo data
3 layers: Source (CBS/LOS/CRM/BUREAU) → Middle (RISK/FRAUD/COLLECTIONS) → Reporting (MIS/DWH/REGULATOR)
"""
import uuid
from typing import List
from app.core.graph import graph
from app.core.parser import SQLLineageParser, SchemaParser
from app.ai.nl_search import search_engine
from app.models.lineage import (
    IngestRequest, IngestResult, FieldNode, LineageEdge,
    SourceType, TransformationType
)


class IngestionService:
    def ingest(self, request: IngestRequest) -> IngestResult:
        nodes: List[FieldNode] = []
        edges: List[LineageEdge] = []
        warnings: List[str] = []
        if request.sql:
            parser = SQLLineageParser(request.system_name)
            try:
                n, e = parser.parse(request.sql)
                nodes.extend(n); edges.extend(e)
            except Exception as ex:
                warnings.append(f"SQL parse: {ex}")
        if request.schema_json:
            from app.core.parser import SchemaParser
            sp = SchemaParser(request.system_name)
            try:
                n = sp.parse(request.schema_json)
                nodes.extend(n)
            except Exception as ex:
                warnings.append(f"Schema: {ex}")
        seen = {}
        for n in nodes:
            seen[n.id] = n
        unique = list(seen.values())
        for node in unique:
            graph.add_field(node)
            search_engine.index_field(node)
        for edge in edges:
            try:
                graph.add_lineage(edge)
            except ValueError as ex:
                warnings.append(f"Edge skip: {ex}")
        return IngestResult(nodes_created=len(unique), edges_created=len(edges),
                            fields=[n.id for n in unique], warnings=warnings)

    def seed_demo_data(self):
        """Seed rich 3-layer credit domain demo: Source → Middle → Reporting"""

        # ── LAYER 1: SOURCE SYSTEMS ─────────────────────────────────────
        sql_cbs = """
        CREATE TABLE CBS_CUSTOMER (
            CUST_ID VARCHAR(20), CUST_NAME VARCHAR(100), DOB DATE,
            PAN_NUMBER VARCHAR(10), MOBILE VARCHAR(15), EMAIL VARCHAR(100),
            CITY VARCHAR(50), STATE VARCHAR(30), PINCODE VARCHAR(10),
            KYC_STATUS VARCHAR(20), SEGMENT VARCHAR(20), CREATED_DT TIMESTAMP
        );
        CREATE TABLE CBS_LOAN_ACCOUNT (
            ACCT_ID VARCHAR(20), CUST_ID VARCHAR(20), PRODUCT_CODE VARCHAR(10),
            PRODUCT_TYPE VARCHAR(30), SANCTION_AMT DECIMAL(15,2),
            DISBURSED_AMT DECIMAL(15,2), OUTSTANDING_BAL DECIMAL(15,2),
            EMI_AMT DECIMAL(10,2), INTEREST_RATE DECIMAL(5,2),
            TENURE_MONTHS INT, OPEN_DT DATE, MATURITY_DT DATE,
            ACCT_STATUS VARCHAR(10), BRANCH_CODE VARCHAR(10)
        );
        CREATE TABLE CBS_TRANSACTION (
            TXN_ID VARCHAR(30), ACCT_ID VARCHAR(20), TXN_DT TIMESTAMP,
            TXN_AMT DECIMAL(15,2), TXN_TYPE VARCHAR(20),
            CHANNEL VARCHAR(20), MERCHANT_CAT VARCHAR(50), STATUS VARCHAR(10)
        );
        """

        sql_los = """
        CREATE TABLE LOS_APPLICATION (
            APP_ID VARCHAR(20), CUST_ID VARCHAR(20), APP_DT DATE,
            PRODUCT_TYPE VARCHAR(30), REQUESTED_AMT DECIMAL(15,2),
            PURPOSE VARCHAR(50), EMPLOYMENT_TYPE VARCHAR(30),
            MONTHLY_INCOME DECIMAL(12,2), APP_STATUS VARCHAR(20),
            DECISION_DT DATE, REJECTION_REASON VARCHAR(100)
        );
        CREATE TABLE LOS_DOCUMENTS (
            DOC_ID VARCHAR(20), APP_ID VARCHAR(20), DOC_TYPE VARCHAR(30),
            DOC_STATUS VARCHAR(20), UPLOAD_DT TIMESTAMP, VERIFIED_BY VARCHAR(50)
        );
        """

        sql_crm = """
        CREATE TABLE CRM_CUSTOMER_PROFILE (
            CUST_ID VARCHAR(20), FULL_NAME VARCHAR(100),
            DATE_OF_BIRTH DATE, GENDER VARCHAR(10),
            OCCUPATION VARCHAR(50), ANNUAL_INCOME DECIMAL(12,2),
            CUSTOMER_SEGMENT VARCHAR(20), RELATIONSHIP_SINCE DATE,
            PREFERRED_CHANNEL VARCHAR(20), NPS_SCORE INT
        );
        CREATE TABLE CRM_INTERACTION (
            INTERACTION_ID VARCHAR(20), CUST_ID VARCHAR(20),
            INTERACTION_DT TIMESTAMP, CHANNEL VARCHAR(20),
            TYPE VARCHAR(30), RESOLUTION VARCHAR(50), AGENT_ID VARCHAR(20)
        );
        """

        sql_bureau = """
        CREATE TABLE BUREAU_CREDIT_REPORT (
            CUST_ID VARCHAR(20), PAN_NUMBER VARCHAR(10),
            BUREAU_SCORE INT, SCORE_VERSION VARCHAR(10),
            REPORT_DT DATE, ENQUIRY_PURPOSE VARCHAR(30),
            TOTAL_ACCOUNTS INT, ACTIVE_ACCOUNTS INT,
            OVERDUE_ACCOUNTS INT, TOTAL_CREDIT_LIMIT DECIMAL(15,2),
            TOTAL_OUTSTANDING DECIMAL(15,2), DPD_30 INT,
            DPD_60 INT, DPD_90 INT, WRITTEN_OFF_AMT DECIMAL(15,2)
        );
        """

        # ── LAYER 2: MIDDLE LAYER ───────────────────────────────────────
        sql_risk = """
        CREATE TABLE RISK_CUSTOMER_SCORE (
            CUST_ID VARCHAR(20), BUREAU_SCORE INT,
            INTERNAL_SCORE INT, COMPOSITE_SCORE INT,
            PD_SCORE DECIMAL(8,6), LGD_PCT DECIMAL(5,2),
            EAD_AMT DECIMAL(15,2), EXPECTED_LOSS DECIMAL(15,2),
            SCORE_DT DATE, MODEL_VERSION VARCHAR(10), SCORE_BAND VARCHAR(10)
        );
        CREATE TABLE RISK_EXPOSURE_SUMMARY (
            CUST_ID VARCHAR(20), TOTAL_SANCTION DECIMAL(15,2),
            TOTAL_OUTSTANDING DECIMAL(15,2), TOTAL_EMI DECIMAL(12,2),
            OVERALL_UTIL_PCT DECIMAL(5,2), MAX_DPD INT,
            CURRENT_DPD INT, NPA_FLAG VARCHAR(1),
            PROVISION_AMT DECIMAL(15,2), AS_OF_DT DATE
        );
        CREATE TABLE RISK_LIMIT_UTILIZATION (
            ACCT_ID VARCHAR(20), CUST_ID VARCHAR(20),
            CREDIT_LIMIT DECIMAL(15,2), UTILIZED_AMT DECIMAL(15,2),
            UTILIZATION_PCT DECIMAL(5,2), AVAILABLE_LIMIT DECIMAL(15,2),
            LIMIT_REVIEW_DT DATE
        );
        """

        sql_fraud = """
        CREATE TABLE FRAUD_ALERT (
            ALERT_ID VARCHAR(20), CUST_ID VARCHAR(20),
            ACCT_ID VARCHAR(20), ALERT_DT TIMESTAMP,
            ALERT_TYPE VARCHAR(30), RISK_SCORE DECIMAL(5,2),
            TRANSACTION_AMT DECIMAL(15,2), CHANNEL VARCHAR(20),
            STATUS VARCHAR(20), INVESTIGATED_BY VARCHAR(50)
        );
        CREATE TABLE FRAUD_RULE_MATCH (
            MATCH_ID VARCHAR(20), ALERT_ID VARCHAR(20),
            RULE_ID VARCHAR(20), RULE_NAME VARCHAR(100),
            MATCH_SCORE DECIMAL(5,2), TRIGGERED_DT TIMESTAMP
        );
        """

        sql_collections = """
        CREATE TABLE COLLECTIONS_CASE (
            CASE_ID VARCHAR(20), ACCT_ID VARCHAR(20),
            CUST_ID VARCHAR(20), OVERDUE_AMT DECIMAL(15,2),
            DPD_DAYS INT, BUCKET VARCHAR(10), ASSIGNED_AGENT VARCHAR(50),
            CASE_STATUS VARCHAR(20), LAST_CONTACT_DT DATE,
            PROMISE_TO_PAY_AMT DECIMAL(15,2), PROMISE_DT DATE
        );
        CREATE TABLE COLLECTIONS_PAYMENT (
            PAYMENT_ID VARCHAR(20), CASE_ID VARCHAR(20),
            PAYMENT_DT DATE, PAYMENT_AMT DECIMAL(15,2),
            PAYMENT_MODE VARCHAR(20), RECEIPT_NO VARCHAR(30)
        );
        """

        # ── LAYER 3: REPORTING / OUTPUT ─────────────────────────────────
        sql_mis = """
        CREATE TABLE MIS_PORTFOLIO_SUMMARY (
            REPORT_DT DATE, PRODUCT_TYPE VARCHAR(30),
            TOTAL_ACCOUNTS INT, ACTIVE_ACCOUNTS INT,
            TOTAL_SANCTION DECIMAL(18,2), TOTAL_OUTSTANDING DECIMAL(18,2),
            NPA_AMOUNT DECIMAL(18,2), NPA_PCT DECIMAL(5,2),
            PROVISION_AMT DECIMAL(18,2), YIELD_PCT DECIMAL(5,2)
        );
        CREATE TABLE MIS_CUSTOMER_SCORECARD (
            REPORT_DT DATE, CUST_ID VARCHAR(20),
            CLIENT_NAME VARCHAR(100), CREDIT_SCORE INT,
            RISK_CATEGORY VARCHAR(20), TOTAL_EXPOSURE DECIMAL(15,2),
            UTILIZATION_PCT DECIMAL(5,2), DPD_STATUS VARCHAR(20),
            NPA_FLAG VARCHAR(1), LAST_REVIEW_DT DATE
        );
        """

        sql_dwh = """
        CREATE TABLE DWH_FACT_LOAN (
            DATE_KEY INT, ACCT_KEY INT, CUST_KEY INT,
            PRODUCT_KEY INT, BRANCH_KEY INT,
            DISBURSED_AMT DECIMAL(15,2), OUTSTANDING_AMT DECIMAL(15,2),
            INTEREST_INCOME DECIMAL(12,2), EMI_COLLECTED DECIMAL(12,2),
            DPD_DAYS INT, NPA_FLAG VARCHAR(1)
        );
        CREATE TABLE DWH_DIM_CUSTOMER (
            CUST_KEY INT, CUST_ID VARCHAR(20),
            CUST_NAME VARCHAR(100), SEGMENT VARCHAR(20),
            CITY VARCHAR(50), STATE VARCHAR(30)
        );
        """

        sql_regulator = """
        CREATE TABLE RBI_NPA_REPORT (
            REPORT_PERIOD VARCHAR(10), ACCT_ID VARCHAR(20),
            CUST_ID VARCHAR(20), PRODUCT_TYPE VARCHAR(30),
            OUTSTANDING_AMT DECIMAL(15,2), NPA_DATE DATE,
            NPA_CATEGORY VARCHAR(20), PROVISION_PCT DECIMAL(5,2),
            PROVISION_AMT DECIMAL(15,2), WRITTEN_OFF_AMT DECIMAL(15,2)
        );
        CREATE TABLE RBI_PRIORITY_SECTOR (
            REPORT_PERIOD VARCHAR(10), ACCT_ID VARCHAR(20),
            SECTOR_CODE VARCHAR(10), SECTOR_NAME VARCHAR(50),
            LOAN_AMT DECIMAL(15,2), OUTSTANDING_AMT DECIMAL(15,2),
            SUBCLASS VARCHAR(30)
        );
        """

        # Ingest all systems
        for system, sql in [
            ("CBS",         sql_cbs),
            ("LOS",         sql_los),
            ("CRM",         sql_crm),
            ("BUREAU",      sql_bureau),
            ("RISK",        sql_risk),
            ("FRAUD",       sql_fraud),
            ("COLLECTIONS", sql_collections),
            ("MIS",         sql_mis),
            ("DWH",         sql_dwh),
            ("REGULATOR",   sql_regulator),
        ]:
            self.ingest(IngestRequest(system_name=system, sql=sql))

        # ── Cross-system lineage edges ──────────────────────────────────
        edges = [
            # CBS → RISK
            ("CBS.CBS_CUSTOMER.CUST_ID",         "RISK.RISK_CUSTOMER_SCORE.CUST_ID",         TransformationType.DIRECT,     "Customer ID propagated to risk engine"),
            ("BUREAU.BUREAU_CREDIT_REPORT.BUREAU_SCORE", "RISK.RISK_CUSTOMER_SCORE.BUREAU_SCORE", TransformationType.DIRECT, "Bureau score fed to risk"),
            ("CBS.CBS_LOAN_ACCOUNT.OUTSTANDING_BAL", "RISK.RISK_EXPOSURE_SUMMARY.TOTAL_OUTSTANDING", TransformationType.AGGREGATED, "SUM(OUTSTANDING_BAL) by CUST_ID"),
            ("CBS.CBS_LOAN_ACCOUNT.SANCTION_AMT", "RISK.RISK_EXPOSURE_SUMMARY.TOTAL_SANCTION", TransformationType.AGGREGATED, "SUM(SANCTION_AMT) by CUST_ID"),
            ("CBS.CBS_LOAN_ACCOUNT.ACCT_ID",     "RISK.RISK_LIMIT_UTILIZATION.ACCT_ID",       TransformationType.DIRECT,     "Account ID for limit tracking"),
            ("CBS.CBS_LOAN_ACCOUNT.SANCTION_AMT","RISK.RISK_LIMIT_UTILIZATION.CREDIT_LIMIT",  TransformationType.RENAMED,    "Sanction amount = credit limit"),
            ("CBS.CBS_LOAN_ACCOUNT.OUTSTANDING_BAL","RISK.RISK_LIMIT_UTILIZATION.UTILIZED_AMT", TransformationType.DIRECT,  "Outstanding = utilized amount"),

            # CBS → FRAUD
            ("CBS.CBS_TRANSACTION.TXN_ID",       "FRAUD.FRAUD_ALERT.ALERT_ID",               TransformationType.DERIVED,    "Alert generated from suspicious transaction"),
            ("CBS.CBS_TRANSACTION.ACCT_ID",      "FRAUD.FRAUD_ALERT.ACCT_ID",                TransformationType.DIRECT,     "Account ID passed to fraud"),
            ("CBS.CBS_TRANSACTION.TXN_AMT",      "FRAUD.FRAUD_ALERT.TRANSACTION_AMT",        TransformationType.DIRECT,     "Transaction amount"),

            # CBS → COLLECTIONS
            ("CBS.CBS_LOAN_ACCOUNT.ACCT_ID",     "COLLECTIONS.COLLECTIONS_CASE.ACCT_ID",     TransformationType.DIRECT,     "Overdue account to collections"),
            ("CBS.CBS_CUSTOMER.CUST_ID",         "COLLECTIONS.COLLECTIONS_CASE.CUST_ID",     TransformationType.DIRECT,     "Customer ID"),
            ("CBS.CBS_LOAN_ACCOUNT.OUTSTANDING_BAL","COLLECTIONS.COLLECTIONS_CASE.OVERDUE_AMT", TransformationType.DERIVED, "Overdue = outstanding past due"),

            # LOS → CBS
            ("LOS.LOS_APPLICATION.CUST_ID",      "CBS.CBS_LOAN_ACCOUNT.CUST_ID",             TransformationType.DIRECT,     "Approved application creates CBS account"),
            ("LOS.LOS_APPLICATION.REQUESTED_AMT","CBS.CBS_LOAN_ACCOUNT.SANCTION_AMT",        TransformationType.RENAMED,    "Requested amount becomes sanction"),

            # CRM → RISK
            ("CRM.CRM_CUSTOMER_PROFILE.CUST_ID", "RISK.RISK_CUSTOMER_SCORE.CUST_ID",         TransformationType.DIRECT,     "Customer profile to risk"),
            ("CRM.CRM_CUSTOMER_PROFILE.ANNUAL_INCOME","RISK.RISK_CUSTOMER_SCORE.INTERNAL_SCORE", TransformationType.DERIVED, "Income is input to internal score"),

            # BUREAU → RISK
            ("BUREAU.BUREAU_CREDIT_REPORT.DPD_30","RISK.RISK_EXPOSURE_SUMMARY.MAX_DPD",      TransformationType.AGGREGATED, "Max DPD across bureau history"),
            ("BUREAU.BUREAU_CREDIT_REPORT.TOTAL_OUTSTANDING","RISK.RISK_EXPOSURE_SUMMARY.TOTAL_OUTSTANDING", TransformationType.DIRECT, "Total bureau outstanding"),

            # RISK → MIS
            ("RISK.RISK_CUSTOMER_SCORE.COMPOSITE_SCORE","MIS.MIS_CUSTOMER_SCORECARD.CREDIT_SCORE", TransformationType.DIRECT, "Composite score to MIS"),
            ("RISK.RISK_CUSTOMER_SCORE.CUST_ID", "MIS.MIS_CUSTOMER_SCORECARD.CUST_ID",       TransformationType.DIRECT,     "Customer ID"),
            ("RISK.RISK_EXPOSURE_SUMMARY.TOTAL_OUTSTANDING","MIS.MIS_CUSTOMER_SCORECARD.TOTAL_EXPOSURE", TransformationType.DIRECT, "Exposure in MIS"),
            ("RISK.RISK_EXPOSURE_SUMMARY.NPA_FLAG","MIS.MIS_CUSTOMER_SCORECARD.NPA_FLAG",    TransformationType.DIRECT,     "NPA flag propagated"),
            ("RISK.RISK_EXPOSURE_SUMMARY.TOTAL_OUTSTANDING","MIS.MIS_PORTFOLIO_SUMMARY.TOTAL_OUTSTANDING", TransformationType.AGGREGATED, "Portfolio-level outstanding"),

            # RISK → REGULATOR
            ("RISK.RISK_EXPOSURE_SUMMARY.NPA_FLAG","REGULATOR.RBI_NPA_REPORT.NPA_CATEGORY",  TransformationType.DERIVED,    "NPA flag maps to RBI category"),
            ("CBS.CBS_LOAN_ACCOUNT.OUTSTANDING_BAL","REGULATOR.RBI_NPA_REPORT.OUTSTANDING_AMT", TransformationType.DIRECT,  "Outstanding for RBI NPA report"),
            ("CBS.CBS_LOAN_ACCOUNT.ACCT_ID",     "REGULATOR.RBI_NPA_REPORT.ACCT_ID",         TransformationType.DIRECT,     "Account ID for regulator"),

            # CBS → DWH
            ("CBS.CBS_LOAN_ACCOUNT.OUTSTANDING_BAL","DWH.DWH_FACT_LOAN.OUTSTANDING_AMT",     TransformationType.DIRECT,     "Outstanding to DWH fact"),
            ("CBS.CBS_LOAN_ACCOUNT.EMI_AMT",     "DWH.DWH_FACT_LOAN.EMI_COLLECTED",          TransformationType.DIRECT,     "EMI collected fact"),
            ("CBS.CBS_CUSTOMER.CUST_ID",         "DWH.DWH_DIM_CUSTOMER.CUST_ID",             TransformationType.DIRECT,     "Customer dim in DWH"),
            ("CBS.CBS_CUSTOMER.CUST_NAME",       "DWH.DWH_DIM_CUSTOMER.CUST_NAME",           TransformationType.DIRECT,     "Customer name"),
            ("CBS.CBS_CUSTOMER.CITY",            "DWH.DWH_DIM_CUSTOMER.CITY",                TransformationType.DIRECT,     "City"),
        ]

        for src, tgt, ttype, logic in edges:
            try:
                e = LineageEdge(
                    id=str(uuid.uuid4()),
                    source_field=src, target_field=tgt,
                    transformation_type=ttype,
                    transformation_logic=logic,
                    source_type=SourceType.AUTHORITATIVE,
                    confidence=1.0, system_boundary=True,
                )
                graph.add_lineage(e)
            except Exception:
                pass


    def seed_extended_data(self):
        """Seed 200+ richly described fields across CBS, RISK, MIS."""
        from app.core.parser import SchemaParser

        # ── CBS — 80 fields ─────────────────────────────────────────────
        cbs_schema = {"tables": {
            "CBS_CUSTOMER": {"columns": {
                "CUST_ID":          {"type":"VARCHAR(20)",   "description":"Unique CBS customer identifier, primary key across all CBS tables"},
                "CUST_REF_NO":      {"type":"VARCHAR(20)",   "description":"Customer reference number used for external communications and statements"},
                "CUST_NAME":        {"type":"VARCHAR(100)",  "description":"Full legal name of customer as per KYC documents", "pii":True},
                "FIRST_NAME":       {"type":"VARCHAR(50)",   "description":"Customer first name extracted from full legal name", "pii":True},
                "LAST_NAME":        {"type":"VARCHAR(50)",   "description":"Customer last name / surname as per PAN or Aadhaar", "pii":True},
                "DOB":              {"type":"DATE",          "description":"Date of birth for age verification and loan eligibility calculation", "pii":True},
                "GENDER":           {"type":"VARCHAR(10)",   "description":"Gender (Male/Female/Other) used for demographic segmentation"},
                "PAN_NUMBER":       {"type":"VARCHAR(10)",   "description":"Permanent Account Number — mandatory tax ID for loans above Rs 2 lakh", "pii":True},
                "AADHAAR_NO":       {"type":"VARCHAR(12)",   "description":"Aadhaar number used for eKYC and biometric verification", "pii":True},
                "MOBILE":           {"type":"VARCHAR(15)",   "description":"Primary mobile number for OTP authentication and alerts", "pii":True},
                "ALT_MOBILE":       {"type":"VARCHAR(15)",   "description":"Alternate mobile number for collections and emergency contact", "pii":True},
                "EMAIL":            {"type":"VARCHAR(100)",  "description":"Email address for digital statements, NOC and regulatory notices", "pii":True},
                "ADDRESS_LINE1":    {"type":"VARCHAR(100)",  "description":"Primary residential address line 1 for KYC and legal notices", "pii":True},
                "ADDRESS_LINE2":    {"type":"VARCHAR(100)",  "description":"Primary residential address line 2 (area/locality)", "pii":True},
                "CITY":             {"type":"VARCHAR(50)",   "description":"City of residence for geographic segmentation and regional reporting"},
                "STATE":            {"type":"VARCHAR(30)",   "description":"State of residence for state-wise portfolio analysis and compliance"},
                "PINCODE":          {"type":"VARCHAR(10)",   "description":"Postal code used for bureau queries and geographic credit heat maps"},
                "COUNTRY":          {"type":"VARCHAR(30)",   "description":"Country of residence, required for FEMA compliance and NRI identification"},
                "KYC_STATUS":       {"type":"VARCHAR(20)",   "description":"KYC verification status: VERIFIED, PENDING, EXPIRED, RE_KYC_DUE"},
                "KYC_DT":           {"type":"DATE",          "description":"Date when KYC was last completed — drives re-KYC calendar alerts"},
                "CUST_SEGMENT":     {"type":"VARCHAR(20)",   "description":"Customer segment: RETAIL, HNI, PRIORITY, SME, CORPORATE, AGRI"},
                "CUST_CATEGORY":    {"type":"VARCHAR(20)",   "description":"Sub-category within segment based on AUM and relationship value"},
                "OCCUPATION":       {"type":"VARCHAR(50)",   "description":"Occupation type: SALARIED, SELF_EMPLOYED, BUSINESS, RETIRED, STUDENT"},
                "EMPLOYER_NAME":    {"type":"VARCHAR(100)",  "description":"Name of current employer — used for income verification and employer risk"},
                "MONTHLY_INCOME":   {"type":"DECIMAL(12,2)", "description":"Declared monthly take-home income — primary input for FOIR calculation"},
                "ANNUAL_INCOME":    {"type":"DECIMAL(15,2)", "description":"Total annual income from all sources declared at onboarding"},
                "INCOME_SOURCE":    {"type":"VARCHAR(30)",   "description":"Primary income source: SALARY, BUSINESS, RENTAL, INVESTMENT, PENSION"},
                "NATIONALITY":      {"type":"VARCHAR(30)",   "description":"Customer nationality for FEMA, cross-border transaction and FATCA compliance"},
                "RESIDENT_TYPE":    {"type":"VARCHAR(20)",   "description":"Residency status: RESIDENT_INDIAN, NRI, PIO, OCI — drives tax treatment"},
                "RELATIONSHIP_DT":  {"type":"DATE",          "description":"Date when customer first opened a relationship with the bank"},
                "RM_ID":            {"type":"VARCHAR(20)",   "description":"Assigned relationship manager ID for HNI and priority customers"},
                "BRANCH_CODE":      {"type":"VARCHAR(10)",   "description":"Home branch code where customer was originally onboarded"},
                "CUST_STATUS":      {"type":"VARCHAR(10)",   "description":"Customer lifecycle status: ACTIVE, DORMANT, DECEASED, BLACKLISTED"},
                "POLITICALLY_EXPOSED": {"type":"VARCHAR(1)", "description":"PEP flag (Y/N) — politically exposed person requiring enhanced due diligence"},
                "CREATED_DT":       {"type":"TIMESTAMP",     "description":"System timestamp when customer record was first created in CBS"},
                "MODIFIED_DT":      {"type":"TIMESTAMP",     "description":"Timestamp of most recent update to the customer master record"},
            }},
            "CBS_LOAN_ACCOUNT": {"columns": {
                "ACCT_ID":          {"type":"VARCHAR(20)",   "description":"Unique loan account number in CBS — primary identifier for all loan operations"},
                "CUST_ID":          {"type":"VARCHAR(20)",   "description":"Foreign key to CBS_CUSTOMER — links account to borrower"},
                "PRODUCT_CODE":     {"type":"VARCHAR(10)",   "description":"Internal product code identifying the specific loan scheme variant"},
                "PRODUCT_TYPE":     {"type":"VARCHAR(30)",   "description":"Loan product type: HOME_LOAN, PERSONAL_LOAN, AUTO_LOAN, CREDIT_CARD, LAP, OD"},
                "LOAN_PURPOSE":     {"type":"VARCHAR(50)",   "description":"Purpose of borrowing: HOME_PURCHASE, RENOVATION, EDUCATION, MEDICAL, BUSINESS"},
                "SANCTION_AMT":     {"type":"DECIMAL(15,2)", "description":"Amount sanctioned and approved by credit committee in sanction letter"},
                "DISBURSED_AMT":    {"type":"DECIMAL(15,2)", "description":"Total amount actually disbursed to borrower across all tranches"},
                "OUTSTANDING_BAL":  {"type":"DECIMAL(15,2)", "description":"Current outstanding principal balance — key exposure metric"},
                "OVERDUE_AMT":      {"type":"DECIMAL(15,2)", "description":"Amount past due date — primary trigger for collections assignment"},
                "PRINCIPAL_PAID":   {"type":"DECIMAL(15,2)", "description":"Cumulative principal repaid since loan disbursement"},
                "INTEREST_PAID":    {"type":"DECIMAL(15,2)", "description":"Cumulative interest collected since loan disbursement"},
                "PENAL_INTEREST":   {"type":"DECIMAL(12,2)", "description":"Penal interest charged on overdue amount per loan agreement terms"},
                "EMI_AMT":          {"type":"DECIMAL(10,2)", "description":"Fixed monthly EMI amount as per amortisation schedule"},
                "INTEREST_RATE":    {"type":"DECIMAL(5,2)",  "description":"Annual interest rate — base rate plus spread as per sanction terms"},
                "RATE_TYPE":        {"type":"VARCHAR(10)",   "description":"Rate type: FIXED or FLOATING (linked to MCLR, EBLR, REPO rate)"},
                "BENCHMARK_RATE":   {"type":"DECIMAL(5,2)",  "description":"Benchmark rate (REPO/MCLR) on which floating rate is anchored"},
                "SPREAD":           {"type":"DECIMAL(5,2)",  "description":"Spread over benchmark rate specific to this borrower's credit profile"},
                "TENURE_MONTHS":    {"type":"INT",           "description":"Original loan tenure in months as per sanction letter"},
                "REMAINING_TENURE": {"type":"INT",           "description":"Remaining months to maturity based on actual repayment track"},
                "OPEN_DT":          {"type":"DATE",          "description":"Date of first disbursement — start of loan tenure"},
                "MATURITY_DT":      {"type":"DATE",          "description":"Scheduled loan maturity date as per original sanction terms"},
                "LAST_PAYMENT_DT":  {"type":"DATE",          "description":"Most recent date on which EMI payment was received and posted"},
                "NEXT_DUE_DT":      {"type":"DATE",          "description":"Next EMI due date — used for delinquency monitoring and NACH triggers"},
                "ACCT_STATUS":      {"type":"VARCHAR(10)",   "description":"Account lifecycle status: ACTIVE, CLOSED, NPA, WRITTEN_OFF, RESTRUCTURED, SMA"},
                "SMA_CATEGORY":     {"type":"VARCHAR(5)",    "description":"Special Mention Account category: SMA-0, SMA-1, SMA-2 per RBI guidelines"},
                "NPA_DT":           {"type":"DATE",          "description":"Date account was first classified as Non-Performing Asset"},
                "NPA_CATEGORY":     {"type":"VARCHAR(20)",   "description":"NPA classification: SUB_STANDARD, DOUBTFUL_1, DOUBTFUL_2, DOUBTFUL_3, LOSS"},
                "COLLATERAL_TYPE":  {"type":"VARCHAR(30)",   "description":"Type of collateral: PROPERTY, VEHICLE, SECURITIES, FD, GOLD, GUARANTEE"},
                "COLLATERAL_VALUE": {"type":"DECIMAL(15,2)", "description":"Current market valuation of collateral securing the loan"},
                "LTV_RATIO":        {"type":"DECIMAL(5,2)",  "description":"Loan-to-Value ratio = outstanding / collateral value * 100"},
                "PROVISION_AMT":    {"type":"DECIMAL(15,2)", "description":"Regulatory provision held against this account per RBI NPA norms"},
                "WRITE_OFF_AMT":    {"type":"DECIMAL(15,2)", "description":"Amount written off from P&L after exhausting recovery options"},
                "BRANCH_CODE":      {"type":"VARCHAR(10)",   "description":"Branch maintaining this loan account for regional attribution"},
                "CHANNEL":          {"type":"VARCHAR(20)",   "description":"Loan origination channel: BRANCH, ONLINE, DSA, MOBILE, REFERRAL"},
                "RESTRUCTURED_FLAG":{"type":"VARCHAR(1)",    "description":"Y/N flag indicating loan was restructured under OTR or COVID schemes"},
                "MORATORIUM_FLAG":  {"type":"VARCHAR(1)",    "description":"Y/N flag for accounts that availed RBI-approved moratorium"},
            }},
            "CBS_TRANSACTION": {"columns": {
                "TXN_ID":           {"type":"VARCHAR(30)",   "description":"Unique transaction reference — used for reconciliation and dispute resolution"},
                "ACCT_ID":          {"type":"VARCHAR(20)",   "description":"Loan account on which this transaction was posted"},
                "TXN_DT":           {"type":"TIMESTAMP",     "description":"Exact timestamp of transaction execution for audit trail"},
                "VALUE_DT":         {"type":"DATE",          "description":"Value date for interest calculation — may differ from transaction date"},
                "TXN_AMT":          {"type":"DECIMAL(15,2)", "description":"Transaction amount — positive for receipts, negative for charges"},
                "TXN_TYPE":         {"type":"VARCHAR(20)",   "description":"Transaction type: EMI_RECEIPT, PREPAYMENT, DISBURSEMENT, CHARGE, REVERSAL"},
                "PRINCIPAL_COMP":   {"type":"DECIMAL(12,2)", "description":"Principal component of payment — reduces outstanding balance"},
                "INTEREST_COMP":    {"type":"DECIMAL(12,2)", "description":"Interest component of payment — revenue for the bank"},
                "PENALTY_COMP":     {"type":"DECIMAL(10,2)", "description":"Penalty and late payment charges component"},
                "CHANNEL":          {"type":"VARCHAR(20)",   "description":"Payment channel: NEFT, NACH, RTGS, CHEQUE, CASH, UPI, DEBIT_MANDATE"},
                "REF_NO":           {"type":"VARCHAR(30)",   "description":"External UTR/NACH/clearing reference for reconciliation"},
                "STATUS":           {"type":"VARCHAR(10)",   "description":"Transaction processing status: SUCCESS, FAILED, PENDING, REVERSED, HOLD"},
                "BATCH_ID":         {"type":"VARCHAR(30)",   "description":"EOD batch run ID — groups transactions processed in same batch"},
                "POSTED_BY":        {"type":"VARCHAR(50)",   "description":"User ID or system process that posted the transaction"},
            }},
        }}

        # ── RISK — 70 fields ─────────────────────────────────────────────
        risk_schema = {"tables": {
            "RISK_CUSTOMER_SCORE": {"columns": {
                "SCORE_ID":         {"type":"VARCHAR(30)",   "description":"Unique scoring run ID for model governance and audit trail"},
                "CUST_ID":          {"type":"VARCHAR(20)",   "description":"Customer ID — foreign key to CBS_CUSTOMER for score attribution"},
                "BUREAU_SCORE":     {"type":"INT",           "description":"Credit bureau score from CIBIL/Experian/Equifax — external creditworthiness signal"},
                "BUREAU_SOURCE":    {"type":"VARCHAR(20)",   "description":"Bureau that provided the score: CIBIL, EXPERIAN, EQUIFAX, CRIF_HIGHMARK"},
                "BUREAU_DT":        {"type":"DATE",          "description":"Date bureau score was pulled — staleness affects score reliability"},
                "INTERNAL_SCORE":   {"type":"INT",           "description":"Internally developed behavioural score from transaction and repayment patterns"},
                "COMPOSITE_SCORE":  {"type":"INT",           "description":"Weighted composite of bureau and internal scores — final credit decision input"},
                "SCORE_BAND":       {"type":"VARCHAR(10)",   "description":"Risk band mapped from composite score: A+ (800+), A, B, C, D, E (<600)"},
                "PD_SCORE":         {"type":"DECIMAL(8,6)",  "description":"Probability of Default — statistical likelihood of 90+DPD in next 12 months"},
                "LGD_PCT":          {"type":"DECIMAL(5,2)",  "description":"Loss Given Default — estimated % of EAD that will not be recovered on default"},
                "EAD_AMT":          {"type":"DECIMAL(15,2)", "description":"Exposure at Default — total credit exposure at time of potential default event"},
                "EXPECTED_LOSS":    {"type":"DECIMAL(15,2)", "description":"Expected Loss = PD × LGD × EAD — minimum provisioning requirement"},
                "UNEXPECTED_LOSS":  {"type":"DECIMAL(15,2)", "description":"Capital buffer needed for tail risk beyond expected loss"},
                "RAROC_PCT":        {"type":"DECIMAL(8,4)",  "description":"Risk-Adjusted Return on Capital — pricing and portfolio allocation metric"},
                "RISK_APPETITE":    {"type":"VARCHAR(10)",   "description":"Customer risk classification: LOW, MEDIUM, HIGH, VERY_HIGH, UNACCEPTABLE"},
                "WATCHLIST_FLAG":   {"type":"VARCHAR(1)",    "description":"Y if customer is on risk watchlist requiring enhanced monitoring"},
                "EARLY_WARNING":    {"type":"VARCHAR(1)",    "description":"Y if early warning signals are active — triggers proactive intervention"},
                "MODEL_VERSION":    {"type":"VARCHAR(10)",   "description":"Scoring model version — essential for model validation and back-testing"},
                "SCORE_DT":         {"type":"DATE",          "description":"Date scoring was computed — triggers re-score if older than policy threshold"},
                "NEXT_REVIEW_DT":   {"type":"DATE",          "description":"Scheduled re-score date based on risk band and review frequency policy"},
                "OVERRIDE_FLAG":    {"type":"VARCHAR(1)",    "description":"Y if score was manually overridden by credit officer with approval"},
                "OVERRIDE_REASON":  {"type":"VARCHAR(100)",  "description":"Documented reason for score override — audit trail requirement"},
                "APPROVED_BY":      {"type":"VARCHAR(50)",   "description":"Credit officer who approved manual override of system-generated score"},
            }},
            "RISK_EXPOSURE_SUMMARY": {"columns": {
                "CUST_ID":          {"type":"VARCHAR(20)",   "description":"Customer ID for cross-account exposure aggregation"},
                "TOTAL_SANCTION":   {"type":"DECIMAL(15,2)", "description":"Sum of all sanctioned limits across customer's active loan portfolio"},
                "TOTAL_OUTSTANDING":{"type":"DECIMAL(15,2)", "description":"Aggregate outstanding principal — key credit concentration metric"},
                "TOTAL_OVERDUE":    {"type":"DECIMAL(15,2)", "description":"Total overdue amount across all accounts — primary stress signal"},
                "TOTAL_EMI":        {"type":"DECIMAL(12,2)", "description":"Sum of monthly EMIs across all accounts — Fixed Obligation input"},
                "TOTAL_PROVISION":  {"type":"DECIMAL(15,2)", "description":"Aggregate regulatory provision held for this customer's portfolio"},
                "FOIR":             {"type":"DECIMAL(5,2)",  "description":"Fixed Obligation to Income Ratio — total EMI / monthly income * 100"},
                "OVERALL_UTIL_PCT": {"type":"DECIMAL(5,2)",  "description":"Overall credit utilisation across all revolving facilities"},
                "MAX_DPD_12M":      {"type":"INT",           "description":"Maximum days past due across all accounts in last 12 months"},
                "MAX_DPD_24M":      {"type":"INT",           "description":"Maximum days past due in last 24 months — historical delinquency depth"},
                "CURRENT_DPD":      {"type":"INT",           "description":"Current days past due on most delinquent active account"},
                "DPD_30_COUNT":     {"type":"INT",           "description":"Number of 30+ DPD instances in last 24 months — frequency metric"},
                "DPD_60_COUNT":     {"type":"INT",           "description":"Number of 60+ DPD instances in last 24 months"},
                "DPD_90_COUNT":     {"type":"INT",           "description":"Number of 90+ DPD instances — NPA trigger count in history"},
                "NPA_FLAG":         {"type":"VARCHAR(1)",    "description":"Y if any active account is NPA — regulatory reporting and provisioning flag"},
                "WRITTEN_OFF_AMT":  {"type":"DECIMAL(15,2)", "description":"Lifetime written-off amount — measure of historical credit loss"},
                "RECOVERY_AMT":     {"type":"DECIMAL(15,2)", "description":"Amount recovered post write-off through negotiated settlement or legal action"},
                "ACTIVE_ACCT_COUNT":{"type":"INT",           "description":"Count of currently active loan accounts — credit relationship breadth"},
                "TOTAL_ACCT_COUNT": {"type":"INT",           "description":"Lifetime count of accounts including closed — customer tenure indicator"},
                "AS_OF_DT":         {"type":"DATE",          "description":"Date as of which this exposure summary was computed by the risk engine"},
            }},
            "RISK_LIMIT_UTILIZATION": {"columns": {
                "ACCT_ID":          {"type":"VARCHAR(20)",   "description":"Loan/facility account for limit utilisation tracking"},
                "CUST_ID":          {"type":"VARCHAR(20)",   "description":"Customer owning this facility"},
                "FACILITY_TYPE":    {"type":"VARCHAR(20)",   "description":"Facility type: TERM_LOAN, CC_LIMIT, OD_LIMIT, KISAN_CC, WC_DEMAND_LOAN"},
                "CREDIT_LIMIT":     {"type":"DECIMAL(15,2)", "description":"Approved credit limit for revolving facilities — control parameter"},
                "UTILIZED_AMT":     {"type":"DECIMAL(15,2)", "description":"Current drawn amount against the credit limit"},
                "AVAILABLE_LIMIT":  {"type":"DECIMAL(15,2)", "description":"Undrawn balance available for drawdown = credit limit minus utilized"},
                "UTILIZATION_PCT":  {"type":"DECIMAL(5,2)",  "description":"Utilisation % = (utilized / limit) × 100 — high % signals liquidity stress"},
                "AVG_UTIL_3M":      {"type":"DECIMAL(5,2)",  "description":"3-month rolling average utilisation for trend analysis"},
                "AVG_UTIL_6M":      {"type":"DECIMAL(5,2)",  "description":"6-month rolling average — longer trend smoothing for limit review"},
                "PEAK_UTIL_12M":    {"type":"DECIMAL(5,2)",  "description":"Peak utilisation in last 12 months — seasonality and stress indicator"},
                "LIMIT_REVIEW_DT":  {"type":"DATE",          "description":"Date of last credit limit review conducted by relationship team"},
                "LIMIT_EXPIRY_DT":  {"type":"DATE",          "description":"Facility expiry date — triggers renewal process 90 days prior"},
            }},
            "RISK_EARLY_WARNING": {"columns": {
                "EWS_ID":           {"type":"VARCHAR(30)",   "description":"Unique early warning signal record for tracking and escalation"},
                "CUST_ID":          {"type":"VARCHAR(20)",   "description":"Customer for whom the early warning signal was triggered"},
                "ACCT_ID":          {"type":"VARCHAR(20)",   "description":"Specific account that exhibited the stress behaviour"},
                "SIGNAL_TYPE":      {"type":"VARCHAR(30)",   "description":"Warning type: EMI_BOUNCE, UTIL_SPIKE, BUREAU_ENQUIRY, INCOME_DROP, LEGAL_NOTICE"},
                "SIGNAL_VALUE":     {"type":"DECIMAL(10,2)", "description":"Actual measured value of the signal at time of trigger"},
                "THRESHOLD_VALUE":  {"type":"DECIMAL(10,2)", "description":"Policy threshold breach of which triggers this warning signal"},
                "SEVERITY":         {"type":"VARCHAR(10)",   "description":"Alert severity: RED (immediate action), AMBER (monitor), GREEN (resolved)"},
                "TRIGGERED_DT":     {"type":"TIMESTAMP",     "description":"Timestamp when the early warning was first detected and raised"},
                "RESOLVED_DT":      {"type":"DATE",          "description":"Date warning was resolved — cleared or escalated to collections"},
                "ASSIGNED_TO":      {"type":"VARCHAR(50)",   "description":"RM or credit officer assigned to investigate and take remedial action"},
                "ACTION_TAKEN":     {"type":"VARCHAR(100)",  "description":"Documented action: CONTACTED_CUSTOMER, RESTRUCTURED, LIMIT_REDUCED, LEGAL"},
                "REVIEWED_BY":      {"type":"VARCHAR(50)",   "description":"Senior credit officer who reviewed and signed off on action taken"},
            }},
        }}

        # ── MIS REPORTING — 50 fields ────────────────────────────────────
        mis_schema = {"tables": {
            "MIS_PORTFOLIO_SUMMARY": {"columns": {
                "REPORT_DT":        {"type":"DATE",          "description":"As-of date for portfolio metrics — monthly or quarterly snapshot"},
                "REPORT_PERIOD":    {"type":"VARCHAR(10)",   "description":"Reporting frequency: DAILY, MONTHLY, QUARTERLY, ANNUAL"},
                "PRODUCT_TYPE":     {"type":"VARCHAR(30)",   "description":"Loan product segment for granular portfolio analysis"},
                "REGION":           {"type":"VARCHAR(30)",   "description":"Geographic region for regional MD/CEO portfolio review"},
                "SEGMENT":          {"type":"VARCHAR(20)",   "description":"Customer segment: RETAIL, SME, CORPORATE, AGRI, MICRO_FINANCE"},
                "TOTAL_ACCOUNTS":   {"type":"INT",           "description":"Total loan accounts in portfolio segment as of report date"},
                "ACTIVE_ACCOUNTS":  {"type":"INT",           "description":"Accounts currently in active repayment — performing portfolio count"},
                "NPA_ACCOUNTS":     {"type":"INT",           "description":"Accounts classified NPA — count for regulator report"},
                "TOTAL_SANCTION":   {"type":"DECIMAL(18,2)", "description":"Total sanctioned amount — portfolio size indicator for Board MIS"},
                "TOTAL_OUTSTANDING":{"type":"DECIMAL(18,2)", "description":"Total outstanding principal — primary balance sheet credit line"},
                "TOTAL_OVERDUE":    {"type":"DECIMAL(18,2)", "description":"Total overdue amount — precursor to NPA, closely monitored by management"},
                "NPA_AMOUNT":       {"type":"DECIMAL(18,2)", "description":"Total outstanding in NPA accounts — provisioning and capital adequacy input"},
                "NPA_PCT":          {"type":"DECIMAL(5,2)",  "description":"NPA % = NPA amount / total outstanding — headline asset quality metric"},
                "GNPA_PCT":         {"type":"DECIMAL(5,2)",  "description":"Gross NPA % before provisioning — RBI-mandated quarterly disclosure"},
                "NNPA_PCT":         {"type":"DECIMAL(5,2)",  "description":"Net NPA % after provisions — bank financial health indicator"},
                "PROVISION_AMT":    {"type":"DECIMAL(18,2)", "description":"Cumulative provision held against NPA and SMA accounts"},
                "PCR_PCT":          {"type":"DECIMAL(5,2)",  "description":"Provision Coverage Ratio — measures adequacy of provisions vs gross NPA"},
                "YIELD_PCT":        {"type":"DECIMAL(5,2)",  "description":"Portfolio yield = interest income / average outstanding — revenue metric"},
                "COST_OF_FUNDS":    {"type":"DECIMAL(5,2)",  "description":"Average cost of funds raised to lend this portfolio"},
                "NIM_PCT":          {"type":"DECIMAL(5,2)",  "description":"Net Interest Margin = yield minus cost of funds — profitability spread"},
                "WRITE_OFF_AMT":    {"type":"DECIMAL(18,2)", "description":"Amount written off in the period — credit loss crystallisation"},
                "RECOVERY_AMT":     {"type":"DECIMAL(18,2)", "description":"Post write-off recovery in period — partial credit loss reversal"},
                "NET_CREDIT_LOSS":  {"type":"DECIMAL(18,2)", "description":"Net credit loss = write-offs minus recoveries — P&L charge"},
                "CAR_PCT":          {"type":"DECIMAL(5,2)",  "description":"Capital Adequacy Ratio — Basel III Pillar 1 regulatory capital metric"},
                "DISBURSEMENTS":    {"type":"DECIMAL(18,2)", "description":"New loan disbursements in the period — business growth metric"},
            }},
            "MIS_CUSTOMER_SCORECARD": {"columns": {
                "REPORT_DT":        {"type":"DATE",          "description":"Scorecard snapshot date for trend analysis across periods"},
                "CUST_ID":          {"type":"VARCHAR(20)",   "description":"Customer ID from CBS for scorecard linkage"},
                "CLIENT_NAME":      {"type":"VARCHAR(100)",  "description":"Customer display name for management reports — masked in analytics", "pii":True},
                "CREDIT_SCORE":     {"type":"INT",           "description":"Composite risk score sourced from RISK_CUSTOMER_SCORE for period"},
                "RISK_CATEGORY":    {"type":"VARCHAR(20)",   "description":"Traffic-light risk classification: GREEN, AMBER, RED, WATCH, EXIT"},
                "TOTAL_EXPOSURE":   {"type":"DECIMAL(15,2)", "description":"Total credit exposure as of report date for single-borrower limit check"},
                "UTILIZATION_PCT":  {"type":"DECIMAL(5,2)",  "description":"Overall utilisation across revolving facilities in the scorecard"},
                "DPD_STATUS":       {"type":"VARCHAR(20)",   "description":"Delinquency status bucket: REGULAR, 1-30, 31-60, 61-90, 90+ (NPA)"},
                "NPA_FLAG":         {"type":"VARCHAR(1)",    "description":"NPA classification flag for management NPA review meetings"},
                "PROVISION_AMT":    {"type":"DECIMAL(15,2)", "description":"Provision allocated to this customer for period-end financial reporting"},
                "EWS_STATUS":       {"type":"VARCHAR(10)",   "description":"Active early warning signal status for RM action tracking"},
                "RM_NAME":          {"type":"VARCHAR(100)",  "description":"Relationship manager name for escalation and accountability"},
                "LAST_REVIEW_DT":   {"type":"DATE",          "description":"Date of last credit review — drives annual review calendar"},
                "NEXT_REVIEW_DT":   {"type":"DATE",          "description":"Next scheduled review — overdue reviews flagged to credit head"},
            }},
            "MIS_BRANCH_PERFORMANCE": {"columns": {
                "REPORT_DT":        {"type":"DATE",          "description":"Performance measurement date for branch score card"},
                "BRANCH_CODE":      {"type":"VARCHAR(10)",   "description":"Branch code for branch-level performance attribution"},
                "BRANCH_NAME":      {"type":"VARCHAR(100)",  "description":"Branch name for display in regional performance dashboards"},
                "REGION":           {"type":"VARCHAR(30)",   "description":"Region for regional manager rollup reporting"},
                "DISBURSEMENTS":    {"type":"DECIMAL(15,2)", "description":"Total new disbursements from branch in period — growth metric"},
                "COLLECTIONS":      {"type":"DECIMAL(15,2)", "description":"Total collections received at branch — efficiency metric"},
                "NPA_AMOUNT":       {"type":"DECIMAL(15,2)", "description":"NPA outstanding in branch portfolio — branch risk quality score"},
                "NPA_PCT":          {"type":"DECIMAL(5,2)",  "description":"Branch NPA % — key metric in branch manager performance appraisal"},
                "NEW_CUSTOMERS":    {"type":"INT",           "description":"New customers onboarded from this branch — acquisition metric"},
                "ACTIVE_ACCOUNTS":  {"type":"INT",           "description":"Active accounts managed by branch — portfolio size indicator"},
                "TARGET_ACHV_PCT":  {"type":"DECIMAL(5,2)",  "description":"Disbursement target achievement % — MBO incentive basis"},
                "COLLECTION_EFF":   {"type":"DECIMAL(5,2)",  "description":"Collection efficiency = collected / demanded × 100"},
            }},
            "MIS_REGULATORY_REPORT": {"columns": {
                "REPORT_DT":        {"type":"DATE",          "description":"Regulatory submission date for RBI and other regulators"},
                "REGULATOR":        {"type":"VARCHAR(20)",   "description":"Regulatory body: RBI, SEBI, IRDAI, NHB, SIDBI"},
                "REPORT_TYPE":      {"type":"VARCHAR(30)",   "description":"Report type: NPA, PRIORITY_SECTOR, SLR, CRR, CAPITAL_ADEQUACY"},
                "SUBMISSION_DT":    {"type":"DATE",          "description":"Date report was submitted to regulator — penalty risk if delayed"},
                "STATUS":           {"type":"VARCHAR(20)",   "description":"Submission status: DRAFT, SUBMITTED, ACCEPTED, RESUBMIT_REQUIRED"},
                "PREPARED_BY":      {"type":"VARCHAR(50)",   "description":"User ID who prepared the regulatory report"},
                "APPROVED_BY":      {"type":"VARCHAR(50)",   "description":"Senior officer who approved before regulatory submission"},
            }},
        }}

        for system, schema in [("CBS", cbs_schema), ("RISK", risk_schema), ("MIS", mis_schema)]:
            sp = SchemaParser(system)
            nodes = sp.parse(schema)
            for node in nodes:
                graph.add_field(node)
                search_engine.index_field(node)
                try:
                    from app.core.persistence import persistence
                    persistence.save_node(node.model_dump())
                except Exception:
                    pass

        s = graph.stats()
        print(f"Extended seed done — {s['total_fields']} total fields, systems: {s['systems']}")


    def seed_large_data(self):
        """Seed 755+ fields across 5 deep systems: CBS, RISK, LOS, MIS, BUREAU."""
        from app.services.seed_large import build_all_nodes, build_edges
        nodes = build_all_nodes()
        edges = build_edges()
        added = 0
        for node in nodes:
            graph.add_field(node)
            search_engine.index_field(node)
            try:
                from app.core.persistence import persistence
                persistence.save_node(node.model_dump())
            except Exception:
                pass
            added += 1
        for edge in edges:
            try:
                graph.add_lineage(edge)
                from app.core.persistence import persistence
                persistence.save_edge(edge.model_dump())
            except Exception:
                pass
        s = graph.stats()
        print(f"✅ Large seed done — {s['total_fields']} fields, {s['total_edges']} edges across {s['systems']}")


ingestion_service = IngestionService()
