"""
Conversational Lineage Chat
User asks plain English questions — AI answers using live graph context.
"""
import json
from typing import List, Dict
from app.ai.provider import ask_ai
from app.core.graph import graph

CHAT_SYSTEM = """You are Data-DNA, an expert data lineage assistant for credit systems.
You have access to the live lineage graph. Answer questions about:
- Where fields come from (upstream lineage)
- What fields are affected by changes (impact analysis)  
- Data quality issues and conflicts
- PII and compliance concerns
- Transformation logic between systems

Always be specific — reference actual field names and system names from the graph context.
Keep answers concise and actionable. Format key field names in backticks."""


def build_graph_context(field_id: str = None) -> str:
    """Build a compact graph summary to inject into the AI prompt."""
    stats = graph.stats()
    ctx = f"""LIVE GRAPH CONTEXT:
Systems: {', '.join(stats['systems'])}
Total fields: {stats['total_fields']}
Authoritative edges: {stats['authoritative_edges']}
Inferred edges: {stats['inferred_edges']}
"""
    if field_id:
        try:
            field = graph.get_field(field_id)
            if field:
                ctx += f"\nFOCUSED FIELD: {field.id} ({field.data_type or 'unknown type'})"
                if field.pii:
                    ctx += " [PII]"
            path = graph.get_lineage(field_id, hops=4, direction="both")
            ctx += f"\nLineage nodes: {[n.id for n in path.nodes[:10]]}"
            ctx += f"\nLineage edges: {[(e.source_field.split('.')[-1], '->', e.target_field.split('.')[-1], e.transformation_type) for e in path.edges[:8]]}"
            impact = graph.get_impact(field_id)
            ctx += f"\nDownstream impact: {impact.affected_count} fields, risk={impact.risk_level}"
        except Exception:
            pass

    # Add sample of all fields
    fields = graph.list_fields()
    ctx += f"\nAll fields sample: {[f.id for f in fields[:20]]}"
    return ctx


def chat(message: str, history: List[Dict], field_id: str = None) -> str:
    """Process a chat message with graph context injected."""
    ctx = build_graph_context(field_id)
    history_text = ""
    for h in history[-6:]:   # last 6 turns
        history_text += f"\n{h['role'].upper()}: {h['content']}"

    prompt = f"""{ctx}

CONVERSATION HISTORY:{history_text}

USER: {message}

Answer based on the graph context above. Be specific about field names and systems."""

    result = ask_ai(prompt, system=CHAT_SYSTEM, max_tokens=800)
    if result:
        return result
    # Fallback: rule-based answers
    return _rule_based_chat(message, field_id)


def _rule_based_chat(message: str, field_id: str = None) -> str:
    msg = message.lower()
    if field_id:
        try:
            impact = graph.get_impact(field_id)
            audit = graph.get_audit(field_id)
            field = graph.get_field(field_id)
            fname = field_id.split(".")[-1] if field_id else "this field"

            if any(w in msg for w in ["where", "come from", "source", "upstream", "origin"]):
                sources = audit.authoritative_sources[:3]
                if sources:
                    return f"`{fname}` receives data from: {', '.join([s.split('.')[-1] for s in sources])}. Lineage completeness: {int(audit.completeness_score*100)}%."
                return f"No authoritative upstream sources found for `{fname}`. Consider running AI inference to discover potential links."

            if any(w in msg for w in ["impact", "affect", "break", "downstream", "depend"]):
                return f"Changing `{fname}` affects **{impact.affected_count} downstream fields**. Risk level: **{impact.risk_level.upper()}**. Cross-system impacts: {', '.join(impact.cross_system_impacts) or 'none'}."

            if any(w in msg for w in ["pii", "sensitive", "personal", "compliance"]):
                f = graph.get_field(field_id)
                if f and f.pii:
                    return f"`{fname}` is flagged as **PII**. Ensure it is masked in REPORTING layers and encrypted at rest. Review all downstream consumers."
                return f"`{fname}` is not flagged as PII based on column name analysis."
        except Exception:
            pass

    stats = graph.stats()
    return (f"The graph contains {stats['total_fields']} fields across "
            f"{len(stats['systems'])} systems: {', '.join(stats['systems'])}. "
            f"Select a field on the graph and ask about its lineage, impact, or compliance status. "
            f"Configure an AI provider in Settings for intelligent answers.")
