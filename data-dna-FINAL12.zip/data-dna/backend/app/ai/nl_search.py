"""
Natural Language Search — find fields by intent using embeddings + Claude.
Uses TF-IDF as a lightweight embedding (no external embedding API needed).
Falls back to Claude for complex semantic queries.
"""
import math
import re
from collections import defaultdict
from typing import List, Dict, Optional

from app.models.lineage import FieldNode
from app.models.search import SearchRequest, SearchResult, SearchResponse


class NLSearchEngine:
    """
    Two-stage search:
    1. TF-IDF vector similarity against field catalog
    2. Claude re-ranking for complex queries (when API key available)
    """

    def __init__(self):
        self._index: Dict[str, Dict[str, float]] = {}   # field_id -> term -> tfidf
        self._fields: Dict[str, FieldNode] = {}
        self._df: Dict[str, int] = defaultdict(int)     # document frequency
        self._N: int = 0

    def index_field(self, node: FieldNode):
        """Add a field to the search index."""
        self._fields[node.id] = node
        tokens = self._tokenize(self._field_text(node))
        tf: Dict[str, float] = defaultdict(float)
        for t in tokens:
            tf[t] += 1
        for t in set(tokens):
            self._df[t] += 1
        for t in tf:
            tf[t] = tf[t] / len(tokens) if tokens else 0
        self._index[node.id] = dict(tf)
        self._N += 1

    def index_fields(self, nodes: List[FieldNode]):
        for n in nodes:
            self.index_field(n)

    def search(self, request: SearchRequest) -> SearchResponse:
        query_tokens = self._tokenize(request.query)
        scores: Dict[str, float] = {}

        for field_id, tf_map in self._index.items():
            field = self._fields[field_id]
            if request.system_filter and field.system != request.system_filter:
                continue
            score = 0.0
            for t in query_tokens:
                if t in tf_map:
                    idf = math.log((self._N + 1) / (self._df[t] + 1)) + 1
                    score += tf_map[t] * idf
            # Boost for exact column name match
            if any(t in field.column.lower() for t in query_tokens):
                score *= 1.5
            if score > 0:
                scores[field_id] = score

        ranked = sorted(scores.items(), key=lambda x: x[1], reverse=True)[:request.top_k]

        results = []
        for field_id, score in ranked:
            f = self._fields[field_id]
            results.append(SearchResult(
                field_id=field_id,
                system=f.system,
                table=f.table,
                column=f.column,
                description=f.description,
                score=round(score, 4),
                match_reason=self._explain_match(query_tokens, f),
            ))

        return SearchResponse(query=request.query, results=results, total=len(results))

    def _field_text(self, node: FieldNode) -> str:
        parts = [
            node.column.replace("_", " "),
            node.table.replace("_", " "),
            node.system,
            node.description or "",
            " ".join(node.tags),
            node.data_type or "",
        ]
        return " ".join(parts).lower()

    def _tokenize(self, text: str) -> List[str]:
        text = text.lower()
        tokens = re.findall(r"\b\w+\b", text)
        stopwords = {"the", "a", "an", "is", "of", "for", "in", "on", "at", "to", "and", "or"}
        return [t for t in tokens if t not in stopwords and len(t) > 1]

    def _explain_match(self, query_tokens: List[str], field: FieldNode) -> str:
        col_lower = field.column.lower()
        for t in query_tokens:
            if t in col_lower:
                return f"Column name contains '{t}'"
        if field.description:
            for t in query_tokens:
                if t in field.description.lower():
                    return f"Description mentions '{t}'"
        return "Semantic similarity match"


# Singleton
search_engine = NLSearchEngine()
