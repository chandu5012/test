"""
Multi-AI Provider Engine
Supports: Anthropic Claude, OpenAI GPT, Google Gemini, GitHub Copilot (OpenAI-compatible)
User picks their preferred provider and supplies their own API key.
All providers implement the same interface: ask(prompt) -> str
"""
import os
import json
from typing import Optional
from enum import Enum


class AIProvider(str, Enum):
    ANTHROPIC = "anthropic"
    OPENAI = "openai"
    GEMINI = "gemini"
    GITHUB_COPILOT = "github_copilot"
    OLLAMA = "ollama"       # local, no key needed
    NONE = "none"           # rule-based fallback


class AIConfig:
    """Global AI provider configuration — set once, used everywhere."""
    _provider: AIProvider = AIProvider.NONE
    _api_key: str = ""
    _model: str = ""
    _base_url: str = ""

    @classmethod
    def configure(cls, provider: AIProvider, api_key: str = "",
                  model: str = "", base_url: str = ""):
        cls._provider = provider
        cls._api_key = api_key
        cls._model = model or cls._default_model(provider)
        cls._base_url = base_url
        # Also set env vars so sub-libraries pick them up
        if api_key:
            os.environ["OPENAI_API_KEY"] = api_key
            os.environ["ANTHROPIC_API_KEY"] = api_key
            os.environ["GOOGLE_API_KEY"] = api_key

    @classmethod
    def _default_model(cls, provider: AIProvider) -> str:
        return {
            AIProvider.ANTHROPIC: "claude-sonnet-4-20250514",
            AIProvider.OPENAI: "gpt-4o",
            AIProvider.GEMINI: "gemini-1.5-pro",
            AIProvider.GITHUB_COPILOT: "gpt-4o",
            AIProvider.OLLAMA: "llama3",
            AIProvider.NONE: "",
        }.get(provider, "")

    @classmethod
    def get(cls):
        return cls._provider, cls._api_key, cls._model, cls._base_url

    @classmethod
    def is_configured(cls) -> bool:
        if cls._provider == AIProvider.OLLAMA:
            return True
        if cls._provider == AIProvider.NONE:
            return False
        return bool(cls._api_key)

    @classmethod
    def status(cls):
        return {
            "provider": cls._provider.value,
            "model": cls._model,
            "configured": cls.is_configured(),
            "has_key": bool(cls._api_key),
        }


def ask_ai(prompt: str, system: str = "", max_tokens: int = 2000) -> Optional[str]:
    """
    Universal AI ask function.
    Routes to the configured provider transparently.
    Returns None if no provider configured (triggers rule-based fallback).
    """
    provider, api_key, model, base_url = AIConfig.get()

    if not AIConfig.is_configured():
        return None

    try:
        if provider == AIProvider.ANTHROPIC:
            return _ask_anthropic(prompt, system, model, api_key, max_tokens)
        elif provider == AIProvider.OPENAI:
            return _ask_openai(prompt, system, model, api_key, max_tokens)
        elif provider == AIProvider.GEMINI:
            return _ask_gemini(prompt, system, model, api_key, max_tokens)
        elif provider == AIProvider.GITHUB_COPILOT:
            return _ask_openai(prompt, system, model, api_key, max_tokens,
                               base_url="https://models.inference.ai.azure.com")
        elif provider == AIProvider.OLLAMA:
            return _ask_ollama(prompt, system, model, base_url or "http://localhost:11434", max_tokens)
    except Exception as e:
        print(f"[AI Provider Error] {provider}: {e}")
        return None


def _ask_anthropic(prompt, system, model, api_key, max_tokens):
    import anthropic
    client = anthropic.Anthropic(api_key=api_key)
    kwargs = {"model": model, "max_tokens": max_tokens,
              "messages": [{"role": "user", "content": prompt}]}
    if system:
        kwargs["system"] = system
    msg = client.messages.create(**kwargs)
    return msg.content[0].text


def _ask_openai(prompt, system, model, api_key, max_tokens, base_url=None):
    from openai import OpenAI
    kwargs = {"api_key": api_key}
    if base_url:
        kwargs["base_url"] = base_url
    client = OpenAI(**kwargs)
    messages = []
    if system:
        messages.append({"role": "system", "content": system})
    messages.append({"role": "user", "content": prompt})
    resp = client.chat.completions.create(
        model=model, messages=messages, max_tokens=max_tokens)
    return resp.choices[0].message.content


def _ask_gemini(prompt, system, model, api_key, max_tokens):
    import google.generativeai as genai
    genai.configure(api_key=api_key)
    m = genai.GenerativeModel(model)
    full = f"{system}\n\n{prompt}" if system else prompt
    resp = m.generate_content(full, generation_config={"max_output_tokens": max_tokens})
    return resp.text


def _ask_ollama(prompt, system, model, base_url, max_tokens):
    import urllib.request
    payload = json.dumps({
        "model": model,
        "prompt": f"{system}\n\n{prompt}" if system else prompt,
        "stream": False
    }).encode()
    req = urllib.request.Request(
        f"{base_url}/api/generate",
        data=payload, headers={"Content-Type": "application/json"}
    )
    with urllib.request.urlopen(req, timeout=60) as r:
        return json.loads(r.read())["response"]
