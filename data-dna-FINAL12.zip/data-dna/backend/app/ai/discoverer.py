"""
AI Lineage Discoverer — infer missing lineage relationships using Claude.
All inferred edges are clearly tagged and include confidence + reasoning.
This module NEVER overrides authoritative edges.
"""
import json
import os
import uuid
from typing import List, Optional
import anthropic

from app.models.lineage import FieldNode, LineageEdge, SourceType, TransformationType


DISCOVERY_PROMPT = """You are a data lineage expert for credit systems.

Given these two sets of fields from different systems, identify potential lineage 
relationships — fields in the TARGET that likely receive data from fields in the SOURCE.

SOURCE system ({source_system}):
{source_fields}

TARGET system ({target_system}):
{target_fields}

Context: {context}

Analyze each potential source→target field pair. For each relationship you identify:
1. Explain WHY these fields are related (data flow, transformation, business logic)
2. Estimate confidence (0.0-1.0)
3. Identify the transformation type: direct/derived/joined/aggregated/filtered/renamed

Return ONLY valid JSON (no markdown, no explanation):
{{
  "relationships": [
    {{
      "source_field": "SOURCE_SYSTEM.table.COLUMN",
      "target_field": "TARGET_SYSTEM.table.COLUMN", 
      "transformation_type": "direct",
      "transformation_logic": "Direct copy / description of transformation",
      "confidence": 0.85,
      "reasoning": "Detailed explanation of why these fields are related"
    }}
  ]
}}

Only include relationships with confidence >= 0.5. Be conservative — false positives 
in lineage are dangerous for audit and compliance purposes."""


class LineageDiscoverer:
    """
    AI-powered lineage discovery between systems.
    Inferred edges are strictly separated from authoritative edges.
    Every inferred edge includes confidence score and reasoning for explainability.
    """

    def __init__(self):
        self._client: Optional[anthropic.Anthropic] = None
        api_key = os.getenv("ANTHROPIC_API_KEY")
        if api_key:
            self._client = anthropic.Anthropic(api_key=api_key)

    def discover(
        self,
        source_fields: List[FieldNode],
        target_fields: List[FieldNode],
        context: str = "Credit data platform",
    ) -> List[LineageEdge]:
        """
        Infer lineage relationships between source and target field sets.
        Returns edges tagged as INFERRED with confidence scores.
        """
        if not source_fields or not target_fields:
            return []

        if self._client:
            return self._discover_with_ai(source_fields, target_fields, context)
        return self._discover_with_rules(source_fields, target_fields)

    def _discover_with_ai(
        self,
        source_fields: List[FieldNode],
        target_fields: List[FieldNode],
        context: str,
    ) -> List[LineageEdge]:
        src_sys = source_fields[0].system
        tgt_sys = target_fields[0].system

        def fmt(fields: List[FieldNode]) -> str:
            return json.dumps([
                {"id": f.id, "table": f.table, "column": f.column,
                 "data_type": f.data_type, "description": f.description}
                for f in fields
            ], indent=2)

        prompt = DISCOVERY_PROMPT.format(
            source_system=src_sys,
            source_fields=fmt(source_fields),
            target_system=tgt_sys,
            target_fields=fmt(target_fields),
            context=context,
        )

        try:
            msg = self._client.messages.create(
                model="claude-sonnet-4-20250514",
                max_tokens=3000,
                messages=[{"role": "user", "content": prompt}]
            )
            raw = msg.content[0].text.strip()
            data = json.loads(raw)
            edges = []
            for r in data.get("relationships", []):
                ttype_map = {
                    "direct": TransformationType.DIRECT,
                    "derived": TransformationType.DERIVED,
                    "joined": TransformationType.JOINED,
                    "aggregated": TransformationType.AGGREGATED,
                    "filtered": TransformationType.FILTERED,
                    "renamed": TransformationType.RENAMED,
                }
                ttype = ttype_map.get(r.get("transformation_type", "direct"), TransformationType.DIRECT)
                edge = LineageEdge(
                    id=str(uuid.uuid4()),
                    source_field=r["source_field"],
                    target_field=r["target_field"],
                    transformation_type=ttype,
                    transformation_logic=r.get("transformation_logic"),
                    source_type=SourceType.INFERRED,
                    confidence=float(r.get("confidence", 0.5)),
                    reasoning=r.get("reasoning"),
                    system_boundary=(src_sys != tgt_sys),
                )
                edges.append(edge)
            return edges
        except Exception:
            return self._discover_with_rules(source_fields, target_fields)

    def _discover_with_rules(
        self,
        source_fields: List[FieldNode],
        target_fields: List[FieldNode],
    ) -> List[LineageEdge]:
        """Rule-based discovery: match by normalized column names."""
        edges = []
        src_index = {f.column.lower().replace("_", ""): f for f in source_fields}

        for tgt in target_fields:
            tgt_key = tgt.column.lower().replace("_", "")
            if tgt_key in src_index:
                src = src_index[tgt_key]
                confidence = 0.75 if src.column.lower() == tgt.column.lower() else 0.55
                edges.append(LineageEdge(
                    id=str(uuid.uuid4()),
                    source_field=src.id,
                    target_field=tgt.id,
                    transformation_type=TransformationType.DIRECT,
                    transformation_logic="Name match",
                    source_type=SourceType.INFERRED,
                    confidence=confidence,
                    reasoning=f"Column name similarity: {src.column} ≈ {tgt.column}",
                    system_boundary=(src.system != tgt.system),
                ))
        return edges


discoverer = LineageDiscoverer()
