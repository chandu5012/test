"""
Semantic Field Resolver — detect aliases and synonyms across systems.
Uses Claude AI to identify that cust_id, customer_id, client_identifier
are all the same logical field.
"""
import json
import os
from typing import List, Dict, Optional
import anthropic

from app.models.lineage import FieldNode
from app.models.search import AliasGroup


RESOLVER_PROMPT = """You are a data lineage expert analyzing credit system field names.

Given the following list of fields from different systems, identify groups of fields 
that represent the SAME logical data concept (even if named differently).

Fields:
{fields_json}

Rules:
1. Group fields that represent the same business concept
2. Consider abbreviations: cust = customer, id = identifier, num = number, amt = amount
3. Consider credit domain: acct = account, bal = balance, lmt = limit, util = utilization
4. Only group fields where you are CONFIDENT they represent the same data
5. Ignore fields that are clearly different concepts

Return ONLY valid JSON (no markdown, no explanation) in this exact format:
{{
  "groups": [
    {{
      "canonical_name": "customer_id",
      "aliases": ["cust_id", "client_identifier", "customer_identifier"],
      "systems": ["CRM", "CREDIT_CORE", "RISK"],
      "confidence": 0.95,
      "reasoning": "All represent the unique customer identifier. 'cust' and 'client' are standard abbreviations for customer."
    }}
  ]
}}"""


class SemanticResolver:
    """
    Detects field aliases across systems.
    Uses Claude AI for intelligent semantic matching.
    Falls back to rule-based matching if no API key.
    """

    def __init__(self):
        self._client: Optional[anthropic.Anthropic] = None
        api_key = os.getenv("ANTHROPIC_API_KEY")
        if api_key:
            self._client = anthropic.Anthropic(api_key=api_key)

    def resolve_aliases(self, fields: List[FieldNode]) -> List[AliasGroup]:
        """Find groups of fields that represent the same logical concept."""
        if self._client:
            return self._resolve_with_ai(fields)
        return self._resolve_with_rules(fields)

    def _resolve_with_ai(self, fields: List[FieldNode]) -> List[AliasGroup]:
        fields_data = [
            {"id": f.id, "system": f.system, "table": f.table,
             "column": f.column, "data_type": f.data_type}
            for f in fields
        ]
        prompt = RESOLVER_PROMPT.format(fields_json=json.dumps(fields_data, indent=2))
        try:
            msg = self._client.messages.create(
                model="claude-sonnet-4-20250514",
                max_tokens=2000,
                messages=[{"role": "user", "content": prompt}]
            )
            raw = msg.content[0].text.strip()
            data = json.loads(raw)
            groups = []
            for g in data.get("groups", []):
                groups.append(AliasGroup(
                    canonical_name=g["canonical_name"],
                    aliases=g["aliases"],
                    systems=g["systems"],
                    confidence=g["confidence"],
                    reasoning=g["reasoning"],
                ))
            return groups
        except Exception as e:
            return self._resolve_with_rules(fields)

    def _resolve_with_rules(self, fields: List[FieldNode]) -> List[AliasGroup]:
        """Rule-based alias detection without AI."""
        normalizations = {
            "cust": "customer", "client": "customer", "clnt": "customer",
            "acct": "account", "acc": "account",
            "id": "identifier", "identifier": "identifier", "num": "number",
            "amt": "amount", "amount": "amount",
            "bal": "balance", "balance": "balance",
            "dt": "date", "ts": "timestamp",
        }

        def normalize(col: str) -> str:
            parts = col.lower().split("_")
            return "_".join(normalizations.get(p, p) for p in parts)

        groups: Dict[str, List[FieldNode]] = {}
        for f in fields:
            key = normalize(f.column)
            groups.setdefault(key, []).append(f)

        result = []
        for canonical, group_fields in groups.items():
            if len(group_fields) > 1:
                systems = list({f.system for f in group_fields})
                aliases = [f.column for f in group_fields]
                result.append(AliasGroup(
                    canonical_name=canonical,
                    aliases=aliases,
                    systems=systems,
                    confidence=0.7,
                    reasoning=f"Rule-based normalization: {', '.join(set(aliases))} → {canonical}",
                ))
        return result


resolver = SemanticResolver()
