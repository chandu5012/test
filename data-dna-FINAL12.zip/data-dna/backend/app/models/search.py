from typing import List, Optional
from pydantic import BaseModel


class SearchRequest(BaseModel):
    query: str
    top_k: int = 5
    system_filter: Optional[str] = None


class SearchResult(BaseModel):
    field_id: str
    system: str
    table: str
    column: str
    description: Optional[str]
    score: float
    match_reason: str


class SearchResponse(BaseModel):
    query: str
    results: List[SearchResult]
    total: int


class AliasGroup(BaseModel):
    canonical_name: str
    aliases: List[str]
    systems: List[str]
    confidence: float
    reasoning: str
