"""
Pydantic models for lineage graph nodes, edges, and API responses.
"""
from enum import Enum
from typing import Optional, List, Dict, Any
from pydantic import BaseModel, Field
import time


class SourceType(str, Enum):
    AUTHORITATIVE = "authoritative"   # From parsed SQL/schema — deterministic
    INFERRED = "inferred"             # From AI discovery — probabilistic


class TransformationType(str, Enum):
    DIRECT = "direct"           # Field copied as-is
    DERIVED = "derived"         # Computed / transformed
    JOINED = "joined"           # Result of a JOIN
    AGGREGATED = "aggregated"   # GROUP BY / SUM / COUNT etc.
    FILTERED = "filtered"       # WHERE clause filter
    RENAMED = "renamed"         # Same data, different name


class FieldNode(BaseModel):
    id: str                    # Unique: "system.table.column"
    system: str                # Source system name
    table: str
    column: str
    data_type: Optional[str] = None
    description: Optional[str] = None
    tags: List[str] = Field(default_factory=list)
    pii: bool = False
    created_at: float = Field(default_factory=time.time)
    # Extended metadata (enterprise-grade)
    length: Optional[int] = None           # Column length e.g. VARCHAR(20) -> 20
    precision: Optional[int] = None        # Decimal precision
    scale: Optional[int] = None            # Decimal scale
    nullable: Optional[bool] = True        # IS NULL / NOT NULL
    is_primary_key: bool = False           # Primary key indicator
    is_foreign_key: bool = False           # Foreign key indicator
    foreign_key_ref: Optional[str] = None  # References: system.table.column
    is_indexed: bool = False               # Has index
    index_name: Optional[str] = None       # Index name if indexed
    default_value: Optional[str] = None    # Column default value
    column_order: Optional[int] = None     # Column position in table


class LineageEdge(BaseModel):
    id: str                    # Unique edge id
    source_field: str          # FieldNode.id
    target_field: str          # FieldNode.id
    transformation_type: TransformationType = TransformationType.DIRECT
    transformation_logic: Optional[str] = None   # SQL snippet or description
    source_type: SourceType = SourceType.AUTHORITATIVE
    confidence: float = 1.0    # 0-1, always 1.0 for authoritative
    reasoning: Optional[str] = None   # AI explanation for inferred edges
    system_boundary: bool = False     # True if crosses system boundary
    created_at: float = Field(default_factory=time.time)
    metadata: Dict[str, Any] = Field(default_factory=dict)


class LineagePath(BaseModel):
    nodes: List[FieldNode]
    edges: List[LineageEdge]
    hops: int
    has_inferred: bool


class ImpactResult(BaseModel):
    source_field: str
    affected_fields: List[FieldNode]
    affected_count: int
    cross_system_impacts: List[str]
    risk_level: str   # "low" | "medium" | "high"


class AuditEntry(BaseModel):
    field_id: str
    lineage_path: LineagePath
    authoritative_sources: List[str]
    inferred_links: List[LineageEdge]
    completeness_score: float   # 0-1
    conflicts: List[str]


class IngestRequest(BaseModel):
    system_name: str
    sql: Optional[str] = None
    schema_json: Optional[Dict[str, Any]] = None
    description: Optional[str] = None


class IngestResult(BaseModel):
    nodes_created: int
    edges_created: int
    fields: List[str]
    warnings: List[str] = Field(default_factory=list)
