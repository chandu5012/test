"""
Run this ONCE before starting the server.
Creates the DataDNA folder and copies the correct database.
Usage: python setup_db.py
"""
import os
import sys
import shutil
from pathlib import Path

print("=" * 50)
print("  Data-DNA — Database Setup")
print("=" * 50)

# Determine fixed DB location
if sys.platform == "win32":
    base = Path(os.environ.get("LOCALAPPDATA", Path.home() / "AppData" / "Local"))
    db_dir = base / "DataDNA"
else:
    db_dir = Path.home() / ".datadna"

db_path = db_dir / "data_dna.json"

print(f"\nDatabase location: {db_path}")

# Create folder
db_dir.mkdir(parents=True, exist_ok=True)
print(f"✓ Folder created: {db_dir}")

# Find seed file (bundled with project)
script_dir = Path(__file__).parent
seed_candidates = [
    script_dir / "seed_data_dna.json",
    script_dir / "data_dna.json",
    script_dir / "app" / "seed_data_dna.json",
]

seed_file = None
for c in seed_candidates:
    if c.exists():
        seed_file = c
        break

if db_path.exists():
    import json
    try:
        with open(db_path) as f:
            existing = json.load(f)
        node_count = len(existing.get("nodes", {}))
        print(f"\nExisting database found: {node_count} fields")
        if node_count >= 500:
            print("✓ Database already has 500+ fields — no action needed.")
            print("\nStart the server:")
            print("  uvicorn app.main:app --reload --port 8000")
            sys.exit(0)
        else:
            print(f"⚠ Only {node_count} fields found — will replace with full dataset.")
    except Exception:
        print("⚠ Existing file is corrupt — will replace.")

if seed_file:
    shutil.copy2(seed_file, db_path)
    import json
    with open(db_path) as f:
        d = json.load(f)
    print(f"\n✓ Database installed: {len(d.get('nodes', {}))} fields, {len(d.get('edges', {}))} edges")
else:
    print("\n⚠ No seed file found — server will generate data on first start.")
    print("  This takes ~10 seconds on first run only.")

print("\n" + "=" * 50)
print("  Setup complete! Now start the server:")
print("  uvicorn app.main:app --reload --port 8000")
print("=" * 50)
