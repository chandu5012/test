"""
AI Discovery Layer — three AI-powered modules:

1. SemanticSearchEngine  — NL search over field catalog
2. SemanticResolver      — cross-system alias/synonym matching  
3. LineageInferencer     — AI-hypothesized lineage edges via Claude API

All AI outputs are clearly marked INFERRED with confidence scores and reasons.
The system NEVER overwrites authoritative data with AI guesses.
"""
import hashlib
import json
import os
from typing import Any

from core.models import (
    EdgeType, FieldNode, InferenceResult, LineageEdge,
    SearchResult, SourceType
)

# Optional heavy deps — graceful degradation if not installed
try:
    import numpy as np
    from sentence_transformers import SentenceTransformer
    EMBEDDINGS_AVAILABLE = True
except ImportError:
    EMBEDDINGS_AVAILABLE = False
    np = None

try:
    import anthropic
    CLAUDE_AVAILABLE = bool(os.getenv("ANTHROPIC_API_KEY"))
except ImportError:
    CLAUDE_AVAILABLE = False


def _cosine_similarity(a: list[float], b: list[float]) -> float:
    if not EMBEDDINGS_AVAILABLE:
        return 0.0
    va = np.array(a)
    vb = np.array(b)
    denom = np.linalg.norm(va) * np.linalg.norm(vb)
    return float(np.dot(va, vb) / denom) if denom > 0 else 0.0


class SemanticSearchEngine:
    """
    Natural language search over the field catalog using sentence embeddings.
    Falls back to keyword search if sentence-transformers not available.
    """

    MODEL_NAME = "all-MiniLM-L6-v2"

    def __init__(self):
        self._model = None
        self._field_index: list[tuple[FieldNode, list[float]]] = []

        if EMBEDDINGS_AVAILABLE:
            try:
                self._model = SentenceTransformer(self.MODEL_NAME)
            except Exception:
                pass

    def index_fields(self, fields: list[FieldNode]) -> None:
        """Embed all fields for fast similarity search."""
        self._field_index = []
        for field in fields:
            text = self._field_to_text(field)
            if self._model:
                embedding = self._model.encode(text).tolist()
            else:
                embedding = []
            self._field_index.append((field, embedding))

    def search(self, query: str, top_k: int = 10) -> list[SearchResult]:
        """Search fields by natural language query."""
        if not self._field_index:
            return []

        if self._model and EMBEDDINGS_AVAILABLE:
            return self._vector_search(query, top_k)
        return self._keyword_search(query, top_k)

    def _vector_search(self, query: str, top_k: int) -> list[SearchResult]:
        q_embedding = self._model.encode(query).tolist()
        scored = []
        for field, emb in self._field_index:
            if emb:
                score = _cosine_similarity(q_embedding, emb)
                scored.append((score, field))

        scored.sort(key=lambda x: x[0], reverse=True)
        return [
            SearchResult(
                field=f,
                similarity_score=round(s, 4),
                match_reason=f"Semantic similarity: {s:.2%}"
            )
            for s, f in scored[:top_k]
            if s > 0.3
        ]

    def _keyword_search(self, query: str, top_k: int) -> list[SearchResult]:
        q_lower = query.lower()
        scored = []
        for field, _ in self._field_index:
            score = 0.0
            field_text = self._field_to_text(field).lower()
            if q_lower in field.field.lower():
                score = 0.9
            elif q_lower in field_text:
                score = 0.6
            elif any(word in field_text for word in q_lower.split()):
                score = 0.4
            if score > 0:
                scored.append((score, field))

        scored.sort(key=lambda x: x[0], reverse=True)
        return [
            SearchResult(field=f, similarity_score=s, match_reason="Keyword match")
            for s, f in scored[:top_k]
        ]

    @staticmethod
    def _field_to_text(field: FieldNode) -> str:
        parts = [field.field, field.table, field.system]
        if field.description:
            parts.append(field.description)
        parts.extend(field.tags)
        return " ".join(parts)


class SemanticResolver:
    """
    Detects that fields like `cust_id`, `customer_id`, `customer_identifier`
    across different systems likely refer to the same concept.

    Produces cross-system INFERRED edges with confidence scores.
    """

    SIMILARITY_THRESHOLD = 0.75

    def __init__(self, search_engine: SemanticSearchEngine):
        self._search = search_engine

    def resolve_aliases(self, fields: list[FieldNode]) -> list[LineageEdge]:
        """
        For each field, find probable cross-system aliases.
        Returns INFERRED edges with system_boundary=True.
        """
        inferred_edges: list[LineageEdge] = []

        for field in fields:
            candidates = self._search.search(self._field_to_query(field), top_k=5)

            for result in candidates:
                candidate = result.field
                # Skip same system, same field
                if candidate.system == field.system:
                    continue
                if result.similarity_score < self.SIMILARITY_THRESHOLD:
                    continue
                # Avoid duplicate edges
                src_id = field.id
                tgt_id = candidate.id
                edge_id = hashlib.md5(f"alias:{src_id}~{tgt_id}".encode()).hexdigest()[:12]

                inferred_edges.append(LineageEdge(
                    id=edge_id,
                    source_field_id=src_id,
                    target_field_id=tgt_id,
                    edge_type=EdgeType.COPY,
                    source_type=SourceType.INFERRED,
                    confidence=result.similarity_score,
                    reason=f"Semantic alias resolution: '{field.field}' ≈ '{candidate.field}' (similarity={result.similarity_score:.2%})",
                    system_boundary=True,
                ))

        return inferred_edges

    @staticmethod
    def _field_to_query(field: FieldNode) -> str:
        parts = [field.field]
        if field.description:
            parts.append(field.description)
        return " ".join(parts)


class LineageInferencer:
    """
    Uses Claude API to infer likely lineage relationships between fields
    in different systems that have no declared lineage.

    Results are ALWAYS marked INFERRED and never overwrite authoritative edges.
    """

    def __init__(self):
        self._client = None
        if CLAUDE_AVAILABLE:
            try:
                self._client = anthropic.Anthropic(
                    api_key=os.getenv("ANTHROPIC_API_KEY")
                )
            except Exception:
                pass

    def infer_relationship(
        self,
        source: FieldNode,
        target: FieldNode,
    ) -> InferenceResult:
        """
        Ask Claude whether two fields likely have a lineage relationship.
        Returns structured InferenceResult with confidence and reason.
        """
        if self._client:
            return self._infer_with_claude(source, target)
        return self._infer_heuristic(source, target)

    def _infer_with_claude(self, source: FieldNode, target: FieldNode) -> InferenceResult:
        prompt = f"""You are a data lineage expert analyzing credit data systems.

Given these two fields from different systems, determine if there is likely a lineage relationship:

Field A:
- ID: {source.id}
- Table: {source.table}
- Field: {source.field}
- Type: {source.data_type}
- Description: {source.description or 'N/A'}
- Tags: {source.tags}
- System: {source.system}

Field B:
- ID: {target.id}
- Table: {target.table}
- Field: {target.field}
- Type: {target.data_type}
- Description: {target.description or 'N/A'}
- Tags: {target.tags}
- System: {target.system}

Respond ONLY with a JSON object (no markdown, no explanation outside the JSON):
{{
  "related": true/false,
  "confidence": 0.0-1.0,
  "reason": "one sentence human-readable explanation",
  "edge_type": "COPY|TRANSFORM|AGGREGATE|DERIVED"
}}"""

        try:
            message = self._client.messages.create(
                model="claude-sonnet-4-20250514",
                max_tokens=256,
                messages=[{"role": "user", "content": prompt}]
            )
            text = message.content[0].text.strip()
            data = json.loads(text)
            return InferenceResult(
                source_field_id=source.id,
                target_field_id=target.id,
                related=data.get("related", False),
                confidence=float(data.get("confidence", 0.0)),
                reason=data.get("reason", "AI inference"),
                suggested_edge_type=EdgeType(data.get("edge_type", "COPY")),
            )
        except Exception as e:
            return self._infer_heuristic(source, target)

    def _infer_heuristic(self, source: FieldNode, target: FieldNode) -> InferenceResult:
        """Rule-based fallback when Claude API unavailable."""
        score = 0.0
        reason_parts = []

        # Field name similarity
        src_words = set(source.field.lower().replace("_", " ").split())
        tgt_words = set(target.field.lower().replace("_", " ").split())
        overlap = len(src_words & tgt_words) / max(len(src_words | tgt_words), 1)
        if overlap > 0.5:
            score += overlap * 0.5
            reason_parts.append(f"field name similarity ({overlap:.0%})")

        # Tag overlap
        src_tags = set(source.tags)
        tgt_tags = set(target.tags)
        tag_overlap = len(src_tags & tgt_tags) / max(len(src_tags | tgt_tags), 1)
        if tag_overlap > 0:
            score += tag_overlap * 0.3
            reason_parts.append(f"shared tags: {src_tags & tgt_tags}")

        # Same data type
        if source.data_type and target.data_type:
            if source.data_type.split("(")[0] == target.data_type.split("(")[0]:
                score += 0.2
                reason_parts.append("matching data type")

        related = score >= 0.5
        return InferenceResult(
            source_field_id=source.id,
            target_field_id=target.id,
            related=related,
            confidence=min(round(score, 3), 0.85),  # Cap heuristic at 0.85
            reason=f"Heuristic inference: {'; '.join(reason_parts) or 'no strong signals'}",
            suggested_edge_type=EdgeType.COPY,
        )

    def bulk_infer(
        self,
        candidate_pairs: list[tuple[FieldNode, FieldNode]],
        min_confidence: float = 0.5
    ) -> list[LineageEdge]:
        """
        Run inference on a list of candidate field pairs.
        Returns INFERRED edges for pairs above min_confidence.
        """
        edges = []
        for src, tgt in candidate_pairs:
            result = self.infer_relationship(src, tgt)
            if result.related and result.confidence >= min_confidence:
                edge_id = hashlib.md5(
                    f"infer:{result.source_field_id}~{result.target_field_id}".encode()
                ).hexdigest()[:12]
                edge = LineageEdge(
                    id=edge_id,
                    source_field_id=result.source_field_id,
                    target_field_id=result.target_field_id,
                    edge_type=result.suggested_edge_type,
                    source_type=SourceType.INFERRED,
                    confidence=result.confidence,
                    reason=result.reason,
                    system_boundary=True,
                )
                edges.append(edge)
        return edges
