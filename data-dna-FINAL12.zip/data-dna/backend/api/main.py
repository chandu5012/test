"""
Data-DNA FastAPI Application
Serves all lineage, search, impact, and audit endpoints.
"""
import os
import time
from contextlib import asynccontextmanager
from typing import Any

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from ai.discovery import LineageInferencer, SemanticResolver, SemanticSearchEngine
from core.models import EdgeType, FieldNode, LineageEdge, SourceType
from core.schema_crawler import MockCreditAdapter, MockRiskEngineAdapter, SchemaIngester
from core.sql_parser import SQLParser
from graph.lineage_graph import LineageGraph

# ── App State ─────────────────────────────────────────────────────────────

graph = LineageGraph()
search_engine = SemanticSearchEngine()
resolver = SemanticResolver(search_engine)
inferencer = LineageInferencer()


def bootstrap_demo_data():
    """Load demo credit data lineage on startup."""

    # 1. Crawl mock schemas
    ingester = SchemaIngester()
    nodes, edges = ingester.ingest([MockCreditAdapter(), MockRiskEngineAdapter()])
    graph.bulk_ingest(nodes, edges)

    # 2. Parse representative SQL to add transform lineage
    parser = SQLParser("credit_core")
    sql_statements = [
        # Utilization rate derived from balance/limit
        """INSERT INTO credit_accounts (utilization_rate)
           SELECT current_balance / credit_limit FROM credit_accounts""",
        # Credit score components derived from payment history
        """INSERT INTO credit_score (payment_component)
           SELECT AVG(CASE WHEN days_late = 0 THEN 1.0 ELSE 0.0 END)
           FROM payment_history""",
        # Risk assessment references credit score
        """INSERT INTO risk_assessment (credit_score_ref, income_to_debt_ratio)
           SELECT cs.score_value,
                  cp.annual_income / SUM(ca.current_balance)
           FROM credit_score cs
           JOIN customer_profile cp ON cs.customer_id = cp.customer_id
           JOIN credit_accounts ca ON ca.customer_id = cp.customer_id""",
    ]
    for sql in sql_statements:
        sql_nodes, sql_edges = parser.parse_sql(sql)
        graph.bulk_ingest(sql_nodes, sql_edges)

    # 3. Add explicit cross-system edges (credit_core → risk_engine)
    import hashlib
    cross_system_edges = [
        LineageEdge(
            id=hashlib.md5(b"xs1").hexdigest()[:12],
            source_field_id="credit_core.credit_score.score_value",
            target_field_id="risk_engine.customer_risk_profile.fico_score",
            edge_type=EdgeType.COPY,
            source_type=SourceType.AUTHORITATIVE,
            confidence=1.0,
            reason="ETL pipeline: credit_score.score_value is copied nightly to risk_engine.fico_score",
            system_boundary=True,
        ),
        LineageEdge(
            id=hashlib.md5(b"xs2").hexdigest()[:12],
            source_field_id="credit_core.risk_assessment.income_to_debt_ratio",
            target_field_id="risk_engine.customer_risk_profile.debt_to_income",
            edge_type=EdgeType.COPY,
            source_type=SourceType.AUTHORITATIVE,
            confidence=1.0,
            reason="ETL pipeline: DTI ratio synced from credit_core risk_assessment",
            system_boundary=True,
        ),
        LineageEdge(
            id=hashlib.md5(b"xs3").hexdigest()[:12],
            source_field_id="credit_core.payment_history.days_late",
            target_field_id="risk_engine.scoring_features.payment_score",
            edge_type=EdgeType.TRANSFORM,
            source_type=SourceType.AUTHORITATIVE,
            confidence=1.0,
            reason="Feature pipeline: payment_score = normalize(aggregate(days_late))",
            system_boundary=True,
        ),
        LineageEdge(
            id=hashlib.md5(b"xs4").hexdigest()[:12],
            source_field_id="credit_core.credit_accounts.utilization_rate",
            target_field_id="risk_engine.scoring_features.utilization_score",
            edge_type=EdgeType.TRANSFORM,
            source_type=SourceType.AUTHORITATIVE,
            confidence=1.0,
            reason="Feature pipeline: utilization_score = normalize(utilization_rate)",
            system_boundary=True,
        ),
        LineageEdge(
            id=hashlib.md5(b"xs5").hexdigest()[:12],
            source_field_id="credit_core.risk_assessment.decision",
            target_field_id="risk_engine.decision_log.final_decision",
            edge_type=EdgeType.COPY,
            source_type=SourceType.AUTHORITATIVE,
            confidence=1.0,
            reason="Decision is written to audit log from risk_assessment",
            system_boundary=True,
        ),
    ]
    for edge in cross_system_edges:
        graph.add_edge(edge)

    # 4. Run AI alias resolution for cross-system inferred links
    all_fields = graph.get_all_fields()
    search_engine.index_fields(all_fields)
    inferred = resolver.resolve_aliases(all_fields)
    for edge in inferred:
        graph.add_edge(edge)

    print(f"[Data-DNA] Bootstrap complete: {graph.get_metrics()}")


@asynccontextmanager
async def lifespan(app: FastAPI):
    bootstrap_demo_data()
    yield


# ── App Setup ─────────────────────────────────────────────────────────────

app = FastAPI(
    title="Data-DNA Lineage API",
    version="1.0.0",
    description="AI-powered credit data lineage discovery platform",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


# ── Response Models ────────────────────────────────────────────────────────

def field_to_dict(f: FieldNode) -> dict:
    return {
        "id": f.id,
        "system": f.system,
        "table": f.table,
        "field": f.field,
        "data_type": f.data_type,
        "description": f.description,
        "tags": f.tags,
        "last_seen": f.last_seen.isoformat(),
    }


def edge_to_dict(e: LineageEdge) -> dict:
    return {
        "id": e.id,
        "source_field_id": e.source_field_id,
        "target_field_id": e.target_field_id,
        "edge_type": e.edge_type.value,
        "source_type": e.source_type.value,
        "confidence": e.confidence,
        "reason": e.reason,
        "transformation_sql": e.transformation_sql,
        "system_boundary": e.system_boundary,
        "discovered_at": e.discovered_at.isoformat(),
    }


# ── Routes ─────────────────────────────────────────────────────────────────

@app.get("/api/health")
def health():
    return {"status": "ok", "version": "1.0.0"}


@app.get("/api/metrics")
def metrics():
    m = graph.get_metrics()
    return {
        "total_fields": m.total_fields,
        "total_edges": m.total_edges,
        "authoritative_edges": m.authoritative_edges,
        "inferred_edges": m.inferred_edges,
        "systems": m.systems,
        "avg_confidence": m.avg_confidence,
        "lineage_coverage_pct": m.lineage_coverage_pct,
        "cross_system_edges": m.cross_system_edges,
        "orphan_fields": m.orphan_fields,
    }


@app.get("/api/fields")
def list_fields(
    system: str | None = None,
    table: str | None = None,
    tag: str | None = None,
):
    """List all fields, optionally filtered by system/table/tag."""
    fields = graph.get_all_fields()
    if system:
        fields = [f for f in fields if f.system == system]
    if table:
        fields = [f for f in fields if f.table == table]
    if tag:
        fields = [f for f in fields if tag in f.tags]
    return {"fields": [field_to_dict(f) for f in fields], "count": len(fields)}


@app.get("/api/fields/{field_id:path}")
def get_field(field_id: str):
    f = graph.get_field(field_id)
    if not f:
        raise HTTPException(404, f"Field '{field_id}' not found")
    return field_to_dict(f)


@app.get("/api/lineage/{field_id:path}")
def get_lineage(
    field_id: str,
    direction: str = Query("both", regex="^(upstream|downstream|both)$"),
    max_hops: int = Query(5, ge=1, le=10),
):
    """Get full lineage graph for a field."""
    path = graph.get_lineage(field_id, direction=direction, max_hops=max_hops)
    if not path:
        raise HTTPException(404, f"Field '{field_id}' not found in lineage graph")

    return {
        "field_id": field_id,
        "direction": direction,
        "nodes": [field_to_dict(n) for n in path.nodes],
        "edges": [edge_to_dict(e) for e in path.hops],
        "total_confidence": path.total_confidence,
        "crosses_systems": path.crosses_systems,
        "has_inferred_hops": path.has_inferred_hops,
        "hop_count": len(path.hops),
    }


@app.get("/api/impact/{field_id:path}")
def get_impact(field_id: str):
    """Downstream impact analysis — what breaks if this field changes?"""
    impact = graph.get_impact(field_id)
    if not impact:
        raise HTTPException(404, f"Field '{field_id}' not found")

    return {
        "field_id": field_id,
        "downstream_fields": [field_to_dict(f) for f in impact.downstream_fields],
        "downstream_edges": [edge_to_dict(e) for e in impact.downstream_edges],
        "system_count": impact.system_count,
        "has_inferred_paths": impact.has_inferred_paths,
        "risk_level": impact.risk_level,
        "downstream_count": len(impact.downstream_fields),
    }


@app.get("/api/audit/{field_id:path}")
def get_audit(field_id: str):
    """Authoritative-only provenance chain for compliance."""
    chain = graph.get_audit_chain(field_id)
    return {
        "field_id": field_id,
        "audit_chain": chain,
        "chain_length": len(chain),
        "note": "Only AUTHORITATIVE edges included. Inferred relationships excluded from audit.",
    }


@app.get("/api/search")
def search_fields(
    q: str = Query(..., min_length=1),
    top_k: int = Query(10, ge=1, le=50),
):
    """Natural language / semantic search over field catalog."""
    start = time.time()
    results = search_engine.search(q, top_k=top_k)

    # Fall back to text search if embeddings returned nothing
    if not results:
        text_fields = graph.search_fields(q, limit=top_k)
        results_out = [
            {"field": field_to_dict(f), "similarity_score": 0.5, "match_reason": "Keyword match"}
            for f in text_fields
        ]
    else:
        results_out = [
            {"field": field_to_dict(r.field), "similarity_score": r.similarity_score,
             "match_reason": r.match_reason}
            for r in results
        ]

    return {
        "query": q,
        "results": results_out,
        "count": len(results_out),
        "latency_ms": round((time.time() - start) * 1000, 1),
    }


@app.post("/api/ingest/sql")
def ingest_sql(payload: dict):
    """Ingest a SQL statement and extract lineage."""
    sql = payload.get("sql", "")
    system = payload.get("system", "unknown")
    if not sql:
        raise HTTPException(400, "sql field required")

    parser = SQLParser(system)
    nodes, edges = parser.parse_sql(sql)
    result = graph.bulk_ingest(nodes, edges)

    # Re-index search
    search_engine.index_fields(graph.get_all_fields())

    return {
        "status": "ok",
        "nodes_discovered": result["added_nodes"],
        "edges_discovered": result["added_edges"],
        "nodes": [field_to_dict(n) for n in nodes],
        "edges": [edge_to_dict(e) for e in edges],
    }


@app.get("/api/systems")
def list_systems():
    """List all systems with field counts."""
    fields = graph.get_all_fields()
    by_system: dict[str, int] = {}
    for f in fields:
        by_system[f.system] = by_system.get(f.system, 0) + 1
    return {"systems": [{"name": k, "field_count": v} for k, v in by_system.items()]}
