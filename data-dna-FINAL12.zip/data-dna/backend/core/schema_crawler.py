"""
Schema Crawler — pluggable adapter pattern for metadata ingestion.

Each source type implements SourceAdapter protocol.
Ships with MockCreditAdapter for demo/hackathon purposes.
"""
from dataclasses import dataclass
from datetime import datetime
from typing import Protocol

from core.models import EdgeType, FieldNode, LineageEdge, SourceType
import hashlib


@dataclass
class TableMeta:
    name: str
    description: str | None = None


@dataclass
class FieldMeta:
    table: str
    field: str
    data_type: str
    description: str | None = None
    tags: list[str] | None = None
    nullable: bool = True


@dataclass
class FKRelation:
    source_table: str
    source_field: str
    target_table: str
    target_field: str
    description: str | None = None


class SourceAdapter(Protocol):
    def get_tables(self) -> list[TableMeta]: ...
    def get_fields(self, table: str) -> list[FieldMeta]: ...
    def get_foreign_keys(self) -> list[FKRelation]: ...


class MockCreditAdapter:
    """
    Realistic mock of a credit data warehouse for hackathon demo.
    Models a typical credit bureau / lending platform with 3 systems.
    """

    SYSTEM = "credit_core"

    def get_tables(self) -> list[TableMeta]:
        return [
            TableMeta("customer_profile", "Core customer identity and demographics"),
            TableMeta("credit_accounts", "All credit accounts per customer"),
            TableMeta("payment_history", "Monthly payment records per account"),
            TableMeta("credit_score", "Computed credit scores with breakdown"),
            TableMeta("risk_assessment", "Risk classification and decisioning"),
            TableMeta("loan_applications", "Loan application data and outcomes"),
        ]

    def get_fields(self, table: str) -> list[FieldMeta]:
        schema = {
            "customer_profile": [
                FieldMeta("customer_profile", "customer_id", "VARCHAR(36)", "Unique customer identifier", ["PII", "key"]),
                FieldMeta("customer_profile", "date_of_birth", "DATE", "Customer DOB", ["PII", "sensitive"]),
                FieldMeta("customer_profile", "annual_income", "DECIMAL(12,2)", "Declared annual income", ["financial"]),
                FieldMeta("customer_profile", "employment_status", "VARCHAR(20)", "Current employment status", ["financial"]),
                FieldMeta("customer_profile", "postal_code", "VARCHAR(10)", "Residential postal code", ["PII"]),
                FieldMeta("customer_profile", "created_at", "TIMESTAMP", "Record creation time", []),
            ],
            "credit_accounts": [
                FieldMeta("credit_accounts", "account_id", "VARCHAR(36)", "Unique account identifier", ["key"]),
                FieldMeta("credit_accounts", "customer_id", "VARCHAR(36)", "FK to customer_profile", ["key", "FK"]),
                FieldMeta("credit_accounts", "credit_limit", "DECIMAL(10,2)", "Approved credit limit", ["financial"]),
                FieldMeta("credit_accounts", "current_balance", "DECIMAL(10,2)", "Outstanding balance", ["financial"]),
                FieldMeta("credit_accounts", "utilization_rate", "DECIMAL(5,4)", "Balance/limit ratio", ["derived", "financial"]),
                FieldMeta("credit_accounts", "account_status", "VARCHAR(20)", "Active/closed/delinquent", []),
                FieldMeta("credit_accounts", "opened_date", "DATE", "Account opening date", []),
            ],
            "payment_history": [
                FieldMeta("payment_history", "payment_id", "VARCHAR(36)", "Unique payment record", ["key"]),
                FieldMeta("payment_history", "account_id", "VARCHAR(36)", "FK to credit_accounts", ["key", "FK"]),
                FieldMeta("payment_history", "payment_date", "DATE", "Date payment received", []),
                FieldMeta("payment_history", "amount_due", "DECIMAL(10,2)", "Minimum payment due", ["financial"]),
                FieldMeta("payment_history", "amount_paid", "DECIMAL(10,2)", "Actual payment made", ["financial"]),
                FieldMeta("payment_history", "days_late", "INTEGER", "Days past due (0 = on time)", ["risk"]),
                FieldMeta("payment_history", "payment_status", "VARCHAR(20)", "ON_TIME/LATE/MISSED", ["risk"]),
            ],
            "credit_score": [
                FieldMeta("credit_score", "score_id", "VARCHAR(36)", "Unique score record", ["key"]),
                FieldMeta("credit_score", "customer_id", "VARCHAR(36)", "FK to customer_profile", ["key", "FK"]),
                FieldMeta("credit_score", "score_value", "INTEGER", "Credit score 300-850", ["derived", "credit_score"]),
                FieldMeta("credit_score", "payment_component", "DECIMAL(5,4)", "Payment history component weight", ["derived"]),
                FieldMeta("credit_score", "utilization_component", "DECIMAL(5,4)", "Utilization component weight", ["derived"]),
                FieldMeta("credit_score", "score_date", "DATE", "Date score was computed", []),
                FieldMeta("credit_score", "score_version", "VARCHAR(10)", "Scoring model version", []),
            ],
            "risk_assessment": [
                FieldMeta("risk_assessment", "assessment_id", "VARCHAR(36)", "Unique assessment", ["key"]),
                FieldMeta("risk_assessment", "customer_id", "VARCHAR(36)", "FK to customer_profile", ["key", "FK"]),
                FieldMeta("risk_assessment", "risk_tier", "VARCHAR(10)", "PRIME/NEAR_PRIME/SUBPRIME", ["derived", "risk"]),
                FieldMeta("risk_assessment", "default_probability", "DECIMAL(5,4)", "ML model default probability", ["derived", "ML"]),
                FieldMeta("risk_assessment", "credit_score_ref", "INTEGER", "Credit score at assessment time", ["financial"]),
                FieldMeta("risk_assessment", "income_to_debt_ratio", "DECIMAL(6,4)", "DTI ratio", ["derived", "financial"]),
                FieldMeta("risk_assessment", "decision", "VARCHAR(20)", "APPROVE/DECLINE/REVIEW", ["risk"]),
            ],
            "loan_applications": [
                FieldMeta("loan_applications", "application_id", "VARCHAR(36)", "Unique application", ["key"]),
                FieldMeta("loan_applications", "customer_id", "VARCHAR(36)", "FK to customer_profile", ["key", "FK"]),
                FieldMeta("loan_applications", "requested_amount", "DECIMAL(12,2)", "Loan amount requested", ["financial"]),
                FieldMeta("loan_applications", "approved_amount", "DECIMAL(12,2)", "Final approved amount", ["financial"]),
                FieldMeta("loan_applications", "interest_rate", "DECIMAL(5,4)", "Approved interest rate", ["financial", "derived"]),
                FieldMeta("loan_applications", "application_status", "VARCHAR(20)", "Final application status", []),
            ],
        }
        return schema.get(table, [])

    def get_foreign_keys(self) -> list[FKRelation]:
        return [
            FKRelation("credit_accounts", "customer_id", "customer_profile", "customer_id",
                       "Account belongs to customer"),
            FKRelation("payment_history", "account_id", "credit_accounts", "account_id",
                       "Payment belongs to account"),
            FKRelation("credit_score", "customer_id", "customer_profile", "customer_id",
                       "Score computed for customer"),
            FKRelation("risk_assessment", "customer_id", "customer_profile", "customer_id",
                       "Assessment for customer"),
            FKRelation("loan_applications", "customer_id", "customer_profile", "customer_id",
                       "Application by customer"),
        ]


class MockRiskEngineAdapter:
    """Simulates a separate risk engine system with overlapping field names."""

    SYSTEM = "risk_engine"

    def get_tables(self) -> list[TableMeta]:
        return [
            TableMeta("customer_risk_profile", "Aggregated risk view per customer"),
            TableMeta("scoring_features", "ML feature store for scoring model"),
            TableMeta("decision_log", "Audit log of all risk decisions"),
        ]

    def get_fields(self, table: str) -> list[FieldMeta]:
        schema = {
            "customer_risk_profile": [
                FieldMeta("customer_risk_profile", "cust_id", "VARCHAR(36)", "Customer identifier (maps to customer_id)", ["key", "PII"]),
                FieldMeta("customer_risk_profile", "fico_score", "INTEGER", "Credit score snapshot", ["credit_score"]),
                FieldMeta("customer_risk_profile", "debt_to_income", "DECIMAL(6,4)", "DTI ratio", ["derived", "financial"]),
                FieldMeta("customer_risk_profile", "risk_grade", "CHAR(1)", "A/B/C/D risk grade", ["derived", "risk"]),
                FieldMeta("customer_risk_profile", "updated_at", "TIMESTAMP", "Last profile update", []),
            ],
            "scoring_features": [
                FieldMeta("scoring_features", "customer_identifier", "VARCHAR(36)", "Customer ID", ["key"]),
                FieldMeta("scoring_features", "payment_score", "DECIMAL(5,4)", "Normalized payment history score", ["derived", "ML"]),
                FieldMeta("scoring_features", "utilization_score", "DECIMAL(5,4)", "Normalized utilization score", ["derived", "ML"]),
                FieldMeta("scoring_features", "income_normalized", "DECIMAL(8,4)", "Normalized annual income", ["derived", "ML"]),
                FieldMeta("scoring_features", "feature_version", "VARCHAR(10)", "Feature pipeline version", []),
            ],
            "decision_log": [
                FieldMeta("decision_log", "decision_id", "VARCHAR(36)", "Unique decision record", ["key"]),
                FieldMeta("decision_log", "cust_id", "VARCHAR(36)", "Customer identifier", ["key"]),
                FieldMeta("decision_log", "final_decision", "VARCHAR(20)", "Outcome of risk assessment", ["risk"]),
                FieldMeta("decision_log", "decision_timestamp", "TIMESTAMP", "When decision was made", []),
                FieldMeta("decision_log", "model_version", "VARCHAR(20)", "Risk model version used", []),
            ],
        }
        return schema.get(table, [])

    def get_foreign_keys(self) -> list[FKRelation]:
        return []


class SchemaIngester:
    """Orchestrates crawling of all adapters into FieldNodes and FK edges."""

    def ingest(self, adapters: list) -> tuple[list[FieldNode], list[LineageEdge]]:
        all_nodes: list[FieldNode] = []
        all_edges: list[LineageEdge] = []

        for adapter in adapters:
            system = adapter.SYSTEM
            for table_meta in adapter.get_tables():
                tbl = table_meta.name
                for fm in adapter.get_fields(tbl):
                    node = FieldNode(
                        id=FieldNode.make_id(system, fm.table, fm.field),
                        system=system,
                        table=fm.table,
                        field=fm.field,
                        data_type=fm.data_type,
                        description=fm.description,
                        tags=fm.tags or [],
                    )
                    all_nodes.append(node)

            for fk in adapter.get_foreign_keys():
                src_id = FieldNode.make_id(system, fk.source_table, fk.source_field)
                tgt_id = FieldNode.make_id(system, fk.target_table, fk.target_field)
                edge_id = hashlib.md5(f"fk:{src_id}->{tgt_id}".encode()).hexdigest()[:12]
                edge = LineageEdge(
                    id=edge_id,
                    source_field_id=tgt_id,  # FK points from child to parent (upstream)
                    target_field_id=src_id,
                    edge_type=EdgeType.COPY,
                    source_type=SourceType.AUTHORITATIVE,
                    confidence=1.0,
                    reason=fk.description or f"Foreign key: {fk.source_table}.{fk.source_field} → {fk.target_table}.{fk.target_field}",
                    system_boundary=False,
                )
                all_edges.append(edge)

        return all_nodes, all_edges
