"""
Core data models for Data-DNA lineage platform.
All data classes are immutable-friendly and fully typed.
"""
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any


class EdgeType(str, Enum):
    TRANSFORM = "TRANSFORM"      # field is mathematically transformed
    COPY = "COPY"                # direct copy / rename
    AGGREGATE = "AGGREGATE"      # rollup, sum, avg, count
    FILTER = "FILTER"            # subset/filtered version
    JOIN = "JOIN"                # joined from multiple sources
    DERIVED = "DERIVED"          # computed from business logic


class SourceType(str, Enum):
    AUTHORITATIVE = "AUTHORITATIVE"   # parsed from SQL/schema — ground truth
    INFERRED = "INFERRED"             # AI-hypothesized — must be validated


@dataclass
class FieldNode:
    id: str                            # "{system}.{table}.{field}"
    system: str
    table: str
    field: str
    data_type: str
    description: str | None = None
    tags: list[str] = field(default_factory=list)
    embedding: list[float] | None = None
    last_seen: datetime = field(default_factory=datetime.utcnow)
    metadata: dict[str, Any] = field(default_factory=dict)

    @staticmethod
    def make_id(system: str, table: str, field_name: str) -> str:
        return f"{system}.{table}.{field_name}"

    def display_name(self) -> str:
        return f"{self.table}.{self.field} ({self.system})"


@dataclass
class LineageEdge:
    id: str
    source_field_id: str
    target_field_id: str
    edge_type: EdgeType
    source_type: SourceType
    confidence: float                  # 0.0 – 1.0
    reason: str                        # human-readable explanation
    transformation_sql: str | None = None
    system_boundary: bool = False
    discovered_at: datetime = field(default_factory=datetime.utcnow)
    last_validated: datetime = field(default_factory=datetime.utcnow)


@dataclass
class LineagePath:
    """A multi-hop lineage chain from source to target."""
    field_id: str
    hops: list[LineageEdge]
    nodes: list[FieldNode]
    total_confidence: float
    crosses_systems: list[str]
    has_inferred_hops: bool
    direction: str  # "upstream" | "downstream" | "both"

    @staticmethod
    def compute_confidence(edges: list[LineageEdge]) -> float:
        if not edges:
            return 1.0
        result = 1.0
        for e in edges:
            result *= e.confidence
        return round(result, 4)


@dataclass
class ImpactAnalysis:
    """Downstream impact of changing a field."""
    field_id: str
    downstream_fields: list[FieldNode]
    downstream_edges: list[LineageEdge]
    system_count: int
    has_inferred_paths: bool
    risk_level: str  # "LOW" | "MEDIUM" | "HIGH"


@dataclass
class SearchResult:
    field: FieldNode
    similarity_score: float
    match_reason: str


@dataclass
class InferenceResult:
    source_field_id: str
    target_field_id: str
    related: bool
    confidence: float
    reason: str
    suggested_edge_type: EdgeType


@dataclass
class GraphMetrics:
    total_fields: int
    total_edges: int
    authoritative_edges: int
    inferred_edges: int
    systems: list[str]
    avg_confidence: float
    lineage_coverage_pct: float      # % fields with at least one lineage edge
    cross_system_edges: int
    orphan_fields: int               # fields with no lineage at all
