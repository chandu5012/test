"""
SQL Parser — extracts field-level lineage from SQL DDL/DML.

Uses sqlglot for robust SQL parsing across dialects (Postgres, MySQL, etc.)
Produces authoritative LineageEdge records with confidence=1.0.
"""
import hashlib
import re
from datetime import datetime

try:
    import sqlglot
    import sqlglot.expressions as exp
    SQLGLOT_AVAILABLE = True
except ImportError:
    SQLGLOT_AVAILABLE = False

from core.models import EdgeType, FieldNode, LineageEdge, SourceType


class SQLParser:
    """
    Parses SQL statements to extract column-level lineage.

    Supports:
    - CREATE TABLE AS SELECT
    - INSERT INTO ... SELECT
    - CREATE VIEW AS SELECT
    - CTEs (WITH ... AS (...) SELECT)
    """

    def __init__(self, system_name: str = "unknown"):
        self.system_name = system_name

    def parse_sql(self, sql: str) -> tuple[list[FieldNode], list[LineageEdge]]:
        """
        Parse a SQL string, return discovered fields and lineage edges.
        Falls back to regex-based parsing if sqlglot not available.
        """
        if SQLGLOT_AVAILABLE:
            return self._parse_with_sqlglot(sql)
        return self._parse_with_regex(sql)

    def _parse_with_sqlglot(self, sql: str) -> tuple[list[FieldNode], list[LineageEdge]]:
        nodes: list[FieldNode] = []
        edges: list[LineageEdge] = []

        try:
            statements = sqlglot.parse(sql)
        except Exception:
            return nodes, edges

        for stmt in statements:
            if stmt is None:
                continue

            # INSERT INTO target SELECT ... FROM source
            if isinstance(stmt, exp.Insert):
                self._handle_insert(stmt, nodes, edges)

            # CREATE TABLE/VIEW AS SELECT
            elif isinstance(stmt, (exp.Create,)):
                self._handle_create(stmt, nodes, edges)

        return nodes, edges

    def _handle_insert(self, stmt, nodes, edges):
        target_table = stmt.find(exp.Table)
        if not target_table:
            return
        target_name = target_table.name

        select = stmt.find(exp.Select)
        if not select:
            return

        self._process_select(select, target_name, nodes, edges)

    def _handle_create(self, stmt, nodes, edges):
        table = stmt.find(exp.Table)
        if not table:
            return
        target_name = table.name

        select = stmt.find(exp.Select)
        if select:
            self._process_select(select, target_name, nodes, edges)

    def _process_select(self, select, target_table: str, nodes, edges):
        for sel_expr in select.expressions:
            target_col = None
            source_col = None
            source_table = None
            edge_type = EdgeType.COPY

            # Get target column alias or name
            if isinstance(sel_expr, exp.Alias):
                target_col = sel_expr.alias
                inner = sel_expr.this
            else:
                inner = sel_expr
                if isinstance(inner, exp.Column):
                    target_col = inner.name

            if target_col is None:
                continue

            # Determine edge type from expression
            if isinstance(inner, (exp.Add, exp.Sub, exp.Mul, exp.Div)):
                edge_type = EdgeType.TRANSFORM
            elif isinstance(inner, (exp.Sum, exp.Avg, exp.Count, exp.Max, exp.Min)):
                edge_type = EdgeType.AGGREGATE
            elif isinstance(inner, exp.Column):
                edge_type = EdgeType.COPY
                source_col = inner.name
                if inner.table:
                    source_table = inner.table

            # Find FROM table if not set
            if not source_table:
                from_tables = list(select.find_all(exp.Table))
                if from_tables:
                    source_table = from_tables[0].name

            if source_col and source_table:
                src_id = FieldNode.make_id(self.system_name, source_table, source_col)
                tgt_id = FieldNode.make_id(self.system_name, target_table, target_col)

                # Create nodes if not exists
                for fid, tbl, col in [(src_id, source_table, source_col), (tgt_id, target_table, target_col)]:
                    nodes.append(FieldNode(
                        id=fid, system=self.system_name,
                        table=tbl, field=col, data_type="unknown"
                    ))

                edge_id = hashlib.md5(f"{src_id}->{tgt_id}".encode()).hexdigest()[:12]
                edges.append(LineageEdge(
                    id=edge_id,
                    source_field_id=src_id,
                    target_field_id=tgt_id,
                    edge_type=edge_type,
                    source_type=SourceType.AUTHORITATIVE,
                    confidence=1.0,
                    reason=f"Parsed from SQL: {edge_type.value} operation",
                    transformation_sql=None,
                ))

    def _parse_with_regex(self, sql: str) -> tuple[list[FieldNode], list[LineageEdge]]:
        """Fallback regex parser for environments without sqlglot."""
        nodes: list[FieldNode] = []
        edges: list[LineageEdge] = []

        sql_upper = sql.upper().strip()

        # Match: INSERT INTO target_table SELECT col1, col2 FROM source_table
        insert_pattern = re.compile(
            r"INSERT\s+INTO\s+(\w+).*?SELECT\s+(.*?)\s+FROM\s+(\w+)",
            re.IGNORECASE | re.DOTALL
        )
        m = insert_pattern.search(sql)
        if m:
            target_table = m.group(1)
            cols_str = m.group(2)
            source_table = m.group(3)

            cols = [c.strip().split()[-1] for c in cols_str.split(",")]
            for col in cols:
                col = col.strip().strip("*")
                if not col or col == "*":
                    continue
                src_id = FieldNode.make_id(self.system_name, source_table, col)
                tgt_id = FieldNode.make_id(self.system_name, target_table, col)
                for fid, tbl in [(src_id, source_table), (tgt_id, target_table)]:
                    nodes.append(FieldNode(
                        id=fid, system=self.system_name,
                        table=tbl, field=col, data_type="unknown"
                    ))
                edge_id = hashlib.md5(f"{src_id}->{tgt_id}".encode()).hexdigest()[:12]
                edges.append(LineageEdge(
                    id=edge_id, source_field_id=src_id, target_field_id=tgt_id,
                    edge_type=EdgeType.COPY, source_type=SourceType.AUTHORITATIVE,
                    confidence=1.0, reason="Parsed from SQL (regex fallback)"
                ))

        return nodes, edges
