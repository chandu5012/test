@echo off
setlocal enabledelayedexpansion
title DataLineage IQ - Startup

echo.
echo  ╔══════════════════════════════════════════════════════════════╗
echo  ║          DataLineage IQ — Intelligent Lineage Platform       ║
echo  ║          v1.0.0   Powered by FastAPI + Python                ║
echo  ╚══════════════════════════════════════════════════════════════╝
echo.

:: ── Check Python ────────────────────────────────────────────────────────────
echo [1/5] Checking Python installation...
python --version >nul 2>&1
if errorlevel 1 (
    echo  ✗ Python not found!
    echo    Please install Python 3.10+ from https://www.python.org/downloads/
    echo    Make sure to check "Add Python to PATH" during installation.
    pause
    exit /b 1
)
for /f "tokens=2" %%v in ('python --version 2^>^&1') do set PYVER=%%v
echo  ✓ Python %PYVER% found

:: ── Check pip ────────────────────────────────────────────────────────────────
echo [2/5] Checking pip...
pip --version >nul 2>&1
if errorlevel 1 (
    echo  ✗ pip not found! Running ensurepip...
    python -m ensurepip --upgrade
)
echo  ✓ pip ready

:: ── Create virtual environment ───────────────────────────────────────────────
echo [3/5] Setting up virtual environment...
if not exist "venv" (
    echo    Creating new venv...
    python -m venv venv
)
echo  ✓ Virtual environment ready

:: ── Activate venv ────────────────────────────────────────────────────────────
call venv\Scripts\activate.bat

:: ── Install dependencies ─────────────────────────────────────────────────────
echo [4/5] Installing dependencies...
pip install -r backend\requirements.txt --quiet --disable-pip-version-check
if errorlevel 1 (
    echo  ✗ Failed to install dependencies
    pause
    exit /b 1
)
echo  ✓ All dependencies installed

:: ── Optional: Set environment variables ─────────────────────────────────────
echo [5/5] Configuring environment...

:: ERWIN DI Settings (update these for your environment)
set ERWIN_BASE_URL=http://localhost:8080/erwin-di/api
set ERWIN_API_KEY=YOUR_ERWIN_API_KEY

:: Data Dictionary Settings
set DATA_DICT_URL=http://localhost:9090/data-dictionary/api

:: GitHub Code Search (optional)
set GITHUB_TOKEN=
set GITHUB_REPO=

:: Local Code Directory (relative to run location)
set LOCAL_CODE_DIR=.\code_repo_samples

echo  ✓ Environment configured

echo.
echo ════════════════════════════════════════════════════════════════
echo   Starting DataLineage IQ on http://localhost:8080
echo   API Docs available at:    http://localhost:8080/docs
echo   Health check:             http://localhost:8080/api/health
echo ════════════════════════════════════════════════════════════════
echo.
echo   Press Ctrl+C to stop the server
echo.

:: ── Open browser after 3 seconds ─────────────────────────────────────────────
start /b cmd /c "timeout /t 3 /nobreak >nul && start http://localhost:8080"

:: ── Start the FastAPI server ──────────────────────────────────────────────────
cd backend
python -m uvicorn main:app --host 0.0.0.0 --port 8080 --reload

:: ── Cleanup on exit ──────────────────────────────────────────────────────────
echo.
echo  Server stopped.
pause
