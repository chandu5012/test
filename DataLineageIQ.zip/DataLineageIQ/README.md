# 🔗 DataLineage IQ
### Intelligent Data Lineage & Impact Intelligence Platform

> **"Where does your data come from? Where does it go? DataLineage IQ tells you — instantly."**

---

## 🏆 Competition Highlights

| Feature | Description |
|---------|-------------|
| 🔍 **Unified Search** | Search by System ID, Table Name, or Table.Field |
| 🏛️ **ERWIN DI Integration** | Live API + intelligent mock fallback |
| 📖 **Data Dictionary** | Business glossary, field definitions, ownership |
| 💻 **Code Intelligence** | SQL · HQL · PySpark · Spark · Java · Python · ETL |
| 🕸️ **Interactive Lineage Graph** | D3.js force-directed with drag, zoom, fullscreen |
| 📋 **Rich Metadata** | Full field-level information with risk levels |
| 📄 **PDF Impact Reports** | One-click professional PDF per field |
| 🎨 **Competition-Grade UI** | Dark theme, animations, production design |

---

## ⚡ Quick Start (Windows)

**Just double-click:**
```
START_APP.bat
```

The batch file will:
1. Check Python 3.10+ is installed
2. Create a virtual environment
3. Install all dependencies automatically
4. Start the FastAPI server on http://localhost:8000
5. Open your browser automatically

---

## 📋 Prerequisites

- **Python 3.10+** — https://www.python.org/downloads/
  - ✅ Check "Add Python to PATH" during installation
- **Internet connection** (for font loading on first run)

---

## 🏗️ Project Structure

```
DataLineageIQ/
├── START_APP.bat              ← Run this on Windows
├── README.md
├── backend/
│   ├── main.py                ← FastAPI application
│   └── requirements.txt       ← Python dependencies
├── frontend/
│   └── index.html             ← Single-page UI
└── code_repo_samples/         ← Sample code files for demo
    ├── customer_etl.sql
    └── transform_sales.py
```

---

## ⚙️ Configuration

Edit `START_APP.bat` to configure your connections:

```bat
:: ERWIN DI
set ERWIN_BASE_URL=http://your-erwin-server/erwin-di/api
set ERWIN_API_KEY=your_api_key_here

:: Data Dictionary
set DATA_DICT_URL=http://your-dict-server/data-dictionary/api

:: GitHub (for code search)
set GITHUB_TOKEN=ghp_your_token_here
set GITHUB_REPO=your-org/your-repo

:: Local code folder
set LOCAL_CODE_DIR=C:\path\to\your\code
```

> **Note:** If live APIs are unavailable, the system automatically falls back to realistic mock data — perfect for demonstrations!

---

## 🔍 How to Use

1. **Enter a search term** — any of:
   - System ID: `SYS_001` or `CUSTOMER`
   - Table name: `ORDER_FACT`, `SALES`
   - Table.Field: `SALES.REVENUE_AMT`, `EMPLOYEE.EMP_ID`

2. **Select your sources** (toggle on/off):
   - 🏛️ ERWIN DI
   - 📖 Data Dictionary
   - 💻 Code Repository

3. **Click "Discover Lineage"** — results appear in seconds

4. **Explore the results**:
   - 🕸️ **Lineage Graph** — interactive force-directed graph
   - 📋 **Metadata** — all field definitions with risk levels
   - 📡 **Source Details** — raw results from each source

5. **Click any field or node** to see full impact details

6. **Download PDF** — professional impact report per field

---

## 🛠️ API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| `POST` | `/api/search` | Main lineage search |
| `POST` | `/api/generate-report` | Generate PDF report |
| `GET`  | `/api/health` | Health check |
| `GET`  | `/docs` | Swagger API documentation |

---

## 🏛️ ERWIN DI API Integration

The system calls:
```
GET /erwin-di/api/v2/lineage/search?query={term}&includeLineage=true
Authorization: Bearer {ERWIN_API_KEY}
```

If ERWIN is unreachable, a realistic mock response is returned automatically.

---

## 📄 PDF Report Contents

Each generated PDF includes:
- Field overview & metadata
- Business logic (from code repo)
- Complete data lineage (sources → targets)
- Impact analysis narrative
- Risk assessment matrix
- Timestamp & governance information

---

## 🚀 Manual Start (Alternative)

```bash
cd backend
pip install -r requirements.txt
uvicorn main:app --host 0.0.0.0 --port 8000 --reload
```

Then open: http://localhost:8000

---

*DataLineage IQ — Built for the Data Governance Competition 2025*
