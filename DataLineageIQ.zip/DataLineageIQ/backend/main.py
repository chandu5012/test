from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, StreamingResponse
from pydantic import BaseModel
from typing import Optional, List, Dict, Any
import json
import os
import re
import glob
import httpx
import asyncio
from datetime import datetime
import io

app = FastAPI(title="DataLineage IQ API", version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ─── Config ────────────────────────────────────────────────────────────────────
ERWIN_BASE_URL = os.getenv("ERWIN_BASE_URL", "http://localhost:8080/erwin-di/api")
ERWIN_API_KEY  = os.getenv("ERWIN_API_KEY",  "YOUR_ERWIN_API_KEY")
DATA_DICT_URL  = os.getenv("DATA_DICT_URL",  "http://localhost:9090/data-dictionary/api")
GITHUB_TOKEN   = os.getenv("GITHUB_TOKEN",   "")
GITHUB_REPO    = os.getenv("GITHUB_REPO",    "owner/repo")
LOCAL_CODE_DIR = os.getenv("LOCAL_CODE_DIR", "./code_repo_samples")

# ─── Models ────────────────────────────────────────────────────────────────────
class SearchRequest(BaseModel):
    query: str                        # system_id, table name, or table.field
    use_erwin: bool = True
    use_data_dict: bool = True
    use_code_repo: bool = True
    github_token: Optional[str] = None
    github_repo: Optional[str] = None
    local_code_dir: Optional[str] = None

class LineageNode(BaseModel):
    id: str
    label: str
    type: str           # source | transform | target | field
    system: Optional[str] = None
    database: Optional[str] = None
    schema_name: Optional[str] = None
    table: Optional[str] = None
    field: Optional[str] = None
    description: Optional[str] = None
    data_type: Optional[str] = None
    risk_level: Optional[str] = "Low"
    source: Optional[str] = None      # erwin | data_dict | code_repo

class LineageEdge(BaseModel):
    id: str
    source: str
    target: str
    label: Optional[str] = None
    transformation: Optional[str] = None

class FieldMetadata(BaseModel):
    field_name: str
    table_name: str
    data_type: Optional[str]
    description: Optional[str]
    business_logic: Optional[str]
    sources: List[str]
    targets: List[str]
    risk_level: str
    impact: Optional[str]
    owner: Optional[str]
    last_updated: Optional[str]
    tags: List[str] = []

class SearchResponse(BaseModel):
    query: str
    nodes: List[Dict]
    edges: List[Dict]
    metadata: List[Dict]
    sources_used: List[str]
    search_time_ms: int
    summary: str

# ─── ERWIN DI Mock / Real ──────────────────────────────────────────────────────
async def fetch_erwin_metadata(query: str) -> Dict[str, Any]:
    """Call ERWIN DI API or return mock data if unavailable."""
    try:
        async with httpx.AsyncClient(timeout=5.0) as client:
            headers = {"Authorization": f"Bearer {ERWIN_API_KEY}", "Content-Type": "application/json"}
            # Try real ERWIN endpoint
            resp = await client.get(
                f"{ERWIN_BASE_URL}/v2/lineage/search",
                params={"query": query, "includeLineage": True},
                headers=headers
            )
            if resp.status_code == 200:
                return {"status": "live", "data": resp.json()}
    except Exception:
        pass

    # ── Mock ERWIN response ───────────────────────────────────────────────────
    q = query.upper()
    table = q.split(".")[0] if "." in q else q
    field = q.split(".")[1] if "." in q else None

    mock = {
        "status": "mock",
        "system_id": f"SYS_{table[:4]}",
        "application": f"{table} Processing System",
        "objects": [
            {
                "id": f"src_{table}_RAW",
                "name": f"STG_{table}_RAW",
                "type": "source_table",
                "database": "STAGING_DB",
                "schema": "STG",
                "system": "Source System A",
                "fields": [
                    {"name": "ID", "type": "VARCHAR(50)", "description": "Primary identifier", "nullable": False},
                    {"name": "CREATED_DATE", "type": "TIMESTAMP", "description": "Record creation date", "nullable": True},
                    {"name": "STATUS", "type": "VARCHAR(20)", "description": "Processing status", "nullable": True},
                ] + ([{"name": field, "type": "VARCHAR(255)", "description": f"Business field: {field}", "nullable": True}] if field else [])
            },
            {
                "id": f"tgt_{table}_DW",
                "name": f"DW_{table}_FACT",
                "type": "target_table",
                "database": "DW_DB",
                "schema": "FACTS",
                "system": "Data Warehouse",
                "fields": [
                    {"name": "ID", "type": "BIGINT", "description": "Surrogate key", "nullable": False},
                    {"name": "CREATED_DATE", "type": "DATE", "description": "Partition date", "nullable": True},
                    {"name": "STATUS_CODE", "type": "VARCHAR(5)", "description": "Normalized status", "nullable": True},
                ] + ([{"name": field, "type": "DECIMAL(18,4)", "description": f"Transformed: {field}", "nullable": True}] if field else [])
            },
            {
                "id": f"trf_{table}_ETL",
                "name": f"ETL_{table}_TRANSFORM",
                "type": "transformation",
                "database": None,
                "schema": None,
                "system": "ETL Engine",
                "logic": f"LOAD {table} from STG to DW with STATUS normalization",
            }
        ],
        "lineage_edges": [
            {"from": f"src_{table}_RAW",  "to": f"trf_{table}_ETL", "type": "reads"},
            {"from": f"trf_{table}_ETL",  "to": f"tgt_{table}_DW",  "type": "writes"},
        ]
    }
    return mock

# ─── Data Dictionary Mock / Real ──────────────────────────────────────────────
async def fetch_data_dictionary(query: str) -> Dict[str, Any]:
    try:
        async with httpx.AsyncClient(timeout=5.0) as client:
            resp = await client.get(f"{DATA_DICT_URL}/search", params={"term": query})
            if resp.status_code == 200:
                return {"status": "live", "data": resp.json()}
    except Exception:
        pass

    # ── Mock Data Dictionary ──────────────────────────────────────────────────
    q = query.upper()
    table = q.split(".")[0] if "." in q else q
    field = q.split(".")[1] if "." in q else None

    entries = []
    fields_info = [
        ("ID",           "VARCHAR(50)",   "Unique business key",                       "High",   "Core identifier — impacts all downstream reports"),
        ("CREATED_DATE", "TIMESTAMP",     "Date the record was first created",         "Medium", "Used in SLA calculations and audit trails"),
        ("STATUS",       "VARCHAR(20)",   "Lifecycle status: ACTIVE, INACTIVE, PEND",  "High",   "Drives workflow routing and reporting filters"),
    ]
    if field:
        fields_info.append((field, "VARCHAR(255)", f"Domain-specific attribute: {field}", "Medium", f"Business metric — review with data steward before changing"))

    for fname, ftype, fdesc, frisk, fimpact in fields_info:
        entries.append({
            "table": f"STG_{table}_RAW",
            "field": fname,
            "data_type": ftype,
            "description": fdesc,
            "risk_level": frisk,
            "impact": fimpact,
            "owner": "Data Governance Team",
            "tags": ["certified", "pii" if "id" in fname.lower() else "operational"],
            "last_updated": "2025-03-15",
            "business_rules": [f"Must not be NULL", f"Validated against lookup table LKP_{fname}"],
        })

    return {"status": "mock", "entries": entries}

# ─── Code Repo Scanner ────────────────────────────────────────────────────────
CODE_EXTENSIONS = [".sql", ".hql", ".py", ".java", ".scala", ".ksh", ".sh", ".xml", ".json"]

def extract_business_logic(content: str, search_term: str) -> Optional[str]:
    """Return the most relevant single line containing the search term."""
    lines = content.splitlines()
    term = search_term.upper()
    scored = []
    for i, line in enumerate(lines):
        if term in line.upper():
            clean = line.strip()
            if clean and not clean.startswith(("#", "--", "//", "/*", "*")):
                score = len(clean)
                if any(kw in clean.upper() for kw in ["SELECT", "INSERT", "UPDATE", "JOIN", "FROM", "WHERE", "TRANSFORM", "MAP", "REDUCE"]):
                    score += 100
                scored.append((score, clean, i + 1))
    if scored:
        scored.sort(reverse=True)
        return scored[0][1][:200]
    return None

async def search_github(query: str, token: str, repo: str) -> List[Dict]:
    results = []
    try:
        headers = {"Authorization": f"token {token}", "Accept": "application/vnd.github.v3+json"}
        table = query.split(".")[0] if "." in query else query
        async with httpx.AsyncClient(timeout=10.0) as client:
            for ext in [".sql", ".py", ".hql", ".java", ".scala"]:
                search_url = f"https://api.github.com/search/code?q={table}+in:file+repo:{repo}+extension:{ext[1:]}"
                resp = await client.get(search_url, headers=headers)
                if resp.status_code == 200:
                    items = resp.json().get("items", [])[:3]
                    for item in items:
                        file_resp = await client.get(item["url"], headers=headers)
                        if file_resp.status_code == 200:
                            import base64
                            content_b64 = file_resp.json().get("content", "")
                            content = base64.b64decode(content_b64).decode("utf-8", errors="ignore")
                            logic = extract_business_logic(content, table)
                            if logic:
                                results.append({
                                    "file": item["name"],
                                    "path": item["path"],
                                    "url": item["html_url"],
                                    "language": ext[1:].upper(),
                                    "business_logic": logic,
                                    "source": "github"
                                })
    except Exception as e:
        pass
    return results

def search_local_code(query: str, code_dir: str) -> List[Dict]:
    results = []
    table = query.split(".")[0].upper() if "." in query else query.upper()
    try:
        for ext in CODE_EXTENSIONS:
            for filepath in glob.glob(os.path.join(code_dir, "**", f"*{ext}"), recursive=True):
                try:
                    with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
                        content = f.read()
                    if table in content.upper():
                        logic = extract_business_logic(content, table)
                        if logic:
                            lang_map = {".sql":"SQL",".hql":"HQL",".py":"Python",".java":"Java",
                                        ".scala":"Scala",".ksh":"Shell",".sh":"Shell"}
                            results.append({
                                "file": os.path.basename(filepath),
                                "path": filepath,
                                "url": None,
                                "language": lang_map.get(ext, ext[1:].upper()),
                                "business_logic": logic,
                                "source": "local"
                            })
                except Exception:
                    continue
    except Exception:
        pass
    return results

# ─── Mock code results (always returned for demo) ────────────────────────────
def get_mock_code_results(query: str) -> List[Dict]:
    table = query.split(".")[0].upper() if "." in query else query.upper()
    return [
        {
            "file": f"load_{table.lower()}_stg.sql",
            "path": f"etl/staging/load_{table.lower()}_stg.sql",
            "url": None,
            "language": "SQL",
            "business_logic": f"INSERT INTO STG_{table}_RAW SELECT id, created_date, status FROM SRC_{table} WHERE status != 'DELETED'",
            "source": "local_mock"
        },
        {
            "file": f"transform_{table.lower()}.py",
            "path": f"pipelines/transform_{table.lower()}.py",
            "url": None,
            "language": "PySpark",
            "business_logic": f"df_{table.lower()} = spark.sql(\"SELECT id, to_date(created_date) AS created_date, UPPER(status) AS status_code FROM STG_{table}_RAW\")",
            "source": "local_mock"
        },
        {
            "file": f"DW_{table}Processor.java",
            "path": f"src/main/java/com/etl/DW_{table}Processor.java",
            "url": None,
            "language": "Java",
            "business_logic": f"jdbcTemplate.execute(\"MERGE INTO DW_{table}_FACT USING STG_{table}_RAW ON (target.id = source.id) WHEN MATCHED THEN UPDATE SET status_code = UPPER(source.status)\");",
            "source": "local_mock"
        },
    ]

# ─── Build Lineage Graph ───────────────────────────────────────────────────────
def build_lineage_graph(query: str, erwin_data: Dict, dict_data: Dict, code_results: List[Dict]) -> tuple:
    nodes = []
    edges = []
    q = query.upper()
    table = q.split(".")[0] if "." in q else q
    field = q.split(".")[1] if "." in q else None

    # Nodes from ERWIN
    if erwin_data:
        for obj in erwin_data.get("objects", []):
            risk = "Low"
            if dict_data:
                for entry in dict_data.get("entries", []):
                    if entry["table"] == obj["name"]:
                        risk = entry.get("risk_level", "Low")
                        break
            node = {
                "id": obj["id"],
                "label": obj["name"],
                "type": obj["type"],
                "system": obj.get("system"),
                "database": obj.get("database"),
                "schema_name": obj.get("schema"),
                "description": obj.get("logic", f"{obj['type'].replace('_',' ').title()}: {obj['name']}"),
                "risk_level": risk,
                "source": "erwin",
                "fields": obj.get("fields", [])
            }
            nodes.append(node)
        for edge in erwin_data.get("lineage_edges", []):
            edges.append({
                "id": f"e_{edge['from']}_{edge['to']}",
                "source": edge["from"],
                "target": edge["to"],
                "label": edge.get("type", "flow"),
                "transformation": None
            })

    # Extra code-repo node
    if code_results:
        code_node_id = f"code_{table}_REPO"
        nodes.append({
            "id": code_node_id,
            "label": f"Code Repository\n({len(code_results)} scripts)",
            "type": "code_repo",
            "system": "Code Repository",
            "description": f"Found {len(code_results)} scripts referencing {table}",
            "risk_level": "Low",
            "source": "code_repo",
            "code_results": code_results
        })
        # Link to transformation if it exists
        trf_id = f"trf_{table}_ETL"
        if any(n["id"] == trf_id for n in nodes):
            edges.append({
                "id": f"e_{code_node_id}_{trf_id}",
                "source": code_node_id,
                "target": trf_id,
                "label": "implements",
                "transformation": code_results[0]["business_logic"] if code_results else None
            })

    # Field node if specific field queried
    if field:
        field_node_id = f"field_{table}_{field}"
        field_meta = None
        if dict_data:
            for entry in dict_data.get("entries", []):
                if entry["field"] == field:
                    field_meta = entry
                    break
        nodes.append({
            "id": field_node_id,
            "label": f"{table}.{field}",
            "type": "field",
            "system": "Data Warehouse",
            "field": field,
            "table": table,
            "description": field_meta["description"] if field_meta else f"Field: {field}",
            "risk_level": field_meta["risk_level"] if field_meta else "Medium",
            "data_type": field_meta["data_type"] if field_meta else "VARCHAR",
            "source": "data_dict",
        })
        tgt_id = f"tgt_{table}_DW"
        if any(n["id"] == tgt_id for n in nodes):
            edges.append({
                "id": f"e_{tgt_id}_{field_node_id}",
                "source": tgt_id,
                "target": field_node_id,
                "label": "contains",
                "transformation": None
            })

    return nodes, edges

# ─── Build Metadata ────────────────────────────────────────────────────────────
def build_metadata(query: str, erwin_data: Dict, dict_data: Dict, code_results: List[Dict]) -> List[Dict]:
    metadata = []
    q = query.upper()
    table = q.split(".")[0] if "." in q else q

    dict_entries = {}
    if dict_data:
        for e in dict_data.get("entries", []):
            dict_entries[e["field"]] = e

    # Collect all fields
    all_fields = set()
    if erwin_data:
        for obj in erwin_data.get("objects", []):
            for fld in obj.get("fields", []):
                all_fields.add(fld["name"])

    for fname in all_fields:
        entry = dict_entries.get(fname, {})
        code_logic = None
        for cr in code_results:
            if fname.upper() in cr.get("business_logic", "").upper():
                code_logic = cr["business_logic"]
                break

        metadata.append({
            "field_name": fname,
            "table_name": f"STG_{table}_RAW → DW_{table}_FACT",
            "data_type": entry.get("data_type", "VARCHAR"),
            "description": entry.get("description", f"Field {fname}"),
            "business_logic": code_logic or entry.get("business_rules", ["No logic found"])[0],
            "sources": [f"STG_{table}_RAW"],
            "targets": [f"DW_{table}_FACT"],
            "risk_level": entry.get("risk_level", "Low"),
            "impact": entry.get("impact", "Review before modifying"),
            "owner": entry.get("owner", "Data Team"),
            "last_updated": entry.get("last_updated", "2025-01-01"),
            "tags": entry.get("tags", []),
        })

    return metadata

# ─── Main Search Endpoint ──────────────────────────────────────────────────────
@app.post("/api/search", response_model=SearchResponse)
async def search_lineage(req: SearchRequest):
    start = datetime.now()
    sources_used = []

    erwin_data = None
    dict_data  = None
    code_results = []

    tasks = []
    if req.use_erwin:
        tasks.append(("erwin", fetch_erwin_metadata(req.query)))
    if req.use_data_dict:
        tasks.append(("dict",  fetch_data_dictionary(req.query)))

    results = await asyncio.gather(*[t[1] for t in tasks], return_exceptions=True)
    for (name, _), result in zip(tasks, results):
        if isinstance(result, Exception):
            continue
        if name == "erwin":
            erwin_data = result
            sources_used.append("ERWIN DI")
        elif name == "dict":
            dict_data = result
            sources_used.append("Data Dictionary")

    if req.use_code_repo:
        token = req.github_token or GITHUB_TOKEN
        repo  = req.github_repo  or GITHUB_REPO
        cdir  = req.local_code_dir or LOCAL_CODE_DIR

        if token and repo and token != "":
            code_results = await search_github(req.query, token, repo)
        if not code_results:
            code_results = search_local_code(req.query, cdir)
        if not code_results:
            code_results = get_mock_code_results(req.query)

        if code_results:
            sources_used.append("Code Repository")

    nodes, edges = build_lineage_graph(req.query, erwin_data, dict_data, code_results)
    metadata     = build_metadata(req.query, erwin_data, dict_data, code_results)

    elapsed = int((datetime.now() - start).total_seconds() * 1000)

    return SearchResponse(
        query=req.query,
        nodes=nodes,
        edges=edges,
        metadata=metadata,
        sources_used=sources_used,
        search_time_ms=elapsed,
        summary=f"Found {len(nodes)} lineage objects, {len(edges)} relationships, and {len(metadata)} field definitions across {len(sources_used)} source(s)."
    )

# ─── PDF Report Endpoint ───────────────────────────────────────────────────────
@app.post("/api/generate-report")
async def generate_report(payload: Dict[str, Any]):
    """Generate a PDF impact report for a field."""
    try:
        from reportlab.lib.pagesizes import letter, A4
        from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, HRFlowable
        from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
        from reportlab.lib import colors
        from reportlab.lib.units import inch
        from reportlab.lib.enums import TA_CENTER, TA_LEFT

        field    = payload.get("field_name", "UNKNOWN")
        table    = payload.get("table_name", "UNKNOWN")
        dtype    = payload.get("data_type", "VARCHAR")
        desc     = payload.get("description", "N/A")
        logic    = payload.get("business_logic", "N/A")
        sources  = payload.get("sources", [])
        targets  = payload.get("targets", [])
        risk     = payload.get("risk_level", "Low")
        impact   = payload.get("impact", "N/A")
        owner    = payload.get("owner", "Data Team")
        updated  = payload.get("last_updated", "N/A")
        tags     = payload.get("tags", [])

        risk_colors = {"High": colors.HexColor("#EF4444"), "Medium": colors.HexColor("#F59E0B"), "Low": colors.HexColor("#10B981")}
        risk_color  = risk_colors.get(risk, colors.grey)

        buf = io.BytesIO()
        doc = SimpleDocTemplate(buf, pagesize=A4, rightMargin=50, leftMargin=50, topMargin=60, bottomMargin=50)

        styles = getSampleStyleSheet()
        title_style  = ParagraphStyle("Title",  fontSize=22, fontName="Helvetica-Bold",  textColor=colors.HexColor("#0F172A"), alignment=TA_CENTER, spaceAfter=6)
        sub_style    = ParagraphStyle("Sub",    fontSize=11, fontName="Helvetica",        textColor=colors.HexColor("#64748B"), alignment=TA_CENTER, spaceAfter=20)
        h2_style     = ParagraphStyle("H2",     fontSize=13, fontName="Helvetica-Bold",   textColor=colors.HexColor("#1E293B"), spaceBefore=16, spaceAfter=6)
        body_style   = ParagraphStyle("Body",   fontSize=10, fontName="Helvetica",        textColor=colors.HexColor("#334155"), leading=14)
        code_style   = ParagraphStyle("Code",   fontSize=9,  fontName="Courier",          textColor=colors.HexColor("#1E293B"), backColor=colors.HexColor("#F1F5F9"), leading=13, leftIndent=10, rightIndent=10)

        story = []

        # Header
        story.append(Paragraph("DataLineage IQ", title_style))
        story.append(Paragraph("Field Impact &amp; Lineage Report", sub_style))
        story.append(HRFlowable(width="100%", thickness=2, color=colors.HexColor("#6366F1")))
        story.append(Spacer(1, 14))

        # Risk badge row
        badge_data = [[
            Paragraph(f"<b>Field:</b> {field}", body_style),
            Paragraph(f"<b>Table:</b> {table}", body_style),
            Paragraph(f"<b>Risk:</b> <font color='#{risk_color.hexval()[2:]}'>● {risk}</font>", body_style),
        ]]
        badge_tbl = Table(badge_data, colWidths=[160, 220, 110])
        badge_tbl.setStyle(TableStyle([
            ("BACKGROUND", (0,0), (-1,-1), colors.HexColor("#F8FAFC")),
            ("BOX",        (0,0), (-1,-1), 1, colors.HexColor("#E2E8F0")),
            ("INNERGRID",  (0,0), (-1,-1), 0.5, colors.HexColor("#E2E8F0")),
            ("TOPPADDING", (0,0), (-1,-1), 8),
            ("BOTTOMPADDING", (0,0), (-1,-1), 8),
            ("LEFTPADDING",   (0,0), (-1,-1), 10),
        ]))
        story.append(badge_tbl)
        story.append(Spacer(1, 16))

        # Overview section
        overview = [
            ["Data Type",      dtype],
            ["Description",    desc],
            ["Business Owner", owner],
            ["Last Updated",   updated],
            ["Tags",           ", ".join(tags) if tags else "—"],
        ]
        story.append(Paragraph("Overview", h2_style))
        ov_tbl = Table(overview, colWidths=[140, 360])
        ov_tbl.setStyle(TableStyle([
            ("BACKGROUND", (0,0), (0,-1), colors.HexColor("#EEF2FF")),
            ("FONTNAME",   (0,0), (0,-1), "Helvetica-Bold"),
            ("FONTSIZE",   (0,0), (-1,-1), 10),
            ("TOPPADDING", (0,0), (-1,-1), 6),
            ("BOTTOMPADDING", (0,0), (-1,-1), 6),
            ("LEFTPADDING",   (0,0), (-1,-1), 10),
            ("BOX",        (0,0), (-1,-1), 1, colors.HexColor("#C7D2FE")),
            ("INNERGRID",  (0,0), (-1,-1), 0.5, colors.HexColor("#E0E7FF")),
        ]))
        story.append(ov_tbl)

        # Business Logic
        story.append(Paragraph("Business Logic", h2_style))
        story.append(Paragraph(logic, code_style))
        story.append(Spacer(1, 10))

        # Lineage
        story.append(Paragraph("Data Lineage", h2_style))
        lin_data = [["Direction", "Objects"]]
        lin_data.append(["Sources ↑", "\n".join(sources) if sources else "—"])
        lin_data.append(["Targets ↓", "\n".join(targets) if targets else "—"])
        lin_tbl = Table(lin_data, colWidths=[140, 360])
        lin_tbl.setStyle(TableStyle([
            ("BACKGROUND",    (0,0), (-1,0),  colors.HexColor("#6366F1")),
            ("TEXTCOLOR",     (0,0), (-1,0),  colors.white),
            ("FONTNAME",      (0,0), (-1,0),  "Helvetica-Bold"),
            ("BACKGROUND",    (0,1), (0,1),   colors.HexColor("#DCFCE7")),
            ("BACKGROUND",    (0,2), (0,2),   colors.HexColor("#FEE2E2")),
            ("FONTSIZE",      (0,0), (-1,-1), 10),
            ("TOPPADDING",    (0,0), (-1,-1), 7),
            ("BOTTOMPADDING", (0,0), (-1,-1), 7),
            ("LEFTPADDING",   (0,0), (-1,-1), 10),
            ("BOX",           (0,0), (-1,-1), 1, colors.HexColor("#A5B4FC")),
            ("INNERGRID",     (0,0), (-1,-1), 0.5, colors.HexColor("#C7D2FE")),
        ]))
        story.append(lin_tbl)

        # Impact Analysis
        story.append(Paragraph("Impact Analysis", h2_style))
        story.append(Paragraph(impact, body_style))
        story.append(Spacer(1, 10))

        # Risk Matrix
        story.append(Paragraph("Risk Assessment", h2_style))
        risk_rows = [
            ["Risk Level", "Implication", "Recommended Action"],
            ["High   🔴", "Breaking change possible; downstream systems affected",  "Mandatory review by Data Steward before modification"],
            ["Medium 🟡", "Moderate impact; verify downstream dependencies",        "Peer review + UAT in staging before deploy"],
            ["Low    🟢", "Minimal downstream risk",                                "Standard change process applies"],
        ]
        risk_tbl = Table(risk_rows, colWidths=[90, 220, 190])
        risk_tbl.setStyle(TableStyle([
            ("BACKGROUND",    (0,0), (-1,0), colors.HexColor("#1E293B")),
            ("TEXTCOLOR",     (0,0), (-1,0), colors.white),
            ("FONTNAME",      (0,0), (-1,0), "Helvetica-Bold"),
            ("FONTSIZE",      (0,0), (-1,-1), 9),
            ("TOPPADDING",    (0,0), (-1,-1), 6),
            ("BOTTOMPADDING", (0,0), (-1,-1), 6),
            ("LEFTPADDING",   (0,0), (-1,-1), 8),
            ("ROWBACKGROUNDS", (0,1), (-1,-1), [colors.HexColor("#FEF2F2"), colors.HexColor("#FFFBEB"), colors.HexColor("#F0FDF4")]),
            ("BOX",           (0,0), (-1,-1), 1, colors.HexColor("#94A3B8")),
            ("INNERGRID",     (0,0), (-1,-1), 0.5, colors.HexColor("#CBD5E1")),
        ]))
        story.append(risk_tbl)

        story.append(Spacer(1, 20))
        story.append(HRFlowable(width="100%", thickness=1, color=colors.HexColor("#E2E8F0")))
        story.append(Spacer(1, 8))
        story.append(Paragraph(f"Generated by DataLineage IQ  •  {datetime.now().strftime('%B %d, %Y %H:%M')}  •  Confidential", 
                                ParagraphStyle("footer", fontSize=8, fontName="Helvetica", textColor=colors.HexColor("#94A3B8"), alignment=TA_CENTER)))

        doc.build(story)
        buf.seek(0)

        return StreamingResponse(
            buf,
            media_type="application/pdf",
            headers={"Content-Disposition": f"attachment; filename=lineage_{field}_{datetime.now().strftime('%Y%m%d')}.pdf"}
        )

    except ImportError:
        raise HTTPException(status_code=500, detail="reportlab not installed. Run: pip install reportlab")
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# ─── Health check ──────────────────────────────────────────────────────────────
@app.get("/api/health")
async def health():
    return {"status": "ok", "version": "1.0.0", "timestamp": datetime.now().isoformat()}

# ─── Serve frontend HTML explicitly ───────────────────────────────────────────
@app.get("/", response_class=FileResponse)
async def serve_ui():
    p = os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "frontend", "index.html"))
    if os.path.exists(p):
        return FileResponse(p, media_type="text/html")
    return {"error": "frontend/index.html not found"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8080, reload=True)
